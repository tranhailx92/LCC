# Figure Rebuild Brief

## Figure ID
F_DOCX_002

## Manuscript number
Hình 2.2

## Title
Chỉ số kết nối vận tải biển (LSCI) của Việt Nam và một số quốc gia ASEAN (2024–2025)

## Source note
Nguồn: UNCTAD Review of Maritime Transport 2025.

## Original asset path
05_figures/assets/F_DOCX_002.png

## Rebuild method decision
WAITING_FOR_AUTHOR_DATA

## Rebuild status
WAITING_FOR_AUTHOR_DATA

## Human review required
Yes

## Notes
Requires author data or high-resolution graphic to rebuild without inventing data.
