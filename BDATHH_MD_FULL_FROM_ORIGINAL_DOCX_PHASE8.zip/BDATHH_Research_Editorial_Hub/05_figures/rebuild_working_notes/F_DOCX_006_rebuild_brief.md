# Figure Rebuild Brief

## Figure ID
F_DOCX_006

## Manuscript number
Hình 2.6

## Title
Biểu đồ diễn biến tai nạn hàng hải giai đoạn 2015–2025.

## Source note
Nguồn: Báo cáo tổng kết thi hành Bộ luật Hàng hải 2015 (Bộ Xây dựng, 2026a).

## Original asset path
05_figures/assets/F_DOCX_006.png

## Rebuild method decision
WAITING_FOR_AUTHOR_DATA

## Rebuild status
WAITING_FOR_AUTHOR_DATA

## Human review required
Yes

## Notes
Requires author data or high-resolution graphic to rebuild without inventing data.
