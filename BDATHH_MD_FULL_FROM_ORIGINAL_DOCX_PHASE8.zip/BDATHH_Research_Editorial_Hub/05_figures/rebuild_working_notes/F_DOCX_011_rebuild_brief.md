# Figure Rebuild Brief

## Figure ID
F_DOCX_011

## Manuscript number
Hình 2.11

## Title
Cơ cấu mẫu khảo sát phân bổ theo giới tính, độ tuổi, vai trò công tác và thâm niên làm việc (N=250 mẫu)

## Source note
Nguồn: Kết quả khảo sát của nghiên cứu sinh, 2025.

## Original asset path
05_figures/assets/F_DOCX_011.png

## Rebuild method decision
WAITING_FOR_AUTHOR_DATA

## Rebuild status
WAITING_FOR_AUTHOR_DATA

## Human review required
Yes

## Notes
Requires author data or high-resolution graphic to rebuild without inventing data.
