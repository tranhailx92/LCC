# Figure Rebuild Brief

## Figure ID
F_DOCX_004

## Manuscript number
Hình 2.4

## Title
Biểu đồ tăng trưởng hệ thống bảo đảm an toàn hàng hải Việt Nam, giai đoạn 2015–2025

## Source note
Nguồn: Thống kê Bộ Xây dựng, Cục Hàng hải và Đường thủy Việt Nam, 2025c (số liệu chi tiết do nghiên cứu sinh tổng hợp) (Bộ Xây dựng, 2026a).

## Original asset path
05_figures/assets/F_DOCX_004.png

## Rebuild method decision
WAITING_FOR_AUTHOR_DATA

## Rebuild status
WAITING_FOR_AUTHOR_DATA

## Human review required
Yes

## Notes
Requires author data or high-resolution graphic to rebuild without inventing data.
