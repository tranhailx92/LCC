# Figure Rebuild Brief

## Figure ID
F_DOCX_003

## Manuscript number
Hình 2.3

## Title
Sơ đồ tổ chức bộ máy quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam sau hợp nhất.

## Source note
Nguồn: Nghiên cứu sinh tổng hợp từ các văn bản pháp luật (Bộ Xây dựng, 2025a, 2025f, 2025g, 2025h, 2025i; Chính phủ nước CHXHCN Việt Nam, 2025b, 2025c, 2025d), 2026.

## Original asset path
05_figures/assets/F_DOCX_003.png

## Rebuild method decision
WAITING_FOR_AUTHOR_DATA

## Rebuild status
WAITING_FOR_AUTHOR_DATA

## Human review required
Yes

## Notes
Requires author data or high-resolution graphic to rebuild without inventing data.
