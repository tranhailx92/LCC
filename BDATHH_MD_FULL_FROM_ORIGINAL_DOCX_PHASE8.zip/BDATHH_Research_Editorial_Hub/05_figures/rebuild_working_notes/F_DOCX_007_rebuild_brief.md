# Figure Rebuild Brief

## Figure ID
F_DOCX_007

## Manuscript number
Hình 2.7

## Title
Xu hướng kinh phí nạo vét duy tu luồng hàng hải giai đoạn 2015–2025

## Source note
Nguồn: Tổng hợp và xử lý từ các quyết định giao dự toán, điều chỉnh kế hoạch của Bộ Giao thông vận tải (2014–2024) và Bộ Xây dựng (2025g). (số liệu cụ thể do nghiên cứu sinh tổng hợp)

## Original asset path
05_figures/assets/F_DOCX_007.png

## Rebuild method decision
WAITING_FOR_AUTHOR_DATA

## Rebuild status
WAITING_FOR_AUTHOR_DATA

## Human review required
Yes

## Notes
Requires author data or high-resolution graphic to rebuild without inventing data.
