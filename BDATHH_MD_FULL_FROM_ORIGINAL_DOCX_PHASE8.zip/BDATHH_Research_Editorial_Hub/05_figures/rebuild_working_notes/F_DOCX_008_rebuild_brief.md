# Figure Rebuild Brief

## Figure ID
F_DOCX_008

## Manuscript number
Hình 2.8

## Title
Biểu đồ tỷ trọng và cơ cấu nguồn nhân lực dịch vụ hàng hải giai đoạn 2015–2024

## Source note
Nguồn: Tác giả tổng hợp từ số liệu thống kê giai đoạn 2015–2024.

## Original asset path
05_figures/assets/F_DOCX_008.png

## Rebuild method decision
WAITING_FOR_AUTHOR_DATA

## Rebuild status
WAITING_FOR_AUTHOR_DATA

## Human review required
Yes

## Notes
Requires author data or high-resolution graphic to rebuild without inventing data.
