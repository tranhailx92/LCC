# Figure Rebuild Brief

## Figure ID
F_DOCX_001

## Manuscript number
Hình 2.1

## Title
Sản lượng hàng hóa thông qua hệ thống cảng biển Việt Nam giai đoạn 2015–2025.

## Source note
Nguồn: Cục Hàng hải và Đường thủy Việt Nam (tổng kết 2025); Market Times (2026); VnEconomy (2024–2025).

## Original asset path
05_figures/assets/F_DOCX_001.png

## Rebuild method decision
WAITING_FOR_AUTHOR_DATA

## Rebuild status
WAITING_FOR_AUTHOR_DATA

## Human review required
Yes

## Notes
Requires author data or high-resolution graphic to rebuild without inventing data.
