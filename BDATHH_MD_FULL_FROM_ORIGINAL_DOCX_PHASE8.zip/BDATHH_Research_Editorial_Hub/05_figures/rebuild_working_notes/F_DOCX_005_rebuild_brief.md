# Figure Rebuild Brief

## Figure ID
F_DOCX_005

## Manuscript number
Hình 2.5

## Title
Kinh phí bảo trì kết cấu hạ tầng hàng hải giai đoạn 2015–2026

## Source note
Nguồn: Tổng hợp từ Báo cáo tổng kết việc thi hành Bộ luật Hàng hải Việt Nam năm 2015 (Bộ Xây dựng, 2026a).

## Original asset path
05_figures/assets/F_DOCX_005.png

## Rebuild method decision
WAITING_FOR_AUTHOR_DATA

## Rebuild status
WAITING_FOR_AUTHOR_DATA

## Human review required
Yes

## Notes
Requires author data or high-resolution graphic to rebuild without inventing data.
