# Asset Manifest

| Figure ID | Manuscript number | Extracted asset path | Original DOCX target |
| :--- | :--- | :--- | :--- |
| F_DOCX_001 | Hình 2.1 | 05_figures/assets/F_DOCX_001.png | media/image1.png |
| F_DOCX_002 | Hình 2.2 | 05_figures/assets/F_DOCX_002.png | media/image2.png |
| F_DOCX_003 | Hình 2.3 | 05_figures/assets/F_DOCX_003.png | media/image3.png |
| F_DOCX_004 | Hình 2.4 | 05_figures/assets/F_DOCX_004.png | media/image4.png |
| F_DOCX_005 | Hình 2.5 | 05_figures/assets/F_DOCX_005.png | media/image5.png |
| F_DOCX_006 | Hình 2.6 | 05_figures/assets/F_DOCX_006.png | media/image6.png |
| F_DOCX_007 | Hình 2.7 | 05_figures/assets/F_DOCX_007.png | media/image7.png |
| F_DOCX_008 | Hình 2.8 | 05_figures/assets/F_DOCX_008.png | media/image8.png |
| F_DOCX_009 | Hình 2.9 | 05_figures/assets/F_DOCX_009.png | media/image9.png |
| F_DOCX_010 | Hình 2.10 | 05_figures/assets/F_DOCX_010.png | media/image10.png |
| F_DOCX_011 | Hình 2.11 | 05_figures/assets/F_DOCX_011.png | media/image11.png |
