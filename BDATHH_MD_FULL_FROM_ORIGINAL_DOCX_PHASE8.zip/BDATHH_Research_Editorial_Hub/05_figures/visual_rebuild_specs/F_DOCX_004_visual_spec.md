# Visual Rebuild Specification

## Figure ID
F_DOCX_004

## Manuscript number
Hình 2.4

## Title
Biểu đồ tăng trưởng hệ thống bảo đảm an toàn hàng hải Việt Nam, giai đoạn 2015–2025

## Current asset path
05_figures/assets/F_DOCX_004.png

## Current candidate status
FIGURE_NEEDS_VISUAL_REBUILD

## Draft integration status
Integrated in `md_integrated_v02` as draft asset. Do not use as final until visual QA is complete.

## Figure type
Unknown / requires author-data review

## Purpose in manuscript
Visual support for the surrounding analysis. Rebuild must preserve analytical meaning and must not invent data.

## Data required for rebuild
Needs author-provided structured data or high-resolution original figure.

## Source note
Nguồn: Thống kê Bộ Xây dựng, Cục Hàng hải và Đường thủy Việt Nam, 2025c (số liệu chi tiết do nghiên cứu sinh tổng hợp) (Bộ Xây dựng, 2026a).

## Visual design rules
- White/light background.
- Black text.
- Academic colors may be used for data categories.
- No 3D effects.
- No complex gradients.
- Readable at A4 print size.
- Caption/source should remain outside the image in manuscript layout.

## Recommended rebuild approach
WAITING_FOR_AUTHOR_DATA

## Output requirements later
- SVG if suitable.
- PNG 300dpi.
- Editable source if possible.
- Word-ready image.

## Current decision
WAITING_FOR_AUTHOR_DATA
