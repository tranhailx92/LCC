# Visual Rebuild Specification

## Figure ID
F_DOCX_005

## Manuscript number
Hình 2.5

## Title
Kinh phí bảo trì kết cấu hạ tầng hàng hải giai đoạn 2015–2026

## Current asset path
05_figures/assets/F_DOCX_005.png

## Current candidate status
FIGURE_NEEDS_VISUAL_REBUILD

## Draft integration status
Integrated in `md_integrated_v02` as draft asset. Do not use as final until visual QA is complete.

## Figure type
Unknown / requires author-data review

## Purpose in manuscript
Visual support for the surrounding analysis. Rebuild must preserve analytical meaning and must not invent data.

## Data required for rebuild
Needs author-provided structured data or high-resolution original figure.

## Source note
Nguồn: Tổng hợp từ Báo cáo tổng kết việc thi hành Bộ luật Hàng hải Việt Nam năm 2015 (Bộ Xây dựng, 2026a).

## Visual design rules
- White/light background.
- Black text.
- Academic colors may be used for data categories.
- No 3D effects.
- No complex gradients.
- Readable at A4 print size.
- Caption/source should remain outside the image in manuscript layout.

## Recommended rebuild approach
WAITING_FOR_AUTHOR_DATA

## Output requirements later
- SVG if suitable.
- PNG 300dpi.
- Editable source if possible.
- Word-ready image.

## Current decision
WAITING_FOR_AUTHOR_DATA
