# Figure Candidate

## Figure ID
F_DOCX_003

## Manuscript number
Hình 2.3

## Title
Sơ đồ tổ chức bộ máy quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam sau hợp nhất.

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.1. KHÁI QUÁT NGÀNH HÀNG HẢI VÀ BỘ MÁY QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.1.2. Bộ máy quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam > 2.1.2.2. Vị trí, vai trò của Bộ Xây dựng trong quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

## Original DOCX asset
05_figures/assets/F_DOCX_003.png

## Source note
Nguồn: Nghiên cứu sinh tổng hợp từ các văn bản pháp luật (Bộ Xây dựng, 2025a, 2025f, 2025g, 2025h, 2025i; Chính phủ nước CHXHCN Việt Nam, 2025b, 2025c, 2025d), 2026.

## Candidate status
FIGURE_NEEDS_VISUAL_REBUILD

## Visual status
DRAFT_ASSET_RETAINED_WAITING_FOR_DATA

## Author source decision note
Source note extracted from DOCX.
