# Figure Candidate

## Figure ID
F_DOCX_004

## Manuscript number
Hình 2.4

## Title
Biểu đồ tăng trưởng hệ thống bảo đảm an toàn hàng hải Việt Nam, giai đoạn 2015–2025

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025 > 2.2.1. Thực trạng tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải > 2.2.1.2. Tổ chức thực hiện quản lý và vận hành hệ thống bảo đảm an toàn hàng hải

## Original DOCX asset
05_figures/assets/F_DOCX_004.png

## Source note
Nguồn: Thống kê Bộ Xây dựng, Cục Hàng hải và Đường thủy Việt Nam, 2025c (số liệu chi tiết do nghiên cứu sinh tổng hợp) (Bộ Xây dựng, 2026a).

## Candidate status
FIGURE_NEEDS_VISUAL_REBUILD

## Visual status
DRAFT_ASSET_RETAINED_WAITING_FOR_DATA

## Author source decision note
Source note extracted from DOCX.
