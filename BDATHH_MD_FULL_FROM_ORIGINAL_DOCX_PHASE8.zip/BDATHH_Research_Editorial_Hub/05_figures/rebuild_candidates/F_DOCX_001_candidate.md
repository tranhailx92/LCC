# Figure Candidate

## Figure ID
F_DOCX_001

## Manuscript number
Hình 2.1

## Title
Sản lượng hàng hóa thông qua hệ thống cảng biển Việt Nam giai đoạn 2015–2025.

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.1. KHÁI QUÁT NGÀNH HÀNG HẢI VÀ BỘ MÁY QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.1.1. Khái quát ngành hàng hải Việt Nam

## Original DOCX asset
05_figures/assets/F_DOCX_001.png

## Source note
Nguồn: Cục Hàng hải và Đường thủy Việt Nam (tổng kết 2025); Market Times (2026); VnEconomy (2024–2025).

## Candidate status
FIGURE_NEEDS_VISUAL_REBUILD

## Visual status
DRAFT_ASSET_RETAINED_WAITING_FOR_DATA

## Author source decision note
Source note extracted from DOCX.
