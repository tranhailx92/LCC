# Figure Candidate

## Figure ID
F_DOCX_010

## Manuscript number
Hình 2.10

## Title
Mô hình hồi quy tuyến tính bội theo khung 2×3.

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.3. ĐÁNH GIÁ ĐỊNH LƯỢNG CÁC YẾU TỐ ẢNH HƯỞNG TỚI KẾT QUẢ QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.3.1. Thiết kế mô hình nghiên cứu

## Original DOCX asset
05_figures/assets/F_DOCX_010.png

## Source note
Nguồn: Nghiên cứu sinh đề xuất, 2025.

## Candidate status
FIGURE_NEEDS_VISUAL_REBUILD

## Visual status
DRAFT_ASSET_RETAINED_WAITING_FOR_DATA

## Author source decision note
Source note extracted from DOCX.
