# Figure Candidate

## Figure ID
F_DOCX_011

## Manuscript number
Hình 2.11

## Title
Cơ cấu mẫu khảo sát phân bổ theo giới tính, độ tuổi, vai trò công tác và thâm niên làm việc (N=250 mẫu)

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.3. ĐÁNH GIÁ ĐỊNH LƯỢNG CÁC YẾU TỐ ẢNH HƯỞNG TỚI KẾT QUẢ QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.3.2. Dữ liệu nghiên cứu

## Original DOCX asset
05_figures/assets/F_DOCX_011.png

## Source note
Nguồn: Kết quả khảo sát của nghiên cứu sinh, 2025.

## Candidate status
FIGURE_NEEDS_VISUAL_REBUILD

## Visual status
DRAFT_ASSET_RETAINED_WAITING_FOR_DATA

## Author source decision note
Source note extracted from DOCX.
