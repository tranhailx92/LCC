# Figure Candidate

## Figure ID
F_DOCX_009

## Manuscript number
Hình 2.9

## Title
Cơ cấu phân hạng hoa tiêu hàng hải Việt Nam hiện nay

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025 > 2.2.2. Thực trạng quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải > 2.2.2.2. Tổ chức thực hiện, quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

## Original DOCX asset
05_figures/assets/F_DOCX_009.png

## Source note
Nguồn: Tác giả tổng hợp.

## Candidate status
FIGURE_NEEDS_VISUAL_REBUILD

## Visual status
DRAFT_ASSET_RETAINED_WAITING_FOR_DATA

## Author source decision note
Source note supplied by author decision after DOCX verification confirmed no source note was present in the original DOCX.
