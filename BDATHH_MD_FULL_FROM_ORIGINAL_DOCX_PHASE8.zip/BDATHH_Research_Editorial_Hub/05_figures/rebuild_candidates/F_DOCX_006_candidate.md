# Figure Candidate

## Figure ID
F_DOCX_006

## Manuscript number
Hình 2.6

## Title
Biểu đồ diễn biến tai nạn hàng hải giai đoạn 2015–2025.

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025 > 2.2.1. Thực trạng tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải > 2.2.1.3. Giám sát, đánh giá hệ thống bảo đảm an toàn hàng hải

## Original DOCX asset
05_figures/assets/F_DOCX_006.png

## Source note
Nguồn: Báo cáo tổng kết thi hành Bộ luật Hàng hải 2015 (Bộ Xây dựng, 2026a).

## Candidate status
FIGURE_NEEDS_VISUAL_REBUILD

## Visual status
DRAFT_ASSET_RETAINED_WAITING_FOR_DATA

## Author source decision note
Source note extracted from DOCX.
