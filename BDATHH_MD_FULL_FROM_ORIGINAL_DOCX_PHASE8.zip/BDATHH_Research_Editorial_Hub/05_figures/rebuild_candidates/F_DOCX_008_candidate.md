# Figure Candidate

## Figure ID
F_DOCX_008

## Manuscript number
Hình 2.8

## Title
Biểu đồ tỷ trọng và cơ cấu nguồn nhân lực dịch vụ hàng hải giai đoạn 2015–2024

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025 > 2.2.2. Thực trạng quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải > 2.2.2.2. Tổ chức thực hiện, quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

## Original DOCX asset
05_figures/assets/F_DOCX_008.png

## Source note
Nguồn: Tác giả tổng hợp từ số liệu thống kê giai đoạn 2015–2024.

## Candidate status
FIGURE_NEEDS_VISUAL_REBUILD

## Visual status
DRAFT_ASSET_RETAINED_WAITING_FOR_DATA

## Author source decision note
Source note supplied by author decision after DOCX verification confirmed no source note was present in the original DOCX.
