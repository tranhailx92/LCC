# Figure Candidate

## Figure ID
F_DOCX_007

## Manuscript number
Hình 2.7

## Title
Xu hướng kinh phí nạo vét duy tu luồng hàng hải giai đoạn 2015–2025

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025 > 2.2.2. Thực trạng quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải > 2.2.2.2. Tổ chức thực hiện, quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

## Original DOCX asset
05_figures/assets/F_DOCX_007.png

## Source note
Nguồn: Tổng hợp và xử lý từ các quyết định giao dự toán, điều chỉnh kế hoạch của Bộ Giao thông vận tải (2014–2024) và Bộ Xây dựng (2025g). (số liệu cụ thể do nghiên cứu sinh tổng hợp)

## Candidate status
FIGURE_NEEDS_VISUAL_REBUILD

## Visual status
DRAFT_ASSET_RETAINED_WAITING_FOR_DATA

## Author source decision note
Source note extracted from DOCX.
