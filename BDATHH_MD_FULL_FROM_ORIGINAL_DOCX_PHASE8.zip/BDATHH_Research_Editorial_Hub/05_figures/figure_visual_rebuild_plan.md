# Figure Visual Rebuild Plan

| Figure ID | Manuscript number | Title | Asset path | Current status | Rebuild needed? | Data source needed? | Notes |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| F_DOCX_001 | Hình 2.1 | Sản lượng hàng hóa thông qua hệ thống cảng biển Việt Nam giai đoạn 2015–2025. | 05_figures/assets/F_DOCX_001.png | DRAFT_ASSET_RETAINED_WAITING_FOR_DATA | Yes | Yes | Do not use as final until author data/design review. |
| F_DOCX_002 | Hình 2.2 | Chỉ số kết nối vận tải biển (LSCI) của Việt Nam và một số quốc gia ASEAN (2024–2025) | 05_figures/assets/F_DOCX_002.png | DRAFT_ASSET_RETAINED_WAITING_FOR_DATA | Yes | Yes | Do not use as final until author data/design review. |
| F_DOCX_003 | Hình 2.3 | Sơ đồ tổ chức bộ máy quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam sau hợp nhất. | 05_figures/assets/F_DOCX_003.png | DRAFT_ASSET_RETAINED_WAITING_FOR_DATA | Yes | Yes | Do not use as final until author data/design review. |
| F_DOCX_004 | Hình 2.4 | Biểu đồ tăng trưởng hệ thống bảo đảm an toàn hàng hải Việt Nam, giai đoạn 2015–2025 | 05_figures/assets/F_DOCX_004.png | DRAFT_ASSET_RETAINED_WAITING_FOR_DATA | Yes | Yes | Do not use as final until author data/design review. |
| F_DOCX_005 | Hình 2.5 | Kinh phí bảo trì kết cấu hạ tầng hàng hải giai đoạn 2015–2026 | 05_figures/assets/F_DOCX_005.png | DRAFT_ASSET_RETAINED_WAITING_FOR_DATA | Yes | Yes | Do not use as final until author data/design review. |
| F_DOCX_006 | Hình 2.6 | Biểu đồ diễn biến tai nạn hàng hải giai đoạn 2015–2025. | 05_figures/assets/F_DOCX_006.png | DRAFT_ASSET_RETAINED_WAITING_FOR_DATA | Yes | Yes | Do not use as final until author data/design review. |
| F_DOCX_007 | Hình 2.7 | Xu hướng kinh phí nạo vét duy tu luồng hàng hải giai đoạn 2015–2025 | 05_figures/assets/F_DOCX_007.png | DRAFT_ASSET_RETAINED_WAITING_FOR_DATA | Yes | Yes | Do not use as final until author data/design review. |
| F_DOCX_008 | Hình 2.8 | Biểu đồ tỷ trọng và cơ cấu nguồn nhân lực dịch vụ hàng hải giai đoạn 2015–2024 | 05_figures/assets/F_DOCX_008.png | DRAFT_ASSET_RETAINED_WAITING_FOR_DATA | Yes | Yes | Do not use as final until author data/design review. |
| F_DOCX_009 | Hình 2.9 | Cơ cấu phân hạng hoa tiêu hàng hải Việt Nam hiện nay | 05_figures/assets/F_DOCX_009.png | DRAFT_ASSET_RETAINED_WAITING_FOR_DATA | Yes | Yes | Do not use as final until author data/design review. |
| F_DOCX_010 | Hình 2.10 | Mô hình hồi quy tuyến tính bội theo khung 2×3. | 05_figures/assets/F_DOCX_010.png | DRAFT_ASSET_RETAINED_WAITING_FOR_DATA | Yes | Yes | Do not use as final until author data/design review. |
| F_DOCX_011 | Hình 2.11 | Cơ cấu mẫu khảo sát phân bổ theo giới tính, độ tuổi, vai trò công tác và thâm niên làm việc (N=250 mẫu) | 05_figures/assets/F_DOCX_011.png | DRAFT_ASSET_RETAINED_WAITING_FOR_DATA | Yes | Yes | Do not use as final until author data/design review. |
