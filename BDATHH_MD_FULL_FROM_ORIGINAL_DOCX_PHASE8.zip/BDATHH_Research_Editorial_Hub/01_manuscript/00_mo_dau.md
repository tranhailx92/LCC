# MỞ ĐẦU

## 1. Lý do lựa chọn đề tài

Trong bối cảnh chuỗi cung ứng quốc tế mở rộng, vận tải biển đảm nhận trên 80% khối lượng thương mại hàng hóa quốc tế (UNCTAD, 2025b). Ngành hàng hải đang chuyển dịch từ tuân thủ quy định truyền thống sang vận hành thông minh, tích hợp theo các chuẩn mực của IMO và IALA (Heikkilä et al., 2024; IALA, 2023; IMO, 2024b). An toàn hàng hải hiện là kết quả của hệ thống dịch vụ công và hạ tầng kỹ thuật hiện đại vận hành thời gian thực, gồm báo hiệu, luồng, hoa tiêu, quản lý giao thông (VTS), thông tin hàng hải (IALA, 2023; IMO, 2021). Trong bối cảnh đó, yêu cầu đặt ra là các quốc gia phải chuyển từ quản lý hành chính sang quản lý cung ứng dịch vụ bảo đảm an toàn chất lượng cao theo hướng hàng hải xanh và chuyển đổi số (OECD, 2019a; World Bank & International Association of Ports and Harbors [IAPH], 2021).

Đối với Việt Nam, Nghị quyết 36-NQ/TW (Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam, 2018) của Ban Chấp hành Trung ương Khóa XII xác định kinh tế biển là động lực trọng yếu, hướng tới mục tiêu quốc gia giàu mạnh về biển. Hơn 90% hàng hóa xuất nhập khẩu của Việt Nam đi qua hệ thống cảng biển (Cục Hàng hải Việt Nam, 2022), hệ thống bảo đảm an toàn hàng hải vừa phòng ngừa rủi ro vừa là cấu phần hỗ trợ quan trọng đối với năng lực cạnh tranh quốc gia. Vận hành hiệu quả hệ thống này giúp tối ưu hóa luồng hàng hóa, giảm thời gian neo đậu tàu. Theo Bộ Công Thương, chi phí logistics của Việt Nam chiếm khoảng 16,8% GDP (Bộ Công Thương, 2024); đồng thời, UNCTAD cho thấy hiệu quả cảng và thuận lợi hóa thương mại có tác dụng giảm chậm trễ và chi phí giao dịch (UNCTAD, 2025a). Do đó, hoàn thiện quản lý nhà nước lĩnh vực này là yếu tố quan trọng trong việc thực hiện chiến lược phát triển bền vững kinh tế biển.

Mặc dù nhận thức rõ tầm quan trọng của vấn đề, thực tiễn quản lý nhà nước về bảo đảm an toàn hàng hải tại Việt Nam vẫn tồn tại những vướng mắc thể chế và phương thức quản trị. Cơ chế tài chính dịch vụ công hiện nay làm suy giảm động lực đổi mới, tối ưu hóa chi phí. Khung pháp lý cho xã hội hóa đầu tư hạ tầng chưa huy động được nguồn lực xã hội cho phát triển hạ tầng bảo đảm an toàn hàng hải, mà vốn đầu tư vẫn phụ thuộc chính vào ngân sách Nhà nước. Phương thức quản lý, giám sát hiện tập trung vào quy trình thay vì kết quả và rủi ro, hệ thống chỉ số đánh giá hiệu quả (KPI), cam kết dịch vụ (SLA) còn sơ khai, quản lý chưa dựa trên dữ liệu thực. Điều này dẫn đến quản lý thụ động, thiếu dữ liệu phân tích cho dự báo, phòng ngừa rủi ro, đặc biệt trước các thách thức mới và yêu cầu nghiêm ngặt của các hãng tàu quốc tế. Những bất cập này trở thành rào cản cho hiện đại hóa và hội nhập ngành hàng hải Việt Nam (Bộ Xây dựng, 2026a; OECD, 2014; OECD, 2019b; World Bank Group, Asian Development Bank, European Bank for Reconstruction and Development, Inter-American Development Bank, Islamic Development Bank, OECD, UNECE & UNESCAP, 2017).

Mặt khác, xét về phương diện lý luận, các công trình nghiên cứu trong nước trước đây thường tiếp cận vấn đề bảo đảm an toàn hàng hải dưới góc độ kỹ thuật hàng hải hoặc khoa học pháp lý thuần túy hay mô hình tổ chức, mà chưa đi sâu phân tích bản chất của hoạt động này dưới góc độ quản lý nhà nước về hệ thống bảo đảm an toàn hàng hải và dịch vụ bảo đảm an toàn hàng hải (Hoàng Thị Lịch, 2021; Lương Thị Kim Dung, 2019; Lưu Việt Hùng, 2019; Nguyễn Mạnh Cường & Phan Văn Hưng, 2021; Vũ Đăng Thái, 2023). Hiện đang tồn tại một khoảng trống về cơ sở lý luận cho việc đổi mới mô hình tổ chức, cung ứng và điều tiết dịch vụ bảo đảm an toàn hàng hải ở Việt Nam; khoảng trống này cần được tiếp tục soi chiếu và bổ sung dưới góc nhìn của quản trị công mới, quản trị rủi ro và phát triển bền vững (ISO, 2018; Musgrave & Musgrave, 1989). Việc thiếu vắng một khung phân tích khoa học để giải quyết mối quan hệ giữa Nhà nước (người kiến tạo/mua dịch vụ) và các đơn vị sự nghiệp/doanh nghiệp (người cung ứng dịch vụ) là một trong những nguyên nhân khiến công cuộc đổi mới quản lý trong lĩnh vực này còn chưa tương xứng với tiềm năng (Musgrave & Musgrave, 1989; Osborne & Gaebler, 1992).

Xuất phát từ những yêu cầu lý luận và thực tiễn cấp thiết về việc khắc phục các hạn chế chủ yếu trong tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải, nghiên cứu sinh đã lựa chọn đề tài “Quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam” để thực hiện nghiên cứu. Luận án đặt mục tiêu xây dựng nền tảng khoa học nhằm đề xuất hệ thống các giải pháp hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải đến năm 2030, tầm nhìn 2045, góp phần hiện đại hóa ngành hàng hải, bảo đảm an ninh, an toàn và phát triển bền vững kinh tế biển Việt Nam phù hợp với xu thế quốc tế hiện nay.

## 2. Mục đích và nhiệm vụ nghiên cứu

## 2.1. Mục đích nghiên cứu

Luận án nhằm làm rõ cơ sở lý luận và thực tiễn của quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam; phân tích, đánh giá thực trạng quản lý nhà nước về bảo đảm an toàn hàng hải; từ đó đề xuất định hướng và giải pháp hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải đến năm 2030, tầm nhìn 2045.

## 2.2. Nhiệm vụ nghiên cứu

Một là, luận án hệ thống hóa và làm rõ các khái niệm, đặc điểm, vai trò, nội dung quản lý nhà nước, tiêu chí đánh giá (bộ KPI) và các yếu tố ảnh hưởng đối với quản lý nhà nước về bảo đảm an toàn hàng hải; đồng thời nghiên cứu kinh nghiệm quốc tế để rút ra bài học phù hợp cho Việt Nam.

Hai là, luận án phân tích, đánh giá thực trạng quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam giai đoạn 2015–2025 trên cơ sở lý luận và khung phân tích đã xây dựng, rút ra kết quả, hạn chế, nguyên nhân.

Ba là, kiểm định mức độ ảnh hưởng của các biến số quản lý nhà nước đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam bằng phương pháp định lượng, qua đó bổ sung bằng chứng thực chứng cho các nhận định rút ra từ nghiên cứu lý luận và thực trạng.

Bốn là, luận án đề xuất hệ thống giải pháp và kiến nghị đồng bộ nhằm hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam đến năm 2030, tầm nhìn 2045.

## 3. Đối tượng và phạm vi nghiên cứu

## 3.1. Đối tượng nghiên cứu

Đối tượng nghiên cứu của luận án là các hoạt động quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam.

## 3.2. Phạm vi nghiên cứu

Phạm vi chủ thể: Chủ thể quản lý nhà nước về bảo đảm an toàn hàng hải là Bộ Xây dựng (trước thời điểm hợp nhất tháng 3/2025 là Bộ Giao thông vận tải), cơ quan được Chính phủ giao nhiệm vụ tham mưu xây dựng chính sách và trực tiếp quản lý nhà nước về bảo đảm an toàn hàng hải của Việt Nam (Chính phủ nước CHXHCN Việt Nam, 2025b).

Phạm vi nội dung: Luận án giới hạn nghiên cứu trong hai nội dung trọng tâm của quản lý nhà nước về bảo đảm an toàn hàng hải. Nội dung thứ nhất là tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải, được phân tích theo ba chức năng: H1 là ban hành; H2 là tổ chức thực hiện; H3 là giám sát, đánh giá. Nội dung thứ hai là quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải, được phân tích theo ba chức năng: D1 là ban hành; D2 là tổ chức thực hiện; D3 là giám sát, đánh giá.

Phạm vi không gian: Luận án nghiên cứu trên lãnh thổ Việt Nam, có đối sánh với các mô hình quản lý nhà nước về bảo đảm an toàn hàng hải tiêu biểu trên thế giới (Singapore, Nhật Bản, Malaysia, Hà Lan/EU) để rút ra bài học kinh nghiệm cho Việt Nam.

Phạm vi thời gian: Luận án phân tích, đánh giá thực trạng quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam giai đoạn 2015–2025; đề xuất giải pháp đến 2030, tầm nhìn 2045. Dữ liệu khảo sát định lượng và phỏng vấn sâu được thu thập chủ yếu từ tháng 3 đến tháng 5 năm 2025.

## 4. Phương pháp nghiên cứu

## 4.1. Phương pháp luận và tiếp cận nghiên cứu

Về phương pháp luận: Luận án được xây dựng trên nền tảng khoa học quản lý và quản trị công hiện đại, với định hướng chuyển từ tư duy kiểm soát tuân thủ sang kiến tạo giá trị, quản lý theo kết quả và trách nhiệm giải trình. Trên cơ sở kết hợp lý thuyết kinh tế công cộng của Musgrave và Musgrave (1989), tư duy quản trị công hiện đại của Osborne và Gaebler (1992) và cách tiếp cận quản trị rủi ro theo ISO 31000:2018 (ISO, 2018), nghiên cứu khẳng định vai trò của Nhà nước trong đầu tư, điều tiết và giám sát hệ thống bảo đảm an toàn hàng hải; phân biệt giữa quản lý hệ thống và quản lý cung ứng dịch vụ; đồng thời nhấn mạnh yêu cầu minh bạch, lượng hóa kết quả và kiểm soát rủi ro trong toàn bộ chu trình quản lý. Đây là cơ sở lý luận trực tiếp để luận án xây dựng khung phân tích 2×3 gồm hai nội dung quản lý và ba chức năng quản lý nhà nước là ban hành, tổ chức thực hiện và giám sát, đánh giá.

Về cách tiếp cận: luận án sử dụng thiết kế nghiên cứu hỗn hợp, kết hợp phân tích định tính với kiểm định định lượng (Creswell & Plano Clark, 2018). Phần định tính được thực hiện thông qua phân tích tài liệu, so sánh quốc tế và phỏng vấn sâu chuyên gia nhằm làm rõ bối cảnh thể chế, đặc điểm quản lý và các vấn đề thực tiễn (Gill et al., 2008; Palinkas et al., 2015). Phần định lượng được sử dụng để kiểm định mức độ ảnh hưởng tương đối của các biến số quản lý nhà nước đến kết quả quản lý nhà nước, qua đó bổ sung bằng chứng thực chứng cho các nhận định rút ra từ nghiên cứu lý luận và thực trạng.

Về công cụ phân tích cốt lõi: luận án sử dụng khung phân tích tích hợp (ma trận 2×3) được xây dựng trên cơ sở tham chiếu tư tưởng tổ chức, hành chính của Weber (1947) và vận dụng các khuyến nghị hiện đại của IALA (2022). Khung này kết hợp hai trụ cột nội dung (quản lý hệ thống bảo đảm an toàn hàng hải và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải) với ba chức năng quản lý nhà nước (ban hành, tổ chức thực hiện và giám sát, đánh giá), qua đó tạo cơ sở để đánh giá toàn diện hoạt động quản lý, nhận diện hạn chế thể chế và phân tích kết quả vận hành của hệ thống dưới góc nhìn đa chiều.

## 4.2. Phương pháp nghiên cứu định tính

Luận án sử dụng ba nhóm phương pháp định tính chủ yếu.

Thứ nhất là phương pháp phân tích tài liệu. Luận án phân tích hệ thống các văn bản pháp luật, chiến lược, quy hoạch, báo cáo và số liệu thống kê của Bộ Xây dựng (trước tháng 3 năm 2025 là Bộ Giao thông vận tải), Cục Hàng hải và Đường thủy Việt Nam và các cơ quan, tổ chức liên quan đến bảo đảm an toàn hàng hải; đồng thời đối chiếu với các chuẩn mực quốc tế của IMO, IALA, IHO và các công trình khoa học trong nước có liên quan trực tiếp. Kết quả phân tích tài liệu được sử dụng để xây dựng tiêu chí đánh giá quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam, hình thành các biến quan sát cho khảo sát, xác định chuẩn so sánh quốc tế và cung cấp luận cứ cho việc đánh giá thực trạng, đề xuất giải pháp.

Thứ hai là phương pháp nghiên cứu so sánh. Luận án lựa chọn một số mô hình quản lý nhà nước về bảo đảm an toàn hàng hải tiêu biểu như Singapore, Malaysia, Nhật Bản, Hà Lan/EU để đối sánh. Nội dung so sánh tập trung vào cách thức ban hành, tổ chức thực hiện và giám sát đối với hai nhóm nội dung là quản lý hệ thống bảo đảm an toàn hàng hải và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải. Kết quả nghiên cứu so sánh được sử dụng để rút ra bài học kinh nghiệm cho Việt Nam, đồng thời làm cơ sở hoàn thiện khung phân tích, bộ tiêu chí đánh giá và hệ thống giải pháp của luận án.

Thứ ba là phương pháp phỏng vấn sâu bán cấu trúc (phỏng vấn sâu chuyên gia). Luận án thực hiện phỏng vấn sâu bán cấu trúc với 25 chuyên gia được lựa chọn theo phương pháp chọn mẫu có chủ đích, dựa trên hai tiêu chí: có tối thiểu 10 năm kinh nghiệm trong lĩnh vực hàng hải hoặc quản lý nhà nước về bảo đảm an toàn hàng hải; và đang hoặc đã từng giữ vị trí quản lý, điều hành hoặc là chuyên gia đầu ngành. Mẫu chuyên gia được phân theo các nhóm chức năng chính, bảo đảm tính đa dạng giữa khu vực quản lý nhà nước, cơ quan chuyên ngành, doanh nghiệp dịch vụ hàng hải, cơ sở đào tạo, nghiên cứu và nhóm chính sách, tài chính, hợp tác quốc tế. Nội dung phỏng vấn tập trung vào khung phân tích 2×3, thực trạng quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam, các yếu tố ảnh hưởng đến kết quả quản lý và định hướng hoàn thiện đến năm 2030, tầm nhìn 2045. Dữ liệu phỏng vấn được mã hóa theo chủ đề và sử dụng để hiệu chỉnh mô hình nghiên cứu, hoàn thiện thang đo và hỗ trợ biện giải kết quả định lượng (Gill et al., 2008; Palinkas et al., 2015).

## 4.3. Phương pháp nghiên cứu định lượng

Phương pháp nghiên cứu định lượng của luận án được trình bày cụ thể tại mục 2.3 của Chương 2. Trong phạm vi phần Mở đầu, luận án khái quát những nội dung cơ bản như sau:

Thứ nhất, về Mô hình nghiên cứu

Trên cơ sở khung phân tích 2×3, luận án sử dụng mô hình hồi quy tuyến tính bội với hệ số beta chuẩn hóa để kiểm định tác động của sáu biến độc lập H1, H2, H3, D1, D2 và D3 đến biến phụ thuộc Y. Phương trình nghiên cứu được biểu diễn như sau: Y = β0 + β1H1 + β2H2 + β3H3 + β4D1 + β5D2 + β6D3 + ε (Hair et al., 2010; Kline, 2016).

Trong mô hình này, H1 là biến ban hành trong quản lý hệ thống bảo đảm an toàn hàng hải; H2 là biến tổ chức thực hiện trong quản lý hệ thống bảo đảm an toàn hàng hải; H3 là biến giám sát trong quản lý hệ thống bảo đảm an toàn hàng hải; D1 là biến ban hành trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải; D2 là biến tổ chức thực hiện trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải; D3 là biến giám sát trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải. Biến Y phản ánh kết quả quản lý nhà nước về bảo đảm an toàn hàng hải. Các biến này được hình thành từ giá trị trung bình của các nhóm biến quan sát thuộc bảng hỏi khảo sát, sau khi đã kiểm định độ tin cậy của thang đo.

Thứ hai, về thiết kế bảng hỏi và thang đo.

Công cụ thu thập dữ liệu định lượng là bảng hỏi khảo sát có cấu trúc, được xây dựng trên cơ sở lý thuyết, tổng quan nghiên cứu, khung phân tích 2×3 và kết quả tham vấn chuyên gia. Bảng hỏi gồm các nhóm câu hỏi phản ánh thông tin nền của người trả lời, các biến quan sát của sáu cấu phần H1, H2, H3, D1, D2, D3 và nhóm biến phản ánh kết quả quản lý nhà nước Y (gồm 10 biến Y1 đến Y10). Toàn bộ thang đo được thiết kế theo thang Likert 5 mức để lượng hóa mức độ đánh giá của người trả lời.

Thứ ba, về cỡ mẫu, chọn mẫu và thu thập dữ liệu.

Dữ liệu định lượng được thu thập từ tháng 3 đến tháng 5 năm 2025. Luận án sử dụng phương pháp chọn mẫu thuận tiện kết hợp có chủ đích, nhằm bảo đảm sự tham gia của các nhóm đối tượng có liên quan trực tiếp đến quản lý nhà nước về bảo đảm an toàn hàng hải. Các nhóm được tiếp cận bao gồm cán bộ quản lý nhà nước, cán bộ cơ quan chuyên ngành, cán bộ quản lý tại các đơn vị cung ứng dịch vụ bảo đảm an toàn hàng hải, chuyên gia, cùng những người có kinh nghiệm thực tiễn trong hoạt động hàng hải. Việc phát phiếu được thực hiện bằng cả hai hình thức trực tiếp và trực tuyến để tăng khả năng tiếp cận đối tượng khảo sát. Sau khi thu hồi, toàn bộ phiếu khảo sát được rà soát theo các tiêu chí về mức độ hoàn thành, tính nhất quán của câu trả lời và khả năng sử dụng cho việc hình thành biến nghiên cứu. Những phiếu không bảo đảm yêu cầu bị loại khỏi tập dữ liệu phân tích. Kết quả cuối cùng, 250 phiếu hợp lệ được sử dụng cho phân tích định lượng (Hair et al., 2010; Kline, 2016).

Thứ tư, về xử lý dữ liệu.

Bộ số liệu được làm sạch, mã hóa thống nhất và kiểm tra tính hợp lệ trước khi phân tích. Các câu hỏi đảo chiều được quy đổi theo nguyên tắc thống nhất; sau đó, các biến H1, H2, H3, D1, D2, D3 và Y được tính bằng giá trị trung bình của các chỉ báo hợp lệ thuộc từng biến. Tiếp theo, luận án sử dụng Cronbach’s Alpha để kiểm định độ tin cậy nội tại của các thang đo, sau đó tiến hành phân tích tương quan, kiểm tra đa cộng tuyến và ước lượng mô hình hồi quy tuyến tính bội với hệ số beta chuẩn hóa. Các bước xử lý và phân tích được thực hiện trên môi trường Python nhằm bảo đảm tính minh bạch, nhất quán và khả năng tái lập kết quả.

## 5. Đóng góp mới của luận án

## 5.1. Đóng góp mới về mặt lý luận

Luận án cung cấp thêm bằng chứng lý luận và thực chứng cho cách tiếp cận quản lý nhà nước về bảo đảm an toàn hàng hải như một chỉnh thể tích hợp giữa tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải, thay vì chỉ tiếp cận tách rời theo từng mặt kỹ thuật, pháp lý hoặc tác nghiệp chuyên ngành. Trên cơ sở đó, luận án góp phần làm rõ hơn nội hàm của quản lý nhà nước về bảo đảm an toàn hàng hải trong điều kiện quản trị công hiện đại, nhấn mạnh rằng kết quả quản lý không chỉ phụ thuộc vào việc ban hành quy định, mà còn phụ thuộc trực tiếp vào chất lượng tổ chức thực hiện và hiệu lực của cơ chế giám sát, đánh giá trên cả hai trục quản lý hệ thống và quản lý cung ứng dịch vụ.

Đóng góp lý luận quan trọng của luận án không nằm ở việc đơn thuần đề xuất một sơ đồ phân tích mới, mà ở chỗ luận án làm rõ được giá trị giải thích của cách tiếp cận 2×3 đối với đối tượng nghiên cứu. Cụ thể, luận án cho thấy quản lý nhà nước về bảo đảm an toàn hàng hải có thể được nhận diện và phân tích một cách nhất quán thông qua hai nội dung quản lý và ba chức năng quản lý nhà nước, qua đó giúp kết nối chặt chẽ giữa lý luận, tiêu chí đánh giá, phân tích thực trạng và thiết kế giải pháp.

Một đóng góp lý luận khác của luận án là làm rõ hơn mối quan hệ giữa các cấu phần quản lý nhà nước và kết quả quản lý nhà nước trong lĩnh vực bảo đảm an toàn hàng hải. Trên cơ sở bằng chứng thực chứng, luận án chỉ ra rằng các cấu phần thuộc tổ chức thực hiện và ban hành có vai trò nổi bật hơn đối với kết quả quản lý nhà nước, trong khi chức năng giám sát, đánh giá tuy có ý nghĩa lý thuyết lớn nhưng trong thực tiễn chưa phát huy tương xứng. Kết quả này góp phần làm sâu sắc hơn cách tiếp cận lý luận đối với chất lượng quản lý nhà nước trong lĩnh vực công chuyên ngành.

## 5.2. Đóng góp mới về mặt thực tiễn

Về mặt thực tiễn, luận án cung cấp một bức tranh tương đối toàn diện về thực trạng quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam giai đoạn 2015–2025 trên cả hai trục là tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải. Không chỉ dừng ở mô tả hiện trạng, luận án đã làm rõ được những kết quả đạt được, các hạn chế chủ yếu và nguyên nhân của các hạn chế, từ đó tạo ra cơ sở thực tiễn có hệ thống cho việc xác định trọng tâm ưu tiên trong hoàn thiện quản lý nhà nước ở giai đoạn tiếp theo.

Đóng góp thực tiễn nổi bật của luận án là cung cấp bằng chứng thực chứng cho thấy mức độ ảnh hưởng của các cấu phần quản lý nhà nước đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam là không giống nhau. Trên cơ sở kết quả này, luận án không chỉ khẳng định vai trò quan trọng của toàn bộ chu trình quản lý nhà nước, mà còn chỉ ra rõ hơn những cấu phần cần được ưu tiên trong cải cách, đặc biệt là tổ chức thực hiện trong quản lý hệ thống và tổ chức thực hiện trong quản lý cung ứng dịch vụ. Giá trị thực tiễn của phát hiện này nằm ở chỗ nó giúp việc đề xuất giải pháp không rơi vào tình trạng dàn trải, mà có căn cứ để xác định đâu là điểm nghẽn cần ưu tiên xử lý trước.

## 6. Kết cấu của luận án

Ngoài Mở đầu, Kết luận, Danh mục các công trình khoa học đã công bố và Tài liệu tham khảo, nội dung chính của luận án gồm 3 chương:

# Chương 1: Cơ sở lý luận và kinh nghiệm quốc tế trong quản lý nhà nước về bảo đảm an toàn hàng hải

# Chương 2: Thực trạng quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

# Chương 3: Giải pháp hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam.
