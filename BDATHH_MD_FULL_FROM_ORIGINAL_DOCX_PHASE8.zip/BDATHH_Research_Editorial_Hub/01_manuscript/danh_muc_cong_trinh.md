# DANH MỤC CÁC CÔNG TRÌNH KHOA HỌC ĐÃ CÔNG BỐ

## 1. Phạm Quang Giáp, Nguyễn Ngọc Toàn (2025), Khung lý thuyết tích hợp "2 nội dung - 3 bình diện" trong quản lý nhà nước về bảo đảm an toàn hàng hải, Tạp chí Kinh tế và Dự báo, Bộ Tài chính (e-ISSN 2734–9365), số 902, tháng 9/2025 (32393).

## 2. Phạm Quang Giáp, Nguyễn Ngọc Toàn (2025), Kinh nghiệm quốc tế về mô hình quản lý nhà nước về bảo đảm an toàn hàng hải và gợi ý cho Việt Nam, Tạp chí Kinh tế và Dự báo, Bộ Tài chính (e-ISSN 2734–9365), số 1001, tháng 10/2025, (32402).

## 3. Phạm Quang Giáp, Nguyễn Ngọc Toàn (2025), Giải pháp hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam đến năm 2030 tầm nhìn năm 2045, Tạp chí Kinh tế và Dự báo, Bộ Tài chính, (e-ISSN 2734–9365), số 1001, tháng 10/2025, (32410).

## 4. Phạm Quang Giáp, Nguyễn Ngọc Toàn (2025), Tổ chức bảo đảm an toàn hàng hải ở Việt Nam hiện nay, Tạp chí Kinh tế và Quản lý, Học viện Chính trị quốc gia Hồ Chí Minh, (ISSN 1859 - 4565), số 86, tháng 10/2025 (tr.52 -tr.58).

## 5. Phạm Quang Giáp, Nguyễn Ngọc Toàn (2025), Quản lý nhà nước về dịch vụ bảo đảm an toàn hàng hải mới ở Việt Nam trong kỷ nguyên số và hội nhập toàn cầu, Tạp chí Kinh tế - Tài chính, Bộ Tài chính (ISSN 3093–3390), Kỳ II tháng 10/2025 (tr.121 – tr.126).
