# TÀI LIỆU THAM KHẢO

Abuja Memorandum of Understanding on Port State Control. (2024). 2024 Annual Report, Abuja MOU.

Abuja Memorandum of Understanding on Port State Control. (2025). Report of Annual Port State Inspection Data (APSID 2024), Abuja MOU.

African Union. (2012). 2050 Africas Integrated Maritime Strategy (2050 AIM Strategy), African Union Commission.

Androjna, A., Perkovič, M., Pavic, I., & Mišković, J. (2021). AIS Data Vulnerability Indicated by a Spoofing Case-Study, Applied Sciences, 11(11), 5015. https://doi.org/10.3390/app11115015

Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam. (2018). Nghị quyết số 36-NQ/TW ngày 22/10/2018 về Chiến lược phát triển bền vững kinh tế biển Việt Nam đến năm 2030, tầm nhìn đến năm 2045.

Bộ Chính trị. (2024). Nghị quyết số 57-NQ/TW ngày 22/12/2024 về đột phá phát triển khoa học, công nghệ, đổi mới sáng tạo và chuyển đổi số quốc gia.

Bộ Chính trị. (2025). Nghị quyết số 68-NQ/TW ngày 04/5/2025 về phát triển kinh tế tư nhân.

Bộ Công Thương. (2024). Tọa đàm trực tuyến: Logistics với thị trường Hoa Kỳ. https://moit.gov.vn/tin-tuc/thi-truong-nuoc-ngoai/toa-dam-truc-tuyen-logistics-voi-thi-truong-hoa-ky.html

Bộ Giao thông vận tải. (2019). Thông tư số 42/2019/TT-BGTVT ngày 30/10/2019 quy định tiêu chí, kiểm tra, giám sát, đánh giá, nghiệm thu chất lượng dịch vụ sự nghiệp công bảo đảm an toàn hàng hải.

Bộ Giao thông vận tải. (2021a). Thông tư số 37/2021/TT-BGTVT ngày 30/12/2021 hướng dẫn giá dịch vụ sự nghiệp công bảo đảm an toàn hàng hải sử dụng kinh phí ngân sách nhà nước từ nguồn kinh phí thường xuyên, thực hiện theo phương thức đặt hàng.

Bộ Giao thông vận tải. (2021b). Thông tư số 38/2021/TT-BGTVT ngày 30/12/2021 ban hành định mức kinh tế - kỹ thuật trong lĩnh vực cung ứng dịch vụ sự nghiệp công bảo đảm an toàn hàng hải.

Bộ Giao thông vận tải. (2022). Thông tư số 19/2022/TT-BGTVT ngày 26 tháng 7 năm 2022 quy định về bảo trì công trình hàng hải.

Bộ Giao thông vận tải. (2023a). Thông tư số 20/2023/TT-BGTVT ngày 30/6/2023 quy định về tiêu chuẩn chuyên môn, chứng chỉ chuyên môn, đào tạo, huấn luyện thuyền viên và định biên an toàn tối thiểu của tàu biển Việt Nam.

Bộ Giao thông vận tải. (2023b). Thông tư số 40/2023/TT-BGTVT ngày 25/12/2023 quy định tiêu chí chất lượng và công tác kiểm tra, giám sát, đánh giá để nghiệm thu chất lượng dịch vụ sự nghiệp công thông tin duyên hải.

Bộ Giao thông vận tải. (2023c). Thông tư số 57/2023/TT-BGTVT ngày 31/12/2023 quy định về chương trình đào tạo, huấn luyện thuyền viên, hoa tiêu hàng hải.

Bộ Giao thông vận tải. (2024a). Quyết định số 814/QĐ-BGTVT ngày 01 tháng 7 năm 2024 ban hành giá tối đa dịch vụ hoa tiêu hàng hải tại cảng biển Việt Nam.

Bộ Giao thông vận tải. (2024b). Thông tư số 12/2024/TT-BGTVT ngày 15/5/2024 quy định cơ chế, chính sách quản lý giá dịch vụ tại cảng biển Việt Nam.

Bộ Giao thông vận tải. (2025). QCVN 21:2025/BGTVT: Quy chuẩn kỹ thuật quốc gia về phân cấp và đóng tàu biển vỏ thép.

Bộ Khoa học và Công nghệ. (2015a). TCVN 10703:2015: Yêu cầu chất lượng dịch vụ vận hành đèn biển.

Bộ Khoa học và Công nghệ. (2015b). TCVN 10704:2015: Yêu cầu chất lượng dịch vụ vận hành luồng hàng hải.

Bộ Khoa học và Công nghệ. (2024). TCVN 14141:2024: Phương pháp tính toán, xác định tầm hiệu lực của báo hiệu hàng hải.

Bộ Tài chính. (2016). Thông tư số 261/2016/TT-BTC ngày 14 tháng 11 năm 2016 quy định về phí, lệ phí hàng hải và biểu mức thu phí, lệ phí hàng hải.

Bộ Xây dựng. (2025a). Quyết định số 08/QĐ-BXD ngày 01/3/2025 quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Cục Hàng hải và Đường thủy Việt Nam.

Bộ Xây dựng. (2025b). Quyết định số 1644/QĐ-BXD ngày 30/9/2025 ban hành Chiến lược chuyển đổi số của Bộ Xây dựng giai đoạn 2025–2030.

Bộ Xây dựng. (2025c). Quyết định số 2287/QĐ-BXD ngày 12/12/2025 ban hành Kế hoạch triển khai thực hiện Quyết định số 1901/QĐ-TTg.

Bộ Xây dựng. (2025d). Quyết định số 2530/QĐ-BXD ngày 31/12/2025 về việc công bố thủ tục hành chính được sửa đổi, bổ sung trong lĩnh vực hàng hải thuộc phạm vi chức năng quản lý của Bộ Xây dựng.

Bộ Xây dựng. (2025e). Quyết định số 438/QĐ-BXD ngày 18/4/2025 về việc thành lập Tổng công ty Bảo đảm an toàn hàng hải Việt Nam.

Bộ Xây dựng. (2025f). Thông tư số 18/2025/TT-BXD ngày 30/6/2025 quy định về tổ chức và hoạt động của Cảng vụ hàng hải, Cảng vụ đường thủy nội địa.

Bộ Xây dựng. (2025g). Thông tư số 21/2025/TT-BXD ngày 21/7/2025 ban hành định mức chi phí áp dụng cho dịch vụ sự nghiệp công thông tin duyên hải sử dụng ngân sách nhà nước từ nguồn kinh phí chi thường xuyên, thực hiện theo phương thức đặt hàng.

Bộ Xây dựng. (2025h). Thông tư số 31/2025/TT-BXD ngày 31/10/2025 quy định về tiêu chuẩn đào tạo hoa tiêu hàng hải; cấp, thu hồi chứng chỉ chuyên môn hoa tiêu hàng hải và giấy chứng nhận vùng hoạt động hoa tiêu hàng hải.

Bộ Xây dựng. (2025i). Văn bản hợp nhất số 02/VBHN-BXD ngày 20 tháng 3 năm 2025 hợp nhất Nghị định số 58/2017/NĐ-CP và các quy định sửa đổi, bổ sung liên quan.

Bộ Xây dựng. (2026a). Báo cáo số 36/BC-BXD ngày 12/02/2026 về tổng kết việc thi hành Bộ luật Hàng hải Việt Nam năm 2015, Luật Giao thông đường thủy nội địa năm 2004 và các sửa đổi, bổ sung.

Bộ Xây dựng. (2026b). Quyết định số 143/QĐ-BXD ngày 03/02/2026 về việc giao một số chỉ tiêu định hướng năm 2026 đối với Tổng công ty Bảo đảm an toàn hàng hải Việt Nam.

Bộ Xây dựng. (2026c). Quyết định số 147/QĐ-BXD ngày 03/02/2026 về việc giao một số chỉ tiêu định hướng năm 2026 cho Công ty TNHH MTV Thông tin điện tử hàng hải Việt Nam.

Bộ Xây dựng. (2026d). Thông tư số 05/2026/TT-BXD ngày 10/02/2026 quy định về bảo trì công trình hàng hải và tần suất khảo sát thông báo hàng hải.

Chính phủ nước CHXHCN Việt Nam. (2016). Nghị định số 70/2016/NĐ-CP ngày 01/7/2016 về điều kiện cung cấp dịch vụ bảo đảm an toàn hàng hải.

Chính phủ nước CHXHCN Việt Nam. (2017). Nghị định số 58/2017/NĐ-CP ngày 10 tháng 5 năm 2017 quy định chi tiết một số điều của Bộ luật Hàng hải Việt Nam về quản lý hoạt động hàng hải.

Chính phủ nước CHXHCN Việt Nam. (2019). Nghị định số 32/2019/NĐ-CP ngày 10/4/2019 quy định giao nhiệm vụ, đặt hàng hoặc đấu thầu cung cấp sản phẩm, dịch vụ công sử dụng ngân sách nhà nước từ nguồn kinh phí chi thường xuyên.

Chính phủ nước CHXHCN Việt Nam. (2021a). Nghị định số 06/2021/NĐ-CP ngày 26/01/2021 quy định chi tiết một số nội dung về quản lý chất lượng, thi công xây dựng và bảo trì công trình xây dựng.

Chính phủ nước CHXHCN Việt Nam. (2021b). Nghị định số 99/2021/NĐ-CP ngày 11/11/2021 quy định về quản lý, thanh toán, quyết toán sử dụng vốn đầu tư công.

Chính phủ nước CHXHCN Việt Nam. (2022). Nghị định số 69/2022/NĐ-CP ngày 23/09/2022 sửa đổi, bổ sung một số điều của các Nghị định quy định liên quan đến hoạt động kinh doanh trong lĩnh vực hàng hải.

Chính phủ nước CHXHCN Việt Nam. (2024). Nghị định số 57/2024/NĐ-CP ngày 20 tháng 5 năm 2024 về quản lý hoạt động nạo vét trong vùng nước cảng biển và vùng nước đường thủy nội địa.

Chính phủ nước CHXHCN Việt Nam. (2025a). Nghị định số 214/2025/NĐ-CP ngày 04/8/2025 quy định chi tiết một số điều và biện pháp thi hành Luật Đấu thầu về lựa chọn nhà thầu.

Chính phủ nước CHXHCN Việt Nam. (2025b). Nghị định số 33/2025/NĐ-CP ngày 25/02/2025 quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ Xây dựng.

Chính phủ nước CHXHCN Việt Nam. (2025c). Nghị định số 34/2025/NĐ-CP ngày 25 tháng 2 năm 2025 sửa đổi, bổ sung một số nghị định trong lĩnh vực hàng hải.

Chính phủ nước CHXHCN Việt Nam. (2025d). Nghị định số 84/2025/NĐ-CP ngày 04 tháng 4 năm 2025 quy định việc quản lý, sử dụng và khai thác tài sản kết cấu hạ tầng hàng hải.

Chính phủ nước CHXHCN Việt Nam. (2025e). Nghị quyết số 58/NQ-CP ngày 21/3/2025 về giải thể Ủy ban Quản lý vốn nhà nước tại doanh nghiệp.

Cổng Thông tin điện tử Chính phủ. (2025). Hàng hóa qua cảng biển tăng mạnh, 100% thủ tục hành chính được làm online. https://baochinhphu.vn/hang-hoa-qua-cang-bien-tang-manh-100-thu-tuc-hanh-chinh-duoc-lam-online-102251224220645014.htm

Công ty TNHH MTV Thông tin Điện tử Hàng hải Việt Nam (VISHIPEL). (2026). Giới thiệu/Hệ thống Thông tin duyên hải Việt Nam. https://vishipel.vn/

Creswell, J. W., & Plano Clark, V. L. (2018). Designing and Conducting Mixed Methods Research, 3rd ed., SAGE.

Cục Hàng hải và Đường thủy Việt Nam. (2025a). Cục Hàng hải và Đường thủy Việt Nam tổ chức Hội nghị tổng kết công tác năm 2025 và triển khai kế hoạch năm 2026. https://vimawa.gov.vn/vi/tin-tuc/cuc-hang-hai-va-duong-thuy-viet-nam-chuc-hoi-nghi-tong-ket-cong-tac-nam-2025-va-trien-khai

Cục Hàng hải và Đường thủy Việt Nam. (2025b). Mô hình hệ thống. https://vimawa.gov.vn/vi/noi-dung/mo-hinh-he-thong

Cục Hàng hải và Đường thủy Việt Nam. (2025c). Thống kê. https://vimawa.gov.vn/vi/thong-ke

Cục Hàng hải Việt Nam. (2022). Hội thảo xin ý kiến về dự thảo Quy hoạch chi tiết phát triển hạ tầng cảng biển 2021–2030, tầm nhìn đến năm 2050. https://vimawa.gov.vn/vi/tin-tuc/hoi-thao-xin-y-kien-ve-du-thao-quy-hoach-chi-tiet-phat-trien-ha-tang-cang-bien-2021–2030-tam

Đảng Cộng sản Việt Nam. (2026). Nghị quyết Đại hội đại biểu toàn quốc lần thứ XIV của Đảng.

European Maritime Safety Agency (EMSA). (2024). Annual Overview of Marine Casualties and Incidents 2024, EMSA.

European Maritime Safety Agency (EMSA). (2025). The 2025 European Maritime Safety Report (EMSAFE), EMSA.

European Maritime Safety Agency (EMSA). (n.d.). Common Information Sharing Environment (CISE). https://emsa.europa.eu/ssn-main/378-cise.html

European Maritime Safety Agency (EMSA). (n.d.). SafeSeaNet. https://www.emsa.europa.eu/ssn-main.html

Gill, P., Stewart, K., Treasure, E., & Chadwick, B. (2008). Methods of data collection in qualitative research: Interviews and focus groups, British Dental Journal, 204, 291–295. https://doi.org/10.1038/bdj.2008.192

Hair, J. F., Black, W. C., Babin, B. J., & Anderson, R. E. (2010). Multivariate Data Analysis, 7th ed., Pearson.

Hair, J. F., Risher, J. J., Sarstedt, M., & Ringle, C. M. (2019). When to use and how to report the results of PLS-SEM, European Business Review, 31(1), 2-24.

Heikkilä, M., Himmanen, H., Soininen, O., Sonninen, S., & Heikkilä, J. (2024). Navigating the Future: Developing Smart Fairways for Enhanced Maritime Safety and Efficiency, Journal of Marine Science and Engineering, 12(2), 324. https://doi.org/10.3390/jmse12020324

Hoàng Thị Lịch. (2021). Quản lý nhà nước về dịch vụ cảng biển tại Việt Nam, Luận án Tiến sĩ, Trường Đại học Hàng hải Việt Nam, Hải Phòng.

Hollnagel, E. (2014). Safety-I and Safety-II: The Past and Future of Safety Management, Ashgate, Farnham.

Hood, C., & Peters, B. G. (2004). The Middle Aging of New Public Management: Into the Age of Paradox?, Journal of Public Administration Research and Theory, 14(3), 267-282. https://doi.org/10.1093/jopart/muh019

International Association of Marine Aids to Navigation and Lighthouse Authorities. (2017a). Recommendation R0130: Categorisation and Availability Objectives for Short Range Aids to Navigation (Edition 3.1, revised 16 June 2017), IALA, Saint-Germain-en-Laye, France.

International Association of Marine Aids to Navigation and Lighthouse Authorities. (2017b). Recommendation R1002: Risk Management for Marine Aids to Navigation (Edition 1.1, revised 16 June 2017), IALA, Saint-Germain-en-Laye, France.

International Association of Marine Aids to Navigation and Lighthouse Authorities. (2022). Guideline G1089: Provision of a VTS (Edition 2.0, revised 31 January 2022), IALA, Saint-Germain-en-Laye, France.

International Association of Marine Aids to Navigation and Lighthouse Authorities. (2023). Standard S1010: Marine Aids to Navigation Planning and Service Requirements, IALA, Saint-Germain-en-Laye, France.

International Hydrographic Organization. (2018). Publication M-2: The Need for National Hydrographic Services (Version 3.0.7), IHO, Monaco.

International Hydrographic Organization. (2022). IHO S-100: Universal Hydrographic Data Model (Edition 5.0.0), IHO, Monaco.

International Hydrographic Organization. (2024). S-44: IHO Standards for Hydrographic Surveys (Edition 6.2.0, October 2024), IHO, Monaco.

International Maritime Organization. (1972). Convention on the International Regulations for Preventing Collisions at Sea (COLREG), 1972, IMO.

International Maritime Organization. (1973/1978). International Convention for the Prevention of Pollution from Ships (MARPOL), IMO.

International Maritime Organization. (1974). International Convention for the Safety of Life at Sea (SOLAS), 1974, IMO.

International Maritime Organization. (1978). International Convention on Standards of Training, Certification and Watchkeeping for Seafarers (STCW), 1978, IMO.

International Maritime Organization. (1991). Resolution A.705(17): Promulgation of Maritime Safety Information, IMO.

International Maritime Organization. (2003). Resolution A.958(23): Provision of Hydrographic Services, IMO.

International Maritime Organization. (2013). Resolution A.1070(28): IMO Instruments Implementation Code (III Code), IMO.

International Maritime Organization. (2018a). MSC- MEPC.2/Circ.12/Rev.2: Revised Guidelines for Formal Safety Assessment (FSA) for Use in the IMO Rule-Making Process, IMO.

International Maritime Organization. (2018b). MSC.1/Circ.1595: E- Navigation Strategy Implementation Plan – Update 1, IMO.

International Maritime Organization. (2019). MSC.1/Circ.1610: Initial Descriptions of Maritime Services in the Context of E-Navigation, IMO.

International Maritime Organization. (2020). SOLAS Consolidated Edition 2020, IMO.

International Maritime Organization. (2021). Resolution A.1158(32): Guidelines for Vessel Traffic Services, IMO.

International Maritime Organization. (2023). 2023 IMO Strategy on Reduction of GHG Emissions from Ships. Resolution MEPC.377(80), IMO.

International Maritime Organization. (2024a). MSC.1/Circ.1310/Rev.2: Joint IMO/IHO/WMO Manual on Maritime Safety Information, IMO.

International Maritime Organization. (2024b). MSC.1/Circ.1610/Rev.1: Descriptions of Maritime Services in the Context of E-Navigation, IMO.

International Maritime Organization. (2024c). SOLAS Consolidated Edition 2024, IMO.

International Maritime Organization. (n.d.). Maritime Security and Piracy. https://www.imo.org/en/OurWork/Security/Pages/MaritimeSecurity.aspx

International Maritime Organization. (n.d.). SOLAS XI-2 and the ISPS Code. https://www.imo.org/en/OurWork/Security/Pages/ISPSCode.aspx

International Maritime Organization. (n.d.). Status of Conventions. https://www.imo.org/en/about/conventions/pages/statusofconventions.aspx

International Organization for Marine Aids to Navigation (IALA). (2025). Guideline G1111: Establishing Functional and Performance Requirements for VTS Systems and Equipment (Edition 2.1), IALA, Saint- Germain-en-Laye, France.

ISO. (2018). ISO 31000:2018 Risk management – Guidelines, ISO.

ISO. (2024). ISO 55000:2024 Asset management - Vocabulary, overview and principles, ISO.

Issa-Zadeh, S. B., & Garay-Rondero, C. L. (2025). Maritime Pilotage and Sustainable Seaport: A Systematic Review, Journal of Marine Science and Engineering, 13(5), 945. https://doi.org/10.3390/jmse13050945

Japan Coast Guard – Osaka Wan Vessel Traffic Service Center (OSAKA MARTIS). (2025). User Manual (English), Japan Coast Guard.

Japan Coast Guard. (2025). Navigation Safety Guidance: Tokyo Wan, Ise Wan (including Nagoya-Ko), Seto Inland Sea (including Kanmon Kaikyo) (38th Revised Edition, March 2025), Maritime Traffic Department, Navigation Safety Division.

Joint Nautical Authority (VTS-Scheldt). (n.d.). Joint Nautical Authority. https://www.vts-scheldt.net/default.aspx?KL=en&path=Over+ons%2FBeleid%2FGNA

Kline, R. B. (2016). Principles and Practice of Structural Equation Modeling, The Guilford Press.

Kuo, C. (1998). Managing Ship Safety, Lloyds of London Press.

Kusek, J. Z., & Rist, R. C. (2004). Ten Steps to a Results-Based Monitoring and Evaluation System, World Bank.

Lee, C., & Lee, S. (2024). Expanding IMO Compendium with NAVTEX Messages for Maritime Single Window, Journal of Marine Science and Engineering, 12(12), 2328. https://doi.org/10.3390/jmse12122328

Lương Thị Kim Dung. (2019). An ninh hàng hải đối với tàu biển, cảng biển trong pháp luật quốc tế và thực tiễn của Việt Nam, Luận án Tiến sĩ, Trường Đại học Luật Hà Nội.

Lưu Việt Hùng. (2019). Nghiên cứu giải pháp nâng cao an toàn hàng hải vùng biển Việt Nam, Luận án Tiến sĩ, Trường Đại học Hàng hải Việt Nam, Hải Phòng.

Majone, G. (1994). The Rise of the Regulatory State in Europe, West European Politics, 17(3), 77-101. https://doi.org/10.1080/01402389408425031

Mao, X., & Wang, Z. (2020). AIS Big Data in Maritime Safety: Applications and Challenges, Journal of Marine Science and Engineering, 8(10), 789. https://doi.org/10.3390/jmse8100789

Marine Casualties Investigative Body (Italy). (2013). Cruise Ship COSTA CONCORDIA Marine Casualty on January 13, 2012: Report on the Safety Technical Investigation, Ministry of Infrastructure and Transport.

Maritime and Port Authority of Singapore (MPA). (2023a). Port Marine Circular No. 10 of 2023: digitalPORT@SGTM – Implementation of Just in Time Planning and Coordination Platform for Port of Singapore, MPA.

Maritime and Port Authority of Singapore (MPA). (2023b). Port Statistics, MPA.

Maritime and Port Authority of Singapore (MPA). (2025). Singapore Port Information (STRAITREP, VTIS/TSS Guidance), MPA.

Maritime and Port Authority of Singapore (MPA). (n.d.). About MPA. https://www.mpa.gov.sg/who-we-are/about-mpa

Ministry of Transport Malaysia. (2023). Aids to Navigation, Ministry of Transport.

Ministry of Transport Malaysia. (n.d.). Vessel Traffic System (VTS). https://www.mot.gov.my/en/maritime/safety-and-security/VTS

Moore, M. H. (1995). Creating Public Value: Strategic Management in Government, Harvard University Press, Cambridge, MA.

Musgrave, R. A., & Musgrave, P. B. (1989). Public Finance in Theory and Practice, McGraw-Hill.

National Oceanic and Atmospheric Administration. (n.d.). Exxon Valdez. https://darrp.noaa.gov/oil-spills/exxon-valdez

Nguyễn Mạnh Cường, & Phan Văn Hưng. (2021). Những lợi ích của e-navigation và xu hướng phát triển, Tạp chí Khoa học Công nghệ Hàng hải, 65(01), 96–100.

North, D. C. (1990). Institutions, Institutional Change and Economic Performance, Cambridge University Press.

Norwegian Coastal Administration (Kystverket). (2025). Rates of fee 2025, Kystverket.

Norwegian Coastal Administration (Kystverket). (n.d.). This is the standard for Norwegian coast markings. https://www.kystverket.no/en/fairway/lightshouses-and-navigations-marks/standard-for-norwegian-coast/

Norwegian Coastal Administration (Kystverket). (n.d.). Vessel Traffic Service (VTS). https://www.kystverket.no/en/navigation-and-monitoring/vts---vessel-traffic-service/

Norwegian Coastal Administration (Kystverket). (n.d.). VTS services. https://www.kystverket.no/en/navigation-and-monitoring/vts---vessel-traffic-service/services/

OECD. (2014). OECD Framework for Regulatory Policy Evaluation, OECD Publishing.

OECD. (2019a). Better Regulation Practices across the European Union, OECD Publishing.

OECD. (2019b). OECD Good Practices for Performance Budgeting, OECD Publishing.

Osborne, D., & Gaebler, T. (1992). Reinventing Government: How the Entrepreneurial Spirit is Transforming the Public Sector, Addison-Wesley.

Osborne, S. P., chủ biên. (2010). The New Public Governance? Emerging Perspectives on the Theory and Practice of Public Governance, Routledge.

Palinkas, L. A., Horwitz, S. M., Green, C. A., Wisdom, J. P., Duan, N., & Hoagwood, K. (2015). Purposeful Sampling for Qualitative Data Collection and Analysis in Mixed Method Implementation Research, Administration and Policy in Mental Health and Mental Health Services Research, 42(5), 533–544. https://doi.org/10.1007/s10488-013-0528-y

Pollitt, C., & Bouckaert, G. (2011). Public Management Reform: A Comparative Analysis - New Public Management, Governance, and the Neo-Weberian State, 3rd ed., Oxford University Press.

Port Klang Authority. (2025). Marine Handbook, Port Klang Authority.

Port of Rotterdam. (2021). VTS services and VHF communication procedure. https://www.portofrotterdam.com/en/contact-harbourmaster/vts-services-and-vhf-communication-procedure

Praetorius, G. (2014). Vessel Traffic Service (VTS): a maritime information service or traffic control system? Understanding everyday performance and resilience in a socio-technical system under change, Doctoral thesis, Chalmers University of Technology.

Quốc hội nước CHXHCN Việt Nam. (2015). Bộ luật Hàng hải Việt Nam số 95/2015/QH13.

Rhodes, R. A. W. (1996). The new governance: governing without government, Political Studies, 44(4), 652-667.

Sampson, H., & Bloor, M. (2012). The effectiveness of global regulation in the shipping industry: a critical case study, Revista Latino-americana de Estudos do Trabalho, 17(28), 45–72.

Samuelson, P. A. (1954). The pure theory of public expenditure, Review of Economics and Statistics, 36(4), 387-389.

Stiglitz, J. E., & Rosengard, J. K. (2015). Economics of the Public Sector, 4th ed., W. W. Norton.

Thanh tra. (2025). Kết luận thanh tra tại Công ty Cảng Container Trung tâm Sài Gòn. https://thanhtra.com.vn/ket-luan-thanh-tra-E17BD7A25/ket-luan-thanh-tra-tai-cong-ty-cang-container-trung-tam-sai-gon-fd59fa7ed.html

Thủ tướng Chính phủ. (2021). Quyết định số 1579/QĐ-TTg ngày 22 tháng 9 năm 2021 phê duyệt Quy hoạch tổng thể phát triển hệ thống cảng biển Việt Nam thời kỳ 2021–2030, tầm nhìn đến năm 2050.

Thủ tướng Chính phủ. (2024). Quyết định số 442/QĐ-TTg ngày 22 tháng 5 năm 2024 phê duyệt điều chỉnh Quy hoạch tổng thể phát triển hệ thống cảng biển Việt Nam.

Thủ tướng Chính phủ. (2025a). Quyết định số 140/QĐ-TTg ngày 16 tháng 1 năm 2025 phê duyệt Quy hoạch chi tiết nhóm cảng biển, bến cảng, khu nước, vùng nước thời kỳ 2021–2030, tầm nhìn đến năm 2050.

Thủ tướng Chính phủ. (2025b). Quyết định số 1901/QĐ-TTg ngày 05/9/2025 về việc phê duyệt Đề án xây dựng Trường Đại học Hàng hải Việt Nam là trường trọng điểm quốc gia về đào tạo, nghiên cứu phục vụ phát triển bền vững kinh tế biển giai đoạn đến năm 2030, tầm nhìn đến năm 2045.

Tokyo Memorandum of Understanding on Port State Control. (n.d.). New Inspection Regime (NIR): Flags Meeting Low Risk Criteria. https://www.tokyo-mou.org/inspections-detentions/nir/

Trung tâm Phối hợp tìm kiếm, cứu nạn hàng hải Việt Nam (VMRCC). (n.d.). Trang chủ. https://vmrcc.gov.vn/trang-chu

UNCTAD. (2023). Review of Maritime Transport 2023, United Nations.

UNCTAD. (2024). Review of Maritime Transport 2024, United Nations.

UNCTAD. (2025a). Review of Maritime Transport 2025, Chapter 4: Port Performance and Maritime Trade Facilitation, United Nations.

UNCTAD. (2025b). Review of Maritime Transport 2025, United Nations.

UNCTADstat. (n.d.). Maritime and other transport. https://unctadstat.unctad.org/insights/theme/246

UNDP. (2009). Handbook on Planning, Monitoring and Evaluating for Development Results, United Nations Development Programme.

United Nations. (1982). United Nations Convention on the Law of the Sea (UNCLOS), United Nations, Montego Bay.

United States Environmental Protection Agency. (n.d.). Summary of the Oil Pollution Act. https://www.epa.gov/laws-regulations/summary-oil-pollution-act

Valdez Banda, O. A., & Goerlandt, F. (2018). A STAMP-based approach for designing maritime safety management systems: The case of the Vessel Traffic Services in the Gulf of Finland, Safety Science, 109, 109-129. https://doi.org/10.1016/j.ssci.2018.05.003

Vicente, J. P. D. (2022). Portugals cartographic responsibility in Africa, The International Hydrographic Review, 28, 197-204. https://doi.org/10.58440/ihr-28-n07

Vũ Đăng Thái. (2023). Rủi ro hàng hải: Tổng quan và xu hướng nghiên cứu, Tạp chí Khoa học Công nghệ Hàng hải, 75(75), 82-87.

Weber, M. (1947). The Theory of Social and Economic Organization (A. M. Henderson và T. Parsons, trans.), Oxford University Press, New York. (Original work published 1922).

Wilhelmsen Ship Management. (2024). Marine Safety Management: Safety and Compliance Excellence. https://www.wilhelmsen.com/media-news-and-events/industry-perspectives/2024/marine-safety-management-systems/

Wilson, W. (1887). The Study of Administration, Political Science Quarterly, 2(2), 197-222. https://doi.org/10.2307/2139277

World Bank & International Association of Ports and Harbors (IAPH). (2021). Accelerating Digitalization: Critical Actions to Strengthen the Resilience of the Maritime Supply Chain, World Bank.

World Bank Group, Asian Development Bank, European Bank for Reconstruction and Development, Inter-American Development Bank, Islamic Development Bank, OECD, UNECE và UNESCAP. (2017). PPP Reference Guide 3.0 (Full version), World Bank Group.

World Bank. (1994). World Development Report 1994: Infrastructure for Development, Oxford University Press for the World Bank.
