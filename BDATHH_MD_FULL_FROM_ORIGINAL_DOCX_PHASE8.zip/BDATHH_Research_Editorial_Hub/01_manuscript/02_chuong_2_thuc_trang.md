# Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM

## 2.1. KHÁI QUÁT NGÀNH HÀNG HẢI VÀ BỘ MÁY QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM

### 2.1.1. Khái quát ngành hàng hải Việt Nam

Ngành hàng hải là bộ phận quan trọng của kinh tế biển Việt Nam, giữ vai trò kết nối thương mại và logistics toàn cầu. Trên thế giới, vận tải biển đảm nhận hơn 80% khối lượng hàng hóa thương mại, nên năng lực khai thác cảng và dịch vụ phụ trợ tác động trực tiếp đến chi phí logistics, độ tin cậy lịch trình và sức cạnh tranh hàng xuất khẩu (UNCTAD, 2025b). Việt Nam sở hữu 3.260 km bờ biển, nằm trên tuyến giao thương huyết mạch Đông Á và tiếp cận thuận lợi các trung tâm công nghiệp lớn như Trung Quốc, Nhật Bản, Hàn Quốc và ASEAN – tạo lợi thế chiến lược trong phát triển cảng biển và logistics (Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam, 2018).

Giai đoạn 2015–2025 ghi nhận sự chuyển dịch về chất trong cấu trúc hạ tầng ngành hàng hải, được thúc đẩy bởi xu hướng container hóa và quá trình tái cấu trúc tuyến vận tải quốc tế. Hệ thống cảng biển đã phát triển theo mô hình phân tầng chức năng rõ rệt. Tại khu vực phía Nam, cụm cảng Cái Mép – Thị Vải đã khẳng định năng lực vận hành tiệm cận chuẩn trung chuyển quốc tế khi tiếp nhận thành công các tàu mẹ có trọng tải lớn. Tại khu vực phía Bắc, cảng Lạch Huyện đã thiết lập các tuyến dịch vụ đi thẳng xuyên Thái Bình Dương, nâng cao vị thế của Việt Nam trong chuỗi giá trị hàng hải toàn cầu (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025a).

Hiệu quả của chiến lược đầu tư hạ tầng được phản ánh qua các chỉ tiêu tăng trưởng sản lượng cao. Năm 2024, tổng sản lượng hàng hóa thông qua hệ thống cảng biển đạt 864,4 triệu tấn, trong đó hàng container đạt 29,9 triệu TEU. Sang năm 2025, tổng lượng hàng hóa thông qua cảng biển và cảng thủy nội địa đạt khoảng 1,17 tỷ tấn, trong đó hàng container đạt 34,36 triệu TEU. Cùng thời điểm, đội tàu biển Việt Nam có 1.434 tàu với tổng trọng tải khoảng 9,4 triệu DWT. Những số liệu này cho thấy cường độ khai thác tăng nhanh, qua đó tạo áp lực lớn hơn lên hệ thống luồng hàng hải, báo hiệu, VTS, thông tin duyên hải, hoa tiêu và cơ chế giám sát chuyên ngành (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025a).

[FIGURE_PLACEHOLDER]
Figure ID: F_DOCX_001
Figure number: 2.1
Title: Sản lượng hàng hóa thông qua hệ thống cảng biển Việt Nam giai đoạn 2015–2025.
Asset: ../../05_figures/assets/F_DOCX_001.png
[/FIGURE_PLACEHOLDER]

Tương thích với phát triển hạ tầng cảng, đội tàu biển quốc gia cũng tăng về quy mô và năng lực vận tải. Tính đến hết năm 2025, đội tàu mang cờ quốc tịch Việt Nam có 1.434 tàu với tổng trọng tải khoảng 9,4 triệu DWT, xếp thứ 4 trong khu vực Đông Nam Á (Cục Hàng hải và Đường thủy Việt Nam, 2025a). Vị thế kết nối quốc tế được lượng hóa qua Chỉ số kết nối hàng hải (LSCI): Quý IV/2025, LSCI của Việt Nam đạt 63,2 điểm, duy trì vị trí thứ 7 toàn cầu và tăng trưởng 6% so với Quý I/2024 (UNCTADstat, n.d.). Tuy nhiên, khoảng cách so với Singapore (114,5 điểm) và Malaysia (99,2 điểm) cho thấy chênh lệch không chỉ về “điểm số”, mà về mô hình quản trị hạ tầng– dịch vụ: quốc gia dẫn đầu dựa nhiều vào số hóa đồng bộ, điều tiết động và quản trị theo dữ liệu; trong khi Việt Nam tiếp tục phải xử lý đồng thời hai nhiệm vụ: mở rộng dung lượng hệ thống và nâng cấp năng lực điều tiết an toàn theo chuẩn mực mới.

[FIGURE_PLACEHOLDER]
Figure ID: F_DOCX_002
Figure number: 2.2
Title: Chỉ số kết nối vận tải biển (LSCI) của Việt Nam và một số quốc gia ASEAN (2024–2025)
Asset: ../../05_figures/assets/F_DOCX_002.png
[/FIGURE_PLACEHOLDER]

Thực tiễn bối cảnh nêu trên không chỉ mang ý nghĩa đơn thuần về sự gia tăng sản lượng hay mở rộng quy mô không gian hạ tầng cảng biển (UNCTAD, 2025b). Quan trọng hơn, quy mô vận tải gia tăng đã tạo ra áp lực lớn lên hệ thống luồng tuyến, mạng lưới báo hiệu hàng hải, hệ thống quản lý giao thông tàu thuyền (VTS), thông tin duyên hải, dịch vụ hoa tiêu và các cơ chế giám sát chuyên ngành (Cục Hàng hải và Đường thủy Việt Nam, 2025c). Có thể thấy, sự phát triển nhanh chóng của ngành hàng hải chính là điều kiện thực tiễn khách quan yêu cầu cấp thiết: phương thức quản lý phải được đổi mới đồng bộ nhằm nâng cao kết quả quản lý nhà nước về bảo đảm an toàn hàng hải tại Việt Nam trong giai đoạn phát triển mới (Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam, 2018).

### 2.1.2. Bộ máy quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

#### 2.1.2.1. Cơ cấu quản lý nhà nước về bảo đảm an toàn hàng hải

Bộ máy quản lý nhà nước về bảo đảm an toàn hàng hải được tổ chức theo trục ngành dọc ở trung ương và địa bàn, kết hợp với các đơn vị cung ứng dịch vụ công ích. Điểm cần nhấn mạnh trong cấu trúc tổ chức không nằm ở việc có bao nhiêu đầu mối, mà ở khả năng phân định rành mạch: (i) quản lý nhà nước; (ii) tổ chức thực thi; (iii) cung ứng dịch vụ công và tương tác thị trường, từ đó hình thành chu trình ban hành, tổ chức thực hiện, giám sát đánh giá theo khung 2×3 của luận án. Cơ cấu quản lý được trình bày tại Bảng 2.1.

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_007
Table number: 2.1
Title: So sánh cơ cấu quản lý nhà nước về bảo đảm an toàn hàng hải trước và sau hợp nhất
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_007_candidate.md
[/TABLE_PLACEHOLDER]

Bảng 2.1 cho thấy việc đổi chủ thể quản lý cấp bộ từ tháng 3/2025 không chỉ là thay tên gọi mà còn yêu cầu chuẩn hóa phối hợp, phân cấp và trách nhiệm giải trình giữa Bộ Xây dựng với các cơ quan tham mưu, thực thi và các đơn vị cung ứng dịch vụ liên quan. Giai đoạn 2015–2025 gồm mô hình cũ trước tháng 3/2025 và giai đoạn chuyển tiếp sau đó, đòi hỏi xác định rõ trách nhiệm khi kế thừa chính sách, dữ liệu, tài sản và hợp đồng dịch vụ công.

#### 2.1.2.2. Vị trí, vai trò của Bộ Xây dựng trong quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

Sau khi hợp nhất Bộ Giao thông vận tải và Bộ Xây dựng (trước hợp nhất) theo mốc tháng 3/2025, Bộ Xây dựng (sau hợp nhất) trở thành chủ thể quản lý nhà nước cấp Bộ đối với lĩnh vực hàng hải, trong đó có bảo đảm an toàn hàng hải. Xét theo logic quản lý nhà nước, vai trò của Bộ không chỉ dừng ở việc ban hành văn bản quy phạm pháp luật, mà còn bao gồm định hướng quy hoạch, phân bổ nguồn lực, tổ chức thực thi và giám sát kết quả quản lý trên phạm vi cả nước. Nói cách khác, Bộ giữ vai trò đầu mối điều tiết, bảo đảm tính thống nhất của chính sách và sự liên thông của bộ máy thực thi (Chính phủ nước CHXHCN Việt Nam, 2025b). Vai trò này càng trở nên quan trọng trong bối cảnh hệ thống hàng hải mở rộng về quy mô, công nghệ thay đổi nhanh, yêu cầu số hóa tăng mạnh và mô hình cung ứng dịch vụ dần chuyển từ cơ chế hành chính sang cơ chế quản trị theo kết quả.

[FIGURE_PLACEHOLDER]
Figure ID: F_DOCX_003
Figure number: 2.3
Title: Sơ đồ tổ chức bộ máy quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam sau hợp nhất.
Asset: ../../05_figures/assets/F_DOCX_003.png
[/FIGURE_PLACEHOLDER]

Từ cấu trúc bộ máy và mạng lưới thực thi có thể rút ra một đặc điểm quản trị nổi bật của lĩnh vực bảo đảm an toàn hàng hải giai đoạn 2015–2025: cơ chế quản lý nhà nước mang tính “vừa tập trung theo ngành, vừa phân tán theo điểm thực thi” và phụ thuộc mạnh vào chất lượng phối hợp liên ngành – liên cấp. Điều này tạo điều kiện cho chuyên môn hóa và duy trì tính liên tục của dịch vụ, nhưng cũng làm tăng nguy cơ chồng chéo hoặc “khoảng trống trách nhiệm” nếu thiếu tiêu chuẩn hóa quy trình và thiếu cơ chế giám sát dựa trên dữ liệu.

#### 2.1.2.3. Chức năng, quyền hạn của Bộ Xây dựng trong quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

Theo khung phân tích 2×3 của luận án, chức năng và quyền hạn của Bộ Xây dựng được nhìn nhận theo hai nhóm nội dung và ba chức năng quản lý nhà nước. Đối với tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải, Bộ thực hiện chức năng ban hành hoặc trình ban hành thể chế, quy hoạch, tiêu chuẩn, định mức; tổ chức đầu tư, quản lý, khai thác và bảo trì kết cấu hạ tầng; đồng thời kiểm tra, thanh tra, giám sát, xử lý vi phạm và điều tra sự cố trong phạm vi quản lý. Đối với quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải, Bộ thực hiện chức năng ban hành danh mục dịch vụ, điều kiện cung ứng, khung giá và tiêu chuẩn chất lượng; tổ chức cấp phép, đặt hàng hoặc kiểm soát cung ứng dịch vụ; đồng thời giám sát chất lượng, xử lý vi phạm và giải quyết khiếu nại liên quan đến dịch vụ (Bộ Xây dựng, 2025a, 2025f, 2025g, 2025h, 2025i; Chính phủ nước CHXHCN Việt Nam, 2025b, 2025c, 2025d). Cách tiếp cận này cho phép làm rõ phạm vi quản lý nhà nước của Bộ Xây dựng và tạo cơ sở để đánh giá thực trạng ở mục 2.2 theo đúng logic khung 2x3.

Tóm lại, sự gia tăng nhanh chóng về quy mô và cường độ hoạt động của ngành hàng hải Việt Nam đã tạo ra những áp lực lớn, đòi hỏi hệ thống bảo đảm an toàn hàng hải phải không ngừng nâng cao năng lực đáp ứng (Cục Hàng hải và Đường thủy Việt Nam, 2025b, 2025c). Để giải quyết yêu cầu thực tiễn này, bộ máy quản lý nhà nước từng bước được kiện toàn xuyên suốt từ trung ương đến các cơ quan thực thi tại địa bàn và mạng lưới đơn vị cung ứng dịch vụ công ích. Đặc biệt, sự chuyển giao vai trò chủ thể hoạch định chính sách vĩ mô sang Bộ Xây dựng từ tháng 3/2025 đánh dấu một bước ngoặt quan trọng về tổ chức bộ máy (Chính phủ nước CHXHCN Việt Nam, 2025b, 2025e). Dù vậy, việc nhận diện cấu trúc các cơ quan quản lý và phân định thẩm quyền mới chỉ phác họa được bộ khung nền tảng. Để đo lường chính xác năng lực điều tiết và kết quả quản lý nhà nước trên thực địa trong giai đoạn 2015–2025, công tác phân tích cần đi sâu vào các khâu vận hành cụ thể. Quá trình đánh giá thực trạng này sẽ được triển khai chi tiết tại mục 2.2, bám sát sáu cấu phần của khung phân tích 2×3 nhằm làm rõ hai nội dung cốt lõi: (i) thực trạng tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải; và (ii) thực trạng quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải.

## 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025

### 2.2.1. Thực trạng tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải

#### 2.2.1.1. Ban hành cơ chế, pháp luật, quy hoạch hệ thống bảo đảm an toàn hàng hải

Trong quản lý nhà nước về bảo đảm an toàn hàng hải, việc ban hành văn bản pháp luật, quy hoạch và tiêu chuẩn đối với hệ thống giữ vai trò kiến tạo nền tảng thể chế, quyết định định hướng phát triển, phạm vi điều chỉnh và chuẩn mực kỹ thuật của toàn bộ hệ thống bảo đảm an toàn hàng hải. Chất lượng của khâu này không được quyết định chủ yếu bởi số lượng văn bản được ban hành, mà bởi mức độ đầy đủ, thống nhất, cập nhật và khả năng điều chỉnh toàn bộ vòng đời tài sản kết cấu hạ tầng hàng hải, từ quy hoạch, đầu tư, khai thác, bảo trì đến kiểm soát kỹ thuật.

Theo Báo cáo tổng kết thi hành Bộ luật Hàng hải, giai đoạn 2015–2025, cơ quan quản lý chuyên ngành cấp Bộ đã tham mưu Chính phủ ban hành 17 nghị định, trực tiếp ban hành 24 thông tư cùng nhiều quyết định liên quan đến quy hoạch, tiêu chuẩn, định mức kinh tế – kỹ thuật và các nội dung quản lý chuyên ngành (Bộ Xây dựng, 2026a). Xét về phạm vi điều chỉnh, hệ thống văn bản này bao quát các nhóm vấn đề chủ yếu như kinh doanh và thủ tục hành chính, quy hoạch cảng biển, phân luồng giao thông, bảo vệ công trình, đăng ký tàu, tiêu chuẩn kỹ thuật, báo hiệu hàng hải, AIS và bảo trì. Điều này cho thấy chức năng ban hành đã từng bước chuyển từ xử lý từng mảng nghiệp vụ riêng lẻ sang tạo lập khung điều chỉnh tương đối toàn diện đối với hệ thống bảo đảm an toàn hàng hải ở Việt Nam (Bộ Xây dựng, 2025i; Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2017).

(1) Hoàn thiện khung pháp lý quản lý vòng đời tài sản hạ tầng BĐATHH

Một chuyển biến đáng chú ý trong giai đoạn nghiên cứu là xu hướng chuyển từ tư duy quản lý “tài sản tĩnh” sang tư duy quản trị vòng đời tài sản. Các văn bản mới, đặc biệt là các quy định liên quan đến quản lý, sử dụng và khai thác tài sản kết cấu hạ tầng hàng hải, đã từng bước đặt nền pháp lý cho việc kiểm soát đầy đủ hơn các khâu đầu tư, khai thác, bảo trì, sử dụng và huy động nguồn lực ngoài ngân sách. Điểm thay đổi ở đây không chỉ nằm ở việc bổ sung thêm quy định, mà ở chỗ hệ thống pháp luật đã bắt đầu hình thành logic quản lý liên tục đối với tài sản hạ tầng hàng hải, thay vì chỉ điều chỉnh từng khâu riêng lẻ. Tuy nhiên, sự chuyển đổi này mới thể hiện rõ ở tầng khung pháp lý; còn ở tầng thực thi, cơ chế cập nhật định mức, phân bổ nguồn lực, dữ liệu vận hành và đo lường kết quả vẫn còn độ trễ nhất định (Bộ Giao thông vận tải, 2022; Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2024; Chính phủ nước CHXHCN Việt Nam, 2025d).

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_008
Table number: 2.2
Title: Hệ thống văn bản quy phạm pháp luật quản lý vòng đời tài sản
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_008_candidate.md
[/TABLE_PLACEHOLDER]

Về công tác bảo trì, duy tu công trình hàng hải, sự hoàn thiện của khung pháp lý về quản lý chất lượng và cơ chế tài chính (Chính phủ nước CHXHCN Việt Nam, 2019; Chính phủ nước CHXHCN Việt Nam, 2021a, 2021b) đã tạo ra chuẩn mực thống nhất về quy trình, hồ sơ và đánh giá an toàn, góp phần đặt công tác này vào hệ quy chiếu quản lý chất lượng công trình quốc gia. Qua đó, công tác bảo trì được thể chế hóa như một dịch vụ công có kế hoạch, có hợp đồng và có trách nhiệm giải trình, thay vì hoạt động xử lý sự cố mang tính tình thế. Ở cấp độ chuyên ngành, các quy định hướng dẫn hiện hành (Bộ Giao thông vận tải, 2022; Bộ Xây dựng, 2026d; Chính phủ nước CHXHCN Việt Nam, 2024) tiếp tục chuẩn hóa quy trình lập, phê duyệt và điều chỉnh kế hoạch bảo trì, bổ sung các công cụ định lượng như tiêu chí xác định tần suất khảo sát; đồng thời hoàn thiện cơ chế nạo vét duy tu theo chuẩn tắc, tăng cường giám sát thi công và nghiệm thu dựa trên chất lượng thực hiện.

Hệ thống văn bản nêu trên phản ánh cấu trúc ba tầng của khung pháp lý: từ việc thiết lập nền tảng quản lý, tạo bước đột phá về quản trị tài sản thông qua các cơ chế cho thuê, nhượng quyền khai thác và xã hội hóa, đến nỗ lực hệ thống hóa toàn diện. Thực tiễn này được minh chứng qua kết quả phân tích định lượng, khi các tiêu chí về mức độ đầy đủ và khả năng cập nhật chuẩn mực quốc tế của khung pháp lý đều đạt mức khá (đạt tương ứng 3,68/5 và 3,65/5). Tuy nhiên, tính đồng bộ và thống nhất của hệ thống thể chế vẫn là một hạn chế (đạt 3,58/5) (kết quả khảo sát của nghiên cứu sinh, 2025). Chi tiết các văn bản chính về tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải ở Việt Nam được thống kê trong hệ thống văn bản pháp luật và báo cáo chuyên ngành đã được tổng hợp trong luận án.

Nguyên nhân sâu xa của hạn chế này xuất phát từ sự phân mảnh trong công tác quản lý vòng đời tài sản, khi các giai đoạn đầu tư, khai thác và bảo trì đang chịu sự chi phối đan chéo của nhiều đạo luật chuyên ngành khác nhau (như Luật Xây dựng, Luật Đầu tư công, Luật Quản lý, sử dụng tài sản công). Bên cạnh đó, công tác đánh giá tác động chính sách (RIA) trong quá trình hoạch định chưa được thực hiện thực chất, dẫn đến rủi ro một số văn bản vừa ban hành đã bộc lộ bất cập.

(2) Về công tác quy hoạch hệ thống bảo đảm an toàn hàng hải.

Định hình không gian chiến lược và dự báo rủi ro vĩ mô. Ở cấp độ vĩ mô, Bộ Xây dựng đã tham mưu trực tiếp Thủ tướng Chính phủ ban hành Quyết định phê duyệt quy hoạch tổng thể và chi tiết hệ thống cảng biển. Điển hình là Quyết định số 1579/QĐ-TTg (2021) và các văn bản điều chỉnh bổ sung như Quyết định 442/QĐ-TTg (2024), Quyết định 140/QĐ-TTg (2025). Các văn bản này đã thiết lập một khuôn khổ quy hoạch tổng thể cho hệ thống bảo đảm an toàn hàng hải quốc gia, bao gồm 5 nhóm cảng biển với phân cấp luồng lạch, hệ thống bảo đảm an toàn hàng hải rõ ràng. Trên cơ sở đó Bộ đã trực tiếp ban hành hàng loạt các “quyết định phê duyệt quy hoạch chi tiết phát triển vùng đất, vùng nước cảng biển thời kỳ 2021 – 2030, tầm nhìn đến năm 2050” cho từng tỉnh, thành phố có biển được triển khai năm 2025 (Bộ Xây dựng, 2026a).

Trong bối cảnh biến động quốc tế và sự thay đổi của dòng chảy logistics toàn cầu, tư duy quy hoạch trong lĩnh vực hàng hải đã mở rộng theo hướng tích hợp các yếu tố rủi ro địa chính trị, an ninh phi truyền thống và phát triển cảng xanh vào hệ thống bảo đảm an toàn hàng hải. Theo đó, định hướng ưu tiên thiết lập các tuyến luồng nước sâu nhằm tiếp nhận tàu lớn không chỉ phục vụ mục tiêu nâng cao hiệu quả vận chuyển, mà còn hỗ trợ kiểm soát rủi ro trong bối cảnh khối lượng hàng hóa gia tăng. Quy hoạch mạng lưới an toàn hàng hải được xây dựng trên ba trụ cột chính: đồng bộ hóa với quy hoạch cảng biển; phát triển hệ thống đèn và trạm xa bờ không chỉ phục vụ bảo đảm an toàn mà còn gắn với yêu cầu khẳng định chủ quyền quốc gia; và phân định rõ giữa luồng công cộng với luồng chuyên dùng nhằm tối ưu hóa nguồn lực. Trên cơ sở đó, các quyết định quy hoạch chi tiết vùng đất, vùng nước cảng biển giai đoạn 2021–2030 đã tạo căn cứ cho việc bố trí báo hiệu, khu neo đậu và xác định các điểm trọng yếu cần ưu tiên đầu tư. Đồng thời, Nhà nước tập trung duy tu tại các khu vực có mức độ rủi ro cao, qua đó nâng cao tính chủ động trong bảo đảm an toàn hàng hải quốc gia.

Mặc dù đã ghi nhận một số kết quả tích cực trong định hình không gian phát triển, công cụ quy hoạch hiện hành của Việt Nam vẫn bộc lộ hạn chế khi đối sánh với các mô hình điều hành luồng thông minh ở một số quốc gia phát triển. Kinh nghiệm của Singapore và Nhật Bản cho thấy quy hoạch hiện đại ngày càng gắn chặt với dữ liệu thời gian thực, hệ thống VTIS/VTS và hướng dẫn điều hành số, trong khi quy hoạch của Việt Nam vẫn chủ yếu thiên về cấu trúc không gian và khảo sát định kỳ (Heikkilä et al., 2024; Japan Coast Guard, 2025; Japan Coast Guard – Osaka Wan Vessel Traffic Service Center (OSAKA MARTIS), 2025; MPA, 2025). Sự thiếu gắn kết giữa quy hoạch và dữ liệu vận hành làm giảm khả năng dự báo rủi ro sa bồi, tắc nghẽn cục bộ và ứng phó với các biến động bất thường của môi trường hàng hải (Bộ Xây dựng, 2026a). Bảng tổng hợp các văn bản về quy hoạch hệ thống bảo đảm an toàn hàng hải ở Việt Nam được trình bày chi tiết trong hệ thống văn bản pháp luật và báo cáo chuyên ngành đã được tổng hợp trong luận án.

(3) Công tác ban hành quy chuẩn/tiêu chuẩn kỹ thuật quốc gia về hệ thống bảo đảm an toàn hàng hải; Định mức kinh tế kỹ thuật và nội luật hóa các cam kết quốc tế

Hệ thống văn bản hiện tại đã bao quát các quy chuẩn, tiêu chuẩn kỹ thuật và định mức bảo đảm an toàn hàng hải, tạo điều kiện tốt cho công tác quản lý của nhà nước, tiệm cận dần tới các tiêu chuẩn quốc tế, điều này thể hiện qua kết quả phân tích định lượng: điểm số khả quan về hội nhập quốc tế (3,72/5) và nội luật hóa (3,65/5) (kết quả khảo sát của nghiên cứu sinh, 2025). Hệ thống văn bản định mức kinh tế kỹ thuật và tiêu chuẩn/quy chuẩn được trình bày chi tiết trong hệ thống văn bản pháp luật và báo cáo chuyên ngành đã được tổng hợp trong luận án.

Về thiết lập nền tảng kỹ thuật và chuẩn hóa an toàn hàng hải, hệ thống quy chuẩn và tiêu chuẩn kỹ thuật quốc gia trong lĩnh vực bảo đảm an toàn hàng hải từng bước được hoàn thiện theo hướng tương thích hơn với chuẩn mực quốc tế. Các tiêu chuẩn như TCVN 10703:2015 về đèn biển, TCVN 10704:2015 về hệ thống báo hiệu trên luồng hàng hải và TCVN 14141:2024 về phương pháp xác định tầm hiệu lực của báo hiệu đã chuẩn hóa yêu cầu kỹ thuật đối với thiết kế, vận hành và đánh giá chất lượng hệ thống (Bộ Khoa học và Công nghệ, 2015a, 2015b; Bộ Khoa học và Công nghệ, 2024). Cùng với đó, quy chuẩn QCVN 21:2025/BGTVT tiếp tục cập nhật yêu cầu phân cấp và đóng tàu biển vỏ thép, góp phần bảo đảm tính đồng bộ giữa kết cấu hạ tầng hàng hải, báo hiệu và phương tiện khai thác (Bộ Giao thông vận tải, 2025). Nhìn tổng thể, khung kỹ thuật hiện hành tạo cơ sở quan trọng cho nội luật hóa các chuẩn mực quốc tế về an toàn và môi trường hàng hải (IMO, 1973/1978; IMO, 1974).

Về ban hành định mức kinh tế – kỹ thuật, hiệu quả của công tác duy tu, bảo trì chỉ được bảo đảm khi hệ thống định mức bám sát điều kiện thi công thực tế và biến động của môi trường hàng hải. Thực tiễn Việt Nam cho thấy quá trình cập nhật định mức còn chậm so với biến động giá nhiên liệu, vật tư và tốc độ sa bồi tại nhiều khu vực, nhất là khu vực hạ nguồn đồng bằng sông Cửu

Long. Điều này làm gia tăng độ trễ trong công tác duy tu, nạo vét và tạo áp lực lên hiệu quả sử dụng ngân sách (Bộ Giao thông vận tải, 2023b; Bộ Xây dựng, 2026a). So với yêu cầu quản trị hiện đại dựa trên dữ liệu và rủi ro, cơ chế điều chỉnh định mức hiện nay vẫn còn nặng về thủ tục hành chính và chưa thật sự linh hoạt.

Không chỉ mở rộng về phạm vi thể chế trong nước, hệ thống văn bản pháp lý còn phản ánh mức độ hội nhập pháp lý quốc tế ngày càng sâu. Đến nay, Việt Nam đã là thành viên của 27 công ước quốc tế, 28 hiệp định vận tải biển và 34 thỏa thuận hàng hải với các nước (Bộ Xây dựng, 2026a). Điểm cần nhấn mạnh ở đây không chỉ là số lượng điều ước tham gia, mà là tác động của chúng đến cấu trúc quản lý nhà nước. Khi Việt Nam tham gia và thực thi các công ước như SOLAS 1974, MARPOL 73/78, STCW, BWM 2004, cùng các khuôn khổ hợp tác như IMO, IHO và ReCAAP ISC, hoạt động quản lý nhà nước về bảo đảm an toàn hàng hải không còn vận hành theo logic thuần túy nội địa, mà phải chuyển dần sang logic nội luật hóa tiêu chuẩn quốc tế, cập nhật quy chuẩn kỹ thuật, điều chỉnh cơ chế giám sát và nâng cao năng lực bộ máy. Điều đó cho thấy thể chế hàng hải của Việt Nam ngày càng chịu tác động trực tiếp từ môi trường pháp lý quốc tế và các chuẩn mực toàn cầu đang thay đổi theo xu hướng xanh hóa, số hóa và tăng cường an ninh hàng hải (IMO, 1973/1978; IMO, 1974; IMO, 1978; IMO, n.d.).

Xét tổng thể, nền tảng thể chế đối với hệ thống bảo đảm an toàn hàng hải đã được củng cố rõ hơn trong giai đoạn 2015–2025, tạo cơ sở pháp lý quan trọng cho quản lý đầu tư, khai thác và bảo trì hệ thống. Tuy nhiên, độ vênh giữa các tầng nấc pháp lý, độ trễ trong cập nhật chuẩn kỹ thuật và sự thiếu gắn kết giữa quy hoạch với dữ liệu vận hành vẫn làm suy giảm một phần kết quả quản lý nhà nước, đồng thời cho thấy yêu cầu tiếp tục hoàn thiện đồng bộ hơn khung thể chế quản lý hệ thống trong thời gian tới.

#### 2.2.1.2. Tổ chức thực hiện quản lý và vận hành hệ thống bảo đảm an toàn hàng hải

Nếu khâu ban hành tạo ra khuôn khổ thể chế, thì tổ chức thực hiện phản ánh trực tiếp năng lực chuyển hóa khuôn khổ đó thành kết quả vận hành của hệ thống bảo đảm an toàn hàng hải. Trọng tâm của khâu này nằm ở hiệu quả huy động, phân bổ và sử dụng nguồn lực đầu tư, bảo trì, khai thác; ở khả năng duy trì vùng phủ, độ tin cậy kỹ thuật và tính liên tục của hệ thống; đồng thời ở trình độ số hóa quản lý và chất lượng phối hợp giữa các chủ thể thực hiện. Do đó, giai đoạn 2015–2025 cần được đánh giá qua các phương diện như phát triển hệ thống gắn với hiện thực hóa quy hoạch, quản lý bảo trì và duy tu tài sản, tổ chức số hóa và quản trị dữ liệu, cũng như phát triển năng lực đội ngũ quản lý hệ thống.

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_009
Table number: 2.3
Title: Đối chiếu sự chuyển dịch mô hình quản trị hệ thống bảo đảm an toàn hàng hải
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_009_candidate.md
[/TABLE_PLACEHOLDER]

Dữ liệu giai đoạn 2015–2025 cho thấy quá trình này đã từng bước chuyển từ cách tiếp cận quản lý nặng về mệnh lệnh hành chính sang tiếp cận coi trọng hiệu quả đầu tư, tiêu chuẩn kỹ thuật, sự tách bạch giữa vai trò quản lý và kinh doanh, cũng như trách nhiệm giải trình trong quản lý dự án và vận hành hệ thống. Trên cơ sở đó, thực trạng giai đoạn 2015–2025, công tác tổ chức thực hiện quản lý và vận hành hệ thống bảo đảm an toàn hàng hải ở Việt Nam được phân tích qua các khía cạnh sau.

(1) Về quản lý đầu tư, phát triển hệ thống và hiện thực hóa quy hoạch

Về mở rộng vùng phủ và hiện đại hóa công nghệ, tính đến cuối năm 2025: hệ thống đèn biển duy trì 100 đèn, trong đó cuối năm 2025 nghiệm thu đưa vào sử dụng 5 đèn biển mới, gồm 26 đèn cấp I, 31 đèn cấp II và 38 đèn cấp III; hệ thống báo hiệu vận hành với 1.061 phao và 201 tiêu trên 44 tuyến luồng hàng hải công cộng. Hệ thống nhận dạng tự động (AIS) mở rộng với trên 100 trạm thu; hệ thống quản lý giao thông hàng hải (VTS) gồm 14 hệ thống, trong đó 7 đã đầu tư hoàn thành, 3 đang thực hiện đầu tư và 4 đang chuẩn bị đầu tư. Đối với hệ thống luồng hàng hải, Bộ phê duyệt và giao nhiệm vụ duy trì vận hành 44 tuyến luồng hàng hải công cộng với tổng chiều dài 1.110,211 km; năm 2025 hoàn thành 100% khối lượng khảo sát cho 43 tuyến luồng và 15 vùng đón trả hoa tiêu bảo đảm cung cấp kịp thời thông tin chính xác cho người đi biển. Các thiết bị ra đa dẫn đường (Racon), chớp đồng bộ và hải đồ điện tử (ENC) được triển khai đồng bộ, qua đó mở rộng khả năng cung cấp thông tin phục vụ hành hải (Bộ Xây dựng, 2026a).

[FIGURE_PLACEHOLDER]
Figure ID: F_DOCX_004
Figure number: 2.4
Title: Biểu đồ tăng trưởng hệ thống bảo đảm an toàn hàng hải Việt Nam, giai đoạn 2015–2025
Asset: ../../05_figures/assets/F_DOCX_004.png
[/FIGURE_PLACEHOLDER]

Biểu đồ trên phản ánh kết quả triển khai thực hiện các quy hoạch, kế hoạch do Bộ phê duyệt. Theo báo cáo của Tổng công ty bảo đảm an toàn hàng hải Việt Nam, 100% thời gian hoạt động của hệ thống đèn biển và luồng hàng hải đạt chất lượng yêu cầu, không để xảy ra sự cố, tai nạn hàng hải nào do lỗi của hệ thống báo hiệu. Việc hiện đại hóa công nghệ với các ứng dụng AIS, VTS và hải đồ điện tử đã góp phần nâng cao năng lực giám sát và hỗ trợ dẫn tàu, tiệm cận khuyến nghị của Hiệp hội các cơ quan quản lý báo hiệu hàng hải quốc tế (IALA).

Thực hiện chiến lược hiện đại hóa hạ tầng và phát triển hệ thống bảo đảm an toàn hàng hải, Bộ chuyên ngành đã tập trung phân bổ ngân sách cho xây dựng mới các công trình bảo đảm an toàn hàng hải và mua sắm trang thiết bị trọng điểm phục vụ cho công tác quản lý, vận hành hệ thống. Số liệu cụ thể theo Bảng 2.4 dưới đây:

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_010
Table number: 2.4
Title: Tổng hợp các dự án đầu tư và mua sắm trọng điểm liên quan tới hệ thống bảo đảm an toàn hàng hải
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_010_candidate.md
[/TABLE_PLACEHOLDER]

Bảng 2.4 cho thấy Bộ đầu tư hệ thống báo hiệu hàng hải với dự án 13 đèn biển tại các vị trí chiến lược và điều chỉnh các dự án theo yêu cầu thực tế. Đối với hạ tầng luồng tuyến, Bộ ưu tiên hoàn thiện Luồng cho tàu lớn vào sông Hậu (giai đoạn 2) với tổng số vốn gần 8.000 tỷ đồng để nâng cao khả năng tiếp cận cảng khu vực đồng bằng sông Cửu Long. Trong kế hoạch 2021–2025, các vùng miền Bắc và Nam đều được phân bổ vốn xây dựng cùng mua sắm phương tiện và trang thiết bị chuyên dụng, nhấn mạnh nâng cấp hệ thống đèn biển Trường Sa. Bộ cũng đã triển khai dự án đóng 02 tàu tiếp tế cho Trường Sa và đảo xa bờ. Định hướng 2026–2030 sẽ tiếp tục đầu tư hạ tầng hàng hải, đường thủy với các cấu phần ưu tiên như luồng tàu, kênh, Trung tâm tìm kiếm cứu nạn, hệ thống VTS và tàu cứu nạn, chuyển từ đầu tư đơn lẻ sang các gói năng lực tổng hợp.

Về phương thức huy động vốn, cấu trúc đầu tư hạ tầng hàng hải đã có sự chuyển dịch mang tính đột phá theo hướng giảm dần sự phụ thuộc vào ngân sách công. Theo Bộ Xây dựng (2026a), giai đoạn 2011–2020, tổng vốn đầu tư hệ thống hạ tầng hàng hải đạt 202 nghìn tỷ đồng, nhưng nguồn vốn ngoài ngân sách đã chiếm tới 86%. Định hướng đến năm 2030, tỷ lệ xã hội hóa dự kiến sẽ được đẩy lên mức 95% trong tổng nhu cầu vốn 312,6 nghìn tỷ đồng. Từ góc độ quản lý, việc sử dụng 5% vốn ngân sách như nguồn vốn dẫn dắt ban đầu nhằm huy động 297 nghìn tỷ đồng từ khu vực tư nhân thông qua các mô hình PPP cho thấy một minh chứng cho tư duy quản trị kiến tạo. Tuy nhiên, mô hình sử dụng vốn nhà nước có tính chất dẫn dắt ban đầu chỉ bền vững khi đi kèm cơ chế giám sát chất lượng thực thi PPP, tiêu chuẩn đầu ra và hệ thống dữ liệu đánh giá hiệu quả theo KPI, nếu không, rủi ro thiên lệch lợi ích và hiệu quả đầu tư thấp có thể gia tăng (World Bank, 1994).

(2) Về quản lý bảo trì, sử dụng, khai thác và duy tu tài sản kết cấu hạ tầng bảo đảm an toàn hàng hải

Trong giai đoạn 2015–2025, công tác duy tu, bảo trì hệ thống bảo đảm an toàn hàng hải được hoạch định và quản lý thông qua cơ chế giao dự toán chi sự nghiệp kinh tế hằng năm, dựa trên kế hoạch bảo trì được Bộ phê duyệt.

Nguồn lực được phân bổ tập trung vào hai cấu phần cốt lõi là nạo vét duy tu luồng hàng hải công cộng và sửa chữa công trình hàng hải (báo hiệu, đê kè, cầu cảng). Đối với hạng mục sửa chữa, kinh phí đã được điều chỉnh tăng dần từ 1,3 tỷ đồng (năm 2015) lên 71,3 tỷ đồng (năm 2017) và đạt 111,1 tỷ đồng (năm 2024) nhằm giải quyết tình trạng xuống cấp của hệ thống tài sản sau thời gian dài khai thác; đồng thời, khoản kinh phí bổ sung 53,5 tỷ đồng cũng được bố trí vào năm 2025 để xử lý dứt điểm khối lượng công việc tồn đọng từ giai đoạn 2017–2018 (Bộ Xây dựng, 2026a). Thực tiễn này phản ánh những hạn chế mang tính hệ thống khi kế hoạch ngân sách được lập theo từng năm tài khóa mà chưa bao quát trọn vẹn chu kỳ vòng đời tài sản, dẫn đến việc các hạng mục sửa chữa ngoài kế hoạch bị phát sinh. Kể từ năm 2025, trong quá trình tiếp nhận chức năng quản lý chuyên ngành, tổng dự toán chi hoạt động kinh tế đã được rà soát và điều chỉnh lên mức 3.250 tỷ đồng; tuy nhiên, cơ cấu phân bổ buộc phải thiết lập lại để tham mưu, trình Chính phủ nhằm đáp ứng yêu cầu tiết kiệm chi theo Nghị quyết số 173/NQ-CP, cho thấy tính ổn định của nguồn lực duy tu hạ tầng đang chịu sức ép nhất định trong giai đoạn chuyển tiếp thể chế (số liệu cụ thể, xem hồ sơ số liệu chi tiết).

[FIGURE_PLACEHOLDER]
Figure ID: F_DOCX_005
Figure number: 2.5
Title: Kinh phí bảo trì kết cấu hạ tầng hàng hải giai đoạn 2015–2026
Asset: ../../05_figures/assets/F_DOCX_005.png
[/FIGURE_PLACEHOLDER]

Một bước chuyển đáng chú ý khác là xu hướng thị trường hóa từng phần và tăng cường trách nhiệm giải trình. Việc áp dụng triệt để phương thức đặt hàng và đấu thầu dịch vụ công ích theo Nghị định số 32/2019/NĐ-CP (Chính phủ nước CHXHCN Việt Nam, 2019) và được sửa đổi, bổ sung bằng Nghị định số 214/2025/NĐ-CP (Chính phủ nước CHXHCN Việt Nam, 2025a) đã từng bước làm thay đổi vai trò của cơ quan quản lý nhà nước, từ can thiệp trực tiếp sang kiểm soát sản phẩm đầu ra. Quy trình nghiệm thu và quyết toán chi phí duy tu hiện nay được căn cứ trực tiếp trên kết quả đo đạc bình đồ thực tế và trạng thái chiếu sáng của báo hiệu, qua đó góp phần nâng cao hiệu quả sử dụng ngân sách nhà nước và tạo áp lực buộc các đơn vị thực hiện nâng cao năng lực kỹ thuật, tính minh bạch trong quá trình cung ứng.

Kết quả quản lý giai đoạn 2015–2025 ghi nhận mức độ ổn định tương đối cao của các chỉ số hiệu suất kỹ thuật và độ tin cậy của hệ thống. Dữ liệu tổng hợp cho thấy tỷ lệ hoạt động tin cậy của mạng lưới 95 trạm đèn biển quốc gia cùng hệ thống báo hiệu trên 45 tuyến luồng hàng hải công cộng luôn duy trì ở mức trên 99%, tăng trên 2% so với năm 2015. Chỉ số này không chỉ đáp ứng các quy chuẩn kỹ thuật quốc gia về hạ tầng kỹ thuật (QCVN 07:2016/BXD) mà còn đạt mức tương thích cao với các tiêu chuẩn quốc tế của IALA. Công tác bảo trì định kỳ trên 1.091 km luồng hàng hải đã giúp duy trì tương đối ổn định chuẩn tắc độ sâu thiết kế, cho phép tàu trọng tải lớn hành hải an toàn 24/7, qua đó giảm thiểu rủi ro mắc cạn và ùn tắc tại các cửa ngõ kinh tế trọng điểm (Bộ Khoa học và Công nghệ, 2015a, 2015b; Bộ Xây dựng, 2026a; IALA, 2017a).

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_011
Table number: 2.5
Title: Chỉ số độ tin cậy vận hành hệ thống bảo đảm an toàn hàng hải
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_011_candidate.md
[/TABLE_PLACEHOLDER]

Tuy nhiên, công tác quản lý bảo trì, duy tu công trình và luồng hàng hải vẫn đối mặt với những thách thức mang tính hệ thống khi phần lớn quá trình ra quyết định duy tu còn dựa trên mô hình bảo trì khắc phục hoặc bảo trì định kỳ mang tính cơ học. Việc thiếu các công cụ phân tích dữ liệu lớn và công nghệ dự báo xu hướng sa bồi khiến công tác nạo vét duy tu có thời điểm rơi vào trạng thái bị động trước những biến động bất thường của tự nhiên. Bên cạnh đó, nguồn vốn bảo trì, duy tu hạ tầng dùng chung hiện vẫn lệ thuộc gần như hoàn toàn vào ngân sách nhà nước; trong khi đó, giai đoạn 2011–2020 nhu cầu vốn bảo trì, duy tu là 15 nghìn tỷ đồng nhưng vốn thực tế chỉ bố trí được khoảng 7,6 nghìn tỷ đồng, tương đương khoảng 51% nhu cầu (Androjna et al., 2021). Điều này cho thấy chưa hình thành được hành lang pháp lý đủ mạnh để thu hút nguồn lực xã hội hóa tham gia thực chất vào công tác duy tu, bảo trì, qua đó làm gia tăng áp lực tài chính công khi quy mô hệ thống bảo đảm an toàn hàng hải tiếp tục mở rộng.

(3) Về số hóa, cải cách thủ tục hành chính và quản lý dữ liệu BĐATHH Trong giai đoạn 2015–2025, công tác quản lý nhà nước về bảo đảm an toàn hàng hải được triển khai song song với lộ trình chuyển đổi số và cải cách thủ tục hành chính ở các cấp. Ở giai đoạn đầu, định hướng chuyển đổi số tập trung vào việc xây dựng nền tảng dữ liệu và nâng cao hiệu quả công tác quản lý, phục vụ. Sau quá trình sắp xếp tổ chức, Bộ Xây dựng đã tiếp nhận và thống nhất quản lý lĩnh vực hàng hải, ban hành chiến lược chuyển đổi số giai đoạn 2025–2030 theo hướng hiện đại hóa, chuẩn hóa dữ liệu (Bộ Xây dựng, 2025b) và bảo đảm an toàn, an ninh mạng (Bộ Chính trị, 2024), với hai trọng tâm xuyên suốt là hoàn thiện cơ sở dữ liệu chuyên ngành và triển khai dịch vụ công trực tuyến gắn với cải cách thủ tục hành chính (Bộ Xây dựng, 2025d).

Thực tiễn cho thấy việc thiết lập nền tảng dữ liệu tài sản tập trung trong giai đoạn 2020–2025 đã ghi nhận những bước tiến đáng chú ý, thể hiện qua việc 100% dữ liệu đăng ký tàu biển và kiểm định kỹ thuật, với 11.497 lượt kiểm định từ năm 2017 đến 2022, được đồng bộ hóa trên môi trường số (Bộ Xây dựng, 2026a). Việc số hóa toàn bộ lý lịch kỹ thuật của 95 trạm đèn biển và 45 tuyến luồng công cộng đã cung cấp căn cứ khoa học hơn cho lập kế hoạch đầu tư và công tác bảo trì, góp phần hạn chế lãng phí nguồn lực nhà nước. Song song với quản lý tài sản tĩnh, việc ứng dụng công nghệ giám sát và điều tiết giao thông động cũng hỗ trợ nâng cao kết quả công tác bảo đảm an toàn hàng hải thông qua hệ thống thông tin địa lý (GIS), cho phép giám sát 1.061 phao báo hiệu bằng tín hiệu AIS/GSM. Theo lộ trình chính sách đã được phê duyệt, việc tích hợp dữ liệu từ hệ thống (VTS) và hải đồ điện tử (ENC) đã bước đầu tạo ra cơ sở dữ liệu tổng thể phục vụ điều tiết phương tiện và giảm thiểu rủi ro (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025c).

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_012
Table number: 2.6
Title: Mức độ số hóa các thành phần quản lý tài sản hệ thống bảo đảm an toàn hàng hải
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_012_candidate.md
[/TABLE_PLACEHOLDER]

Mặc dù đạt được những kết quả tích cực, thực trạng quản trị số vẫn bộc lộ những khoảng trống về tính liên thông và mức độ hiện đại hóa chuyên sâu. Dữ liệu hạ tầng hàng hải hiện vẫn tồn tại dưới dạng chuyên biệt, chưa thiết lập được cơ chế kết nối hoàn toàn với hệ thống ngành cũng như dữ liệu đường thủy nội địa. Sự thiếu đồng bộ này gây ra những điểm mù trong quản trị tại các tuyến luồng hỗn hợp, nơi giao thoa giữa hai thẩm quyền quản lý (Bộ Xây dựng, 2025a). Thêm vào đó, việc xây dựng mô hình bản sao số (Digital Twin) cho hạ tầng bảo đảm an toàn hàng hải, công cụ cho phép mô phỏng các kịch bản hỏng hóc và dự báo sa bồi vẫn đang ở giai đoạn sơ khởi.

(4) Về đào tạo và phát triển nguồn nhân lực quản lý hệ thống BĐATHH Giai đoạn 2015–2025 ghi nhận sự chuyển dịch đáng chú ý trong yêu cầu năng lực nhằm hình thành đội ngũ quản lý đầu tư có tính chuyên nghiệp hơn. Đội ngũ cán bộ hàng hải đã được tập trung bồi dưỡng chuyên sâu về kỹ năng quản lý hợp đồng theo chuẩn quốc tế (FIDIC), giám sát tiến độ và kiểm soát chất lượng dựa trên bằng chứng kỹ thuật. Quá trình chuyên nghiệp hóa này bước đầu mang lại kết quả thực tế thông qua việc giảm thiểu sai sót trong giai đoạn chuẩn bị đầu tư, góp phần nâng cao tỷ lệ giải ngân vốn đầu tư công hằng năm và hỗ trợ các công trình hạ tầng an toàn hàng hải hoàn thành đúng tiến độ phê duyệt (Bộ Giao thông vận tải, 2023a, 2023c).

Đi đôi với năng lực quản lý dự án, thực trạng đào tạo còn tập trung vào khả năng thích ứng với kỹ năng quản trị dữ liệu và công nghệ số. Nhằm đáp ứng lộ trình số hóa, các chương trình tập huấn về vận hành VTS, AIS và khai thác dữ liệu GIS đã được triển khai trên diện rộng. Tuy nhiên, kết quả giám sát thực tế cho thấy sự phân hóa tương đối rõ: trong khi đội ngũ tại các khu vực cảng biển cửa ngõ quốc tế đã từng bước làm chủ công nghệ giám sát hiện đại, thì năng lực công nghệ của nhân sự tại các cảng địa phương vẫn còn bộc lộ hạn chế, gây khó khăn cho việc đồng bộ hóa dữ liệu trên toàn hệ thống (Bộ Xây dựng, 2025h).

Dù đã chú trọng đào tạo, phát triển nhân lực quản lý vẫn gặp nhiều khó khăn như thiếu chuyên gia phân tích dữ liệu lớn, cơ chế đãi ngộ còn hạn chế khiến khó giữ chân nhân sự kỹ thuật cao, và chương trình đào tạo chưa thật sự đồng bộ, còn nặng về lý thuyết và thiếu tính thực hành. Những điểm yếu này cho thấy năng lực nhân sự vẫn là một hạn chế đáng chú ý trong quá trình hiện đại hóa quản lý hệ thống bảo đảm an toàn hàng hải (Bộ Xây dựng, 2025h).

Thực tiễn cho thấy tổ chức thực hiện quản lý và vận hành hệ thống bảo đảm an toàn hàng hải đã có bước chuyển theo hướng hiện đại hơn, góp phần nâng cao vùng phủ, độ tin cậy kỹ thuật và tính liên tục của hệ thống. Dẫu vậy, cơ chế bảo trì theo vòng đời, chất lượng liên thông dữ liệu, năng lực dự báo rủi ro và chất lượng nhân lực quản lý vẫn chưa đáp ứng đồng đều yêu cầu nâng cao hiệu lực, hiệu quả quản lý nhà nước, qua đó cho thấy khâu tổ chức thực hiện tuy đã chuyển biến nhưng chưa thật sự theo kịp yêu cầu của mô hình quản trị hiện đại.

#### 2.2.1.3. Giám sát, đánh giá hệ thống bảo đảm an toàn hàng hải

Giám sát và đánh giá là khâu bảo đảm kỷ luật vận hành và khả năng tự điều chỉnh của hệ thống bảo đảm an toàn hàng hải. Giá trị của khâu này không chỉ nằm ở tần suất thanh tra, kiểm tra, mà còn ở khả năng phát hiện rủi ro, nhận diện sai lệch trong vận hành, chuyển từ giám sát định kỳ sang giám sát dựa trên rủi ro và dữ liệu, đồng thời tạo ra vòng phản hồi chính sách từ kết quả giám sát và điều tra sự cố. Vì vậy, giai đoạn 2015–2025 cần được xem xét qua các phương diện như thanh tra, kiểm tra hệ thống; nghiệm thu và kiểm toán kỹ thuật; giám sát an toàn hàng hải và môi trường biển; điều tra sự cố; và mối liên hệ giữa giám sát hệ thống với kết quả an toàn hàng hải trên thực tế.

(1) Về hoạt động giám sát, đánh giá hệ thống bảo đảm an toàn hàng hải.

Hoạt động giám sát, đánh giá đối với hệ thống kết cấu hạ tầng bảo đảm an toàn hàng hải được tổ chức thông qua thanh tra chuyên ngành và hệ thống

Cảng vụ hàng hải. Theo các báo cáo tổng kết, công tác kiểm tra định kỳ, đột xuất đã được duy trì hằng năm trên phạm vi cả nước, tập trung vào luồng hàng hải, báo hiệu, vùng nước cảng biển, công trình hàng hải và các dịch vụ công ích có liên quan (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025a).

Bên cạnh hoạt động thanh tra chuyên ngành, các Cảng vụ hàng hải khu vực được Bộ phân cấp thực hiện kiểm tra thường xuyên đối với tình trạng báo hiệu, luồng và vùng nước trong phạm vi quản lý. Tổng công ty Bảo đảm an toàn hàng hải Việt Nam cũng thực hiện hoạt động tự kiểm tra, đánh giá nội bộ theo quy định do Bộ ban hành. Kết quả khảo sát cho thấy điểm trung bình của biến "Thanh tra, kiểm tra an toàn hàng hải được thực hiện thường xuyên" (B3_1) đạt 3,48/5, phản ánh nhận định tương đối tích cực về tần suất hoạt động thanh tra (kết quả khảo sát của nghiên cứu sinh, 2025).

Tuy nhiên, phương pháp tiếp cận trong hoạt động thanh tra, kiểm tra vẫn còn một số hạn chế. Biến "Công tác thanh tra an toàn hàng hải được áp dụng theo hướng dựa trên rủi ro, không chỉ thực hiện định kỳ" (B3_3) chỉ đạt điểm trung bình 3,25/5, cho thấy việc chuyển đổi từ giám sát định kỳ sang giám sát dựa trên rủi ro còn chậm (kết quả khảo sát của nghiên cứu sinh, 2025). Đối với các hệ thống kỹ thuật hiện đại như VTS và AIS, hoạt động kiểm tra, giám sát đòi hỏi chuyên môn sâu và thiết bị chuyên dụng, trong khi năng lực đội ngũ cán bộ kiểm tra còn hạn chế, nhất là đối với các công nghệ mới.

(2) Về nghiệm thu chất lượng công trình và kiểm toán kỹ thuật hệ thống

Công tác này hiện nay đang đối mặt với thách thức kép về công nghệ giám sát và khung pháp lý điều chỉnh. Đối với nạo vét duy tu luồng hàng hải, tức hạng mục chiếm tỷ trọng lớn trong ngân sách bảo trì, cơ chế giám sát đã có bước chuyển dịch tích cực thông qua ứng dụng công nghệ. Từ năm 2019, Bộ Xây dựng đã yêu cầu tất cả phương tiện thi công nạo vét lắp đặt thiết bị nhận dạng tự động và camera giám sát hành trình để kiểm soát vị trí đổ thải. Quy định này, được củng cố bởi Thông tư số 43/2024/TT-BGTVT ngày 19/11/2024 của Bộ, đã góp phần hạn chế tình trạng gian lận khối lượng và nhận chìm chất nạo vét sai vị trí. Tuy nhiên, trong một thời gian dài, việc chưa sử dụng hệ thống

AIS để giám sát hoạt động nạo vét duy tu luồng hàng hải đã tạo ra khoảng trống đáng kể, làm gia tăng rủi ro thất thoát, lãng phí ngân sách nhà nước. Ngoài ra, Bộ luật Hàng hải Việt Nam năm 2015 hiện chưa có quy định cụ thể ở cấp luật đối với dịch vụ nạo vét duy tu luồng hàng hải công cộng để bảo đảm chuẩn tắc thiết kế, dẫn đến thiếu cơ sở cho các chế tài kiểm toán chuyên biệt (Bộ Xây dựng, 2026a). Mặc dù hệ thống văn bản pháp luật đã quy định tương đối chi tiết về quản lý chất lượng và bảo trì công trình hàng hải, điển hình là Thông tư số 19/2022/TT-BGTVT, Thông tư số 40/2023/TT-BGTVT và Thông tư số 42/2019/TT-BGTVT quy định về tiêu chí kiểm tra, giám sát, đánh giá, nghiệm thu chất lượng dịch vụ sự nghiệp công bảo đảm an toàn hàng hải, nhưng thực tiễn cho thấy công tác này vẫn mang nặng tính hậu kiểm hành chính hơn là kiểm toán kỹ thuật độc lập. Các chuyên gia trong ngành cho rằng việc thiếu vắng cơ chế kiểm toán độc lập về kỹ thuật làm gia tăng rủi ro thất thoát ngầm về ngân sách, khi tuổi thọ thực tế của công trình có thể thấp hơn tuổi thọ thiết kế, qua đó tạo áp lực lên ngân sách bảo trì trong dài hạn (Bộ Giao thông vận tải, 2019; Bộ Giao thông vận tải, 2022; Bộ Giao thông vận tải, 2023b).

(3) Về hoạt động giám sát an toàn hàng hải và môi trường biển

Trong giai đoạn từ năm 2017 đến ngày 21/10/2024, trong khu vực Tokyo

MOU đã có 7.194 lượt tàu biển Việt Nam bị kiểm tra, phát hiện 17.622 khiếm khuyết liên quan đến 4.909 lượt tàu; có 191 lượt tàu bị lưu giữ, tương ứng tỷ lệ lưu giữ 3,23% (Bộ Xây dựng, 2026a). Sau nhiều năm ở Danh sách đen, đội tàu biển Việt Nam đã duy trì trong danh sách trắng kể từ năm 2014. Đây là chỉ dấu quan trọng cho thấy năng lực giám sát và tuân thủ chuẩn mực quốc tế của hệ thống quản lý nhà nước đã được cải thiện, đồng thời được “thẩm định” bởi cơ chế kiểm soát cảng biển khu vực (Bộ Xây dựng, 2026a; Tokyo Memorandum of Understanding on Port State Control, n.d.).

Ngoài giám sát an toàn khai thác tàu, năng lực cưỡng chế và xử lý các quan hệ pháp lý phức tạp phát sinh trong hoạt động hàng hải cũng từng bước được nâng lên. Giai đoạn 2017–2023, các cảng vụ hàng hải đã thực hiện bắt giữ 43 tàu biển theo quyết định của tòa án. Trong lĩnh vực xử lý tài sản chìm đắm, Cục Hàng hải và Đường thủy Việt Nam đã phê duyệt 1 phương án trục vớt thuộc thẩm quyền của Bộ; riêng khối cảng vụ hàng hải ghi nhận khoảng 44 vụ việc xử lý tài sản chìm đắm (Bộ Xây dựng, 2026a). Các số liệu này cho thấy công tác kiểm tra, giám sát không chỉ giới hạn trong kiểm tra hành chính, mà còn bao gồm khả năng quản lý các rủi ro pháp lý, tài sản và môi trường phát sinh từ tai nạn, đắm chìm, tranh chấp hàng hải và xử lý hậu quả. Đây là biểu hiện của năng lực giám sát hệ thống theo nghĩa rộng, tức giám sát cả quá trình vận hành lẫn hậu quả phát sinh từ vận hành.

Giám sát môi trường trong hoạt động nạo vét và nhận chìm vật chất ở biển vẫn là một hạn chế chưa được xử lý triệt để. Báo cáo tổng kết thi hành Bộ luật Hàng hải Việt Nam năm 2015 cho thấy quá trình thực thi còn gặp khó khăn do thiếu quy hoạch vị trí nhận chìm ổn định, lâu dài và do khung pháp lý chưa bao quát đầy đủ một số dịch vụ mới phát sinh như nạo vét duy tu luồng công cộng (Bộ Xây dựng, 2026a). Bên cạnh đó, công tác quan trắc sa bồi và dự báo biến động luồng tuyến còn thụ động, làm tăng nguy cơ bồi lắng cục bộ trước khi thủ tục nạo vét được kích hoạt.

(4) Về điều tra sự cố hệ thống bảo đảm an toàn hàng hải

Quy trình điều tra tai nạn, sự cố hàng hải đã được Bộ quy định tại Thông tư số 01/2020/TT-BGTVT. Tuy nhiên, trọng tâm của các cuộc điều tra thường nghiêng về việc xác định trách nhiệm bồi thường và xử phạt hành chính hơn là phân tích nguyên nhân gốc rễ để cải tiến hệ thống (Bộ Giao thông vận tải, 2025). Dữ liệu khảo sát chuyên gia cho thấy các chỉ số kỹ thuật quan trọng như thời gian trung bình để khắc phục sự cố chưa được đo lường và công bố rộng rãi như một chỉ số hiệu suất bắt buộc (World Bank & International Association of Ports and Harbors [IAPH], 2021). Hơn nữa, kết quả điều tra sự cố chưa thực sự tạo ra cơ chế phản hồi để điều chỉnh quy hoạch hoặc quy trình vận hành. Chẳng hạn, các sự cố đâm va làm hư hỏng cầu cảng hoặc phao tiêu thường được xử lý cục bộ, thiếu sự tổng hợp dữ liệu để nhận diện các điểm đen hạ tầng nhằm điều chỉnh thiết kế luồng hoặc phương án phân luồng giao thông một cách căn cơ.

Báo cáo tổng kết cho thấy công tác thanh tra, kiểm tra đối với lĩnh vực bảo đảm an toàn hàng hải đã được tăng cường rõ hơn trong giai đoạn sau năm 2020; đồng thời, năng lực khắc phục sự cố báo hiệu và duy trì trạng thái vận hành an toàn của hệ thống cũng được cải thiện nhờ ứng dụng dữ liệu tập trung và các công cụ giám sát tự động (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025a). Tuy vậy, hiệu quả của giám sát vẫn chưa đồng đều giữa các nhóm công việc, đặc biệt ở các dự án nạo vét duy tu luồng hàng hải.

Việc tăng số lượng các cuộc thanh tra, kiểm tra đã góp phần phát hiện và xử lý kịp thời hơn các nguy cơ tiềm ẩn, đồng thời nâng cao ý thức tuân thủ của các đơn vị vận hành hàng hải. Đặc biệt tại các vùng nước có mật độ tàu thuyền cao, giám sát thường xuyên tạo thêm điều kiện hỗ trợ kiểm soát rủi ro, góp phần giảm nguy cơ xảy ra tai nạn và duy trì sự thông suốt của hoạt động thương mại, vận tải biển. Bên cạnh đó, tỷ lệ khắc phục sự cố báo hiệu kịp thời gia tăng cũng phản ánh hiệu quả bước đầu của việc đầu tư vào công nghệ quản lý hiện đại. Tuy nhiên, các kết quả này chưa đồng đều giữa các nhóm công việc; vi phạm vẫn còn tồn tại, nhất là trong các dự án nạo vét duy tu luồng hàng hải.

Qua công tác kiểm tra, thanh tra, nhiều vi phạm tại các doanh nghiệp và đơn vị khai thác cảng đã được phát hiện. Minh chứng điển hình là Kết luận thanh tra số 39/KL-TTr ngày 24/10/2025 đối với Công ty Cảng Container Trung tâm Sài Gòn, trong đó cơ quan thanh tra chỉ ra các sai phạm liên quan đến khảo sát, bảo trì công trình, quản lý giá dịch vụ và công tác môi trường (Thanh tra, 2025). Trường hợp này cho thấy khoảng cách đáng kể giữa yêu cầu của khung pháp lý với năng lực tuân thủ và giám sát ở cấp cơ sở.

(5) Mối quan hệ giữa giám sát hệ thống và kết quả an toàn hàng hải

Một trong những mục tiêu quan trọng của công tác kiểm tra, giám sát hệ thống là góp phần giảm thiểu tai nạn, sự cố hàng hải. Thống kê tai nạn hàng hải giai đoạn 2018–2025 cho thấy xu hướng giảm cả về số vụ và mức độ nghiêm trọng; số vụ tai nạn giảm từ 18 vụ năm 2018 xuống còn 6 vụ năm 2023 và tiếp tục duy trì con số này đến năm 2025, trong khi số người chết và mất tích cũng giảm đáng kể (Cục Hàng hải và Đường thủy Việt Nam, 2025c). Xu hướng này phản ánh những nỗ lực trong công tác quản lý an toàn hàng hải nói chung, trong đó có đóng góp của việc duy trì và nâng cấp hệ thống bảo đảm an toàn hàng hải.

[FIGURE_PLACEHOLDER]
Figure ID: F_DOCX_006
Figure number: 2.6
Title: Biểu đồ diễn biến tai nạn hàng hải giai đoạn 2015–2025.
Asset: ../../05_figures/assets/F_DOCX_006.png
[/FIGURE_PLACEHOLDER]

Tuy nhiên, số liệu hiện có chưa cho phép xác định một cách định lượng mối quan hệ nhân quả trực tiếp giữa chất lượng giám sát hệ thống và tỷ lệ tai nạn. Nguyên nhân là do: (i) chưa có phân loại tai nạn theo nguyên nhân liên quan đến hệ thống bảo đảm an toàn hàng hải; (ii) dữ liệu về tình trạng kỹ thuật của hệ thống tại thời điểm xảy ra tai nạn chưa được thu thập và phân tích một cách hệ thống; (iii) còn nhiều yếu tố nhiễu khác (lỗi con người, thời tiết, điều kiện hàng hải...). Kết quả phân tích định lượng cũng cho thấy nhân tố H3 (Giám sát hệ thống) phản ánh mức độ tác động chưa có ý nghĩa thống kê, qua đó cho thấy chất lượng và hiệu quả của công tác giám sát hiện tại vẫn còn những khoảng trống cần tiếp tục được nhận diện và xử lý (kết quả phân tích định lượng của nghiên cứu sinh, 2025).

Có thể khái quát rằng hoạt động giám sát và đánh giá hệ thống đã được duy trì và từng bước tăng cường, góp phần hỗ trợ kiểm soát vận hành hệ thống bảo đảm an toàn hàng hải. Tuy nhiên, khâu này vẫn nghiêng về hậu kiểm hành chính, chưa đạt chiều sâu kỹ thuật cần thiết và chưa hình thành được cơ chế phản hồi chính sách đủ mạnh để tạo chuyển biến rõ rệt về chất lượng quản lý hệ thống. Đây cũng là dấu hiệu cho thấy giám sát vẫn là một mắt xích còn yếu so với yêu cầu quản lý nhà nước trong bối cảnh mới.

### 2.2.2. Thực trạng quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

#### 2.2.2.1. Ban hành cơ chế, chính sách về dịch vụ bảo đảm an toàn hàng hải

Trên phương diện quản lý cung ứng dịch vụ, việc ban hành cơ chế, chính sách phản ánh năng lực xác lập trật tự pháp lý của Nhà nước đối với các dịch vụ bảo đảm an toàn hàng hải. Cốt lõi của khâu này là xác định rõ phạm vi dịch vụ, chuẩn hóa tiêu chuẩn chất lượng có thể đo lường, quy định điều kiện năng lực của chủ thể cung ứng phù hợp với yêu cầu công nghệ và hội nhập, đồng thời thiết kế cơ chế giá, cơ chế tài chính và chuẩn nhân lực có khả năng định hướng nâng cao chất lượng dịch vụ. Từ góc nhìn đó, giai đoạn 2015–2025 cần được phân tích theo ba phương diện chính là thiết lập danh mục dịch vụ và chuẩn chất lượng, xây dựng khung giá và cơ chế tài chính, và chuẩn hóa năng lực nhân lực dịch vụ bảo đảm an toàn hàng hải.

(1) Thiết lập danh mục dịch vụ, tiêu chuẩn chất lượng và điều kiện kinh doanh dịch vụ bảo đảm an toàn hàng hải

Trên cơ sở Bộ luật Hàng hải Việt Nam năm 2015, hệ thống văn bản hướng dẫn được ban hành qua các giai đoạn đã từng bước cụ thể hóa các loại hình dịch vụ bảo đảm an toàn hàng hải, làm rõ phạm vi dịch vụ sử dụng ngân sách nhà nước, dịch vụ thực hiện theo cơ chế đặt hàng, giao nhiệm vụ hoặc đấu thầu, cũng như trách nhiệm của cơ quan quản lý chuyên ngành. Các nghị định sửa đổi trong lĩnh vực hàng hải ban hành năm 2025 tiếp tục điều chỉnh, cập nhật cơ chế quản lý đối với các dịch vụ công ích và dịch vụ hỗ trợ an toàn hàng hải theo hướng rõ hơn về phạm vi điều chỉnh và trách nhiệm tổ chức thực hiện (Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2025c; Quốc hội nước CHXHCN Việt Nam, 2015). Bảng danh mục các dịch vụ bảo đảm an toàn hàng hải và các văn bản pháp luật điều chỉnh được trình bày trong hệ thống văn bản pháp luật và báo cáo chuyên ngành đã được tổng hợp trong luận án.

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_013
Table number: 2.7
Title: Phân loại danh mục dịch vụ bảo đảm an toàn hàng hải
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_013_candidate.md
[/TABLE_PLACEHOLDER]

Giai đoạn này ghi nhận sự chuyển dịch từ cơ chế chỉ định hành chính sang cơ chế quản lý ngành nghề kinh doanh có điều kiện dựa trên năng lực thực tế. Các nghị định về điều kiện kinh doanh dịch vụ hàng hải, sửa đổi năm 2018 và năm 2022, đã tạo hành lang pháp lý cụ thể hơn đối với các dịch vụ cốt lõi như bảo đảm an toàn hàng hải, hoa tiêu, trục vớt cứu hộ và các dịch vụ hỗ trợ liên quan (Chính phủ nước CHXHCN Việt Nam, 2016; Chính phủ nước CHXHCN Việt Nam, 2022). Hệ thống văn bản này thiết lập các nhóm điều kiện về năng lực tài chính, phương tiện chuyên dùng và nhân sự có chứng chỉ chuyên môn, qua đó chuẩn hóa đầu vào của thị trường dịch vụ.

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_014
Table number: 2.8
Title: Hệ thống văn bản thiết lập tiêu chuẩn chất lượng dịch vụ bảo đảm an toàn hàng hải
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_014_candidate.md
[/TABLE_PLACEHOLDER]

Tiêu chuẩn chất lượng dịch vụ bảo đảm an toàn hàng hải đã từng bước được nội luật hóa dựa trên khuyến nghị của IALA và IMO. Đối với đèn biển, TCVN 10703:2015 quy định chỉ số khả dụng theo nhóm đèn; đối với hệ thống báo hiệu trên luồng, TCVN 10704:2015 quy định ngưỡng chỉ số khả dụng tổng hợp của hệ thống báo hiệu; còn đối với quản lý chất lượng dịch vụ sự nghiệp công, Thông tư số 42/2019/TT-BGTVT và Thông tư số 40/2023/TT-BGTVT đã bổ sung tiêu chí kiểm tra, giám sát và nghiệm thu đối với các nhóm dịch vụ chủ yếu (Bộ Giao thông vận tải, 2019; Bộ Giao thông vận tải, 2023b; Bộ Khoa học và Công nghệ, 2015a, 2015b). Tuy vậy, hệ thống hiện hành vẫn thiên về chuẩn hóa yêu cầu kỹ thuật đầu ra, chưa phát triển đầy đủ thành các cam kết mức dịch vụ (SLA) có tính tích hợp cho toàn hệ thống bảo đảm an toàn hàng hải (IALA, 2017a; IALA, 2023).

(2) Xây dựng và ban hành khung giá và cơ chế tài chính dịch vụ bảo đảm an toàn hàng hải

Giai đoạn 2015–2025 chứng kiến xu hướng chuyển từ quản lý phí, lệ phí sang quản lý giá dịch vụ đối với nhiều dịch vụ tại cảng biển và dịch vụ hỗ trợ hàng hải. Việc thực hiện Thông tư số 261/2016/TT-BTC và sau đó là Thông tư số 12/2024/TT-BGTVT đã làm rõ hơn cơ chế thu, nộp, quản lý phí, lệ phí hàng hải và cơ chế chính sách quản lý giá dịch vụ tại cảng biển (Bộ Giao thông vận tải, 2024b; Bộ Tài chính, 2016). Đây không chỉ là sự thay đổi về công cụ tài chính, mà còn tác động trực tiếp đến cách thức điều tiết thị trường dịch vụ hàng hải.

Bộ đã cụ thể hóa khung pháp lý điều chỉnh hoạt động của nhiều loại hình dịch vụ bảo đảm an toàn hàng hải thông qua các văn bản về giá dịch vụ, định mức kinh tế – kỹ thuật và cơ chế đặt hàng. Điển hình là Thông tư số 37/2021/TT-BGTVT về giá dịch vụ sự nghiệp công bảo đảm an toàn hàng hải, Thông tư số 44/2018/TT-BGTVT về định mức nạo vét công trình hàng hải, Thông tư số 12/2024/TT-BGTVT về cơ chế, chính sách quản lý giá dịch vụ tại cảng biển và Quyết định số 814/QĐ-BGTVT về giá tối đa dịch vụ hoa tiêu hàng hải tại cảng biển Việt Nam (Bộ Giao thông vận tải, 2021a; Bộ Giao thông vận tải, 2024a, 2024b). Các quy định này yêu cầu xây dựng định mức, đơn giá và tiêu chí chất lượng, qua đó tăng trách nhiệm của doanh nghiệp cung ứng và từng bước giảm tính bao cấp trong cung ứng dịch vụ. Tuy nhiên, cơ chế “giá dịch vụ” vẫn còn một số bất cập như độc quyền hoa tiêu, thiếu lựa chọn nhà cung cấp, khung giá đồng loạt trong khi điều kiện phục vụ khác nhau, và việc điều chỉnh giá chưa dựa trên kết quả đầu ra (SLA/KPI), khiến công cụ giá chưa thật sự trở thành đòn bẩy nâng cao chất lượng dịch vụ và hiệu quả quản lý.

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_015
Table number: 2.9
Title: Hệ thống văn bản về cơ chế tài chính và điều kiện năng lực đơn vị cung ứng
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_015_candidate.md
[/TABLE_PLACEHOLDER]

Quy định tiêu chuẩn đào tạo, cấp/thu hồi chứng chỉ hoa

tiêu hàng hải.

Mặc dù vậy, đối với nhóm dịch vụ công ích thiết yếu như vận hành đèn biển và nạo vét luồng công cộng, cơ chế tài chính vẫn còn nhiều bất cập. Việc áp dụng cơ chế đặt hàng theo Nghị định số 32/2019/NĐ-CP và hệ thống định mức kinh tế – kỹ thuật hiện hành đã minh bạch hơn cơ chế giao dự toán cũ, nhưng vẫn chịu độ trễ lớn so với biến động giá nhiên liệu, vật tư và điều kiện thi công thực tế (Bộ Giao thông vận tải, 2021b; Chính phủ nước CHXHCN Việt Nam, 2019). Báo cáo tổng kết cũng cho thấy nguồn vốn ngân sách bố trí cho bảo trì kết cấu hạ tầng hàng hải giai đoạn 2011–2020 chỉ đáp ứng khoảng 51% nhu cầu tính toán, làm gia tăng rủi ro “cắt khúc nhiệm vụ” và suy giảm hiệu quả bảo trì theo vòng đời tài sản (Bộ Xây dựng, 2026a). Danh mục các văn bản về cơ chế tài chính dịch vụ bảo đảm an toàn hàng hải được trình bày trong hệ thống văn bản pháp luật và báo cáo chuyên ngành đã được tổng hợp trong luận án.

(3) Chuẩn hóa năng lực nhân lực dịch vụ bảo đảm an toàn hàng hải

Nhà nước luôn xác định yếu tố con người là trung tâm trong việc nâng cao chất lượng dịch vụ bảo đảm an toàn hàng hải và đã được thể hiện qua Quyết định số 1901/QĐ-TTg về phát triển Trường Đại học Hàng hải Việt Nam thành trường trọng điểm quốc gia. Quyết định này nhấn mạnh mối liên hệ giữa đào tạo nhân lực và yêu cầu vận hành an toàn các dịch vụ hàng hải. Bộ Xây dựng tiếp tục cụ thể hóa mục tiêu chuẩn hóa năng lực nhân lực bằng Quyết định số 2287/QĐ-BXD, chuyển trọng tâm từ quản lý số lượng sang chất lượng và đầu ra. Các nhiệm vụ như mở rộng quy mô đào tạo, phát triển chương trình chuyên sâu, tăng cường thực hành kỹ thuật cao, thúc đẩy chuyển đổi số, kiểm định chất lượng quốc tế và hợp tác quốc tế đều nhằm chuẩn hóa năng lực nghề nghiệp cho nhân lực hàng hải, đáp ứng yêu cầu dịch vụ hiện đại (Bộ Xây dựng, 2025c; Thủ tướng Chính phủ, 2025b).

Ở tầng thực thi chuyên ngành, công tác chuẩn hóa năng lực nhân lực dịch vụ bảo đảm an toàn hàng hải được củng cố thông qua hệ thống thông tư quy định tiêu chuẩn chuyên môn, điển hình như Thông tư số 20/2023/TT-BGTVT quy định tiêu chuẩn chuyên môn, chứng chỉ chuyên môn, đào tạo, huấn luyện thuyền viên và định biên an toàn tối thiểu của tàu biển Việt Nam; Thông tư số 57/2023/TT-BGTVT quy định chương trình đào tạo, huấn luyện thuyền viên, hoa tiêu hàng hải; và Thông tư số 31/2025/TT-BXD tiếp tục hoàn thiện khung pháp lý về tiêu chuẩn đào tạo hoa tiêu hàng hải, cấp và thu hồi chứng chỉ chuyên môn, giấy chứng nhận vùng hoạt động (Bộ Giao thông vận tải, 2023a, 2023c; Bộ Xây dựng, 2025h). Nhìn chung, hệ thống này đã hỗ trợ quá trình nội luật hóa chuẩn STCW và từng bước chuẩn hóa năng lực của đội ngũ thuyền viên, hoa tiêu và nhân lực vận hành dịch vụ (IMO, 1978).

Tổng hợp lại, khung thể chế quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải giai đoạn 2015–2025 đã góp phần thiết lập trật tự pháp lý cho thị trường dịch vụ, nâng cao mức độ chuẩn hóa điều kiện kinh doanh và từng bước minh bạch hóa cơ chế giá, đặt hàng và đào tạo nhân lực. Tuy nhiên, quản lý vẫn còn thiên về kiểm soát đầu vào; hệ thống KPI/SLA và cơ chế đánh giá đầu ra chưa được thiết kế đầy đủ để tạo áp lực cải thiện chất lượng dịch vụ một cách thực chất (Bộ Xây dựng, 2025g, 2025h; Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2016; Chính phủ nước CHXHCN Việt Nam, 2022).

Xét tổng thể, khuôn khổ chính sách đối với dịch vụ bảo đảm an toàn hàng hải đã rõ hơn trước, góp phần định hình trật tự pháp lý cho thị trường dịch vụ và nâng cao mức độ chuẩn hóa trong quản lý. Tuy nhiên, hệ thống chính sách hiện hành vẫn đậm dấu ấn kiểm soát đầu vào, trong khi các công cụ quản lý theo đầu ra, cam kết mức dịch vụ và cơ chế thúc đẩy cạnh tranh bằng chất lượng còn chưa được thiết kế đầy đủ. Điều đó cho thấy khâu ban hành chính sách về dịch vụ đã tiến bộ, nhưng chưa thật sự tạo được sức ép đủ mạnh đối với nâng cao chất lượng cung ứng.

#### 2.2.2.2. Tổ chức thực hiện, quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

Bản chất của khâu này là tổ chức để dịch vụ được cung ứng liên tục, an toàn, đúng tiêu chuẩn; vận hành hiệu quả các cơ chế đặt hàng, giao nhiệm vụ, đấu thầu và điều tiết dịch vụ; sử dụng hợp lý các nguồn lực tài chính, nhân lực, công nghệ; đồng thời duy trì sự phối hợp có hiệu lực giữa cơ quan quản lý nhà nước và các đơn vị cung ứng. Bởi vậy, giai đoạn 2015–2025 cần được xem xét qua các phương diện như tổ chức lựa chọn đơn vị cung ứng, điều tiết hoạt động cung ứng dịch vụ, quản lý đào tạo và cấp chứng chỉ nhân lực dịch vụ, cũng như ứng dụng công nghệ trong điều hành và quản lý.

(1) Công tác đặt hàng, đấu thầu, giao nhiệm vụ dịch vụ bảo đảm an toàn hàng hải

Giai đoạn 2015–2025 chứng kiến nỗ lực chuyển đổi cung ứng dịch vụ công ích từ cơ chế giao nhiệm vụ, giao dự toán sang cơ chế đặt hàng hoặc đấu thầu theo Nghị định số 32/2019/NĐ-CP và các quy định về lựa chọn nhà thầu (Chính phủ nước CHXHCN Việt Nam, 2019; Chính phủ nước CHXHCN Việt Nam, 2025a). Dữ liệu của cơ quan quản lý cho thấy số lượng hợp đồng dịch vụ công ích thực hiện theo các cơ chế này tăng lên, phản ánh xu hướng thị trường hóa có kiểm soát (Bộ Xây dựng, 2026a). Tuy nhiên, quy trình phê duyệt đơn giá, định mức và kế hoạch lựa chọn nhà thầu vẫn còn kéo dài, tạo khoảng trống thực thi đối với các dịch vụ phải duy trì liên tục 24/7. So với kinh nghiệm quốc tế, hợp đồng dịch vụ của Việt Nam vẫn thiên về chu kỳ ngắn và kiểm soát hành chính hơn là hợp đồng dài hạn gắn với chỉ số kết quả (MPA, 2025; World Bank, 1994).

Theo logic quản trị vòng đời tài sản được xác lập trong Nghị định số 84/2025/NĐ-CP, hiệu quả bảo trì phụ thuộc nhiều vào khả năng can thiệp đúng thời điểm và dựa trên dữ liệu (Chính phủ nước CHXHCN Việt Nam, 2025d). Trong khi đó, thực tế vận hành cho thấy biến động sa bồi tự nhiên thường không trùng với chu kỳ lập và phê duyệt dự toán hằng năm; vì vậy, độ trễ trong kế hoạch nạo vét và bảo trì tiếp tục làm giảm hiệu quả kỹ thuật và gia tăng chi phí thực hiện (Bộ Xây dựng, 2026a).

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_016
Table number: 2.10
Title: Tổng hợp kết quả quản lý giữa dịch vụ thông tin và dịch vụ hạ tầng cứng (2020–2025)
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_016_candidate.md
[/TABLE_PLACEHOLDER]

(2) Về điều tiết cung ứng dịch vụ bảo đảm an toàn hàng hải

Đối với dịch vụ hoa tiêu hàng hải, dưới sự điều tiết và giám sát của cơ quan quản lý nhà nước, hoạt động dẫn tàu đã phục hồi và tăng trưởng trở lại sau giai đoạn bị ảnh hưởng bởi dịch bệnh. Theo Quyết định số 143/QĐ-BXD, số lượt hoa tiêu dẫn tàu thực hiện năm 2025 đạt 79.307 lượt; chỉ tiêu định hướng năm 2026 được giao là 87.238 lượt (Bộ Xây dựng, 2026b). Điều này cho thấy nhu cầu dịch vụ tăng lên cùng với yêu cầu ngày càng cao về năng lực tổ chức điều độ và chất lượng cung ứng dịch vụ.

Đối với dịch vụ thông tin và thông báo hàng hải, thông qua cơ chế đặt hàng và phân bổ ngân sách nhà nước, hệ thống 29 đài thông tin duyên hải (do VISHIPEL vận hành) đã được duy trì trạng thái trực canh 24/7, thực hiện phát sóng chuẩn xác các bản tin an toàn hàng hải (MSI). Đồng thời, kế hoạch khảo sát định kỳ được triển khai nghiêm ngặt, hoàn thành 100% khối lượng tại 43 tuyến luồng công cộng và 15 vùng đón trả hoa tiêu trong năm 2025, bảo đảm cung cấp dữ liệu thủy văn tức thời cho các Cảng vụ hàng hải khu vực ban hành thông báo an toàn (Bộ Xây dựng, 2026a; Công ty TNHH MTV Thông tin Điện tử Hàng hải Việt Nam [VISHIPEL], 2026).

Đối với dịch vụ nạo vét duy tu luồng hàng hải công cộng, là hạng mục sử dụng ngân sách nhà nước có quy mô lớn trong toàn bộ hoạt động bảo trì kết cấu hạ tầng hàng hải. Dữ liệu kế hoạch và báo cáo tổng kết cho thấy kinh phí nạo vét duy tu đã tăng mạnh so với giai đoạn đầu kỳ, từ khoảng 700,2 tỷ đồng năm 2015 lên mức trên 1,8 nghìn tỷ đồng trong kế hoạch năm 2024; sau đó việc bố trí vốn tiếp tục được điều chỉnh theo cân đối ngân sách và yêu cầu ưu tiên các tuyến luồng trọng điểm (Bộ Xây dựng, 2026a). Cơ chế bố trí vốn theo năm tài khóa vẫn bộc lộ mâu thuẫn với đặc tính sa bồi liên tục của luồng, vì vậy nhu cầu xây dựng cơ chế nạo vét đa năm và quản trị rủi ro theo chu kỳ tài sản là rất rõ ràng (Bộ Xây dựng, 2026a).

[FIGURE_PLACEHOLDER]
Figure ID: F_DOCX_007
Figure number: 2.7
Title: Xu hướng kinh phí nạo vét duy tu luồng hàng hải giai đoạn 2015–2025
Asset: ../../05_figures/assets/F_DOCX_007.png
[/FIGURE_PLACEHOLDER]

Trong lĩnh vực tìm kiếm cứu nạn, cơ chế phối hợp liên ngành được thiết lập thông qua 4 trung tâm khu vực. Giai đoạn 2015–2021, lực lượng chuyên trách đã tổ chức điều phối và xử lý thành công trên 1.000 sự cố, cứu sống hàng nghìn sinh mạng (Bộ Xây dựng, 2026a; Trung tâm Phối hợp tìm kiếm, cứu nạn hàng hải Việt Nam [VMRCC], n.d.). Dẫu vậy, năng lực ứng phó khẩn nguy tại các vùng biển xa bờ vẫn bị giới hạn bởi sự thiếu hụt phương tiện chuyên dụng và cơ chế phối hợp tác chiến liên lực lượng chưa thực sự đồng bộ.

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_017
Table number: 2.11
Title: Năng lực cung ứng dịch vụ hoa tiêu hàng hải (2019–2025)
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_017_candidate.md
[/TABLE_PLACEHOLDER]

(3) Về quản lý cơ sở đào tạo và đào tạo, cấp chứng chỉ nhân lực dịch vụ

Công tác quản lý nhà nước của Bộ Xây dựng đối với nội dung này được phản ánh qua hệ thống số liệu về nguồn nhân lực dịch vụ trong giai đoạn 2015–2025 do cơ quan quản lý chuyên ngành tổng hợp trong báo cáo tổng kết thi hành Bộ luật Hàng hải Việt Nam năm 2015 (Bộ Xây dựng, 2026a).

[FIGURE_PLACEHOLDER]
Figure ID: F_DOCX_008
Figure number: 2.8
Title: Biểu đồ tỷ trọng và cơ cấu nguồn nhân lực dịch vụ hàng hải giai đoạn 2015–2024
Asset: ../../05_figures/assets/F_DOCX_008.png
[/FIGURE_PLACEHOLDER]

Số liệu giai đoạn 2015–2024 cho thấy nguồn nhân lực hàng hải có xu hướng tăng tương đối rõ, từ 44.720 người năm 2015 lên 65.033 người năm 2024. Trong đó, nhóm sỹ quan quản lý tăng từ 10.578 lên 14.247 người, nhóm sỹ quan vận hành duy trì ở mức trên 9 nghìn người, còn nhóm thủy thủ, thợ máy tăng mạnh từ 24.469 lên 41.247 người (Bộ Xây dựng, 2026a). Xu hướng này phản ánh hệ thống đào tạo và cấp chứng chỉ hàng hải đã góp phần mở rộng nền nhân lực phục vụ hoạt động dịch vụ, song cũng cho thấy yêu cầu tiếp tục hoàn thiện chính sách đào tạo theo hướng gắn chặt hơn giữa cơ cấu đầu ra và nhu cầu nhân lực của từng lĩnh vực dịch vụ.

[FIGURE_PLACEHOLDER]
Figure ID: F_DOCX_009
Figure number: 2.9
Title: Cơ cấu phân hạng hoa tiêu hàng hải Việt Nam hiện nay
Asset: ../../05_figures/assets/F_DOCX_009.png
[/FIGURE_PLACEHOLDER]

Về hệ thống phân hạng nghề nghiệp và cấp chứng chỉ chuyên môn trong lĩnh vực hoa tiêu hàng hải, báo cáo tổng kết cho thấy cả nước có 473 hoa tiêu các hạng, gồm 229 ngoại hạng, 70 hạng nhất, 79 hạng II, 61 hạng III và 34 tập sự; lực lượng này đang thực hiện dẫn tàu trên 185 tuyến thuộc 8 vùng hoa tiêu hàng hải bắt buộc (Bộ Xây dựng, 2026a). Số liệu này cho thấy Nhà nước không chỉ duy trì được lực lượng có chứng chỉ hành nghề, mà còn từng bước chuẩn hóa năng lực theo cấp độ chuyên môn để đáp ứng yêu cầu dẫn tàu tại các vùng nước có mức độ phức tạp khác nhau.

Đối với lực lượng kiểm tra tàu biển, báo cáo tổng kết cho thấy hiện có 175 sỹ quan kiểm tra tàu biển, gồm 63 sỹ quan kiểm tra tàu biển Việt Nam và 112 sỹ quan kiểm tra cảng biển. Từ năm 2017 đến ngày 21/10/2024, lực lượng này đã thực hiện khối lượng công việc rất lớn đối với tàu VR-SB, tàu nội địa, tàu chạy tuyến quốc tế và tàu nước ngoài; riêng hoạt động kiểm tra tàu biển nước ngoài đã ghi nhận 30 lượt tàu bị lưu giữ (Bộ Xây dựng, 2026a). Điều đó cho thấy hiệu quả quản lý không thể đánh giá chỉ bằng số lượng nhân lực được đào tạo hay được cấp chứng chỉ, mà phải xem xét cả khả năng chuyển hóa năng lực chuyên môn thành kết quả thực thi công vụ.

(4) Về ứng dụng công nghệ trong tổ chức thực hiện quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

Nhờ cải cách thủ tục hành chính và mở rộng xử lý hồ sơ trên môi trường điện tử, đến cuối năm 2025, 100% thủ tục hành chính được tiếp nhận qua Hệ thống thông tin một cửa điện tử của Bộ Xây dựng (Cổng Thông tin điện tử Chính phủ, 2025). Tuy nhiên, dữ liệu vận hành chuyên ngành vẫn chưa được liên kết liền mạch giữa các hệ thống như VTS, AIS, LRIT, SAR và các lực lượng thực thi trên biển. Vì vậy, công nghệ hiện mới phát huy rõ nhất ở khâu xử lý hành chính, trong khi điều hành tác nghiệp theo thời gian thực vẫn thiếu đồng bộ (Bộ Xây dựng, 2025b, 2025d; Bộ Xây dựng, 2026a). Thực trạng này cho thấy khoảng cách lớn giữa mục tiêu chuyển đổi số và năng lực thực thi hiện nay.

Tóm lại, thực trạng quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải giai đoạn 2015–2025 cho thấy quá trình tổ chức thực hiện đã có chuyển dịch nhất định từ cơ chế giao nhiệm vụ, giao dự toán sang các phương thức quản lý gắn với đặt hàng, đấu thầu và kiểm soát đầu ra. Tuy nhiên, sự chuyển dịch này diễn ra chưa đồng đều giữa các nhóm dịch vụ; khoảng cách giữa yêu cầu vận hành linh hoạt của dịch vụ bảo đảm an toàn hàng hải với cơ chế điều hành hành chính hiện nay vẫn còn tương đối rõ, qua đó ảnh hưởng trực tiếp đến kết quả hệ thống và khả năng cung ứng dịch vụ.

#### 2.2.2.3. Giám sát, đánh giá chất lượng dịch vụ bảo đảm an toàn hàng hải

Trong quản lý nhà nước đối với dịch vụ, kiểm tra và giám sát chất lượng là khâu kiểm soát đầu ra và duy trì kỷ cương của thị trường dịch vụ bảo đảm an toàn hàng hải. Trọng tâm của khâu này không dừng ở việc kiểm tra hồ sơ hay sự tuân thủ hình thức, mà phải hướng tới giám sát được chất lượng thực tế của dịch vụ, phát hiện và xử lý kịp thời sai phạm, gắn chặt giám sát với nghiệm thu, thanh toán, chế tài và điều chỉnh chính sách. Do đó, giai đoạn 2015–2025 cần được xem xét qua các phương diện như giám sát theo cam kết chất lượng, nghiệm thu và thanh quyết toán, thanh tra năng lực thực tế của đơn vị cung ứng, đánh giá sự hài lòng và xếp hạng nhà cung cấp, cùng với xử lý vi phạm và cưỡng chế thực thi.

(1) Giám sát chất lượng dịch vụ bảo đảm an toàn hàng hải qua tuân thủ cam kết KPI/SLA

Công tác được Bộ triển khai thông qua Cục Hàng hải và Đường thủy Việt Nam và các Cảng vụ hàng hải chủ yếu thực hiện giám sát thông qua việc xét duyệt hồ sơ, báo cáo định kỳ hoặc các đoàn thanh tra theo kế hoạch báo trước. Tư duy giám sát dựa trên tuân thủ quy trình (giám sát vẫn nặng tính thủ công và hành chính hóa) vẫn chiếm ưu thế áp đảo so với tư duy giám sát dựa trên hiệu quả thực tế. Điều này dẫn đến một nghịch lý là mặc dù số lượng các cuộc thanh tra, kiểm tra tăng đều qua các năm, nhưng phần lớn các lỗi vi phạm được phát hiện chỉ dừng lại ở lỗi hành chính, giấy tờ, trong khi các vi phạm về chất lượng dịch vụ thực tế (như độ sâu luồng không đạt, thời gian khắc phục sự cố chậm) lại ít được công khai hoặc xử lý triệt để.

Phân tích số liệu từ Bảng 2.12 dưới đây cho thấy một thực trạng đáng chú ý là tỷ trọng các vi phạm hành chính (như thiếu nhật ký thi công, chậm báo cáo, sai mẫu biểu) luôn chiếm áp đảo từ 76% đến 88% tổng số lỗi phát hiện. Trong khi đó, các vi phạm trực tiếp ảnh hưởng đến an toàn hàng hải và hiệu quả khai thác (như phương tiện thi công không đảm bảo thông số kỹ thuật, nạo vét không đúng chuẩn tắc, thả phao sai vị trí) chỉ chiếm tỷ lệ khiêm tốn dưới 25%. Điều này không đồng nghĩa với việc chất lượng dịch vụ đã hoàn hảo, mà phản ánh năng lực phát hiện lỗi kỹ thuật của cơ quan giám sát còn hạn chế. Do thiếu các công cụ quan trắc tự động và dữ liệu thời gian thực, cán bộ thanh tra thường có xu hướng tập trung vào phát hiện sai sót về hồ sơ thủ tục, văn bản – những lỗi dễ nhìn thấy bằng mắt thường, thay vì đi sâu vào đánh giá các chỉ số hiệu năng kỹ thuật phức tạp.

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_018
Table number: 2.12
Title: Tổng hợp kết quả thanh tra, kiểm tra chuyên ngành đối với doanh nghiệp cung ứng dịch vụ hàng hải (2019–2023)
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_018_candidate.md
[/TABLE_PLACEHOLDER]

Hệ quả của phương thức giám sát này là tính răn đe của chế tài xử lý chưa cao. Tỷ lệ xử phạt vi phạm hành chính trên tổng số lỗi phát hiện chỉ dao động quanh mức 30-40%, phần còn lại chủ yếu được xử lý bằng hình thức nhắc nhở hoặc yêu cầu khắc phục. Việc thiếu vắng các chế tài kinh tế mạnh (như trừ tiền nghiệm thu, đình chỉ tham gia đấu thầu) đối với các vi phạm chất lượng dịch vụ đã tạo ra tâm lý nhờn luật ở một bộ phận đơn vị cung ứng.

(2) Về giám sát nghiệm thu và thanh quyết toán dịch vụ bảo đảm an toàn hàng hải

Giai đoạn 2019–2025, công tác giám sát nghiệm thu và thanh quyết toán dịch vụ từng bước được thể chế hóa rõ hơn thông qua Thông tư số 42/2019/TT-BGTVT và Thông tư số 40/2023/TT-BGTVT (Bộ Giao thông vận tải, 2019; Bộ Giao thông vận tải, 2023b). Xét về phương diện pháp lý, đây là bước chuyển từ kiểm tra hành chính thuần túy sang giám sát có tiêu chí và có căn cứ nghiệm thu chất lượng. Tuy vậy, việc giám sát theo thời gian thực và gắn trực tiếp thanh toán với kết quả đầu ra vẫn chưa được triển khai đồng đều trên toàn hệ thống.

Đối với các dịch vụ thiết yếu như nạo vét duy tu và bảo trì báo hiệu, đèn biển, luồng hàng hải, công tác giám sát đã có bước tiến đáng kể về công nghệ. Việc Chính phủ ban hành Nghị định số 57/2024/NĐ-CP và Bộ Giao thông vận tải ban hành Thông tư số 43/2024/TT-BGTVT đã tạo cơ sở pháp lý cho tăng cường giám sát thời gian thực thông qua thiết bị nhận dạng tự động, camera hành trình và dữ liệu vị trí phương tiện thi công (Bộ Giao thông vận tải, 2022; Chính phủ nước CHXHCN Việt Nam, 2024). Sự thay đổi này góp phần giảm phụ thuộc vào hồ sơ thủ công và tăng khả năng truy vết trong quá trình nghiệm thu.

(3) Về thanh tra năng lực thực tế và tuân thủ quy định tại cảng biển

Mặc dù hệ thống văn bản quy phạm pháp luật về quản lý cảng biển đã được thiết lập tương đối đầy đủ, kết quả thanh tra thực tế tại doanh nghiệp vẫn bộc lộ khoảng trống lớn trong tuân thủ quy định về bảo trì kết cấu hạ tầng và quản lý giá dịch vụ. Minh chứng điển hình là Kết luận thanh tra số 39/KL-TTr ngày 24/10/2025 đối với Công ty Cảng Container Trung tâm Sài Gòn (SPCT), trong đó cơ quan thanh tra chỉ ra các sai phạm liên quan đến khảo sát độ sâu vùng nước, kế hoạch và báo cáo bảo trì, cũng như việc quan trắc công trình bến cảng trong quá trình khai thác (Bộ Giao thông vận tải, 2022; Thanh tra, 2025).

Không những vậy, công tác giám sát của cơ quan quản lý nhà nước trực tiếp tại khu vực cũng bị đánh giá là thiếu chặt chẽ khi chưa kịp thời phát hiện các sai sót trong kê khai giá dịch vụ và sự thiếu hụt nội dung phòng ngừa ô nhiễm môi trường trong biên bản kiểm tra định kỳ. Trường hợp của SPCT phản ánh một thực tế rằng, năng lực thực thi và giám sát tuân thủ ở cấp cơ sở vẫn còn khoảng cách lớn so với yêu cầu, dẫn đến tình trạng các quy định chưa được thực hiện nghiêm túc, tiềm ẩn rủi ro mất an toàn hàng hải.

(4) Về công tác đánh giá sự hài lòng và xếp hạng nhà cung cấp

Bên cạnh các vấn đề về giám sát kỹ thuật, công tác quản lý chất lượng dịch vụ hỗ trợ như hoa tiêu, lai dắt cũng đang tồn tại bất cập về cơ chế sàng lọc thị trường. Hiện chưa có một hệ thống chính thức để đánh giá mức độ hài lòng của khách hàng và xếp hạng tín nhiệm các doanh nghiệp cung ứng dịch vụ trên cơ sở dữ liệu vận hành.

Kết quả phỏng vấn chuyên gia của luận án cho thấy cơ chế quản lý hiện nay vẫn thiên về đánh giá năng lực “tĩnh” thông qua hồ sơ pháp lý và chứng chỉ, trong khi lịch sử an toàn, chất lượng phục vụ và phản hồi của người sử dụng chưa trở thành căn cứ giám sát thường xuyên. Điều này làm giảm động lực cạnh tranh nâng cao chất lượng dịch vụ.

(5) Về công tác xử lý vi phạm và cưỡng chế thực thi.

Công tác xử lý vi phạm và cưỡng chế thực thi giữ vai trò răn đe cuối cùng để bảo vệ kỷ cương thị trường. Mặc dù hệ thống chế tài xử phạt vi phạm hành chính đã được thiết lập, nhưng hiệu lực răn đe trong thực tế vẫn chưa đồng đều. Các báo cáo tổng kết và kết luận thanh tra cho thấy vẫn còn những trường hợp vi phạm về giá dịch vụ, bảo trì hạ tầng, môi trường hoặc hồ sơ quản lý bị phát hiện muộn hoặc xử lý chưa triệt để, một phần do lo ngại ảnh hưởng đến tính liên tục của chuỗi cung ứng dịch vụ tại cảng biển (Bộ Xây dựng, 2026a; Thanh tra, 2025).

Nhìn tổng thể, giai đoạn 2015–2025 cho thấy khung thể chế về kiểm tra, giám sát chất lượng dịch vụ bảo đảm an toàn hàng hải đã chuyển dần từ logic kiểm soát thủ tục sang tiếp cận quản lý theo kết quả. Việc ban hành các quy định về tiêu chí giám sát, nghiệm thu, giá dịch vụ sự nghiệp công và cơ chế đặt hàng không chỉ hoàn thiện căn cứ pháp lý cho hoạt động kiểm tra mà còn bước đầu liên kết giám sát với phân bổ tài chính, lựa chọn đơn vị cung ứng và đánh giá chất lượng dịch vụ. Tuy nhiên, sự hoàn thiện về quy định chưa đồng nghĩa với sự chuyển biến tương ứng về năng lực giám sát thực tế. Phương thức giám sát hiện hành vẫn chủ yếu dựa vào hậu kiểm và nghiệm thu hồ sơ, trong khi giám sát liên tục theo dữ liệu thời gian thực, theo chất lượng đầu ra và theo mức độ hoàn thành cam kết dịch vụ còn hạn chế. Vì vậy, khoảng cách giữa yêu cầu quản lý chất lượng dịch vụ với năng lực kiểm soát thực thi vẫn còn khá rõ. Xét từ góc độ hiệu lực quản lý nhà nước, đây vẫn là khâu yếu trên trục quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải. Sự thiếu vắng cơ chế đánh giá tín nhiệm doanh nghiệp, công cụ giám sát hiệu suất dựa trên dữ liệu thực và chế tài cưỡng chế đủ mạnh khiến hoạt động kiểm tra, giám sát chưa tạo được áp lực cải thiện chất lượng một cách thực chất, đặc biệt trong quản lý doanh nghiệp cảng và các dịch vụ hỗ trợ. Do đó, vấn đề đặt ra không chỉ là tiếp tục bổ sung quy định, mà quan trọng hơn là chuyển trọng tâm từ kiểm tra tuân thủ hình thức sang giám sát đầu ra, giám sát rủi ro và giám sát dựa trên bằng chứng, qua đó nâng cao hiệu lực quản lý nhà nước và chất lượng dịch vụ bảo đảm an toàn hàng hải.

## 2.3. ĐÁNH GIÁ ĐỊNH LƯỢNG CÁC YẾU TỐ ẢNH HƯỞNG TỚI KẾT QUẢ QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM

### 2.3.1. Thiết kế mô hình nghiên cứu

Để bổ sung bằng chứng định lượng cho phần phân tích ở mục 2.2, trên cơ sở khung phân tích 2×3, luận án sử dụng mô hình hồi quy tuyến tính bội (multiple linear regression model) với hệ số beta chuẩn hóa để kiểm định mức độ tác động của sáu biến độc lập H1, H2, H3, D1, D2 và D3 đến biến phụ thuộc Y. Về bản chất, đây là mô hình hồi quy được ước lượng trên các biến nghiên cứu tính từ thang đo Likert 5 mức; vì vậy, trong mục này luận án sử dụng cách gọi trực tiếp là mô hình hồi quy tuyến tính bội nhằm tránh gây hiểu nhầm về kỹ thuật ước lượng. Phương trình nghiên cứu được viết như sau: Y = β0 + β1H1 + β2H2 + β3H3 + β4D1 + β5D2 + β6D3 + ε (Hair et al., 2010; Hair et al., 2019; Kline, 2016).

Liên kết giữa câu hỏi khảo sát và các biến nghiên cứu được khái quát như sau. Cụ thể, H1 được tính từ 13 chỉ báo thuộc các nhóm B1, B6, X1 và X5; H2 được tính từ 21 chỉ báo thuộc các nhóm B2, B5, B7, X2, X4 và X6; H3 được tính từ 3 chỉ báo thuộc nhóm B3; D1 được tính từ 2 chỉ báo S1 và S2; D2 được tính từ 8 chỉ báo thuộc nhóm B4 và X3; D3 được tính từ 2 chỉ báo S3 và S4; Y được tính từ 10 chỉ báo Y1–Y10. Các ký hiệu B, S, X và Y là mã nhóm câu hỏi trong bảng hỏi, không phải là các biến độc lập của phương trình hồi quy. Trên cơ sở mô hình nghiên cứu, các giả thuyết được phát biểu như sau:

GT1: Chất lượng ban hành trong quản lý hệ thống bảo đảm an toàn hàng hải (H1) tác động tích cực đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải (Y).

GT2: Chất lượng tổ chức thực hiện trong quản lý hệ thống bảo đảm an toàn hàng hải (H2) tác động tích cực đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải (Y).

GT3: Chất lượng giám sát trong quản lý hệ thống bảo đảm an toàn hàng hải (H3) tác động tích cực đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải (Y).

GT4: Chất lượng ban hành trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải (D1) tác động tích cực đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải (Y).

GT5: Chất lượng tổ chức thực hiện trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải (D2) tác động tích cực đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải (Y).

GT6: Chất lượng giám sát trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải (D3) tác động tích cực đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải (Y).

[FIGURE_PLACEHOLDER]
Figure ID: F_DOCX_010
Figure number: 2.10
Title: Mô hình hồi quy tuyến tính bội theo khung 2×3.
Asset: ../../05_figures/assets/F_DOCX_010.png
[/FIGURE_PLACEHOLDER]

### 2.3.2. Dữ liệu nghiên cứu

Mẫu khảo sát phục vụ phân tích định lượng gồm 250 phiếu hợp lệ. Quy mô này bảo đảm số quan sát cần thiết để kiểm định độ tin cậy của thang đo, tính giá trị trung bình cho các biến nghiên cứu và ước lượng mô hình hồi quy tuyến tính bội. Cơ cấu mẫu phản ánh khá đầy đủ các góc nhìn quản trị từ ba nhóm chủ đạo: nhóm quản lý nhà nước, nhóm cung ứng dịch vụ và nhóm sử dụng dịch vụ hoặc chịu tác động. Chi tiết phân bố theo giới tính, độ tuổi, vai trò công tác và thâm niên làm việc được trình bày tại Hình 2.11 và dữ liệu khảo sát của luận án.

Dữ liệu được thu thập từ tháng 3 đến tháng 5 năm 2025 theo phương pháp chọn mẫu thuận tiện kết hợp có chủ đích, nhằm bảo đảm sự tham gia của các nhóm đối tượng liên quan trực tiếp đến quản lý nhà nước về bảo đảm an toàn hàng hải. Địa bàn khảo sát trải rộng trên cả ba miền Bắc, Trung và Nam. Người trả lời gồm cán bộ quản lý nhà nước, doanh nghiệp cảng biển, logistics, dịch vụ hàng hải, lực lượng hoa tiêu, dịch vụ quản lý giao thông tàu thuyền, thuyền viên và giảng viên, nhà nghiên cứu (Creswell & Plano Clark, 2018; Palinkas et al., 2015).

[FIGURE_PLACEHOLDER]
Figure ID: F_DOCX_011
Figure number: 2.11
Title: Cơ cấu mẫu khảo sát phân bổ theo giới tính, độ tuổi, vai trò công tác và thâm niên làm việc (N=250 mẫu)
Asset: ../../05_figures/assets/F_DOCX_011.png
[/FIGURE_PLACEHOLDER]

Về xử lý dữ liệu, bộ số liệu được làm sạch, kiểm tra tính hợp lệ và mã hóa thống nhất trước khi phân tích. Các câu hỏi đảo chiều được quy đổi theo công thức 6 - x. Sau đó, các biến H1, H2, H3, D1, D2, D3 và Y được tính bằng giá trị trung bình của các chỉ báo hợp lệ thuộc từng biến; các biến độc lập tiếp tục được chuẩn hóa để ước lượng hệ số beta chuẩn hóa trong mô hình hồi quy tuyến tính bội.

### 2.3.3. Kết quả phân tích mô hình nghiên cứu

#### 2.3.3.1. Kiểm định độ tin cậy của thang đo và xây dựng biến nghiên cứu

Luận án sử dụng hệ số Cronbach’s Alpha để đánh giá độ tin cậy nội tại của các thang đo trước khi tính giá trị trung bình cho từng biến H1, H2, H3, D1, D2, D3 và Y. Cách xử lý này phù hợp với cấu trúc dữ liệu khảo sát và mục tiêu ước lượng mô hình hồi quy tuyến tính bội (Hair et al., 2010).

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_019
Table number: 2.13
Title: Độ tin cậy của các thang đo tổng hợp trong mô hình định lượng
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_019_candidate.md
[/TABLE_PLACEHOLDER]

Kết quả ở Bảng 2.13 cho thấy các thang đo H1, H2, D2 và Y đạt độ tin cậy tốt; H3 đạt mức chấp nhận được; D1 và D3 có hệ số alpha thấp hơn nhưng vẫn có thể sử dụng trong nghiên cứu ứng dụng do số lượng chỉ báo ít và nội dung đo lường tương đối tập trung. Trên cơ sở đó, luận án giữ lại toàn bộ bảy thang đo để tính các biến nghiên cứu cho mô hình định lượng chính thức.

#### 2.3.3.2. Ma trận tương quan giữa các cấu phần và kiểm tra đa cộng tuyến

Sau khi tính giá trị trung bình cho các biến H1, H2, H3, D1, D2, D3 và Y, luận án kiểm tra tương quan Pearson và chỉ số VIF để đánh giá nguy cơ đa cộng tuyến trước khi ước lượng mô hình. Kết quả được trình bày tại Bảng 2.14.

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_020
Table number: 2.14
Title: Ma trận tương quan Pearson giữa các biến nghiên cứu và chỉ số VIF
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_020_candidate.md
[/TABLE_PLACEHOLDER]

Bảng 2.14 cho thấy Y có tương quan dương với cả sáu biến độc lập, trong đó mức tương quan cao nhất thuộc về H2 (r = 0,800) và H1 (r = 0,767). Các hệ số VIF dao động từ 1,330 đến 2,021, thấp hơn ngưỡng thường được sử dụng trong nghiên cứu thực nghiệm, cho thấy mô hình không có dấu hiệu đa cộng tuyến nghiêm trọng. Điều này cho phép tiếp tục ước lượng mô hình hồi quy tuyến tính bội theo khung 2×3 (Hair et al., 2010; Kline, 2016).

#### 2.3.3.3. Kết quả kiểm định giả thuyết nghiên cứu

Sau khi tính giá trị trung bình của các chỉ báo cho từng biến, luận án ước lượng mô hình bằng phương pháp hồi quy tuyến tính bội với hệ số beta chuẩn hóa (standardized beta coefficients) và kiểm định 6 giả thuyết nghiên cứu. Kết quả cho thấy mô hình giải thích được 77,6% (R² = 0,776) sự biến thiên của biến Y. Hệ số xác định hiệu chỉnh đạt 0,770; kiểm định F của toàn mô hình có ý nghĩa thống kê ở mức p < 0,001. Đây là mức giải thích khá cao đối với một nghiên cứu quản lý nhà nước sử dụng dữ liệu khảo sát thu thập tại một thời điểm.

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_021
Table number: 2.15
Title: Kết quả ước lượng mô hình hồi quy tuyến tính bội theo khung 2×3
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_021_candidate.md
[/TABLE_PLACEHOLDER]

Kết quả ở Bảng 2.15 cho thấy bốn biến có tác động dương và có ý nghĩa thống kê đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải, bao gồm: H2, H1, D2 và D3. Trong đó, H2 có hệ số tác động chuẩn hóa lớn nhất (β = 0,438), tiếp đến là H1 (β = 0,348), D2 (β = 0,152) và D3 (β = 0,088). Ngược lại, H3 và D1 không có ý nghĩa thống kê trong mô hình tổng thể, mặc dù hệ số tác động vẫn mang dấu dương.

### 2.3.4. Thảo luận về kết quả nghiên cứu

Kết quả định lượng cho thấy kết quả quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam chịu tác động rõ rệt nhất từ chất lượng tổ chức thực hiện trong quản lý hệ thống (H2). Điều này hàm ý rằng, trong một lĩnh vực có tính liên thông cao, kết quả quản lý không phụ thuộc chủ yếu vào việc có quy định hay không, mà phụ thuộc nhiều hơn vào khả năng chuyển hóa quy định thành hoạt động vận hành, phối hợp và triển khai trên thực tế.

Đứng thứ hai về mức độ tác động là chất lượng ban hành trong quản lý hệ thống (H1). Kết quả này khẳng định vai trò nền tảng của thể chế, quy hoạch, kế hoạch và tiêu chuẩn đối với toàn bộ chu trình quản lý. Tuy nhiên, hệ số của H1 thấp hơn H2 cho thấy ban hành là điều kiện cần, còn hiệu lực quản lý thực chất vẫn phụ thuộc lớn hơn vào chất lượng tổ chức thực hiện.

Ở trục quản lý cung ứng dịch vụ, biến D2 có tác động dương và có ý nghĩa thống kê, phản ánh vai trò của cơ chế điều phối cung ứng, chuẩn hóa năng lực chủ thể và kiểm soát quá trình thực hiện dịch vụ. Đồng thời, biến D3 cũng có tác động dương, dù mức tác động khiêm tốn hơn, cho thấy công tác đánh giá chất lượng đầu ra và điều tiết chất lượng dịch vụ vẫn là một kênh cải thiện kết quả quản lý quan trọng.

Ngược lại, giám sát hệ thống (H3) và ban hành dịch vụ (D1) không có ý nghĩa thống kê trong mô hình tổng thể. Kết quả này không phủ định vai trò lý thuyết của hai khâu này, mà gợi ý rằng trong điều kiện nghiên cứu hiện nay, giám sát hệ thống vẫn chưa đủ mạnh để tạo ra khác biệt độc lập rõ rệt; đồng thời cơ chế ban hành đối với dịch vụ bảo đảm an toàn hàng hải vẫn chưa vận hành như một đòn bẩy điều tiết đủ mạnh để chuyển hóa trực tiếp thành kết quả quản lý.

Từ đó có thể rút ra một hàm ý trọng tâm cho Chương 2: ưu tiên cải cách nên tập trung vào nâng cao năng lực tổ chức thực hiện đối với hệ thống bảo đảm an toàn hàng hải, đồng thời tiếp tục hoàn thiện chất lượng ban hành ở trục hệ thống và cải thiện cơ chế tổ chức thực hiện, giám sát chất lượng ở trục dịch vụ. Đây là hướng đi phù hợp với kết quả định lượng của mô hình chính thức.

## 2.4. ĐÁNH GIÁ CHUNG THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025

Trong phạm vi nghiên cứu của luận án, các thành tựu quản lý đạt được và hạn chế trong quản lý sau đây tập trung vào hoạt động quản lý nhà nước của Bộ Xây dựng (trước tháng 3/2025 là Bộ Giao thông vận tải, sau đây gọi chung là Bộ) đối với công tác bảo đảm an toàn hàng hải. Các chủ thể khác như Chính phủ, các bộ, ngành, địa phương và lực lượng phối hợp được xem là chủ thể liên quan, không phải đối tượng phân tích trực tiếp của mục 2.4 này.

### 2.4.1. Thành tựu quản lý đạt được

#### 2.4.1.1. Thành tựu về tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải

Một là, trong khâu ban hành đối với trục hệ thống, Bộ Xây dựng đã từng bước hoàn thiện khung pháp lý và tiêu chuẩn kỹ thuật cho hệ thống bảo đảm an toàn hàng hải theo hướng ngày càng đồng bộ hơn với yêu cầu phát triển của ngành và tiệm cận gần hơn với các thông lệ, quy chuẩn quốc tế. Xét về bản chất quản lý nhà nước, thành tựu này không chỉ là sự gia tăng về số lượng văn bản, mà quan trọng hơn là Bộ đã tạo lập được nền tảng thể chế tương đối rõ cho quản lý báo hiệu, luồng hàng hải, thông tin hàng hải và các cấu phần hạ tầng liên quan. Nhờ đó, hoạt động đầu tư, vận hành và bảo trì hệ thống có cơ sở pháp lý chặt chẽ hơn, mức độ phối hợp giữa các chủ thể thực thi được cải thiện, đồng thời vị thế và khả năng hội nhập của hệ thống bảo đảm an toàn hàng hải Việt Nam cũng từng bước được nâng lên (Bộ Xây dựng, 2026a; IMO, 1973/1978; IMO, 1974).

Hai là, trong khâu tổ chức thực hiện, Bộ đã kiện toàn bộ máy thực thi và duy trì mô hình doanh nghiệp công ích trong lĩnh vực bảo đảm an toàn hàng hải, qua đó hỗ trợ vận hành tương đối đồng bộ hệ thống báo hiệu, luồng tuyến và hạ tầng thiết yếu. Điều đáng ghi nhận ở đây không chỉ là sự ổn định về mặt tổ chức, mà là việc Bộ đã duy trì được một cơ chế thực thi tương đối thống nhất từ khâu chỉ đạo, phân công đến vận hành thực tế. Thành tựu này phản ánh rõ hơn năng lực tổ chức thực hiện của chủ thể quản lý, bởi hệ thống chỉ có thể vận hành an toàn và thông suốt khi bộ máy thực thi đủ khả năng chuyển hóa yêu cầu thể chế thành kết quả vận hành cụ thể (Bộ Xây dựng, 2025a, 2025e, 2025f; Chính phủ nước CHXHCN Việt Nam, 2025b, 2025e).

Ba là, Bộ đã chỉ đạo đầu tư, duy tu, bảo trì và vận hành hệ thống bảo đảm an toàn hàng hải theo hướng gắn chặt hơn với yêu cầu an toàn, thông suốt và hội nhập. Xét từ góc độ quản lý nhà nước, kết quả này cho thấy Bộ không chỉ dừng ở vai trò ban hành quy định, mà đã từng bước chuyển hóa các định hướng chính sách và chuẩn kỹ thuật thành năng lực vận hành thực tế của hệ thống. Việc cải thiện mức độ sẵn sàng vận hành của nhiều cấu phần hệ thống, nâng cao khả năng phục vụ tàu thuyền trên các tuyến luồng trọng điểm và bảo đảm tính liên tục của các công trình hàng hải cho thấy chất lượng điều hành hệ thống đã có chuyển biến theo hướng chủ động hơn, thay vì chỉ xử lý khi phát sinh vấn đề (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025c; IALA, 2017a).

Bốn là, Bộ đã thúc đẩy ứng dụng công nghệ và từng bước đẩy mạnh số hóa trong quản lý hệ thống bảo đảm an toàn hàng hải, nhất là ở các khâu thông tin, giám sát và điều hành. Ý nghĩa quản lý của thành tựu này nằm ở chỗ phương thức quản lý đã bắt đầu dịch chuyển từ dựa chủ yếu vào thủ tục hành chính sang kết hợp ngày càng rõ hơn với dữ liệu và công nghệ. Đây là bước tiến quan trọng, bởi trong điều kiện ngành hàng hải phát triển nhanh, yêu cầu quản lý hiện đại không chỉ là có quy định đầy đủ, mà còn là có khả năng quan sát hệ thống tốt hơn, hỗ trợ ra quyết định nhanh hơn và nâng cao tính minh bạch trong điều hành (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025c).

Năm là, thông qua việc đồng thời thực hiện các chức năng ban hành, tổ chức thực hiện và duy trì kiểm soát đối với hệ thống, Bộ đã góp phần tạo ra chuyển biến tích cực về an toàn hàng hải. Thành tựu này cần được hiểu như kết quả quản lý tổng hợp của chủ thể nghiên cứu, thể hiện ở sự cải thiện về tính ổn định, độ tin cậy và mức độ an toàn của hệ thống, dù vẫn có sự hỗ trợ của các chủ thể phối hợp khác. Trên phương diện rộng hơn, kết quả đó không chỉ góp phần làm cho môi trường hàng hải trở nên an toàn và tin cậy hơn, mà còn tạo nền tảng thuận lợi hơn cho hội nhập, cạnh tranh và phát triển bền vững của ngành hàng hải Việt Nam (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025c).

#### 2.4.1.2. Thành tựu về quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

Một là, trong khâu ban hành đối với trục dịch vụ, Bộ đã duy trì và từng bước mở rộng khuôn khổ quản lý đối với cung ứng dịch vụ bảo đảm an toàn hàng hải theo diễn biến thực tiễn của ngành, bao gồm cả các dịch vụ thông tin, giám sát và hỗ trợ kỹ thuật số. Xét về phương diện quản lý nhà nước, thành tựu này cho thấy Bộ không chỉ theo kịp sự mở rộng của phạm vi dịch vụ, mà còn từng bước củng cố vai trò điều tiết đối với một lĩnh vực có tính kỹ thuật cao và chịu tác động mạnh của chuyển đổi số. Việc hoàn thiện dần các quy định liên quan đã góp phần nâng cao tính minh bạch, đồng bộ và khả năng phối hợp trong quản lý, đồng thời tạo cơ sở cho việc định hướng chất lượng dịch vụ phù hợp hơn với yêu cầu của hoạt động hàng hải hiện đại (Bộ Xây dựng, 2025g, 2025h; Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2025c, 2025d).

Hai là, Bộ đã tổ chức, quản lý và kiểm soát hoạt động hoa tiêu hàng hải theo hướng ngày càng chuyên nghiệp hơn, từ khâu tổ chức mạng lưới, phân công dẫn tàu đến kiểm soát điều kiện hành nghề và phối hợp tác nghiệp. Thành tựu ở đây không chỉ là sự chuyển biến về mặt tổ chức hay chất lượng chuyên môn của riêng lực lượng hoa tiêu, mà sâu hơn là việc Bộ đã từng bước thiết lập được một cơ chế quản lý tương đối ổn định đối với một dịch vụ đặc thù, có rủi ro cao và tác động trực tiếp đến an toàn tàu thuyền. Điều đó phản ánh rõ năng lực của cơ quan quản lý nhà nước trong việc duy trì trật tự, kỷ luật và chất lượng cung ứng của một dịch vụ cốt lõi trong chuỗi bảo đảm an toàn hàng hải (Bộ Xây dựng, 2025h; Bộ Xây dựng, 2026a).

Ba là, trong khâu giám sát và điều tiết dịch vụ, Bộ đã chỉ đạo duy trì hoạt động của các dịch vụ bảo đảm an toàn hàng hải thiết yếu, đồng thời từng bước gắn quản lý dịch vụ với yêu cầu chất lượng, an toàn và trách nhiệm giải trình. Xét theo góc độ quản lý nhà nước, đây là bước chuyển có ý nghĩa vì thực tế cho thấy hoạt động điều tiết dịch vụ không chỉ dừng ở việc bảo đảm dịch vụ được cung ứng liên tục, mà đã bắt đầu hướng tới kiểm soát đầu ra và rủi ro dịch vụ. Nhờ đó, chất lượng cung ứng dịch vụ có chuyển biến tích cực hơn, đáp ứng tốt hơn yêu cầu của chủ tàu, thuyền viên và doanh nghiệp vận tải biển, đồng thời củng cố vai trò của Nhà nước trong việc duy trì sự an toàn và thông suốt của hoạt động hàng hải (Bộ Giao thông vận tải, 2019; Bộ Giao thông vận tải, 2023b; Bộ Xây dựng, 2026a; OECD, 2019b).

### 2.4.2. Hạn chế trong quản lý

#### 2.4.2.1. Hạn chế về tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải

Một là, trong khâu ban hành đối với trục hệ thống, Bộ chưa khắc phục triệt để tình trạng chồng chéo, thiếu đồng bộ giữa một số quy định pháp luật, tiêu chuẩn kỹ thuật và cơ chế quản lý. Hạn chế này thể hiện không phải ở chỗ Bộ thiếu văn bản, mà ở chỗ một số văn bản do Bộ tham mưu hoặc ban hành chưa tạo được khuôn khổ điều tiết đủ rõ và đủ đồng bộ cho toàn bộ quá trình quản lý hệ thống. Một số nội dung quan trọng như nạo vét luồng lạch, quản lý tài sản kết cấu hạ tầng hàng hải, quản trị dữ liệu, chuẩn KPI/SLA và điều tiết rủi ro liên ngành còn chưa được quy định đầy đủ hoặc chưa theo kịp yêu cầu phát triển mới. Kết quả là, trong quá trình tổ chức thực hiện, các cơ quan thuộc Bộ và các đơn vị thực thi vẫn gặp khó khăn khi áp dụng quy định vào các tình huống cụ thể, nhất là các tình huống đòi hỏi phối hợp liên ngành, xử lý theo thời gian thực hoặc ra quyết định trên cơ sở dữ liệu. Điều đó cho thấy hạn chế của Bộ ở đây không chỉ là độ trễ cập nhật thể chế, mà còn là chất lượng kết nối giữa khâu ban hành với yêu cầu điều hành thực tế của hệ thống bảo đảm an toàn hàng hải (Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2017; Chính phủ nước CHXHCN Việt Nam, 2025c, 2025d).

Hai là, trong khâu tổ chức thực hiện đối với trục hệ thống, Bộ chưa xử lý dứt điểm các điểm nghẽn về hạ tầng, công nghệ, nguồn nhân lực và nguồn lực bảo trì. Thông qua các cơ quan chuyên ngành và các đơn vị thuộc hệ thống thực thi, Bộ đã tổ chức đầu tư, duy tu, bảo trì và vận hành hệ thống báo hiệu, luồng hàng hải, VTS, AIS và các cấu phần hạ tầng thiết yếu; tuy nhiên, việc tổ chức thực hiện ở một số khâu vẫn còn chậm, chưa đồng đều và chưa gắn kết chặt với quản trị vòng đời tài sản. Hạn chế này biểu hiện ở chỗ nhiều hạng mục hạ tầng và công nghệ chưa được hiện đại hóa tương xứng, cơ chế phân bổ nguồn lực còn nặng theo chu kỳ ngân sách hằng năm, dữ liệu vận hành chưa thật sự liên thông, trong khi đội ngũ nhân lực kỹ thuật và nhân lực quản trị dữ liệu còn thiếu về chiều sâu chuyên môn. Kết quả quản lý vì vậy tuy có cải thiện, nhưng chưa tạo được mức chủ động cao trong bảo trì dự phòng, trong điều hành theo rủi ro và trong khả năng thích ứng nhanh trước yêu cầu phát triển mới của ngành hàng hải (Bộ Xây dựng, 2025b, 2025h; Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025c).

Ba là, trong khâu giám sát, đánh giá đối với trục hệ thống, Bộ chưa chuyển mạnh từ cách tiếp cận kiểm tra thủ tục sang giám sát dựa trên rủi ro và dữ liệu. Mặc dù hoạt động thanh tra, kiểm tra và giám sát hệ thống đã được duy trì, nhưng cách thức giám sát vẫn còn thiên về hậu kiểm hành chính, tập trung nhiều vào hồ sơ, giấy tờ và tuân thủ hình thức hơn là đo lường chất lượng vận hành thực tế của hệ thống. Bên cạnh đó, tình trạng trùng lặp giữa các lực lượng tham gia giám sát, dữ liệu còn phân tán ở nhiều hệ thống riêng lẻ, năng lực khai thác dữ liệu còn hạn chế, cùng với yêu cầu an ninh mạng ngày càng cao đối với VTS và AIS, đã làm giảm đáng kể tính chủ động của quản lý. Việc ứng dụng công nghệ số vào giám sát tuy đã được đặt ra nhưng mới dừng ở mức độ cục bộ, chưa hình thành được một cơ chế giám sát số hóa đồng bộ trên quy mô toàn hệ thống. Kết quả là Bộ chưa tạo được vòng phản hồi chính sách đủ nhanh và đủ sâu, nên năng lực phát hiện sớm, cảnh báo sớm và điều chỉnh quản lý trước những biến động thực tiễn còn hạn chế (Bộ Xây dựng, 2025b; Bộ Xây dựng, 2026a; Androjna et al., 2021).

#### 2.4.2.2. Hạn chế về quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

Một là, trong khâu ban hành đối với trục dịch vụ, Bộ chưa hoàn thiện đồng bộ cơ chế giá, cơ chế tài chính, tiêu chuẩn chất lượng và điều kiện năng lực của các đơn vị cung ứng dịch vụ. Hạn chế cốt lõi ở đây là việc ban hành cơ chế quản lý dịch vụ vẫn còn thiên về kiểm soát đầu vào và thủ tục, trong khi cơ chế quản lý theo chuẩn đầu ra, theo KPI/SLA và theo mức độ hoàn thành dịch vụ chưa thật sự rõ. Điều đó dẫn tới tình trạng dù Bộ đã ban hành được một số quy định về giá, định mức và điều kiện kinh doanh, nhưng các công cụ này chưa tạo được một khuôn khổ điều tiết đủ mạnh để gắn chất lượng dịch vụ với trách nhiệm của nhà cung ứng. Khi cơ chế giá và cơ chế tài chính chưa phản ánh sát kết quả dịch vụ đầu ra, động lực cải thiện chất lượng, tối ưu hóa chi phí và đổi mới phương thức cung ứng vẫn còn chưa đủ mạnh. Vì vậy, hạn chế trong quản lý của Bộ ở khâu này không chỉ nằm ở nội dung từng văn bản, mà còn nằm ở việc chưa thiết kế được một cơ chế thể chế đủ rõ để điều tiết thị trường dịch vụ theo chất lượng thực tế (Bộ Giao thông vận tải, 2021a, 2021b; Bộ Giao thông vận tải, 2024a, 2024b; Bộ Tài chính, 2016; Bộ Xây dựng, 2026a).

Hai là, trong khâu tổ chức thực hiện đối với trục dịch vụ, Bộ chưa tổ chức được cơ chế lựa chọn nhà cung ứng và quản lý hợp đồng thật sự hiệu quả, khách quan và minh bạch. Dù Bộ đã từng bước chuyển từ cách thức giao nhiệm vụ mang tính hành chính sang quản lý dịch vụ theo điều kiện năng lực, đặt hàng hoặc đấu thầu đối với một số loại hình dịch vụ, nhưng việc tổ chức cung ứng trên thực tế vẫn chưa hình thành được một chuỗi quản lý thống nhất từ lựa chọn nhà cung ứng, điều phối thực hiện, theo dõi kết quả đến xử lý trách nhiệm hợp đồng. Hạn chế này thể hiện ở việc quản lý hợp đồng còn nặng thủ công, thiếu cơ chế chia sẻ rủi ro và thiếu các điều khoản khuyến khích đổi mới; liên thông dữ liệu giữa các cơ quan quản lý, Cảng vụ và đơn vị cung ứng còn hạn chế; trong khi việc áp dụng KPI/SLA vào điều hành cung ứng dịch vụ chưa trở thành thông lệ quản lý. Kết quả là, Bộ mới chủ yếu duy trì được sự vận hành liên tục của dịch vụ, nhưng chưa kiểm soát thật chặt được tính cạnh tranh, tính minh bạch và chất lượng đầu ra của toàn bộ chuỗi cung ứng dịch vụ bảo đảm an toàn hàng hải (Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2019; Chính phủ nước CHXHCN Việt Nam, 2025a; Issa-Zadeh & Garay-Rondero, 2025).

Ba là, trong khâu giám sát, đánh giá đối với trục dịch vụ, Bộ vẫn chủ yếu nghiệm thu và kiểm tra chất lượng dựa trên hồ sơ giấy tờ, chưa hình thành được cơ chế giám sát thời gian thực và phản hồi hiệu quả từ phía người sử dụng dịch vụ. Đây là hạn chế đáng chú ý vì trong quản lý dịch vụ, giám sát phải là công cụ kiểm soát đầu ra, duy trì kỷ cương thị trường và tạo áp lực cải thiện chất lượng. Tuy nhiên, cách thức giám sát hiện nay vẫn nghiêng về xem xét hồ sơ, báo cáo định kỳ hoặc kiểm tra theo đợt, trong khi các cơ chế tiếp nhận phản hồi của hãng tàu, cảng, đại lý và người sử dụng dịch vụ chưa vận hành thật hiệu quả. Việc thiếu tiêu chuẩn giám sát thống nhất, thiếu chỉ số theo dõi liên tục, thiếu đánh giá độc lập và thiếu dữ liệu đủ mạnh để nghiệm thu theo kết quả đã làm cho hoạt động giám sát nhiều khi còn hình thức. Kết quả là vai trò điều tiết và sức ép nâng cao chất lượng từ phía cơ quan quản lý nhà nước chưa phát huy đầy đủ; trách nhiệm giải trình của đơn vị cung ứng dịch vụ chưa thật rõ; và quá trình điều chỉnh chính sách, điều chỉnh giá, điều chỉnh tiêu chuẩn dịch vụ còn chậm so với yêu cầu thực tiễn (Chính phủ nước CHXHCN Việt Nam, 2019; Chính phủ nước CHXHCN Việt Nam, 2025c; World Bank, 1994).

### 2.4.3. Nguyên nhân của hạn chế trong quản lý

#### 2.4.3.1. Nguyên nhân khách quan

Một là, lĩnh vực hàng hải có tính liên ngành, đa chủ thể và đòi hỏi sự phối hợp thường xuyên giữa nhiều cấp, nhiều lực lượng, nên nếu thiếu cơ chế điều phối đủ mạnh rất dễ phát sinh phân tán thẩm quyền, chồng chéo trách nhiệm và giảm kết quả quản lý. Đối với lĩnh vực bảo đảm an toàn hàng hải, mặc dù Bộ Xây dựng là chủ thể quản lý trực tiếp trong phạm vi luận án, nhưng quá trình thực hiện nhiệm vụ lại luôn gắn với Chính phủ, các bộ, ngành liên quan, địa phương, lực lượng bảo đảm an ninh, an toàn và các đơn vị cung ứng dịch vụ. Chính tính chất đa chủ thể đó làm cho chi phí phối hợp cao hơn, ranh giới trách nhiệm dễ chồng lấn hơn, nhất là ở các nội dung liên quan đến luồng lạch, vùng nước, ứng phó sự cố, bảo vệ công trình, an ninh hàng hải và chia sẻ dữ liệu. Vì vậy, ngay cả khi Bộ chủ động điều hành, kết quả quản lý vẫn chịu tác động đáng kể bởi chất lượng phối hợp liên ngành và liên cấp (Bộ Xây dựng, 2025a; Chính phủ nước CHXHCN Việt Nam, 2025b; Rhodes, 1996).

Hai là, công nghệ, chuẩn mực quốc tế và yêu cầu hội nhập trong lĩnh vực hàng hải thay đổi nhanh, nhất là về số hóa, an ninh mạng và xanh hóa, làm gia tăng độ trễ thể chế nếu hệ thống tiêu chuẩn, định mức và dữ liệu không được cập nhật kịp thời. Sự phát triển mạnh của các công nghệ mới trong quản lý luồng tàu, giám sát hành trình, vận hành cảng biển, cảnh báo an toàn và quản trị dữ liệu tạo ra áp lực rất lớn đối với việc sửa đổi văn bản, chuẩn hóa quy trình và nâng cấp phương thức quản lý. Trong khi đó, chu kỳ xây dựng và điều chỉnh thể chế thường chậm hơn tốc độ thay đổi của công nghệ và chuẩn mực quốc tế, nên dễ xuất hiện khoảng cách giữa yêu cầu quản lý mới với khả năng đáp ứng của khuôn khổ pháp lý hiện hành. Đây là nguyên nhân khách quan làm cho nhiều hạn chế trong ban hành và giám sát chưa thể được khắc phục nhanh, dù yêu cầu thực tiễn đã thay đổi rõ (Bộ Chính trị, 2024; Bộ Xây dựng, 2025b; Mao & Wang, 2020).

Ba là, nhu cầu đầu tư cho hạ tầng, công nghệ, bảo trì và dữ liệu trong lĩnh vực bảo đảm an toàn hàng hải rất lớn, trong khi nguồn lực tài chính, nhân lực chất lượng cao và nền tảng dữ liệu dùng chung còn hạn chế. Đây là nguyên nhân khách quan làm chậm quá trình hiện đại hóa hệ thống, làm cho công tác bảo trì, điều hành, giám sát và quản lý dịch vụ khó chuyển nhanh sang mô hình quản lý dựa trên bằng chứng, dữ liệu và rủi ro. Sự phân tán dữ liệu, thiếu liên thông giữa các hệ thống thông tin, cùng với hạn chế về đầu tư cho hạ tầng số và đào tạo nhân lực dữ liệu, cũng trực tiếp làm giảm khả năng thiết kế cơ chế giá, hợp đồng và giám sát chất lượng dịch vụ theo kết quả. Vì vậy, nhiều hạn chế trong tổ chức thực hiện và giám sát không chỉ do cách làm của chủ thể quản lý, mà còn do điều kiện nền tảng khách quan chưa đáp ứng yêu cầu quản trị hiện đại (Bộ Xây dựng, 2025b; Bộ Xây dựng, 2026a; World Bank, 1994; World Bank & International Association of Ports and Harbors [IAPH], 2021).

#### 2.4.3.2. Nguyên nhân chủ quan

Một là, về phía Bộ Xây dựng và các cơ quan thuộc Bộ, chất lượng xây dựng chính sách, đánh giá tác động và phân định trách nhiệm trong một số trường hợp còn chưa thật rõ, làm giảm tính kịp thời và tính điều tiết thực chất của các văn bản do Bộ tham mưu hoặc ban hành. Hạn chế này thể hiện ở chỗ nhiều văn bản tuy đã được ban hành nhưng chưa theo kịp biến đổi thực tiễn, chưa gắn chặt với yêu cầu quản lý theo kết quả, chưa tạo được khuôn khổ điều tiết đủ rõ cho phối hợp liên ngành và chưa chuyển mạnh sang logic quản lý theo chuẩn đầu ra. Nói cách khác, nguyên nhân chủ quan đầu tiên không nằm ở việc

Bộ không ban hành chính sách, mà ở chất lượng thiết kế chính sách và khả năng chuyển chính sách thành công cụ quản lý thực chất còn hạn chế (Bộ Xây dựng, 2026a; OECD, 2014; OECD, 2019a).

Hai là, năng lực tổ chức thực hiện và quản trị thay đổi của trục quản lý thuộc Bộ còn chưa theo kịp yêu cầu của giai đoạn chuyển tiếp, nhất là trong bối cảnh điều chỉnh tổ chức bộ máy theo mốc tháng 3/2025. Việc sắp xếp đầu mối, kế thừa dữ liệu, tài sản, hợp đồng dịch vụ công và phân định lại vai trò giữa Bộ, Cục Hàng hải và Đường thủy Việt Nam, Cảng vụ và các đơn vị cung ứng đã làm gia tăng áp lực phối hợp và làm lộ rõ những hạn chế về quản lý hiệu suất, quản lý hợp đồng và quản trị dữ liệu. Khi chưa có đủ công cụ quản trị hiện đại như KPI, SLA và hệ thống dữ liệu đồng bộ, quá trình phân cấp, điều phối và kiểm soát chất lượng đầu ra khó đạt hiệu quả như yêu cầu. Vì vậy, không ít hạn chế trong khâu tổ chức thực hiện bắt nguồn từ chính năng lực vận hành bộ máy và quản trị chuyển đổi của chủ thể quản lý (Bộ Xây dựng, 2025a, 2025b, 2025e; Chính phủ nước CHXHCN Việt Nam, 2019; Chính phủ nước CHXHCN Việt Nam, 2025b, 2025e).

Ba là, phương thức quản lý của Bộ và các cơ quan thuộc Bộ vẫn còn chịu ảnh hưởng khá rõ của thói quen quản lý truyền thống, nặng về hồ sơ, thủ tục và kiểm tra tuân thủ hình thức. Điều này làm cho khâu giám sát chưa chuyển mạnh sang đánh giá dựa trên rủi ro, dữ liệu và kết quả đầu ra; đồng thời làm hạn chế khả năng phát hiện sớm rủi ro, cảnh báo sớm và phản hồi chính sách. Bên cạnh đó, năng lực khai thác, phân tích và sử dụng dữ liệu của đội ngũ cán bộ quản lý còn chưa đồng đều; trách nhiệm giải trình và động lực cải tiến trong một số khâu chưa đủ mạnh; vì vậy công tác giám sát, nghiệm thu và điều chỉnh quản lý vẫn còn chậm và thiếu tính chủ động. Đây là nguyên nhân chủ quan có ý nghĩa trực tiếp đối với các hạn chế ở cả trục hệ thống và trục dịch vụ, nhất là đối với các khâu giám sát còn yếu (Bộ Xây dựng, 2025b; Bộ Xây dựng, 2026a).

Trên cơ sở phân tích tại mục 2.4.2 và 2.4.3, có thể khái quát ma trận hạn chế, nguyên nhân chủ quan và nguyên nhân khách quan theo hai nội dung quản lý nhà nước về bảo đảm an toàn hàng hải như sau:

[TABLE_PLACEHOLDER]
Table ID: T_DOCX_022
Table number: 2.16
Title: Tổng hợp khái quát hạn chế và nguyên nhân trong tổ chức, quản lý hệ thống và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải
Candidate: ../../04_tables/rebuild_candidates/T_DOCX_022_candidate.md
[/TABLE_PLACEHOLDER]

Từ hạn chế trong quản lý, nguyên nhân chủ quan, nguyên nhân khách quan được tổng hợp trong Bảng 2.16 và kết quả phân tích định lượng tại mục 2.3 là cơ sở để Chương 3 đề xuất hệ thống giải pháp và kiến nghị đồng bộ nhằm hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam đến năm 2030, tầm nhìn đến năm 2045 phù hợp với xu thế phát triển của đất nước trong điều kiện chuyển đổi số toàn diện và hợp tác quốc tế sâu rộng trong lĩnh vực hàng hải.
