# Table Candidate

## Table ID
T_DOCX_012

## Manuscript number
Bảng 2.6

## Title
Mức độ số hóa các thành phần quản lý tài sản hệ thống bảo đảm an toàn hàng hải

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025 > 2.2.1. Thực trạng tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải > 2.2.1.2. Tổ chức thực hiện quản lý và vận hành hệ thống bảo đảm an toàn hàng hải

## Source note
Nguồn: Tổng hợp từ dữ liệu Cục Hàng hải Việt Nam, Quyết định 1009/QĐ-BGTVT và Báo cáo tổng kết thi hành Bộ luật Hàng hải Việt Nam năm 2015 (Bộ Xây dựng, 2026a).

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Thành phần tài sản | Trạng thái số hóa | Công nghệ ứng dụng | Hiệu quả quản lý |
| --- | --- | --- | --- |
| Hồ sơ tàu biển và kiểm định | 100% | Cơ sở dữ liệu tập trung | Truy xuất và phê duyệt trực tuyến |
| Mạng lưới báo hiệu hàng hải | 85% | GIS / AIS / GSM | Giám sát vị trí & trạng thái thực |
| Luồng hàng hải và đèn biển | 100% | ENC / Digital Profile | Lập kế hoạch bảo trì dựa trên dữ liệu |
| Điều tiết giao thông | 50% | VTS / Big Data | Dự báo xung đột và phân luồng từ xa |
