# Table Candidate

## Table ID
T_DOCX_009

## Manuscript number
Bảng 2.3

## Title
Đối chiếu sự chuyển dịch mô hình quản trị hệ thống bảo đảm an toàn hàng hải

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025 > 2.2.1. Thực trạng tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải > 2.2.1.2. Tổ chức thực hiện quản lý và vận hành hệ thống bảo đảm an toàn hàng hải

## Source note
Nguồn: Nghiên cứu sinh tổng hợp và phân tích từ hệ thống pháp luật hàng hải Việt Nam, 2025.

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Đặc điểm | Mô hình hành chính truyền thống | Mô hình quản trị hiện đại |
| --- | --- | --- |
| Vai trò Nhà nước | Trực tiếp điều hành và thực hiện | Kiến tạo, sở hữu và giám sát hiệu quả |
| Phương thức đầu tư | Dàn trải, dựa trên kế hoạch hành chính | Tập trung trọng điểm, dựa trên hiệu quả kinh tế |
| Công cụ quản lý | Mệnh lệnh và phê duyệt hồ sơ | Chỉ số KPI, tiêu chuẩn SLA và dữ liệu thực |
| Trách nhiệm giải trình | Tập thể, chưa rõ định mức kết quả | Cá nhân hóa thông qua Ban Quản lý chuyên ngành |
