# Table Candidate

## Table ID
T_DOCX_011

## Manuscript number
Bảng 2.5

## Title
Chỉ số độ tin cậy vận hành hệ thống bảo đảm an toàn hàng hải

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025 > 2.2.1. Thực trạng tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải > 2.2.1.2. Tổ chức thực hiện quản lý và vận hành hệ thống bảo đảm an toàn hàng hải

## Source note
Nguồn: NCS tổng hợp từ Báo cáo Tổng kết thi hành Bộ luật hàng hải (Bộ Xây dựng, 2026a), 2026.

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Thành phần hệ thống | Quy mô quản lý | Chỉ số tin cậy (SLA) | Chuẩn mực đối chiếu |
| --- | --- | --- | --- |
| Đèn biển quốc gia | 95 trạm | > 99,5% | IALA / QCVN |
| Báo hiệu luồng hàng hải | 1.061 phao | > 99,0% | IALA / QCVN |
| Luồng hàng hải công cộng | 1.091 km | Duy trì chuẩn tắc | Thiết kế phê duyệt/QCVN |
