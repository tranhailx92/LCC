# Table Candidate

## Table ID
T_DOCX_007

## Manuscript number
Bảng 2.1

## Title
So sánh cơ cấu quản lý nhà nước về bảo đảm an toàn hàng hải trước và sau hợp nhất

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.1. KHÁI QUÁT NGÀNH HÀNG HẢI VÀ BỘ MÁY QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.1.2. Bộ máy quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam > 2.1.2.1. Cơ cấu quản lý nhà nước về bảo đảm an toàn hàng hải

## Source note
Nguồn: Nghiên cứu sinh tổng hợp từ hệ thống văn bản pháp luật hàng hải, 2026.

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Tiêu chí so sánh | Trước thời điểm hợp nhất tháng 3/2025 | Sau thời điểm hợp nhất tháng 3/2025 |
| --- | --- | --- |
| Cơ sở pháp lý | Bộ luật Hàng hải 2015, Nghị định số 56/2022/NĐ-CP ngày 24/8/2022 của Chính phủ | Bộ luật Hàng hải 2015, Nghị định số 33/2025/NĐ-CP, ngày 25/02/2025 của Chính phủ |
| Chủ thể quản lý cấp Bộ | Bộ Giao thông vận tải (GTVT) quản lý nhà nước lĩnh vực giao thông vận tải, bao gồm hàng hải và dịch vụ công liên quan | Bộ Xây dựng quản lý nhà nước cả lĩnh vực xây dựng và giao thông vận tải, bao gồm hàng hải; đồng thời quản lý dịch vụ công thuộc phạm vi quản lý |
| Trục quản lý ngành (Cục) | Cục Hàng hải Việt Nam là cục quản lý chuyên ngành hàng hải trực thuộc Bộ Giao thông vận tải; tham mưu và tổ chức thực thi pháp luật chuyên ngành hàng hải trên phạm vi cả nước. | Cục Hàng hải và Đường thủy Việt Nam (VIMAWA) là tổ chức trực thuộc Bộ Xây dựng, tham mưu và tổ chức thực thi pháp luật chuyên ngành hàng hải và đường thủy nội địa trên phạm vi cả nước. |
| Tuyến quản lý hiện trường (hệ thống các Cảng vụ) | 25 đơn vị Cảng vụ hàng hải thực thi quản lý nhà nước tại cảng biển/khu vực hàng hải theo trục ngành dọc hàng hải. (Thông tư số 32/2019/TT-BGTVT) | 18 đơn vị Cảng vụ hàng hải và 4 cảng vụ đường thủy trực thuộc VIMAWA thực hiện quản lý nhà nước về hàng hải và đường thủy nội địa tại địa bàn (Thông tư số 18/2025/TT-BXD) |
| Doanh nghiệp công ích và đơn vị cung ứng dịch vụ bảo đảm an toàn hàng hải chủ yếu trực thuộc Bộ Xây dựng | - 2 Tổng công ty BĐATHH miền Nam và Tổng công ty BĐATHH miền Bắc. / - 9 Công ty hoa tiêu hàng hải trực thuộc Bộ GTVT/12 công ty toàn quốc. / - Trung tâm phối hợp và tìm kiếm cứu nạn hàng hải Việt Nam: 4 khu vực (SAR) / - Công ty TNHH MTV Thông tin Điện tử Hàng hải Việt Nam (VISHIPEL): 33 đài | - 1 Tổng công ty BĐATHH Việt Nam (VMSC) / - 2 Công ty hoa tiêu hàng hải miền Nam, miền Bắc trực thuộc VMSC (Bộ Xây dựng) / 5 Công ty toàn quốc. / - Trung tâm phối hợp và tìm kiếm cứu nạn hàng hải Việt Nam: 4 khu vực (SAR) trực thuộc Cục HHĐTVN / - Công ty TNHH MTV Thông tin Điện tử Hàng hải Việt Nam (VISHIPEL): 33 đài |
