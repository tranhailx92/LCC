# Table Candidate

## Table ID
T_DOCX_029

## Manuscript number
Bảng 3.7

## Title
Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện giám sát, đánh giá chất lượng dịch vụ bảo đảm an toàn hàng hải

## Context
Chương 3. GIẢI PHÁP HOÀN THIỆN QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 3.2. GIẢI PHÁP HOÀN THIỆN QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM ĐẾN NĂM 2030, TẦM NHÌN ĐẾN NĂM 2045 > 3.2.2. Nhóm giải pháp hoàn thiện quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải > 3.2.2.3. Hoàn thiện công tác giám sát, đánh giá chất lượng dịch vụ bảo đảm an toàn hàng hải

## Source note
Nguồn: Nghiên cứu sinh đề xuất, kết hợp với khung giải pháp của luận án, 2026

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Giai đoạn | Kết quả kỳ vọng đạt được | KPI đánh giá kết quả quản lý | Trọng tâm |
| --- | --- | --- | --- |
| 2026–2030 | - Thiết lập và vận hành khung KPI/SLA tối thiểu. / - Tăng tỷ lệ hợp đồng có KPI/SLA được quy định, theo dõi. / - Tăng tỷ lệ nghiệm thu có giám sát độc lập. / - Nâng tỷ lệ thực hiện khuyến nghị sau thanh tra, kiểm tra. / - Cải thiện mức độ hài lòng của doanh nghiệp, chủ tàu đối với dịch vụ BĐATHH. | - D3.1 Tỷ lệ hợp đồng dịch vụ công có KPI/SLA được quy định, theo dõi. / - D3.2 Tỷ lệ nghiệm thu dịch vụ có giám sát độc lập. / - D3.3 Tỷ lệ khuyến nghị sau thanh tra, kiểm tra được thực hiện. / - D3.4 Mức độ hài lòng của doanh nghiệp, chủ tàu về dịch vụ BĐATHH. / - D3.5 Tỷ lệ tai nạn, sự cố do chất lượng dịch vụ BĐATHH. | - D3.1 / - D3.2 / - D3.3 |
| 2031–2045 | - Phát triển giám sát liên tục và hậu kiểm thông minh dựa trên dữ liệu. / - Công khai có chọn lọc kết quả đánh giá chất lượng. / - Giảm tỷ lệ tai nạn, sự cố do chất lượng dịch vụ. / - Củng cố mô hình giám sát dịch vụ theo chuẩn đầu ra và phản hồi xử lý rõ hơn. | - D3.3 / - D3.4 / - D3.5 |  |
