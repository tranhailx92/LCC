# Table Candidate

## Table ID
T_DOCX_018

## Manuscript number
Bảng 2.12

## Title
Tổng hợp kết quả thanh tra, kiểm tra chuyên ngành đối với doanh nghiệp cung ứng dịch vụ hàng hải (2019–2023)

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025 > 2.2.2. Thực trạng quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải > 2.2.2.3. Giám sát, đánh giá chất lượng dịch vụ bảo đảm an toàn hàng hải

## Source note
Nguồn: NCS tổng hợp từ Báo cáo tổng kết công tác Thanh tra ngành Giao thông vận tải và Cục Hàng hải Việt Nam các năm 2019, 2020, 2021, 2022, 2023.

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Chỉ tiêu giám sát | Năm 2019 | Năm 2020 | Năm 2021 | Năm 2022 | Năm 2023 | Xu hướng |
| --- | --- | --- | --- | --- | --- | --- |
| 1. Tổng số cuộc thanh tra, kiểm tra | 145 | 112 | 98 | 156 | 172 | Tăng |
| Trong đó: Kiểm tra đột xuất (%) | 12% | 8% | 5% | 15% | 18% | Thấp |
| 2. Tổng số vi phạm phát hiện | 210 | 154 | 132 | 245 | 280 | Tăng |
| 3. Phân loại tính chất vi phạm: |  |  |  |  |  |  |
| - Vi phạm hành chính (Hồ sơ, nhật ký, báo cáo) | 82% | 85% | 88% | 79% | 76% | Chiếm đa số |
| - Vi phạm kỹ thuật/Chất lượng dịch vụ thực tế | 18% | 15% | 12% | 21% | 24% | Chiếm thiểu số |
| 4. Tỷ lệ xử phạt vi phạm trên tổng số vi phạm | 35% | 30% | 28% | 40% | 42% | Trung bình |
