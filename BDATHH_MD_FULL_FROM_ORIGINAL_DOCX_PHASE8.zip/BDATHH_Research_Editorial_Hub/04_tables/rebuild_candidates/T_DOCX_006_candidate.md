# Table Candidate

## Table ID
T_DOCX_006

## Manuscript number
Bảng 1.6

## Title
Tổng hợp kinh nghiệm quốc tế trong quản lý nhà nước về bảo đảm an toàn hàng hải theo khung phân tích 2×3

## Context
Chương 1. CƠ SỞ LÝ LUẬN VÀ KINH NGHIỆM QUỐC TẾ TRONG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI > 1.3. KINH NGHIỆM QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI CỦA MỘT SỐ QUỐC GIA TRÊN THẾ GIỚI VÀ BÀI HỌC RÚT RA CHO VIỆT NAM > 1.3.2. Bài học kinh nghiệm cho Việt Nam > 1.3.2.2. Bài học kinh nghiệm về quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

## Source note
Nguồn: Nghiên cứu sinh tổng hợp từ kinh nghiệm Singapore, Malaysia, Nhật Bản, EU, Châu Phi, 2025.

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Nội dung | Ban hành | Tổ chức thực hiện | Giám sát, đánh giá |
| --- | --- | --- | --- |
| Quản lý hệ thống BĐATHH (H1–H2–H3) | Ban hành chính sách đầu tư theo rủi ro, vòng đời tài sản; gắn phát triển hạ tầng với chuẩn hóa, liên thông dữ liệu. | Tổ chức đầu tư có trọng điểm vào khu vực rủi ro cao; số hóa và tích hợp dữ liệu để nâng cao hiệu quả điều phối. | Giám sát liên tục tình trạng vận hành, mức độ sẵn sàng của hệ thống bằng KPI, bảng điều khiển giám sát và dữ liệu thực tế. |
| Quản lý cung ứng dịch vụ BĐATHH (D1–D2–D3) | Ban hành chuẩn dịch vụ rõ ràng, đo lường được; xây dựng KPI/SLA cho từng loại dịch vụ. | Chuẩn hóa quy trình tác nghiệp, đào tạo nhân lực, tăng cường phối hợp và kết nối dữ liệu trong cung ứng dịch vụ. | Giám sát chất lượng dịch vụ dựa trên dữ liệu thực, theo dõi thời gian, độ tin cậy, độ bao phủ và phản hồi người dùng. |
