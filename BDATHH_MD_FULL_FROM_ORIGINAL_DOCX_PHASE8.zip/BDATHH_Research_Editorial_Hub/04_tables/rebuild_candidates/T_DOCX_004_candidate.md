# Table Candidate

## Table ID
T_DOCX_004

## Manuscript number
Bảng 1.4

## Title
Tổng hợp các tiêu chí đánh giá kết quả quản lý nhà nước về bảo đảm an toàn hàng hải theo khung phân tích 2×3

## Context
Chương 1. CƠ SỞ LÝ LUẬN VÀ KINH NGHIỆM QUỐC TẾ TRONG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI > 1.2. QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI > 1.2.3. Tiêu chí đánh giá và các yếu tố ảnh hưởng tới kết quả quản lý nhà nước về bảo đảm an toàn hàng hải > 1.2.3.1. Tiêu chí đánh giá kết quả quản lý nhà nước về bảo đảm an toàn hàng hải

## Source note
Nguồn: Nghiên cứu sinh tổng hợp và đề xuất, 2026.

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Chức năng | Quản lý hệ thống BĐATHH (trục H) | Quản lý cung ứng dịch vụ BĐATHH (trục D) |
| --- | --- | --- |
| Ban hành thể chế (BH) | Tiêu chí 1 (H1): / • Đầy đủ, đồng bộ VB/QCVN/quy hoạch hệ thống / • Tham vấn và đánh giá tác động quy định trước ban hành / • Rà soát, cập nhật theo chu kỳ / • Mức độ nội luật hóa chuẩn IALA/SOLAS/IHO / • Số hóa và công khai thông tin chính sách | Tiêu chí 2 (D1): / • Chất lượng thể chế về cơ chế tài chính và định mức đơn giá dịch vụ / • Tính kịp thời, minh bạch khi ban hành / • Mức độ tiếp thu khuyến nghị quốc tế và doanh nghiệp / • Công khai văn bản giá, phí, lệ phí, định mức |
| Tổ chức thực hiện (TH) | Tiêu chí 3 (H2): / • Hiệu quả triển khai dự án đầu tư hạ tầng (tiến độ, chất lượng, chi phí) / • Mức độ áp dụng quản lý dựa trên rủi ro trong duy tu bảo trì / • Tuân thủ kế hoạch duy tu bảo trì theo vòng đời tài sản / • Chất lượng hệ thống dữ liệu quản lý tài sản; số hóa thủ tục hành chính | Tiêu chí 4 (D2): / • Tính liên tục và đáp ứng kỹ thuật của dịch vụ so với SLA/KPI đã cam kết / • Minh bạch cơ chế lựa chọn nhà cung ứng / • Không gián đoạn dịch vụ; ký kết hợp đồng đúng hạn / • Đánh giá định kỳ năng lực nhà cung ứng |
| Giám sát & đánh giá (GS) | Tiêu chí 5 (H3): / • Tỷ lệ kế hoạch thanh tra, kiểm tra được thực hiện / • Mức độ áp dụng kiểm tra theo rủi ro thay vì định kỳ / • Tỷ lệ khiếm khuyết phát hiện chủ động và khắc phục đúng hạn / • Tần suất cập nhật dữ liệu trạng thái hệ thống trên nền tảng số / • Hiệu quả tài chính: định mức, chi phí bình quân, minh bạch tài khóa | Tiêu chí 6 (D3): / • Tỷ lệ hợp đồng có KPI/SLA được theo dõi và nghiệm thu độc lập / • Tỷ lệ khuyến nghị sau thanh tra được thực hiện đúng hạn / • Mức độ hài lòng của doanh nghiệp và thuyền viên (khảo sát định kỳ) / • Công bố báo cáo hiệu quả QLNN hằng năm / • Hiệu quả tiếp nhận và xử lý phản ánh, kiến nghị |
