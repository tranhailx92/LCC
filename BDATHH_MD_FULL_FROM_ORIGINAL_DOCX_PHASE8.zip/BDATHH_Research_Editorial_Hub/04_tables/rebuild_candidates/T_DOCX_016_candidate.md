# Table Candidate

## Table ID
T_DOCX_016

## Manuscript number
Bảng 2.10

## Title
Tổng hợp kết quả quản lý giữa dịch vụ thông tin và dịch vụ hạ tầng cứng (2020–2025)

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025 > 2.2.2. Thực trạng quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải > 2.2.2.2. Tổ chức thực hiện, quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

## Source note
Nguồn: Nghiên cứu sinh tổng hợp từ Báo cáo Kiểm toán Nhà nước, 2023.

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Tiêu chí | Dịch vụ thông tin hàng hải (VTS/Duyên hải) | Dịch vụ kỹ thuật hạ tầng (Nạo vét/Bảo trì) |
| --- | --- | --- |
| Cơ chế thực hiện | Số hóa, vận hành liên tục | Công trình xây dựng, theo thời vụ |
| Độ sẵn sàng | > 99% (đạt chuẩn quốc tế) | Không ổn định tại 20% khu vực luồng |
| Quy trình | Đã được chuẩn hóa quy trình | Vướng mắc thủ tục đấu thầu/định mức |
| Kết quả | Đảm bảo thông tin thông suốt | Tăng nguy cơ mắc cạn cục bộ |
