# Table Candidate

## Table ID
T_DOCX_002

## Manuscript number
Bảng 1.2

## Title
Tổng hợp một số cách tiếp cận về bảo đảm an toàn hàng hải

## Context
Chương 1. CƠ SỞ LÝ LUẬN VÀ KINH NGHIỆM QUỐC TẾ TRONG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI > 1.1. KHÁI QUÁT VỀ AN TOÀN HÀNG HẢI VÀ BẢO ĐẢM AN TOÀN HÀNG HẢI > 1.1.2. Khái niệm bảo đảm an toàn hàng hải

## Source note
Nguồn: Nghiên cứu sinh tổng hợp từ (IMO, 1974), (IMO, 2003), (IMO, 2024b, 2024c), (IALA, 2023), (IHO, 2022), (UNCTAD, 2024).

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Nguồn | Trọng tâm khái niệm | Hàm ý mức dịch vụ hoặc quản lý |
| --- | --- | --- |
| IMO 1974; 2003; 2024 | Trách nhiệm quốc gia ven biển tổ chức dịch vụ công thiết yếu (AtoN, VTS, SAR). | Nội luật hóa chuẩn mực quốc tế, tổ chức thực thi thống nhất và bảo đảm liên tục của dịch vụ công. |
| IALA 2023 | Cung ứng dịch vụ với chỉ số kỹ thuật đo lường được. | Độ sẵn sàng, độ tin cậy, thời gian khôi phục và chất lượng đầu ra. |
| IHO 2022; IMO 2024 | Cấu phần e-Navigation với dữ liệu, hải đồ điện tử, thông tin cảnh báo. | Quản trị dữ liệu nền, liên thông thông tin và cập nhật kịp thời trở thành yêu cầu bắt buộc. |
| UNCTAD 2024 | Nhân tố cạnh tranh logistics, độ tin cậy chuỗi cung ứng và chi phí thương mại biển. | Gắn an toàn hàng hải với hiệu quả logistics, phục hồi chuỗi cung ứng và phát triển kinh tế biển. |
| EMSA 2025 | Quản trị rủi ro dựa trên dữ liệu và khả năng phục hồi của hệ thống khi xảy ra gián đoạn. | Cần phát triển bảng điều khiển giám sát, KPI/SLA và cơ chế điều phối đa chủ thể trên nền tảng số. |
