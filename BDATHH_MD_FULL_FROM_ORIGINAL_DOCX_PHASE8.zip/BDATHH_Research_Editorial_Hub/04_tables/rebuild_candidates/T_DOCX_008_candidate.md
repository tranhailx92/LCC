# Table Candidate

## Table ID
T_DOCX_008

## Manuscript number
Bảng 2.2

## Title
Hệ thống văn bản quy phạm pháp luật quản lý vòng đời tài sản

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025 > 2.2.1. Thực trạng tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải > 2.2.1.1. Ban hành cơ chế, pháp luật, quy hoạch hệ thống bảo đảm an toàn hàng hải

## Source note
Nguồn: Nghiên cứu sinh tổng hợp từ hệ thống văn bản quy phạm pháp luật, 2025.

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Số, ký hiệu văn bản | Trích yếu nội dung cốt lõi | Tác động đến công tác quản lý vòng đời tài sản |
| --- | --- | --- |
| Nghị định số 58/2017/NĐ-CP (và các văn bản sửa đổi) | Quy định chi tiết một số điều của Bộ luật Hàng hải Việt Nam về quản lý hoạt động hàng hải | Thiết lập hành lang pháp lý vĩ mô phục vụ công tác đầu tư, duy tu và bảo vệ công trình hàng hải |
| Nghị định số 84/2025/NĐ-CP. | Quy định việc quản lý, sử dụng và khai thác tài sản kết cấu hạ tầng hàng hải | Kiến tạo cơ chế chuyển đổi sang quản trị vòng đời tài sản; mở ra phương thức nhượng quyền và xã hội hóa |
| Văn bản hợp nhất số 02/VBHN-BXD. | Hợp nhất Nghị định số 58/2017/NĐ-CP và các quy định sửa đổi, bổ sung liên quan | Khắc phục sự phân tán của hệ thống văn bản, bảo đảm tính liên tục của quản lý nhà nước sau sáp nhập |
