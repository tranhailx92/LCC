# Table Candidate

## Table ID
T_DOCX_017

## Manuscript number
Bảng 2.11

## Title
Năng lực cung ứng dịch vụ hoa tiêu hàng hải (2019–2025)

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025 > 2.2.2. Thực trạng quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải > 2.2.2.2. Tổ chức thực hiện, quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

## Source note
Nguồn: Tổng hợp dữ liệu quản lý vận hành từ các doanh nghiệp cung ứng dịch vụ.

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Năm | Tổng số lượt dẫn tàu thực hiện | Tỷ lệ biến động / Đánh giá |
| --- | --- | --- |
| 2019 | 76.400 | - |
| 2020 | 68.200 | -10,73% |
| 2021 | 62.500 | -8,36% |
| 2022 | 65.800 | +5,28% |
| 2023 | 71.200 | +8,21% |
| 2024 | 76.500 | +7,44% |
| 2025 | 79.307 | 101,69% kế hoạch |
