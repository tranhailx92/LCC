# Table Candidate

## Table ID
T_DOCX_020

## Manuscript number
Bảng 2.14

## Title
Ma trận tương quan Pearson giữa các biến nghiên cứu và chỉ số VIF

## Context
Chương 2. THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.3. ĐÁNH GIÁ ĐỊNH LƯỢNG CÁC YẾU TỐ ẢNH HƯỞNG TỚI KẾT QUẢ QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM > 2.3.3. Kết quả phân tích mô hình nghiên cứu > 2.3.3.2. Ma trận tương quan giữa các cấu phần và kiểm tra đa cộng tuyến

## Source note
Nguồn: Kết quả phân tích định lượng qua khảo sát bằng bảng hỏi (N = 250), năm 2025.

## Candidate status
CANDIDATE_READY_FOR_INTEGRATION

## Candidate table content
| Biến | H1 | H2 | H3 | D1 | D2 | D3 | Y | VIF |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| H1 | 1,000 | 0,659 | 0,448 | 0,291 | 0,487 | 0,347 | 0,767 | 2,005 |
| H2 | 0,659 | 1,000 | 0,437 | 0,307 | 0,508 | 0,325 | 0,800 | 2,021 |
| H3 | 0,448 | 0,437 | 1,000 | 0,221 | 0,327 | 0,254 | 0,454 | 1,330 |
| D1 | 0,291 | 0,307 | 0,221 | 1,000 | 0,228 | 0,636 | 0,385 | 1,712 |
| D2 | 0,487 | 0,508 | 0,327 | 0,228 | 1,000 | 0,255 | 0,586 | 1,443 |
| D3 | 0,347 | 0,325 | 0,254 | 0,636 | 0,255 | 1,000 | 0,430 | 1,775 |
| Y | 0,767 | 0,800 | 0,454 | 0,385 | 0,586 | 0,430 | 1,000 |  |
