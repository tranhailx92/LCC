# T_DOCX_003 — Bảng 1.3

**Bảng 1.3. Nội dung quản lý nhà nước về bảo đảm an toàn hàng hải theo khung phân tích 2×3**

| Chức năng QLNN | Tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải (H1–H2–H3) | Quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải (D1–D2–D3) |
| --- | --- | --- |
| Ban hành thể chế (H1–D1) | - Ban hành văn bản pháp luật, cơ chế hệ thống / - Quy hoạch mạng lưới luồng, đèn, đài trạm; số hóa / - Quy chuẩn, tiêu chuẩn kỹ thuật công trình, báo hiệu... / - Định mức kinh tế - kỹ thuật / - Cơ chế tài chính, huy động nguồn lực xã hội | - Ban hành quy định danh mục, tiêu chuẩn chất lượng (KPI/SLA) và điều kiện kinh doanh dịch vụ / - Khung giá/phí/lệ phí dịch vụ và cơ chế tài chính / - Chuẩn năng lực nhân lực dịch vụ / - Điều kiện và tiêu chuẩn cấp phép đào tạo |
| Tổ chức thực hiện (H2–D2) | - Quản lý dự án đầu tư xây dựng và hiện thực hóa quy hoạch / - Quản lý bảo trì, nạo vét duy tu luồng hàng hải / - Số hóa và quản lý dữ liệu tài sản | - Đặt hàng/đấu thầu/giao nhiệm vụ... dịch vụ / - Điều tiết cung ứng dịch vụ / - Quản lý hoạt động cơ sở đào tạo và cấp chứng chỉ chuyên môn, đào tạo nhân lực dịch vụ / - Ứng dụng công nghệ số |
| Kiểm tra giám sát (H3–D3) | - Thanh tra, kiểm tra hệ thống / - Nghiệm thu chất lượng công trình hệ thống / - Giám sát an toàn hàng hải và môi trường biển / - Điều tra sự cố hàng hải | - Giám sát tuân thủ cam kết SLA/KPI / - Nghiệm thu và thanh quyết toán dịch vụ / - Thanh tra năng lực thực tế và tuân thủ tại cảng biển / - Xử lý vi phạm và cưỡng chế thực thi / - Đánh giá sự hài lòng và xếp hạng nhà cung cấp |

*Nguồn: Nghiên cứu sinh đề xuất, 2025.*
