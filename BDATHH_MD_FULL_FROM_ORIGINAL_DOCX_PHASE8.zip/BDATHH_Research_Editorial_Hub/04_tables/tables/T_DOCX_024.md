# T_DOCX_024 — Bảng 3.2

**Bảng 3.2. Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện cơ chế, chính sách về quản lý hệ thống bảo đảm an toàn hàng hải**

| Giai đoạn | Kết quả kỳ vọng đạt được | KPI đánh giá kết quả quản lý | Trọng tâm |
| --- | --- | --- | --- |
| Đến năm 2030 | - Hoàn thiện tương đối đồng bộ khung thể chế pháp lý đối với tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải. / - Chuẩn hóa văn bản, quy hoạch, QCVN và trách nhiệm giải trình. / - Tăng mức độ số hóa, công khai thông tin quản lý hệ thống. | - H1.1 Tỷ lệ nhiệm vụ xây dựng VB/QCVN/quy hoạch hoàn thành đúng tiến độ. / - H1.2 Tỷ lệ văn bản/quy hoạch có tham vấn chính thức. / - H1.3 Tỷ lệ quy hoạch/QCVN được rà soát, cập nhật đúng chu kỳ. / - H1.4 Tỷ lệ chuẩn mực quốc tế được nội luật hóa. / - H1.5 Tỷ lệ quy hoạch/QCVN/danh mục luồng được số hóa, công khai. | - H1.1 / - H1.3 / - H1.5 |
| 2031–2045 | - Duy trì cơ chế rà soát, cập nhật thể chế theo chu kỳ. / - Tăng khả năng thích ứng của khung pháp lý với công nghệ mới và chuẩn quốc tế. / - Vận hành khung quản trị hệ thống theo hướng liên thông, số hóa và minh bạch hơn. | - H1.3 / - H1.4 / - H1.5 |  |

*Nguồn: Nghiên cứu sinh đề xuất, kết hợp với khung giải pháp của luận án, 2026*
