# T_DOCX_016 — Bảng 2.10

**Bảng 2.10. Tổng hợp kết quả quản lý giữa dịch vụ thông tin và dịch vụ hạ tầng cứng (2020–2025)**

| Tiêu chí | Dịch vụ thông tin hàng hải (VTS/Duyên hải) | Dịch vụ kỹ thuật hạ tầng (Nạo vét/Bảo trì) |
| --- | --- | --- |
| Cơ chế thực hiện | Số hóa, vận hành liên tục | Công trình xây dựng, theo thời vụ |
| Độ sẵn sàng | > 99% (đạt chuẩn quốc tế) | Không ổn định tại 20% khu vực luồng |
| Quy trình | Đã được chuẩn hóa quy trình | Vướng mắc thủ tục đấu thầu/định mức |
| Kết quả | Đảm bảo thông tin thông suốt | Tăng nguy cơ mắc cạn cục bộ |

*Nguồn: Nghiên cứu sinh tổng hợp từ Báo cáo Kiểm toán Nhà nước, 2023.*
