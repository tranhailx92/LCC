# T_DOCX_009 — Bảng 2.3

**Bảng 2.3. Đối chiếu sự chuyển dịch mô hình quản trị hệ thống bảo đảm an toàn hàng hải**

| Đặc điểm | Mô hình hành chính truyền thống | Mô hình quản trị hiện đại |
| --- | --- | --- |
| Vai trò Nhà nước | Trực tiếp điều hành và thực hiện | Kiến tạo, sở hữu và giám sát hiệu quả |
| Phương thức đầu tư | Dàn trải, dựa trên kế hoạch hành chính | Tập trung trọng điểm, dựa trên hiệu quả kinh tế |
| Công cụ quản lý | Mệnh lệnh và phê duyệt hồ sơ | Chỉ số KPI, tiêu chuẩn SLA và dữ liệu thực |
| Trách nhiệm giải trình | Tập thể, chưa rõ định mức kết quả | Cá nhân hóa thông qua Ban Quản lý chuyên ngành |

*Nguồn: Nghiên cứu sinh tổng hợp và phân tích từ hệ thống pháp luật hàng hải Việt Nam, 2025.*
