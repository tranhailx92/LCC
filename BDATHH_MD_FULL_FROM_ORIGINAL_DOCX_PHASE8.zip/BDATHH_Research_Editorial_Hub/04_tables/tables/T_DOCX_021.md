# T_DOCX_021 — Bảng 2.15

**Bảng 2.15. Kết quả ước lượng mô hình hồi quy tuyến tính bội theo khung 2×3**

| Cấu phần | Quan hệ | Beta chuẩn hóa | Sai số chuẩn | Giá trị t | p-value | Kết luận |
| --- | --- | --- | --- | --- | --- | --- |
| H1 | Ban hành hệ thống → Kết quả quản lý | 0,348 | 0,043 | 8,090 | <0,001 | Có ý nghĩa thống kê |
| H2 | Thực hiện hệ thống → Kết quả quản lý | 0,438 | 0,043 | 10,150 | <0,001 | Có ý nghĩa thống kê |
| H3 | Giám sát hệ thống → Kết quả quản lý | 0,022 | 0,035 | 0,639 | 0,524 | Không có ý nghĩa thống kê |
| D1 | Ban hành dịch vụ → Kết quả quản lý | 0,054 | 0,040 | 1,351 | 0,178 | Không có ý nghĩa thống kê |
| D2 | Thực hiện dịch vụ → Kết quả quản lý | 0,152 | 0,036 | 4,168 | <0,001 | Có ý nghĩa thống kê |
| D3 | Giám sát dịch vụ → Kết quả quản lý | 0,088 | 0,040 | 2,185 | 0,030 | Có ý nghĩa thống kê |

*Nguồn: Kết quả phân tích định lượng qua khảo sát bằng bảng hỏi (N=250), năm 2025.*
