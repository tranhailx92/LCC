# T_DOCX_030 — Bảng 3.8

**Bảng 3.8. Tổng hợp kiến nghị hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam**

| Đối tượng kiến nghị | Nội dung kiến nghị chính | Kết quả kỳ vọng |
| --- | --- | --- |
| Quốc hội | - Sửa đổi Bộ luật Hàng hải, quản lý vòng đời hạ tầng. / - Luật hóa quản trị dữ liệu, giám sát dữ liệu. / - Hành lang pháp lý KPI/SLA, tài chính bền vững. / - Giám sát, công khai kết quả, quản trị rủi ro. | - Bộ luật Hàng hải mới. / - Luật quản trị dữ liệu, giám sát dữ liệu hàng hải. / - Nghị quyết/Chương trình giám sát chuyên đề 2026–2030 gắn KPI, công khai kết quả. |
| Chính phủ | - Cơ chế điều phối liên ngành quốc gia. / - Khung phối hợp–phân cấp, quy trình vận hành chuẩn (SOP), bản đồ trách nhiệm. / - Cơ chế tài chính trung hạn, ngân sách theo kết quả. / - Chuyển đổi số, an ninh mạng giám sát, hồ dữ liệu tập trung. | - Quyết định thành lập Ban Điều phối an toàn hàng hải và quy chế hoạt động. / - Khung phối hợp–phân cấp. / - Chương trình trung hạn lập ngân sách dựa trên kết quả/Khung chi tiêu trung hạn. / - Đề án dữ liệu–an ninh mạng hàng hải. |
| Cơ quan khác | - Cơ chế tài chính bền vững, đa dạng nguồn vốn. / - Chuẩn an ninh mạng, quy trình ứng cứu sự cố. / - Phối hợp địa phương–Cảng vụ–đơn vị vận hành. / - Doanh nghiệp tuân thủ KPI/SLA, chia sẻ dữ liệu. / - Đào tạo lại, bồi dưỡng chuẩn quốc tế, năng lực số. | - Kế hoạch phối hợp tài chính trung hạn. / - Bộ tiêu chuẩn tối thiểu, quy trình ứng cứu sự cố. / - Chương trình đào tạo/bồi dưỡng. / - Quy chế phối hợp địa phương–Cảng vụ–đơn vị vận hành. / - Trường Đại học Hàng hải Việt Nam ngang tầm khu vực và quốc tế về đào tạo nhân lực hàng hải. |

*Nguồn: Nghiên cứu sinh đề xuất, 2025.*
