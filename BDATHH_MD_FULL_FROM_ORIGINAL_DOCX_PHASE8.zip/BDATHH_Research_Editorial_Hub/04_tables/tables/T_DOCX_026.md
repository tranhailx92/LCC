# T_DOCX_026 — Bảng 3.4

**Bảng 3.4. Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện giám sát, đánh giá hệ thống bảo đảm an toàn hàng hải**

| Giai đoạn | Kết quả kỳ vọng đạt được | KPI đánh giá kết quả quản lý | Trọng tâm |
| --- | --- | --- | --- |
| Đến năm 2030 | - Hình thành cơ chế giám sát hệ thống dựa trên KPI và rủi ro. / - Tăng tỷ lệ thanh tra, kiểm tra đúng kế hoạch. / - Ưu tiên khu vực rủi ro cao trong phân bổ nguồn lực giám sát. / - Nâng tần suất cập nhật dữ liệu hiện trạng trên nền tảng số. / - Tăng tỷ lệ thực hiện khuyến nghị sau giám sát. | - H3.1 Tỷ lệ kế hoạch thanh tra, kiểm tra được thực hiện đúng quy định. / - H3.2 Tỷ lệ thanh tra/khảo sát tập trung vào khu vực rủi ro cao. / - H3.3 Tỷ lệ khiếm khuyết được phát hiện chủ động, khắc phục đúng hạn. / - H3.4 Tần suất cập nhật dữ liệu hiện trạng trên nền tảng số. / - H3.5 Tỷ lệ khuyến nghị quốc tế, trong nước được thực hiện. | - H3.2 / - H3.3 / - H3.4 |
| 2031–2045 | - Phát triển giám sát hệ thống theo hướng gần thời gian thực. / - Tăng năng lực phát hiện sớm bất thường, khắc phục chủ động và phản hồi chính sách. / - Củng cố chiều sâu giám sát dựa trên dữ liệu tích hợp. | - H3.3 / - H3.4 / - H3.5 |  |

*Nguồn: Nghiên cứu sinh đề xuất, kết hợp với khung giải pháp của luận án, 2026*
