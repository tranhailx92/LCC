# T_DOCX_023 — Bảng 3.1

**Bảng 3.1. Các tiêu chí đánh giá kết quả và mục tiêu cụ thể đến năm 2030**

| STT | Nội dung tiêu chí đánh giá | Mục tiêu cụ thể đến năm 2030 |
| --- | --- | --- |
| 1 | H1: Mức độ hoàn thiện và tỷ lệ số hóa đối với hệ thống văn bản quy phạm pháp luật, quy hoạch và quy chuẩn kỹ thuật | Phấn đấu 100% nhiệm vụ được hoàn thành đúng tiến độ; hệ thống văn bản được số hóa và công khai trên nền tảng dữ liệu tập trung. |
| 2 | H1: Mức độ nội luật hóa các điều ước và chuẩn mực quốc tế về hàng hải | Phấn đấu đạt 100% tỷ lệ nội luật hóa đối với các tiêu chuẩn cốt lõi thuộc IMO, IALA và IHO. |
| 3 | H2: Năng lực duy trì độ sẵn sàng hoạt động của hệ thống báo hiệu hàng hải và quản lý giao thông tàu thuyền (VTS) | Mức độ sẵn sàng được duy trì tối thiểu 99,8% trên toàn quốc; riêng các trạm VTS, đèn biển và phao tiêu tại các tuyến luồng trọng điểm đạt độ tin cậy từ 99,9% trở lên. |
| 4 | H2: Mức độ đáp ứng trong xử lý và khắc phục sự cố hạ tầng kỹ thuật | Thời gian khắc phục sự cố được rút ngắn xuống dưới 24 giờ đối với các hệ thống trên tuyến luồng chính. |
| 5 | H3: Năng lực kiểm soát và mức độ bao phủ giám sát tại các khu vực có rủi ro cao | Phấn đấu 100% các tuyến luồng hàng hải trọng điểm và cảng biển loại I được bao phủ bởi hệ thống giám sát tự động AIS/VTS. |
| 6 | H3: Hiệu quả kiểm soát và tỷ lệ giảm thiểu tai nạn, thương vong do sự cố hệ thống | Giảm tối thiểu 50% số người chết và mất tích so với năm 2020; kiểm soát số vụ tai nạn ở mức dưới 5–6 vụ/năm. |
| 7 | D1: Mức độ hoàn thiện và tính cập nhật của hệ thống định mức kinh tế – kỹ thuật và đơn giá dịch vụ | Phấn đấu 100% định mức và đơn giá dịch vụ sự nghiệp công được ban hành hoặc cập nhật đúng thời hạn, bảo đảm bám sát điều kiện thực tiễn. |
| 8 | D2: Năng lực đáp ứng về thời gian của dịch vụ cung cấp thông tin an toàn hàng hải | Phấn đấu 100% các thông báo hàng hải quan trọng được phát hành và truyền phát trong giới hạn 24 giờ. |
| 9 | D2: Mức độ đáp ứng yêu cầu cung cấp dịch vụ của lực lượng hoa tiêu hàng hải | Thời gian chờ hoa tiêu tại trạm được kiểm soát, bảo đảm không vượt quá 15 phút. |
| 10 | D2: Mức độ chuẩn hóa năng lực chuyên môn của lực lượng nhân sự vận hành dịch vụ công | Phấn đấu 100% cán bộ kỹ thuật và hoa tiêu đáp ứng chương trình phát triển chuyên môn liên tục và tuân thủ quy trình an toàn. |
| 11 | D3: Mức độ áp dụng tiêu chuẩn đo lường hiệu quả đối với các hợp đồng cung ứng dịch vụ công ích | Phấn đấu 100% hợp đồng đặt hàng hoặc đấu thầu cung ứng dịch vụ công ích bảo đảm an toàn hàng hải được gắn với tiêu chí đánh giá hiệu quả thực thi và cam kết chất lượng. |
| 12 | D3: Mức độ áp dụng cơ chế cam kết chất lượng dịch vụ tại các cảng biển | Phấn đấu 100% cảng biển loại I áp dụng cơ chế nghiệm thu dịch vụ và công khai cam kết chất lượng đối với người sử dụng. |

*Nguồn: Nghiên cứu sinh tổng hợp và đề xuất, 2026*
