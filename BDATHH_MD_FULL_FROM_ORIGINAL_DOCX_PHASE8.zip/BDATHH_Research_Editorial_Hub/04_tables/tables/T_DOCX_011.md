# T_DOCX_011 — Bảng 2.5

**Bảng 2.5. Chỉ số độ tin cậy vận hành hệ thống bảo đảm an toàn hàng hải**

| Thành phần hệ thống | Quy mô quản lý | Chỉ số tin cậy (SLA) | Chuẩn mực đối chiếu |
| --- | --- | --- | --- |
| Đèn biển quốc gia | 95 trạm | > 99,5% | IALA / QCVN |
| Báo hiệu luồng hàng hải | 1.061 phao | > 99,0% | IALA / QCVN |
| Luồng hàng hải công cộng | 1.091 km | Duy trì chuẩn tắc | Thiết kế phê duyệt/QCVN |

*Nguồn: NCS tổng hợp từ Báo cáo Tổng kết thi hành Bộ luật hàng hải (Bộ Xây dựng, 2026a), 2026.*
