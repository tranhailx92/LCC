# T_DOCX_008 — Bảng 2.2

**Bảng 2.2. Hệ thống văn bản quy phạm pháp luật quản lý vòng đời tài sản**

| Số, ký hiệu văn bản | Trích yếu nội dung cốt lõi | Tác động đến công tác quản lý vòng đời tài sản |
| --- | --- | --- |
| Nghị định số 58/2017/NĐ-CP (và các văn bản sửa đổi) | Quy định chi tiết một số điều của Bộ luật Hàng hải Việt Nam về quản lý hoạt động hàng hải | Thiết lập hành lang pháp lý vĩ mô phục vụ công tác đầu tư, duy tu và bảo vệ công trình hàng hải |
| Nghị định số 84/2025/NĐ-CP. | Quy định việc quản lý, sử dụng và khai thác tài sản kết cấu hạ tầng hàng hải | Kiến tạo cơ chế chuyển đổi sang quản trị vòng đời tài sản; mở ra phương thức nhượng quyền và xã hội hóa |
| Văn bản hợp nhất số 02/VBHN-BXD. | Hợp nhất Nghị định số 58/2017/NĐ-CP và các quy định sửa đổi, bổ sung liên quan | Khắc phục sự phân tán của hệ thống văn bản, bảo đảm tính liên tục của quản lý nhà nước sau sáp nhập |

*Nguồn: Nghiên cứu sinh tổng hợp từ hệ thống văn bản quy phạm pháp luật, 2025.*
