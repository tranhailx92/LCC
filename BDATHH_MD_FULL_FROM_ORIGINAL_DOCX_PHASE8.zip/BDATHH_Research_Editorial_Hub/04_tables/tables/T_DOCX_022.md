# T_DOCX_022 — Bảng 2.16

**Bảng 2.16. Tổng hợp khái quát hạn chế và nguyên nhân trong tổ chức, quản lý hệ thống và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải**

| Nội dung | Hạn chế chủ yếu | Nguyên nhân chủ quan | Nguyên nhân khách quan |
| --- | --- | --- | --- |
| Ban hành hệ thống | Khung pháp lý, tiêu chuẩn và cơ chế quản lý còn thiếu đồng bộ | Năng lực xây dựng chính sách, phối hợp và tổ chức thực hiện còn hạn chế | Lĩnh vực hàng hải liên ngành cao, công nghệ và chuẩn mực quốc tế thay đổi nhanh |
| Thực hiện hệ thống | Hạ tầng, công nghệ, nhân lực và nguồn lực bảo trì chưa đáp ứng yêu cầu | Quản trị vận hành, phân bổ nguồn lực và chuyển đổi số chưa đồng bộ | Nhu cầu đầu tư lớn, điều kiện khai thác phức tạp, áp lực hiện đại hóa cao |
| Giám sát hệ thống | Công tác giám sát, thanh tra và quản trị dữ liệu còn bất cập | Phương thức quản lý còn nặng thủ tục, năng lực khai thác dữ liệu còn hạn chế | Mô hình quản lý đa chủ thể, yêu cầu số hóa và an ninh mạng ngày càng cao |
| Ban hành dịch vụ | Cơ chế giá, tài chính và định hướng chất lượng dịch vụ chưa hoàn thiện | Tư duy quản lý đầu vào còn phổ biến, thiếu dữ liệu phục vụ quản trị kết quả | Dịch vụ hàng hải có tính kỹ thuật cao, rủi ro lớn, yêu cầu thích ứng quốc tế mạnh |
| Thực hiện dịch vụ | Tổ chức cung ứng dịch vụ và quản lý hợp đồng chưa thật sự hiệu quả | Năng lực quản lý thị trường, hợp đồng và áp dụng SLA/KPI còn hạn chế | Thị trường chuyên ngành hẹp, chi phí đầu tư và đổi mới công nghệ lớn |
| Giám sát dịch vụ | Giám sát, nghiệm thu và cơ chế phản hồi chất lượng dịch vụ còn hình thức | Năng lực phân tích dữ liệu, trách nhiệm giải trình và cơ chế tiếp nhận phản hồi còn yếu | Hạ tầng số chưa hoàn thiện, tiêu chuẩn giám sát liên thông còn thiếu |

*Nguồn: Nghiên cứu sinh tổng hợp từ mục 2.4.2 và 2.4.3, 2026*
