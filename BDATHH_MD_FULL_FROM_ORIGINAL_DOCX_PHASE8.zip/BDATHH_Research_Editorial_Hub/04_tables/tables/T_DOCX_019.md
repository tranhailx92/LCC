# T_DOCX_019 — Bảng 2.13

**Bảng 2.13. Độ tin cậy của các thang đo tổng hợp trong mô hình định lượng**

| Cấu phần | Số biến quan sát | Cronbach’s Alpha | Cách tính biến | Đánh giá |
| --- | --- | --- | --- | --- |
| H1 | 13 | 0,830 | Giá trị trung bình của các chỉ báo hợp lệ | Tốt |
| H2 | 21 | 0,860 | Giá trị trung bình của các chỉ báo hợp lệ | Tốt |
| H3 | 3 | 0,683 | Giá trị trung bình của các chỉ báo hợp lệ | Chấp nhận được |
| D1 | 2 | 0,609 | Giá trị trung bình của các chỉ báo hợp lệ | Chấp nhận được |
| D2 | 8 | 0,789 | Giá trị trung bình của các chỉ báo hợp lệ | Tốt |
| D3 | 2 | 0,617 | Giá trị trung bình của các chỉ báo hợp lệ | Chấp nhận được |
| Y | 10 | 0,877 | Giá trị trung bình của các chỉ báo hợp lệ | Tốt |

*Nguồn: Kết quả phân tích định lượng qua khảo sát bằng bảng hỏi (N=250), năm 2025.*
