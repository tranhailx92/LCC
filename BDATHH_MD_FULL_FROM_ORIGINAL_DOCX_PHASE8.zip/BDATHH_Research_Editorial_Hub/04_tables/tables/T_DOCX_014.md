# T_DOCX_014 — Bảng 2.8

**Bảng 2.8. Hệ thống văn bản thiết lập tiêu chuẩn chất lượng dịch vụ bảo đảm an toàn hàng hải**

| Số, ký hiệu văn bản | Trích yếu nội dung cốt lõi | Phạm vi điều chỉnh |
| --- | --- | --- |
| Thông tư số 42/2019/TT-BGTVT | Quy định tiêu chí kiểm tra, giám sát, đánh giá, nghiệm thu chất lượng dịch vụ sự nghiệp công. | Đèn biển, luồng công cộng, khảo sát thông báo hàng hải. |
| Thông tư số 27/2021/TT-BGTVT | Bổ sung quy định về chỉ số khả dụng và yêu cầu bắt buộc trang bị AIS trên phương tiện tiếp tế, kiểm tra. | Hệ thống báo hiệu dẫn luồng hàng hải công cộng. |
| Thông tư số 40/2023/TT-BGTVT | Quy định hệ thống tiêu chí chất lượng, đánh giá nghiệm thu đối với dịch vụ thông tin. | Hệ thống thông tin duyên hải. |
| Thông tư số 31/2025/TT-BXD | Quy định tiêu chuẩn đào tạo, cấp chứng chỉ; định lượng tiêu chí “lượt dẫn tàu an toàn”. | Dịch vụ hoa tiêu hàng hải. |
| TCVN 10704:2015 | Phân cấp luồng dựa trên vai trò, chức năng và tải trọng tàu; yêu cầu chất lượng vận hành luồng. | Dịch vụ vận hành luồng hàng hải. |

*Nguồn: NCS tổng hợp từ hệ thống văn bản quy phạm pháp luật (Bộ Giao thông vận tải, 2019; Bộ Giao thông vận tải, 2023a, 2023b, 2023c; Bộ Khoa học và Công nghệ, 2015a, 2015b; Bộ Xây dựng, 2025f, 2025g, 2025h, 2025i).*
