# T_DOCX_028 — Bảng 3.6

**Bảng 3.6. Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện tổ chức thực hiện quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải**

| Giai đoạn | Kết quả kỳ vọng đạt được | KPI đánh giá kết quả quản lý | Trọng tâm |
| --- | --- | --- | --- |
| Đến năm 2030 | - Tổ chức quản lý cung ứng dịch vụ theo chuỗi thống nhất. / - Tăng tỷ lệ TTHC dịch vụ giải quyết đúng hạn và trực tuyến toàn trình. / - Bảo đảm hợp đồng dịch vụ công ký đúng hạn. / - Mở rộng lựa chọn nhà cung ứng theo phương thức cạnh tranh. / - Hoàn thành nền dữ liệu lượt dẫn tàu hoa tiêu để hỗ trợ quản lý thực chất. | - D2.1 Tỷ lệ thủ tục hành chính (TTHC) về dịch vụ BĐATHH giải quyết đúng hạn. / - D2.2 Tỷ lệ TTHC nhóm D2 xử lý trực tuyến toàn trình. / - D2.3 Tỷ lệ hợp đồng dịch vụ công ký đúng hạn. / - D2.4 Tỷ lệ gói dịch vụ công lựa chọn theo phương thức cạnh tranh. / - D2.5 Tỷ lệ doanh nghiệp cung cấp dịch vụ BĐATHH được đánh giá định kỳ. | - D2.1 / - D2.3 / - D2.4 / - D2.5 |
| 2031–2045 | - Hoàn thiện chuỗi cung ứng dịch vụ dựa trên dữ liệu thời gian thực. / - Tăng mức độ điều phối liên thông giữa các chủ thể. / - Duy trì đánh giá định kỳ doanh nghiệp cung ứng. / - Nâng năng lực điều tiết thị trường và kiểm soát chất lượng đầu ra theo đặc tính từng dịch vụ. | - D2.2 / - D2.4 / - D2.5 |  |

*Nguồn: Nghiên cứu sinh đề xuất, kết hợp với khung giải pháp của luận án, 2026*
