# T_DOCX_015 — Bảng 2.9

**Bảng 2.9. Hệ thống văn bản về cơ chế tài chính và điều kiện năng lực đơn vị cung ứng**

| Số, ký hiệu văn bản | Trích yếu nội dung cốt lõi | Tác động đến công tác quản lý cung ứng dịch vụ |
| --- | --- | --- |
| Thông tư số 37/2021/TT-BGTVT | Hướng dẫn phương pháp xác định giá dịch vụ theo phương thức đặt hàng. | Tạo cơ sở pháp lý để lập dự toán, thanh quyết toán giá dịch vụ sự nghiệp công. |
| Thông tư số 21/2025/TT-BXD | Ban hành định mức chi phí cho dịch vụ thông tin duyên hải. | Lượng hóa cụ thể tỷ lệ chi phí lợi nhuận, thiết lập công cụ quản lý tài chính minh bạch. |
| Nghị định số 70/2016/NĐ-CP (và văn bản sửa đổi) | Quy định điều kiện kinh doanh (cơ sở vật chất, nhân lực, tài chính). | Thiết lập hàng rào kỹ thuật, kiểm soát chặt chẽ chất lượng đầu vào của nhà cung cấp. |
| Nghị định số 32/2019/NĐ-CP | Quy định giao nhiệm vụ, đặt hàng, đấu thầu dịch vụ công. | Thay đổi phương thức lựa chọn nhà cung cấp từ chỉ định sang cơ chế thị trường. |
| Nghị định số 57/2024/NĐ-CP | Quy định quản lý hoạt động nạo vét kết hợp thu hồi sản phẩm. | Mở ra cơ chế đối tác công tư, huy động nguồn lực xã hội hóa tham gia duy tu luồng lạch. |
| Thông tư số 31/2025/TT-BXD | Quy định tiêu chuẩn đào tạo, cấp/thu hồi chứng chỉ hoa tiêu hàng hải. | Chuẩn hóa năng lực nguồn nhân lực đặc thù tương thích với hội nhập quốc tế. |

*Nguồn: NCS tổng hợp từ hệ thống văn bản quy phạm pháp luật, 2025.*
