# T_DOCX_005 — Bảng 1.5

**Bảng 1.5. Tổng hợp các yếu tố ảnh hưởng đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải và sự quy chiếu vào khung phân tích 2×3**

| Yếu tố ảnh hưởng | Tác động trong khung 2×3 | Quy chiếu vào phân tích định lượng (biến quan sát) |
| --- | --- | --- |
| Nhóm bên trong: Thể chế và pháp luật | Tác động trực tiếp, trọng tâm ở H1, D1; đồng thời chi phối gián tiếp H2, H3, D2, D3 thông qua tính khả thi và minh bạch của chính sách. | Biến về tính minh bạch, đồng bộ, ổn định, khả thi và mức độ phù hợp với chuẩn mực quốc tế trong H1, D1. |
| Nhóm bên trong: Tổ chức bộ máy và nhân lực | Tác động trực tiếp, trọng tâm ở H2, H3, D2, D3. | Biến về phân công chức năng, phối hợp, chất lượng nhân lực, năng lực điều hành và giám sát trong H2, H3, D2, D3. |
| Nhóm bên trong: Tài chính và nguồn lực | Tác động trực tiếp, trọng tâm ở H2, H3; ảnh hưởng gián tiếp đến D2, D3 thông qua năng lực bảo đảm dịch vụ. | Biến về mức độ bảo đảm nguồn lực, hiệu quả phân bổ, duy trì tài sản, khả năng đáp ứng vận hành trong H2, H3 và một phần D2, D3. |
| Nhóm bên trong: Khoa học, công nghệ và dữ liệu | Tác động trực tiếp ở H2, H3, D2, D3; đồng thời hỗ trợ H1, D1 trong cập nhật tiêu chuẩn, quy chuẩn kỹ thuật. | Biến về mức độ số hóa, chất lượng dữ liệu, liên thông hệ thống và khả năng hỗ trợ điều hành, giám sát trong H2, H3, D2, D3. |
| Nhóm bên ngoài: Hợp tác quốc tế và khu vực | Tác động gián tiếp, hỗ trợ hoàn thiện thể chế (H1, D1) và nâng cao năng lực thực thi (H2, H3, D2, D3). | Biến về mức độ tham gia điều ước quốc tế, mức độ hài hòa pháp luật, khả năng tiếp thu chuẩn mực và mô hình quản lý tiên tiến. |
| Nhóm bên trong: Hạ tầng và năng lực ứng phó | Tác động trực tiếp, trọng tâm ở H2, H3 (điều kiện vận hành) và D2, D3 (năng lực xử lý sự cố). | Biến về mức độ đáp ứng của hệ thống báo hiệu, luồng tuyến, năng lực ứng phó sự cố, thời gian phục hồi dịch vụ trong H2, H3, D2, D3. |
| Nhóm bối cảnh: kinh tế - xã hội | Tác động gián tiếp, trọng tâm ở H2, H3, D2, D3. Tạo bối cảnh thuận lợi hoặc sức ép bên ngoài đối với hoạt động quản lý. | Chủ yếu dùng làm biến bối cảnh hỗ trợ diễn giải thực trạng, mức độ rủi ro và nhu cầu thích ứng; không tách thành nhân tố cấu trúc độc lập. |

*Nguồn: Nghiên cứu sinh tổng hợp, 2026.*
