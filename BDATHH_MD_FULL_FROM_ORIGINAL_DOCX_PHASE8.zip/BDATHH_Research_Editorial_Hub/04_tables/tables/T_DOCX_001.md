# T_DOCX_001 — Bảng 1.1

**Bảng 1.1. Tổng hợp một số cách tiếp cận về an toàn hàng hải**

| Góc độ | Khái niệm chính | Nguồn tiêu biểu |
| --- | --- | --- |
| Pháp lý | Trạng thái giảm thiểu rủi ro đối với sinh mạng con người, tài sản và môi trường biển thông qua trách nhiệm Flag State. | IMO 2024; UNCLOS 1982; SOLAS 1974 (sửa đổi 2024) |
| Quản lý rủi ro | Chất lượng quản lý rủi ro ở mức chấp nhận được (ALARP), không zero risk. | Kuo 1998; ISO 31000:2018 |
| Hệ thống hiện đại (Safety-II) | Tính kiên cường để thích ứng biến cố, chuyển từ tránh sai sót sang bảo đảm hoạt động đúng. | Erik Hollnagel 2014; EMSA 2025 |
| Dữ liệu số và đa trung tâm | Quản trị dựa trên dữ liệu lớn, AI, tích hợp AIS/LRIT cho giám sát xuyên biên giới. | Mao & Wang 2020; EMSA 2025 |
| Toàn cầu và đa chiều | Tính toàn cầu ảnh hưởng chuỗi cung ứng, đa chiều pháp lý-kỹ thuật-xã hội. | UNCTAD 2024; UNCLOS 1982 |
| Số hóa và phục hồi | Tăng cường e-Navigation, an ninh mạng; khả năng khôi phục nhanh sau sự cố. | IALA 2023; Hollnagel 2014 |

*Nguồn: Nghiên cứu sinh tổng hợp từ (IMO, 1974), (United Nations, 1982), (ISO, 2018), (Kuo, 1998), (Hollnagel, 2014), (Mao & Wang, 2020), (EMSA, 2025), (IALA, 2023), (UNCTAD, 2024).*
