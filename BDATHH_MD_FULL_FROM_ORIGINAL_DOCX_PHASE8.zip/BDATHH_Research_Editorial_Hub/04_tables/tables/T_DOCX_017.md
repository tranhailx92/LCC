# T_DOCX_017 — Bảng 2.11

**Bảng 2.11. Năng lực cung ứng dịch vụ hoa tiêu hàng hải (2019–2025)**

| Năm | Tổng số lượt dẫn tàu thực hiện | Tỷ lệ biến động / Đánh giá |
| --- | --- | --- |
| 2019 | 76.400 | - |
| 2020 | 68.200 | -10,73% |
| 2021 | 62.500 | -8,36% |
| 2022 | 65.800 | +5,28% |
| 2023 | 71.200 | +8,21% |
| 2024 | 76.500 | +7,44% |
| 2025 | 79.307 | 101,69% kế hoạch |

*Nguồn: Tổng hợp dữ liệu quản lý vận hành từ các doanh nghiệp cung ứng dịch vụ.*
