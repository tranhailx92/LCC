# T_DOCX_010 — Bảng 2.4

**Bảng 2.4. Tổng hợp các dự án đầu tư và mua sắm trọng điểm liên quan tới hệ thống bảo đảm an toàn hàng hải**

| Nhóm dự án | Tên dự án / Hạng mục đầu tư | Văn bản phê duyệt của Bộ | Mức đầu tư (tỷ đồng) |
| --- | --- | --- | --- |
| Xây dựng hạ tầng | Mạng lưới 13 đèn biển chiến lược | Quyết định số 1581/QĐ-BGTVT; Quyết định số 138/QĐ-BGTVT | 384,312 |
| Xây dựng hạ tầng | Luồng tàu biển trọng tải lớn vào sông Hậu | Quyết định số 1319/QĐ-BGTVT | 7.894,666 |
| Xây dựng hạ tầng | Hạ tầng BĐATHH miền Bắc (Kế hoạch 2021–2025) | Quyết định số 2250/QĐ-BGTVT | 184,633 |
| Xây dựng hạ tầng | Hạ tầng BĐATHH miền Nam (Kế hoạch 2021–2025) | Quyết định số 2309/QĐ-BGTVT | 233,152 |
| Mua sắm thiết bị, phương tiện | 02 tàu tiếp tế, kiểm tra trên biển (Trường Sa, đảo xa bờ) | Quyết định số 1964/QĐ-BGTVT; Quyết định số 986/QĐ-BGTVT | 440,299 |
| Mua sắm thiết bị, phương tiện | Trang thiết bị, phương tiện miền Bắc (Kế hoạch 2021–2025) | Quyết định số 2250/QĐ-BGTVT | 343,780 |
| Mua sắm thiết bị, phương tiện | Trang thiết bị, phương tiện miền Nam (Kế hoạch 2021–2025) | Quyết định số 2309/QĐ-BGTVT | 298,570 |
| Dự án chiến lược (2026–2030) | Luồng tàu vào khu bến Nam Nghi Sơn | Báo cáo số 8509/BXD-KHTC | 5.220 |
| Dự án chiến lược (2026–2030) | Nâng cấp tuyến kênh Mương Khai – Đốc Phủ Hiền | Báo cáo số 8509/BXD-KHTC | 7.500 |
| Dự án chiến lược (2026–2030) | Đài thông tin duyên hải/TTTKCN tại Trường Sa | Báo cáo số 8509/BXD-KHTC | 522 |
| Dự án chiến lược (2026–2030) | Hoàn thiện hệ thống VTS | Báo cáo số 8509/BXD-KHTC | 700 |
| Dự án chiến lược (2026–2030) | Đóng mới 02 tàu chuyên dụng tìm kiếm cứu nạn | Báo cáo số 8509/BXD-KHTC | 1.000 |

*Nguồn: Tổng hợp từ các Quyết định của Bộ Xây dựng/GTVT và Báo cáo số 8509/BXD-KHTC về kế hoạch đầu tư công trung hạn giai đoạn 2026–2030.*
