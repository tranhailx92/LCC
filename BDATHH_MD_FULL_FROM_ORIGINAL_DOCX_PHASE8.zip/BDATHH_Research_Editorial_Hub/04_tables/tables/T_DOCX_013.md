# T_DOCX_013 — Bảng 2.7

**Bảng 2.7. Phân loại danh mục dịch vụ bảo đảm an toàn hàng hải**

| Nhóm dịch vụ | Các loại hình dịch vụ tiêu biểu | Cơ chế cung ứng và quản lý nhà nước |
| --- | --- | --- |
| Dịch vụ sự nghiệp công | Vận hành đèn biển, luồng hàng hải, hệ thống giám sát giao thông tàu thuyền (VTS), thông tin duyên hải, khảo sát hải đồ, nạo vét duy tu. | Nhà nước quản lý thông qua cơ chế đặt hàng hoặc đấu thầu từ nguồn ngân sách nhà nước; kết hợp xã hội hóa. |
| Dịch vụ sự nghiệp công thiết yếu | Tìm kiếm cứu nạn hàng hải, xử lý thông tin an ninh hàng hải. | Nhà nước trực tiếp tổ chức lực lượng thực thi và bảo đảm nguồn lực 100%. |
| Dịch vụ thương mại có điều kiện | Hoa tiêu hàng hải, lai dắt tàu biển, dịch vụ tàu lặn hoạt động du lịch. | Doanh nghiệp cung ứng theo cơ chế giá thỏa thuận; Nhà nước quản lý thông qua cấp phép và kiểm soát năng lực. |

*Nguồn: NCS tổng hợp từ hệ thống văn bản pháp luật (Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2016; Chính phủ nước CHXHCN Việt Nam, 2017; Chính phủ nước CHXHCN Việt Nam, 2022; Chính phủ nước CHXHCN Việt Nam, 2025c, 2025d; Quốc hội nước CHXHCN Việt Nam, 2015).*
