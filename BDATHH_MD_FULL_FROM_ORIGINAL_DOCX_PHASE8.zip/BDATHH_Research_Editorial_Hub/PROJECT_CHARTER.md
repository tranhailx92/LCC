# Project Charter

Purpose: Convert the original Word dissertation/manuscript into a structured Markdown research editorial hub with traceable tables, figures, QA reports, and draft integration outputs.
