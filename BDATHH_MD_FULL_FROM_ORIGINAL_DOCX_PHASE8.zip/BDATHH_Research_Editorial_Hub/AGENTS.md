# AGENTS rules

- Do not invent data, sources, captions, or figure values.
- Do not alter the approved phrase: “quản lý nhà nước về bảo đảm an toàn hàng hải ở việt nam”.
- Treat extracted figure assets as draft only until visual QA/rebuild.
- Tables must become real Word tables in any later DOCX phase.
