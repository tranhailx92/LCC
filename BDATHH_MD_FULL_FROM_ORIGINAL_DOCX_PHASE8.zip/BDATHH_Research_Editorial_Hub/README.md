# BDATHH Research Editorial Hub — Markdown package from original DOCX

This package was generated directly from `Pham_Quang_Giap_Luan_an_APA7_rut_gon_Mo_dau_den_TLTK_giai_doan_4.docx`.

## Contents
- `01_manuscript/`: split Markdown manuscript with table/figure placeholders.
- `04_tables/`: 30 table candidates and table register.
- `05_figures/`: 11 extracted figure assets, candidates, specs, rebuild briefs.
- `08_outputs/drafts/md_integrated_v02/`: integrated Markdown draft with tables and figure asset links.
- `07_quality_assurance/`: QA reports and dashboards.

## Current status
`PHASE8_CONDITIONAL_NEEDS_AUTHOR_DATA_OR_DESIGN_REVIEW`

## Not final
This is not a final Word/PDF publication package. Figures are draft assets awaiting author data/design review.
