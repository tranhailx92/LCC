# Workflow summary

1. DOCX intake and extraction.
2. Split manuscript into Markdown.
3. Extract 30 tables and 11 figures.
4. Create candidates/registers/specs.
5. Integrate into `md_integrated_v02`.
6. Mark figures as draft assets pending author data/design review.
7. Next: Phase 9 Word draft generation.
