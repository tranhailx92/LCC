MỞ ĐẦU

1. Lý do lựa chọn đề tài

Trong bối cảnh chuỗi cung ứng quốc tế mở rộng, vận tải biển đảm nhận trên 80% khối lượng thương mại hàng hóa quốc tế (UNCTAD, 2025b). Ngành hàng hải đang chuyển dịch từ tuân thủ quy định truyền thống sang vận hành thông minh, tích hợp theo các chuẩn mực của IMO và IALA (Heikkilä et al., 2024; IALA, 2023; IMO, 2024b). An toàn hàng hải hiện là kết quả của hệ thống dịch vụ công và hạ tầng kỹ thuật hiện đại vận hành thời gian thực, gồm báo hiệu, luồng, hoa tiêu, quản lý giao thông (VTS), thông tin hàng hải (IALA, 2023; IMO, 2021). Trong bối cảnh đó, yêu cầu đặt ra là các quốc gia phải chuyển từ quản lý hành chính sang quản lý cung ứng dịch vụ bảo đảm an toàn chất lượng cao theo hướng hàng hải xanh và chuyển đổi số (OECD, 2019a; World Bank & International Association of Ports and Harbors [IAPH], 2021).

Đối với Việt Nam, Nghị quyết 36-NQ/TW (Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam, 2018) của Ban Chấp hành Trung ương Khóa XII xác định kinh tế biển là động lực trọng yếu, hướng tới mục tiêu quốc gia giàu mạnh về biển. Hơn 90% hàng hóa xuất nhập khẩu của Việt Nam đi qua hệ thống cảng biển (Cục Hàng hải Việt Nam, 2022), hệ thống bảo đảm an toàn hàng hải vừa phòng ngừa rủi ro vừa là cấu phần hỗ trợ quan trọng đối với năng lực cạnh tranh quốc gia. Vận hành hiệu quả hệ thống này giúp tối ưu hóa luồng hàng hóa, giảm thời gian neo đậu tàu. Theo Bộ Công Thương, chi phí logistics của Việt Nam chiếm khoảng 16,8% GDP (Bộ Công Thương, 2024); đồng thời, UNCTAD cho thấy hiệu quả cảng và thuận lợi hóa thương mại có tác dụng giảm chậm trễ và chi phí giao dịch (UNCTAD, 2025a). Do đó, hoàn thiện quản lý nhà nước lĩnh vực này là yếu tố quan trọng trong việc thực hiện chiến lược phát triển bền vững kinh tế biển.

Mặc dù nhận thức rõ tầm quan trọng của vấn đề, thực tiễn quản lý nhà nước về bảo đảm an toàn hàng hải tại Việt Nam vẫn tồn tại những vướng mắc thể chế và phương thức quản trị. Cơ chế tài chính dịch vụ công hiện nay làm suy giảm động lực đổi mới, tối ưu hóa chi phí. Khung pháp lý cho xã hội hóa đầu tư hạ tầng chưa huy động được nguồn lực xã hội cho phát triển hạ tầng bảo đảm an toàn hàng hải, mà vốn đầu tư vẫn phụ thuộc chính vào ngân sách Nhà nước. Phương thức quản lý, giám sát hiện tập trung vào quy trình thay vì kết quả và rủi ro, hệ thống chỉ số đánh giá hiệu quả (KPI), cam kết dịch vụ (SLA) còn sơ khai, quản lý chưa dựa trên dữ liệu thực. Điều này dẫn đến quản lý thụ động, thiếu dữ liệu phân tích cho dự báo, phòng ngừa rủi ro, đặc biệt trước các thách thức mới và yêu cầu nghiêm ngặt của các hãng tàu quốc tế. Những bất cập này trở thành rào cản cho hiện đại hóa và hội nhập ngành hàng hải Việt Nam (Bộ Xây dựng, 2026a; OECD, 2014; OECD, 2019b; World Bank Group, Asian Development Bank, European Bank for Reconstruction and Development, Inter-American Development Bank, Islamic Development Bank, OECD, UNECE & UNESCAP, 2017).

Mặt khác, xét về phương diện lý luận, các công trình nghiên cứu trong nước trước đây thường tiếp cận vấn đề bảo đảm an toàn hàng hải dưới góc độ kỹ thuật hàng hải hoặc khoa học pháp lý thuần túy hay mô hình tổ chức, mà chưa đi sâu phân tích bản chất của hoạt động này dưới góc độ quản lý nhà nước về hệ thống bảo đảm an toàn hàng hải và dịch vụ bảo đảm an toàn hàng hải (Hoàng Thị Lịch, 2021; Lương Thị Kim Dung, 2019; Lưu Việt Hùng, 2019; Nguyễn Mạnh Cường & Phan Văn Hưng, 2021; Vũ Đăng Thái, 2023). Hiện đang tồn tại một khoảng trống về cơ sở lý luận cho việc đổi mới mô hình tổ chức, cung ứng và điều tiết dịch vụ bảo đảm an toàn hàng hải ở Việt Nam; khoảng trống này cần được tiếp tục soi chiếu và bổ sung dưới góc nhìn của quản trị công mới, quản trị rủi ro và phát triển bền vững (ISO, 2018; Musgrave & Musgrave, 1989). Việc thiếu vắng một khung phân tích khoa học để giải quyết mối quan hệ giữa Nhà nước (người kiến tạo/mua dịch vụ) và các đơn vị sự nghiệp/doanh nghiệp (người cung ứng dịch vụ) là một trong những nguyên nhân khiến công cuộc đổi mới quản lý trong lĩnh vực này còn chưa tương xứng với tiềm năng (Musgrave & Musgrave, 1989; Osborne & Gaebler, 1992).

Xuất phát từ những yêu cầu lý luận và thực tiễn cấp thiết về việc khắc phục các hạn chế chủ yếu trong tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải, nghiên cứu sinh đã lựa chọn đề tài “Quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam” để thực hiện nghiên cứu. Luận án đặt mục tiêu xây dựng nền tảng khoa học nhằm đề xuất hệ thống các giải pháp hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải đến năm 2030, tầm nhìn 2045, góp phần hiện đại hóa ngành hàng hải, bảo đảm an ninh, an toàn và phát triển bền vững kinh tế biển Việt Nam phù hợp với xu thế quốc tế hiện nay.

2. Mục đích và nhiệm vụ nghiên cứu

2.1. Mục đích nghiên cứu

Luận án nhằm làm rõ cơ sở lý luận và thực tiễn của quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam; phân tích, đánh giá thực trạng quản lý nhà nước về bảo đảm an toàn hàng hải; từ đó đề xuất định hướng và giải pháp hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải đến năm 2030, tầm nhìn 2045.

2.2. Nhiệm vụ nghiên cứu

Một là, luận án hệ thống hóa và làm rõ các khái niệm, đặc điểm, vai trò, nội dung quản lý nhà nước, tiêu chí đánh giá (bộ KPI) và các yếu tố ảnh hưởng đối với quản lý nhà nước về bảo đảm an toàn hàng hải; đồng thời nghiên cứu kinh nghiệm quốc tế để rút ra bài học phù hợp cho Việt Nam.

Hai là, luận án phân tích, đánh giá thực trạng quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam giai đoạn 2015–2025 trên cơ sở lý luận và khung phân tích đã xây dựng, rút ra kết quả, hạn chế, nguyên nhân.

Ba là, kiểm định mức độ ảnh hưởng của các biến số quản lý nhà nước đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam bằng phương pháp định lượng, qua đó bổ sung bằng chứng thực chứng cho các nhận định rút ra từ nghiên cứu lý luận và thực trạng.

Bốn là, luận án đề xuất hệ thống giải pháp và kiến nghị đồng bộ nhằm hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam đến năm 2030, tầm nhìn 2045.

3. Đối tượng và phạm vi nghiên cứu

3.1. Đối tượng nghiên cứu

Đối tượng nghiên cứu của luận án là các hoạt động quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam.

3.2. Phạm vi nghiên cứu

Phạm vi chủ thể: Chủ thể quản lý nhà nước về bảo đảm an toàn hàng hải là Bộ Xây dựng (trước thời điểm hợp nhất tháng 3/2025 là Bộ Giao thông vận tải), cơ quan được Chính phủ giao nhiệm vụ tham mưu xây dựng chính sách và trực tiếp quản lý nhà nước về bảo đảm an toàn hàng hải của Việt Nam (Chính phủ nước CHXHCN Việt Nam, 2025b).

Phạm vi nội dung: Luận án giới hạn nghiên cứu trong hai nội dung trọng tâm của quản lý nhà nước về bảo đảm an toàn hàng hải. Nội dung thứ nhất là tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải, được phân tích theo ba chức năng: H1 là ban hành; H2 là tổ chức thực hiện; H3 là giám sát, đánh giá. Nội dung thứ hai là quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải, được phân tích theo ba chức năng: D1 là ban hành; D2 là tổ chức thực hiện; D3 là giám sát, đánh giá.

Phạm vi không gian: Luận án nghiên cứu trên lãnh thổ Việt Nam, có đối sánh với các mô hình quản lý nhà nước về bảo đảm an toàn hàng hải tiêu biểu trên thế giới (Singapore, Nhật Bản, Malaysia, Hà Lan/EU) để rút ra bài học kinh nghiệm cho Việt Nam.

Phạm vi thời gian: Luận án phân tích, đánh giá thực trạng quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam giai đoạn 2015–2025; đề xuất giải pháp đến 2030, tầm nhìn 2045. Dữ liệu khảo sát định lượng và phỏng vấn sâu được thu thập chủ yếu từ tháng 3 đến tháng 5 năm 2025.

4. Phương pháp nghiên cứu

4.1. Phương pháp luận và tiếp cận nghiên cứu

Về phương pháp luận: Luận án được xây dựng trên nền tảng khoa học quản lý và quản trị công hiện đại, với định hướng chuyển từ tư duy kiểm soát tuân thủ sang kiến tạo giá trị, quản lý theo kết quả và trách nhiệm giải trình. Trên cơ sở kết hợp lý thuyết kinh tế công cộng của Musgrave và Musgrave (1989), tư duy quản trị công hiện đại của Osborne và Gaebler (1992) và cách tiếp cận quản trị rủi ro theo ISO 31000:2018 (ISO, 2018), nghiên cứu khẳng định vai trò của Nhà nước trong đầu tư, điều tiết và giám sát hệ thống bảo đảm an toàn hàng hải; phân biệt giữa quản lý hệ thống và quản lý cung ứng dịch vụ; đồng thời nhấn mạnh yêu cầu minh bạch, lượng hóa kết quả và kiểm soát rủi ro trong toàn bộ chu trình quản lý. Đây là cơ sở lý luận trực tiếp để luận án xây dựng khung phân tích 2×3 gồm hai nội dung quản lý và ba chức năng quản lý nhà nước là ban hành, tổ chức thực hiện và giám sát, đánh giá.

Về cách tiếp cận: luận án sử dụng thiết kế nghiên cứu hỗn hợp, kết hợp phân tích định tính với kiểm định định lượng (Creswell & Plano Clark, 2018). Phần định tính được thực hiện thông qua phân tích tài liệu, so sánh quốc tế và phỏng vấn sâu chuyên gia nhằm làm rõ bối cảnh thể chế, đặc điểm quản lý và các vấn đề thực tiễn (Gill et al., 2008; Palinkas et al., 2015). Phần định lượng được sử dụng để kiểm định mức độ ảnh hưởng tương đối của các biến số quản lý nhà nước đến kết quả quản lý nhà nước, qua đó bổ sung bằng chứng thực chứng cho các nhận định rút ra từ nghiên cứu lý luận và thực trạng.

Về công cụ phân tích cốt lõi: luận án sử dụng khung phân tích tích hợp (ma trận 2×3) được xây dựng trên cơ sở tham chiếu tư tưởng tổ chức, hành chính của Weber (1947) và vận dụng các khuyến nghị hiện đại của IALA (2022). Khung này kết hợp hai trụ cột nội dung (quản lý hệ thống bảo đảm an toàn hàng hải và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải) với ba chức năng quản lý nhà nước (ban hành, tổ chức thực hiện và giám sát, đánh giá), qua đó tạo cơ sở để đánh giá toàn diện hoạt động quản lý, nhận diện hạn chế thể chế và phân tích kết quả vận hành của hệ thống dưới góc nhìn đa chiều.

4.2. Phương pháp nghiên cứu định tính

Luận án sử dụng ba nhóm phương pháp định tính chủ yếu.

Thứ nhất là phương pháp phân tích tài liệu. Luận án phân tích hệ thống các văn bản pháp luật, chiến lược, quy hoạch, báo cáo và số liệu thống kê của Bộ Xây dựng (trước tháng 3 năm 2025 là Bộ Giao thông vận tải), Cục Hàng hải và Đường thủy Việt Nam và các cơ quan, tổ chức liên quan đến bảo đảm an toàn hàng hải; đồng thời đối chiếu với các chuẩn mực quốc tế của IMO, IALA, IHO và các công trình khoa học trong nước có liên quan trực tiếp. Kết quả phân tích tài liệu được sử dụng để xây dựng tiêu chí đánh giá quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam, hình thành các biến quan sát cho khảo sát, xác định chuẩn so sánh quốc tế và cung cấp luận cứ cho việc đánh giá thực trạng, đề xuất giải pháp.

Thứ hai là phương pháp nghiên cứu so sánh. Luận án lựa chọn một số mô hình quản lý nhà nước về bảo đảm an toàn hàng hải tiêu biểu như Singapore, Malaysia, Nhật Bản, Hà Lan/EU để đối sánh. Nội dung so sánh tập trung vào cách thức ban hành, tổ chức thực hiện và giám sát đối với hai nhóm nội dung là quản lý hệ thống bảo đảm an toàn hàng hải và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải. Kết quả nghiên cứu so sánh được sử dụng để rút ra bài học kinh nghiệm cho Việt Nam, đồng thời làm cơ sở hoàn thiện khung phân tích, bộ tiêu chí đánh giá và hệ thống giải pháp của luận án.

Thứ ba là phương pháp phỏng vấn sâu bán cấu trúc (phỏng vấn sâu chuyên gia). Luận án thực hiện phỏng vấn sâu bán cấu trúc với 25 chuyên gia được lựa chọn theo phương pháp chọn mẫu có chủ đích, dựa trên hai tiêu chí: có tối thiểu 10 năm kinh nghiệm trong lĩnh vực hàng hải hoặc quản lý nhà nước về bảo đảm an toàn hàng hải; và đang hoặc đã từng giữ vị trí quản lý, điều hành hoặc là chuyên gia đầu ngành. Mẫu chuyên gia được phân theo các nhóm chức năng chính, bảo đảm tính đa dạng giữa khu vực quản lý nhà nước, cơ quan chuyên ngành, doanh nghiệp dịch vụ hàng hải, cơ sở đào tạo, nghiên cứu và nhóm chính sách, tài chính, hợp tác quốc tế. Nội dung phỏng vấn tập trung vào khung phân tích 2×3, thực trạng quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam, các yếu tố ảnh hưởng đến kết quả quản lý và định hướng hoàn thiện đến năm 2030, tầm nhìn 2045. Dữ liệu phỏng vấn được mã hóa theo chủ đề và sử dụng để hiệu chỉnh mô hình nghiên cứu, hoàn thiện thang đo và hỗ trợ biện giải kết quả định lượng (Gill et al., 2008; Palinkas et al., 2015).

4.3. Phương pháp nghiên cứu định lượng

Phương pháp nghiên cứu định lượng của luận án được trình bày cụ thể tại mục 2.3 của Chương 2. Trong phạm vi phần Mở đầu, luận án khái quát những nội dung cơ bản như sau:

Thứ nhất, về Mô hình nghiên cứu

Trên cơ sở khung phân tích 2×3, luận án sử dụng mô hình hồi quy tuyến tính bội với hệ số beta chuẩn hóa để kiểm định tác động của sáu biến độc lập H1, H2, H3, D1, D2 và D3 đến biến phụ thuộc Y. Phương trình nghiên cứu được biểu diễn như sau: Y = β0 + β1H1 + β2H2 + β3H3 + β4D1 + β5D2 + β6D3 + ε (Hair et al., 2010; Kline, 2016).

Trong mô hình này, H1 là biến ban hành trong quản lý hệ thống bảo đảm an toàn hàng hải; H2 là biến tổ chức thực hiện trong quản lý hệ thống bảo đảm an toàn hàng hải; H3 là biến giám sát trong quản lý hệ thống bảo đảm an toàn hàng hải; D1 là biến ban hành trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải; D2 là biến tổ chức thực hiện trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải; D3 là biến giám sát trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải. Biến Y phản ánh kết quả quản lý nhà nước về bảo đảm an toàn hàng hải. Các biến này được hình thành từ giá trị trung bình của các nhóm biến quan sát thuộc bảng hỏi khảo sát, sau khi đã kiểm định độ tin cậy của thang đo.

Thứ hai, về thiết kế bảng hỏi và thang đo.

Công cụ thu thập dữ liệu định lượng là bảng hỏi khảo sát có cấu trúc, được xây dựng trên cơ sở lý thuyết, tổng quan nghiên cứu, khung phân tích 2×3 và kết quả tham vấn chuyên gia. Bảng hỏi gồm các nhóm câu hỏi phản ánh thông tin nền của người trả lời, các biến quan sát của sáu cấu phần H1, H2, H3, D1, D2, D3 và nhóm biến phản ánh kết quả quản lý nhà nước Y (gồm 10 biến Y1 đến Y10). Toàn bộ thang đo được thiết kế theo thang Likert 5 mức để lượng hóa mức độ đánh giá của người trả lời.

Thứ ba, về cỡ mẫu, chọn mẫu và thu thập dữ liệu.

Dữ liệu định lượng được thu thập từ tháng 3 đến tháng 5 năm 2025. Luận án sử dụng phương pháp chọn mẫu thuận tiện kết hợp có chủ đích, nhằm bảo đảm sự tham gia của các nhóm đối tượng có liên quan trực tiếp đến quản lý nhà nước về bảo đảm an toàn hàng hải. Các nhóm được tiếp cận bao gồm cán bộ quản lý nhà nước, cán bộ cơ quan chuyên ngành, cán bộ quản lý tại các đơn vị cung ứng dịch vụ bảo đảm an toàn hàng hải, chuyên gia, cùng những người có kinh nghiệm thực tiễn trong hoạt động hàng hải. Việc phát phiếu được thực hiện bằng cả hai hình thức trực tiếp và trực tuyến để tăng khả năng tiếp cận đối tượng khảo sát. Sau khi thu hồi, toàn bộ phiếu khảo sát được rà soát theo các tiêu chí về mức độ hoàn thành, tính nhất quán của câu trả lời và khả năng sử dụng cho việc hình thành biến nghiên cứu. Những phiếu không bảo đảm yêu cầu bị loại khỏi tập dữ liệu phân tích. Kết quả cuối cùng, 250 phiếu hợp lệ được sử dụng cho phân tích định lượng (Hair et al., 2010; Kline, 2016).

Thứ tư, về xử lý dữ liệu.

Bộ số liệu được làm sạch, mã hóa thống nhất và kiểm tra tính hợp lệ trước khi phân tích. Các câu hỏi đảo chiều được quy đổi theo nguyên tắc thống nhất; sau đó, các biến H1, H2, H3, D1, D2, D3 và Y được tính bằng giá trị trung bình của các chỉ báo hợp lệ thuộc từng biến. Tiếp theo, luận án sử dụng Cronbach’s Alpha để kiểm định độ tin cậy nội tại của các thang đo, sau đó tiến hành phân tích tương quan, kiểm tra đa cộng tuyến và ước lượng mô hình hồi quy tuyến tính bội với hệ số beta chuẩn hóa. Các bước xử lý và phân tích được thực hiện trên môi trường Python nhằm bảo đảm tính minh bạch, nhất quán và khả năng tái lập kết quả.

5. Đóng góp mới của luận án

5.1. Đóng góp mới về mặt lý luận

Luận án cung cấp thêm bằng chứng lý luận và thực chứng cho cách tiếp cận quản lý nhà nước về bảo đảm an toàn hàng hải như một chỉnh thể tích hợp giữa tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải, thay vì chỉ tiếp cận tách rời theo từng mặt kỹ thuật, pháp lý hoặc tác nghiệp chuyên ngành. Trên cơ sở đó, luận án góp phần làm rõ hơn nội hàm của quản lý nhà nước về bảo đảm an toàn hàng hải trong điều kiện quản trị công hiện đại, nhấn mạnh rằng kết quả quản lý không chỉ phụ thuộc vào việc ban hành quy định, mà còn phụ thuộc trực tiếp vào chất lượng tổ chức thực hiện và hiệu lực của cơ chế giám sát, đánh giá trên cả hai trục quản lý hệ thống và quản lý cung ứng dịch vụ.

Đóng góp lý luận quan trọng của luận án không nằm ở việc đơn thuần đề xuất một sơ đồ phân tích mới, mà ở chỗ luận án làm rõ được giá trị giải thích của cách tiếp cận 2×3 đối với đối tượng nghiên cứu. Cụ thể, luận án cho thấy quản lý nhà nước về bảo đảm an toàn hàng hải có thể được nhận diện và phân tích một cách nhất quán thông qua hai nội dung quản lý và ba chức năng quản lý nhà nước, qua đó giúp kết nối chặt chẽ giữa lý luận, tiêu chí đánh giá, phân tích thực trạng và thiết kế giải pháp.

Một đóng góp lý luận khác của luận án là làm rõ hơn mối quan hệ giữa các cấu phần quản lý nhà nước và kết quả quản lý nhà nước trong lĩnh vực bảo đảm an toàn hàng hải. Trên cơ sở bằng chứng thực chứng, luận án chỉ ra rằng các cấu phần thuộc tổ chức thực hiện và ban hành có vai trò nổi bật hơn đối với kết quả quản lý nhà nước, trong khi chức năng giám sát, đánh giá tuy có ý nghĩa lý thuyết lớn nhưng trong thực tiễn chưa phát huy tương xứng. Kết quả này góp phần làm sâu sắc hơn cách tiếp cận lý luận đối với chất lượng quản lý nhà nước trong lĩnh vực công chuyên ngành.

5.2. Đóng góp mới về mặt thực tiễn

Về mặt thực tiễn, luận án cung cấp một bức tranh tương đối toàn diện về thực trạng quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam giai đoạn 2015–2025 trên cả hai trục là tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải. Không chỉ dừng ở mô tả hiện trạng, luận án đã làm rõ được những kết quả đạt được, các hạn chế chủ yếu và nguyên nhân của các hạn chế, từ đó tạo ra cơ sở thực tiễn có hệ thống cho việc xác định trọng tâm ưu tiên trong hoàn thiện quản lý nhà nước ở giai đoạn tiếp theo.

Đóng góp thực tiễn nổi bật của luận án là cung cấp bằng chứng thực chứng cho thấy mức độ ảnh hưởng của các cấu phần quản lý nhà nước đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam là không giống nhau. Trên cơ sở kết quả này, luận án không chỉ khẳng định vai trò quan trọng của toàn bộ chu trình quản lý nhà nước, mà còn chỉ ra rõ hơn những cấu phần cần được ưu tiên trong cải cách, đặc biệt là tổ chức thực hiện trong quản lý hệ thống và tổ chức thực hiện trong quản lý cung ứng dịch vụ. Giá trị thực tiễn của phát hiện này nằm ở chỗ nó giúp việc đề xuất giải pháp không rơi vào tình trạng dàn trải, mà có căn cứ để xác định đâu là điểm nghẽn cần ưu tiên xử lý trước.

6. Kết cấu của luận án

Ngoài Mở đầu, Kết luận, Danh mục các công trình khoa học đã công bố và Tài liệu tham khảo, nội dung chính của luận án gồm 3 chương:

Chương 1: Cơ sở lý luận và kinh nghiệm quốc tế trong quản lý nhà nước về bảo đảm an toàn hàng hải

Chương 2: Thực trạng quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

Chương 3: Giải pháp hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam.

Chương 1CƠ SỞ LÝ LUẬN VÀ KINH NGHIỆM QUỐC TẾ TRONG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI

1.1. KHÁI QUÁT VỀ AN TOÀN HÀNG HẢI VÀ BẢO ĐẢM AN TOÀN HÀNG HẢI

1.1.1. Khái niệm an toàn hàng hải

An toàn hàng hải là trạng thái mà trong đó các rủi ro phát sinh từ hoạt động hàng hải được nhận diện, kiểm soát và duy trì trong giới hạn chấp nhận được, nhằm bảo vệ tính mạng con người, tàu thuyền, hàng hóa, công trình hàng hải và môi trường biển. Xét từ góc độ pháp lý quốc tế, an toàn hàng hải gắn chặt với nghĩa vụ của quốc gia trong việc nội luật hóa và tổ chức thực hiện các chuẩn mực của IMO, đặc biệt là SOLAS, COLREG, STCW và các tiêu chuẩn liên quan đến thông tin, điều hướng và cứu nạn (IMO, 1972; IMO, 1974; IMO, 1978; United Nations, 1982). Xét từ góc độ quản trị rủi ro, an toàn hàng hải không đồng nhất với trạng thái không có rủi ro, mà là trạng thái trong đó rủi ro được kiểm soát ở mức chấp nhận được thông qua tổ hợp các công cụ pháp luật, quản lý, kỹ thuật và công nghệ (Hollnagel, 2014; ISO, 2018; Kuo, 1998).

Trong điều kiện hiện đại, an toàn hàng hải không còn được hiểu thuần túy như kết quả của tuân thủ kỹ thuật trên tàu, mà là kết quả của một hệ thống quản trị đa tầng, bao gồm chuẩn mực quốc tế, thể chế quốc gia, hạ tầng bảo đảm an toàn hàng hải, dữ liệu hàng hải, cơ chế điều phối từ bờ và hành vi của các chủ thể tham gia vận tải biển. Điều này cho thấy an toàn hàng hải là khái niệm có tính hệ thống, liên ngành và quốc tế hóa cao. Khi vận tải biển chuyển mạnh sang hàng hải điện tử (e-Navigation), tích hợp dữ liệu số, bản đồ số, hệ thống VTS, AIS, LRIT và các nền tảng hỗ trợ ra quyết định, thì an toàn hàng hải ngày càng mang đậm đặc tính số hóa, tính dự báo và tính phục hồi (EMSA, 2025; IALA, 2023; IMO, 2018b; IMO, 2024b; Kuo, 1998; Mao & Wang, 2020).

Bảng 1.1. Tổng hợp một số cách tiếp cận về an toàn hàng hải

[TABLE]

Nguồn: Nghiên cứu sinh tổng hợp từ (IMO, 1974), (United Nations, 1982), (ISO, 2018), (Kuo, 1998), (Hollnagel, 2014), (Mao & Wang, 2020), (EMSA, 2025), (IALA, 2023), (UNCTAD, 2024).

Tổng hợp các cách tiếp cận khoa học, luận án xác định: “an toàn hàng hải là trạng thái trong đó các hoạt động hàng hải được tiến hành ổn định, thông suốt và trong giới hạn rủi ro chấp nhận được, trên cơ sở hệ thống biện pháp pháp luật, quản lý, kỹ thuật và công nghệ phù hợp với chuẩn mực quốc tế và điều kiện quốc gia, nhằm bảo vệ con người, phương tiện, hàng hóa, công trình hàng hải và môi trường biển”.

Từ khái niệm này, có thể khái quát năm đặc trưng cơ bản của an toàn hàng hải. Thứ nhất, an toàn hàng hải có tính toàn cầu, vì sự cố tại một mắt xích có thể lan truyền tác động đến chuỗi cung ứng quốc tế. Thứ hai, an toàn hàng hải có tính đa chiều, kết hợp đồng thời yếu tố pháp lý, kỹ thuật, tổ chức, con người và môi trường. Thứ ba, an toàn hàng hải có tính động, bởi rủi ro thay đổi theo lưu lượng tàu, điều kiện tự nhiên, công nghệ và bối cảnh địa chính trị. Thứ tư, an toàn hàng hải có tính đa chủ thể, vì kết quả an toàn không do một chủ thể đơn lẻ quyết định. Thứ năm, an toàn hàng hải ngày càng mang tính số hóa và tính phục hồi, đòi hỏi năng lực phát hiện sớm, ứng phó nhanh và khôi phục hoạt động sau sự cố (EMSA, 2025; IALA, 2023; IHO, 2022).

1.1.2. Khái niệm bảo đảm an toàn hàng hải

Nếu an toàn hàng hải là trạng thái mục tiêu, thì bảo đảm an toàn hàng hải là tổng thể cơ chế, điều kiện và hoạt động nhằm duy trì trạng thái đó trong thực tiễn. Theo nghĩa này, bảo đảm an toàn hàng hải không chỉ là tập hợp các thiết bị hay dịch vụ riêng lẻ, mà là một hệ thống bao gồm thể chế, hạ tầng, dữ liệu, tổ chức vận hành và các dịch vụ hỗ trợ dẫn tàu, điều phối giao thông, phát hành thông tin an toàn, khảo sát – hải đồ, báo hiệu và cứu nạn (IALA, 2023; IHO, 2022; IMO, 2003; IMO, 2021).

Về phương diện kinh tế công cộng, bảo đảm an toàn hàng hải mang bản chất hỗn hợp giữa hàng hóa công cộng và dịch vụ công ích thiết yếu. Đối với các cấu phần hệ thống như luồng hàng hải công cộng, báo hiệu hàng hải, hệ thống VTS dùng chung, hải đồ và dữ liệu nền, thất bại thị trường thể hiện ở chỗ khu vực tư nhân không có động lực đầu tư đầy đủ nếu thiếu vai trò kiến tạo, tài trợ và điều tiết của Nhà nước. Đối với các dịch vụ như hoa tiêu, thông tin an toàn hàng hải, điều phối giao thông, nạo vét duy tu, thất bại thị trường không nằm ở chỗ hoàn toàn không có cung, mà ở chỗ thị trường có xu hướng cung dưới mức tối ưu xã hội, thiếu chuẩn hóa đầu ra và thiếu cơ chế bảo đảm chất lượng liên tục (Samuelson, 1954; Stiglitz & Rosengard, 2015; World Bank, 1994).

Vì vậy, dưới góc độ quản lý nhà nước, bảo đảm an toàn hàng hải phải được nhận diện theo hai nội dung có liên hệ chặt chẽ nhưng không đồng nhất. Một là, quản lý hệ thống bảo đảm an toàn hàng hải, nhấn mạnh quản trị kết cấu hạ tầng và dữ liệu nền theo vòng đời. Hai là, quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải, nhấn mạnh điều tiết đầu ra dịch vụ phục vụ người sử dụng. Sự phân định này có ý nghĩa lý luận trực tiếp đối với đề tài, vì nó cho phép xác định rõ đối tượng quản lý, tiêu chí đánh giá và cơ chế trách nhiệm giải trình của cơ quan quản lý nhà nước (IALA, 2022; Musgrave & Musgrave, 1989; World Bank, 1994).

Trên cơ sở đó, luận án xác định: “bảo đảm an toàn hàng hải là tổng thể hoạt động tổ chức, quản lý và vận hành hệ thống, hạ tầng, dữ liệu và dịch vụ do Nhà nước chủ trì hoặc điều tiết, nhằm duy trì điều kiện an toàn, thông suốt, hiệu quả và bền vững cho hoạt động hàng hải theo pháp luật quốc gia phù hợp với chuẩn mực quốc tế”.

Bảng 1.2. Tổng hợp một số cách tiếp cận về bảo đảm an toàn hàng hải

[TABLE]

Nguồn: Nghiên cứu sinh tổng hợp từ (IMO, 1974), (IMO, 2003), (IMO, 2024b, 2024c), (IALA, 2023), (IHO, 2022), (UNCTAD, 2024).

Tổng hợp khái niệm cho thấy bốn đặc trưng chính của bảo đảm an toàn hàng hải: Thứ nhất, đây là lĩnh vực gắn trực tiếp với trách nhiệm công và nghĩa vụ quốc gia. Thứ hai, bảo đảm an toàn hàng hải có tính liên ngành và đa chủ thể, nhưng phải có một trung tâm điều tiết thống nhất. Thứ ba, lĩnh vực này ngày càng dựa vào nền tảng dữ liệu số, tiêu chuẩn liên thông và quản trị rủi ro. Thứ tư, bảo đảm an toàn hàng hải không chỉ có chức năng phòng ngừa, mà còn có chức năng duy trì liên tục và phục hồi hoạt động vận tải biển sau gián đoạn (EMSA, 2025; IALA, 2023; IHO, 2022).

1.1.3. Vai trò của bảo đảm an toàn hàng hải

Bảo đảm an toàn hàng hải giữ vai trò then chốt, đa chiều trong phát triển bền vững ngành vận tải biển và kinh tế biển toàn cầu.

Trước hết, bảo đảm an toàn cho thuyền viên, hành khách, hàng hóa, tài sản và cộng đồng ven biển là yếu tố tiên quyết nhằm giảm thiểu rủi ro tai nạn và thảm họa (Wilhelmsen Ship Management, 2024). Một ví dụ quốc tế tiêu biểu là sự cố tàu du lịch Costa Concordia năm 2012, qua đó bộc lộ những hạn chế trong công tác quản lý an toàn, vận hành và tuân thủ quy trình khẩn cấp trên tàu khách. Sau sự cố này,

IMO đã tăng cường quy định SOLAS, trong đó nhấn mạnh yêu cầu tổ chức diễn tập an toàn cho hành khách trước khi tàu rời cảng (IMO, 1974; Marine Casualties Investigative Body (Italy), 2013).

Thứ hai, bảo đảm an toàn hàng hải có vai trò bảo vệ môi trường biển khỏi các tác động tiêu cực của hoạt động vận tải, đặc biệt là ô nhiễm dầu, hóa chất, rác thải và khí thải (IMO, 1973/1978). Công ước MARPOL đã thiết lập khung pháp lý toàn cầu, yêu cầu các quốc gia xây dựng hệ thống kiểm soát và xử lý vi phạm hiệu quả (IMO, 1973/1978). Thảm họa tràn dầu Exxon Valdez năm 1989 ở Alaska cho thấy hậu quả môi trường và kinh tế có thể kéo dài nhiều thập kỷ; sự kiện này cũng góp phần thúc đẩy Hoa Kỳ ban hành Đạo luật Ô nhiễm Dầu mỏ (OPA 90), trong đó yêu cầu tăng cường trách nhiệm pháp lý và các biện pháp phòng ngừa đối với tàu chở dầu (National Oceanic and Atmospheric Administration [NOAA], n.d.; United States Environmental Protection Agency [EPA], n.d.).

Thứ ba, bảo đảm an toàn hàng hải là yếu tố nền tảng bảo đảm sự ổn định và phát triển của thương mại quốc tế. Khoảng 90% hàng hóa toàn cầu được vận chuyển bằng đường biển; do đó, bất kỳ sự cố lớn nào cũng có thể gây gián đoạn chuỗi cung ứng, thiệt hại kinh tế nghiêm trọng và ảnh hưởng đến an ninh lương thực, năng lượng của nhiều quốc gia (UNCTAD, 2024; UNCTAD, 2025b). Sự cố tàu Ever Given mắc cạn ở Kênh đào Suez năm 2021 cho thấy rủi ro hệ thống trong ngành hàng hải hiện đại, khi một sự cố đơn lẻ trên tuyến hàng hải trọng yếu có thể tạo ra tác động dây chuyền đối với chuỗi cung ứng toàn cầu (UNCTAD, 2024).

Thứ tư, việc bảo đảm an toàn hàng hải là điều kiện tiên quyết nhằm duy trì uy tín, năng lực cạnh tranh và thúc đẩy hội nhập quốc tế cho ngành vận tải biển của mỗi quốc gia. Tuân thủ các tiêu chuẩn quốc tế không chỉ góp phần nâng cao hình ảnh quốc gia mà còn tạo thuận lợi trong thu hút đầu tư, phát triển đội tàu và hệ thống cảng biển hiện đại, đồng thời giúp giảm thiểu rủi ro pháp lý cũng như chi phí bảo hiểm (UNCTAD, 2024).

Cuối cùng, bảo đảm an toàn hàng hải là công cụ quan trọng để thực thi chủ quyền, bảo vệ lợi ích quốc gia và duy trì trật tự trên biển. Ngoài ra, đây còn là phương tiện phòng chống cướp biển, buôn lậu, vận chuyển trái phép, đánh bắt bất hợp pháp và khủng bố hàng hải. Việc phối hợp giữa các lực lượng và cơ quan chuyên ngành giúp tăng cường kiểm soát, phản ứng nhanh với tình huống khẩn cấp, thúc đẩy hợp tác quốc tế phòng chống tội phạm xuyên biên giới, góp phần củng cố vị thế và năng lực hội nhập quốc tế (IMO, n.d.; IMO, n.d.; United Nations, 1982).

1.2. QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI

1.2.1. Khái quát chung quản lý nhà nước về bảo đảm an toàn hàng hải

1.2.1.1. Khái niệm, chủ thể, phạm vi quản lý nhà nước về bảo đảm an toàn hàng hải

Về khái niệm quản lý nhà nước: Quản lý nhà nước là quá trình Nhà nước vận dụng quyền lực công để thiết lập thể chế, phân bổ nguồn lực, điều phối cung ứng dịch vụ và kiểm soát quá trình thực hiện. Mục tiêu cốt lõi của hoạt động này là thúc đẩy phát triển kinh tế - xã hội, bảo vệ lợi ích quốc gia và duy trì trật tự công cộng. Xét về mặt lý luận, khoa học hành chính được xem là nền tảng cơ bản của quản lý nhà nước, đặt trọng tâm vào việc kiến tạo một bộ máy công quyền chuyên nghiệp, hiệu quả và đề cao tinh thần trách nhiệm (Wilson, 1887). Trong mô hình truyền thống, hệ thống quản lý nhà nước lý tưởng được vận hành theo cơ chế quan liêu, đặc trưng bởi sự phân công lao động rõ ràng, cấu trúc thứ bậc nghiêm ngặt và tính tuân thủ tuyệt đối các quy tắc pháp lý (Weber, 1947).

Tuy nhiên, bối cảnh hiện đại đã thúc đẩy một bước chuyển dịch mô hình sang tư duy "quản trị mới". Trong đó, hoạt động quản lý nhà nước không còn là đặc quyền của riêng chính phủ truyền thống mà được mở rộng thông qua các mạng lưới đa chủ thể, đề cao sự hợp tác và san sẻ trách nhiệm (Osborne, 2010; Rhodes, 1996). Xu hướng quản trị công mới ngày càng được khẳng định mạnh mẽ, định hình lại lăng kính quản lý với trọng tâm hướng tới việc kiến tạo giá trị công, củng cố trách nhiệm giải trình và thúc đẩy các chương trình cải cách quản trị dựa trên kết quả thực tiễn (Moore, 1995; Pollitt & Bouckaert, 2011; UNDP, 2009).

Về cơ sở khoa học, quản lý nhà nước về bảo đảm an toàn hàng hải trong luận án được xây dựng trên sự kết hợp của bốn nền tảng chủ yếu.

Thứ nhất, kinh tế học công cộng cung cấp luận cứ về thất bại thị trường, ngoại ứng và hàng hóa công cộng. Theo cách tiếp cận này, sự can thiệp của Nhà nước là cần thiết đối với những lĩnh vực mà thị trường không thể tự bảo đảm cung ứng đầy đủ, công bằng và ổn định; bảo đảm an toàn hàng hải là một trường hợp điển hình vì liên quan trực tiếp đến lợi ích công, an toàn sinh mạng, môi trường biển và sự thông suốt của chuỗi vận tải (Samuelson, 1954; Stiglitz & Rosengard, 2015).

Thứ hai, lý thuyết quản trị công hiện đại nhấn mạnh sự chuyển dịch từ quản lý hành chính thuần túy sang quản trị theo kết quả, theo chuẩn đầu ra và trách nhiệm giải trình. Đối với bảo đảm an toàn hàng hải, điều này có nghĩa là cơ quan quản lý nhà nước không chỉ ban hành quy định, mà còn phải tổ chức thực hiện, đo lường hiệu quả và điều chỉnh chính sách trên cơ sở bằng chứng (OECD, 2014; OECD, 2019b; Rhodes, 1996).

Thứ ba, quản trị rủi ro là nền tảng trực tiếp cho việc tổ chức kiểm soát an toàn trong điều kiện rủi ro động, công nghệ thay đổi nhanh và môi trường biển phức tạp. Cách tiếp cận này cho phép chuyển từ tư duy hậu kiểm sang tư duy phòng ngừa, cảnh báo sớm và ưu tiên nguồn lực theo mức độ rủi ro (EMSA, 2025; IALA, 2017b; IMO, 2020).

Thứ tư, quản trị tài sản công và quản trị chất lượng dịch vụ công là nền tảng để luận án tách bạch hai nội dung quản lý: quản lý hệ thống và quản lý cung ứng dịch vụ. Hạ tầng bảo đảm an toàn hàng hải cần được quản trị theo vòng đời tài sản; trong khi dịch vụ bảo đảm an toàn hàng hải cần được điều tiết theo chuẩn đầu ra, KPI/SLA và cơ chế giám sát chất lượng (IALA, 2022; Musgrave & Musgrave, 1989; World Bank, 1994).

Từ bốn nền tảng trên, luận án xác định rằng: “quản lý nhà nước về bảo đảm an toàn hàng hải không thể được hiểu như hoạt động quản lý kỹ thuật đơn thuần, mà phải được nhận diện là quá trình Nhà nước sử dụng quyền lực công để kiến tạo thể chế, tổ chức nguồn lực, điều tiết cung ứng và giám sát kết quả đối với cả hệ thống và dịch vụ bảo đảm an toàn hàng hải”

Khái niệm này cần làm rõ ba lớp nội hàm. Thứ nhất, quản lý nhà nước ở đây là hoạt động quyền lực công, không đồng nhất với hoạt động tác nghiệp hay hoạt động cung ứng dịch vụ. Thứ hai, đối tượng quản lý không chỉ là hệ thống tài sản kỹ thuật, mà còn bao gồm dịch vụ bảo đảm an toàn hàng hải và các quan hệ phát sinh trong quá trình cung ứng. Thứ ba, mục tiêu quản lý không chỉ là tuân thủ pháp luật, mà còn là bảo đảm kết quả an toàn, tính thông suốt, chất lượng dịch vụ và trách nhiệm giải trình.

Về chủ thể quản lý nhà nước, trong quản lý nhà nước về bảo đảm an toàn hàng hải trên thế giới, việc xác định cơ quan quản lý ở các quốc gia là không hoàn toàn giống nhau do phụ thuộc vào thể chế, tổ chức và mức độ phân cấp hành chính của mỗi nước. Thông thường, bộ hoặc cơ quan trung ương của quốc gia đảm nhận xây dựng chiến lược, ban hành quy định, kỹ thuật và khung pháp lý phù hợp với chuẩn mực quốc tế. Các cơ quan quản lý nhà nước chuyên ngành hàng hải chịu trách nhiệm hướng dẫn, giám sát thực hiện chính sách, quản lý dữ liệu kỹ thuật, vận hành tiêu chuẩn và tổng hợp báo cáo. Đáng chú ý, ở nhiều quốc gia có xu hướng tách bạch tương đối giữa chức năng quản lý nhà nước và chức năng cung ứng dịch vụ bảo đảm an toàn hàng hải; mức độ tham gia của khu vực công, tư hoặc đối tác công – tư khác nhau tùy từng nước và từng loại dịch vụ. Nhà nước thiết lập khuôn khổ pháp lý, tiêu chuẩn kỹ thuật, cơ chế giám sát và bảo đảm lợi ích công, còn các chủ thể cung ứng phải tuân thủ các chuẩn đầu ra và chế độ trách nhiệm giải trình tương ứng (World Bank, 1994; World Bank Group, Asian Development Bank, European Bank for Reconstruction and Development, Inter-American Development Bank, Islamic Development Bank, OECD, UNECE & UNESCAP, 2017; World Bank & International Association of Ports and Harbors [IAPH], 2021).

Về phạm vi quản lý nhà nước về bảo đảm an toàn hàng hải được xác lập theo hai chiều cạnh: không gian pháp lý và không gian kỹ thuật. Không gian pháp lý bao gồm toàn bộ vùng nước thuộc quyền tài phán quốc gia và vùng biển quốc tế có liên quan đến hoạt động hàng hải, trong khi không gian kỹ thuật mở rộng theo phạm vi hoạt động của hệ thống định vị, liên lạc và giám sát tàu thuyền. Theo IMO (2020), quản lý hiện đại về an toàn hàng hải không giới hạn trong lãnh thổ mà được tổ chức theo cơ chế phối hợp khu vực và quốc tế, nhằm bảo đảm tính liên thông và an toàn của chuỗi vận tải biển toàn cầu. Sự phối hợp này dựa trên nguyên tắc chia sẻ dữ liệu, hài hòa quy chuẩn và giám sát chung các chỉ tiêu an toàn. Do đó, phạm vi quản lý nhà nước không chỉ dừng lại ở thẩm quyền quốc gia mà còn bao gồm trách nhiệm hợp tác và phối hợp quốc tế trong thực hiện nghĩa vụ chung về an toàn hàng hải (OECD, 2019a).

Về công cụ quản lý, Cơ quan quản lý nhà nước cấp trung ương (cấp Bộ) thực hiện quyền lực công thông qua việc ban hành các văn bản quy phạm pháp luật, phê duyệt các quy hoạch chiến lược, tổ chức triển khai cơ chế phân cấp cũng như giám sát việc tuân thủ (Rhodes, 1996; Weber, 1947; Wilson, 1887). Hoạt động này không dựa trên quyền sở hữu hoặc quyền lực thị trường mà khẳng định tính phi thương mại của quản lý nhà nước, kể cả trong trường hợp dịch vụ bảo đảm an toàn hàng hải được thực hiện thông qua đặt hàng, đấu thầu hay ký kết hợp đồng với các tổ chức ngoài khu vực nhà nước (Samuelson, 1954; World Bank, 1994). Tính phi thương mại ở đây có nghĩa là các hoạt động quản lý nhà nước không nhằm mục đích sinh lợi nhuận mà hướng tới việc bảo đảm lợi ích chung và sự an toàn cho cộng đồng (Hollnagel, 2014; Stiglitz & Rosengard, 2015).

1.2.1.2. Mục tiêu, đặc điểm và xu hướng quản lý nhà nước về bảo đảm an toàn hàng hải

Mục tiêu tổng quát của quản lý nhà nước về bảo đảm an toàn hàng hải là duy trì mức độ an toàn cao cho hoạt động hàng hải, qua đó bảo vệ con người, tài sản và môi trường biển, đồng thời bảo đảm giao thông hàng hải thông suốt, hỗ trợ thương mại và phát triển bền vững kinh tế biển (Kuo, 1998; UNCTAD, 2024). Từ mục tiêu tổng quát đó, có thể cụ thể hóa thành các mục tiêu bộ phận: hoàn thiện thể chế; duy trì tính sẵn sàng của hệ thống; chuẩn hóa chất lượng dịch vụ; nâng cao năng lực giám sát, dự báo và phản ứng; tăng cường minh bạch, trách nhiệm giải trình; và thúc đẩy số hóa, hiện đại hóa quản lý (IALA, 2022; IALA, 2023; IHO, 2022).

Quản lý nhà nước về bảo đảm an toàn hàng hải có một số đặc điểm nổi bật. Thứ nhất, đây là lĩnh vực mang tính quốc tế hóa rất cao, do chịu sự chi phối mạnh của các công ước và tiêu chuẩn quốc tế. Thứ hai, đây là lĩnh vực có tính liên ngành và đa chủ thể, đòi hỏi sự phối hợp giữa nhiều cơ quan, lực lượng và đơn vị cung ứng. Thứ ba, đây là lĩnh vực kết hợp chặt giữa quyền lực công và trình độ kỹ thuật chuyên sâu. Thứ tư, đây là lĩnh vực mà hiệu quả quản lý phụ thuộc lớn vào dữ liệu, công nghệ, nhân lực và năng lực phản ứng trong điều kiện rủi ro động (EMSA, n.d.; IHO, 2022; IMO, 2021).

Trong nhiều thập kỷ gần đây, quản lý nhà nước về bảo đảm an toàn hàng hải ghi nhận xu hướng chuyển dịch căn bản từ mô hình dựa trên quy phạm và kiểm tra định kỳ sang mô hình quản trị hiện đại đặt trọng tâm vào dịch vụ, dữ liệu, rủi ro và trách nhiệm giải trình. Các tổ chức quốc tế trọng yếu như IMO, IALA, IHO, EMSA nhấn mạnh rằng bảo đảm an toàn hàng hải không thể đạt được chỉ bằng quy định pháp luật, mà phải dựa trên sự kết hợp giữa chuẩn kỹ thuật, mức dịch vụ, dữ liệu điện tử và cơ chế tham gia đa chủ thể (IALA, 2023; IMO, 2020). Theo IALA (2023), quản trị theo mức dịch vụ trở thành xu thế khi Nhà nước xác định các chỉ số định lượng như độ sẵn sàng của AtoN, thời gian phản ứng cứu nạn và độ trễ phát hành MSI để đánh giá hiệu quả (IALA, 2023). IHO (2022) khẳng định vai trò của số hóa dữ liệu và chuẩn hóa thông tin trong xây dựng cơ sở dữ liệu thống nhất, hỗ trợ ra quyết định nhanh chóng và chính xác (IHO, 2022). Ở nhiều quốc gia, Nhà nước kết hợp đầu tư công với huy động nguồn lực xã hội và thúc đẩy đổi mới công nghệ trong vận hành hệ thống BĐATHH; tuy nhiên, mức độ và hình thức tham gia của khu vực tư khác nhau giữa từng nước, từng loại hạ tầng và từng dịch vụ (World Bank, 1994; World Bank Group, Asian Development Bank, European Bank for Reconstruction and Development, Inter-American Development Bank, Islamic Development Bank, OECD, UNECE & UNESCAP, 2017; World Bank & International Association of Ports and Harbors [IAPH], 2021). OECD (2019) cũng chỉ ra rằng quản lý dựa trên rủi ro giúp tập trung nguồn lực cho khu vực có nguy cơ cao, giảm thiểu tai nạn và tăng hiệu quả đầu tư (OECD, 2019a). Xu hướng minh bạch hóa và công khai dữ liệu trở thành nguyên tắc cốt lõi của quản trị hiện đại, khẳng định vai trò Nhà nước kiến tạo trong điều phối mạng lưới đa chủ thể, nâng cao tính bền vững của hệ thống quản lý an toàn hàng hải toàn cầu.

1.2.2. Nội dung quản lý nhà nước về bảo đảm an toàn hàng hải

Cấu trúc nội dung quản lý nhà nước (QLNN) về bảo đảm an toàn hàng hải (BĐATHH) được xây dựng dựa trên ma trận 2×3, bao gồm hai nội dung: tổ chức và quản lý hệ thống BĐATHH và quản lý cung ứng dịch vụ BĐATHH. Mỗi nhóm nội dung đều được phân tích theo ba khía cạnh chức năng: ban hành văn bản, tổ chức thực hiện và giám sát, đánh giá (IALA, 2017a, 2017b; IHO, 2018; IMO, 1974; Kusek & Rist, 2004).

1.2.2.1. Tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải

Tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải trước hết là quản trị tài sản kết cấu hạ tầng theo vòng đời, từ quy hoạch đến đầu tư, vận hành, bảo trì, nâng cấp và thanh lý. Khác với một dự án đơn lẻ, hệ thống bảo đảm an toàn hàng hải là mạng lưới kết nối giữa luồng tuyến, báo hiệu, thông tin, thủy đạc– hải đồ và các trung tâm giám sát, đòi hỏi quy hoạch tổng thể gắn với cấu trúc tuyến vận tải, dự báo lưu lượng và phân tích rủi ro. Trong quản trị rủi ro, quy hoạch và đầu tư cần ưu tiên khu vực có nguy cơ tai nạn cao, đoạn luồng tàu và khu vực có điều kiện tự nhiên phức tạp thay vì phân bổ dàn trải (ISO, 2018).

Một là, Ban hành thể chế, quy hoạch, tiêu chuẩn và kế hoạch đầu tư hệ thống bảo đảm an toàn hàng hải

Ở khâu ban hành, cơ quan quản lý nhà nước thực hiện vai trò kiến tạo khuôn khổ để hệ thống bảo đảm an toàn hàng hải (BĐATHH) được thiết kế, đầu tư và vận hành thống nhất trên phạm vi quốc gia (OECD, 2014; Rhodes, 1996). Nội dung này gồm ba nhóm chính: (i) tham mưu, ban hành và tổ chức sửa đổi, bổ sung văn bản quy phạm pháp luật và văn bản hướng dẫn thi hành (hạ tầng vật lý, hạ tầng số và dữ liệu); (ii) xây dựng chiến lược, quy hoạch và kế hoạch phát triển hệ thống dựa trên phân tích rủi ro (IALA, 2017b; IMO, 2018a) và (iii) ban hành tiêu chuẩn, quy chuẩn gắn với mục tiêu an toàn và năng lực tài chính (IALA, 2017b; IALA, 2023).

Về pháp luật và tiêu chuẩn, nội dung ban hành cần làm rõ phạm vi trách nhiệm và cơ chế phối hợp của các chủ thể tham gia (cơ quan quản lý trung ương, cơ quan tại cảng/địa phương, đơn vị quản lý khai thác công trình), đồng thời đặt ra yêu cầu tối thiểu về mức độ sẵn sàng, độ tin cậy và an toàn thông tin đối với các cấu phần như luồng hàng hải, báo hiệu hàng hải, thủy đạc hải đồ, VTS/AIS và hệ thống thông tin hàng hải (IMO, 1974; IMO, 2021). Việc nội luật hóa và cập nhật chuẩn mực quốc tế là cơ sở để bảo đảm tính tương thích, hội nhập và giảm rủi ro vận hành (IHO, 2022; IMO, 2018a).

Về quy hoạch, cơ quan quản lý phải xác định cấu trúc mạng lưới và ưu tiên đầu tư theo tuyến luồng trọng điểm, khu vực mật độ giao thông cao và khu vực có nguy cơ tai nạn cao; gắn quy hoạch với dự báo lưu lượng, xu hướng tàu lớn, điều kiện tự nhiên và các kịch bản biến đổi khí hậu (IHO, 2018; UNCTAD, 2023). Quy hoạch không chỉ xác định cấu trúc hạ tầng mà còn là công cụ điều tiết rủi ro và phân bổ nguồn lực theo mức độ ưu tiên (IALA, 2017b; OECD, 2014).

Về quản lý chất lượng dữ liệu và hạ tầng thông tin nền. Thủy đạc–hải đồ không chỉ là sản phẩm kỹ thuật mà là cơ sở pháp lý–thông tin cho quyết định hành hải và quyết định quản lý. IHO nhấn mạnh nghĩa vụ cung cấp dịch vụ thủy đạc theo SOLAS và đưa ra chuẩn tối thiểu về khảo sát thủy đạc phục vụ an toàn hàng hải (IHO, 2022; IHO, 2024). Vì vậy, quản lý nhà nước cần thiết lập cơ chế bảo đảm chất lượng dữ liệu, cơ chế cập nhật, cơ chế chia sẻ và cơ chế kiểm định, bảo đảm thông tin hàng hải thống nhất giữa các kênh (IHO, 2022). Bên cạnh dữ liệu, quản lý hệ thống còn bao gồm quản lý đầu tư, tiêu chuẩn hóa và hiện đại hóa các cấu phần vật lý và số của hệ thống, như báo hiệu hàng hải, trung tâm VTS, thiết bị giám sát, đường truyền và nền tảng phần mềm (IALA, 2022; IMO, 2024b). Việc hiện đại hóa cần gắn với kiến trúc hàng hải điện tử (eNavigation) và tính tương thích liên thông, vì e-Navigation hướng tới hài hòa thu thập, tích hợp, trao đổi, trình bày, phân tích thông tin biển trên tàu và bờ (IMO, 2018b; IMO, 2019). Nếu thiếu thiết kế tổng thể, đầu tư công nghệ có thể tạo ra sự lãng phí, rời rạc, khó chia sẻ dữ liệu và khó mở rộng (World Bank & International Association of Ports and Harbors [IAPH], 2021).

Cuối cùng, tổ chức quản lý hệ thống bao hàm cơ chế tài chính bền vững cho vận hành và bảo trì. Các cấu phần như báo hiệu, VTS hay khảo sát thủy đạc có chi phí duy trì thường xuyên và chi phí thay thế theo chu kỳ. Trong kinh nghiệm quốc tế, một số quốc gia thiết kế phí an toàn hoặc cơ chế thu–chi chuyên biệt để tài trợ cho giám sát và điều phối giao thông, bảo đảm dịch vụ thiết yếu không phụ thuộc hoàn toàn vào ngân sách thường xuyên (Kystverket, n.d.; Kystverket, 2025). Từ góc độ quản trị, thiết kế tài chính phải đi cùng cơ chế công khai minh bạch và đánh giá hiệu quả để bảo đảm tính chính danh và hiệu lực chi tiêu công (OECD, 2014; OECD, 2019b).

Hai là, tổ chức thực hiện quy hoạch, đầu tư và vận hành hệ thống bảo đảm an toàn hàng hải

Tổ chức thực hiện nhằm bảo đảm các yêu cầu của pháp luật, quy hoạch, tiêu chuẩn và kế hoạch đầu tư được triển khai đồng bộ từ trung ương tới địa phương (Rhodes, 1996; World Bank Group, Asian Development Bank, European Bank for Reconstruction and Development, Inter-American Development Bank, Islamic Development Bank, OECD, UNECE & UNESCAP, 2017). Trước hết, cơ quan quản lý tổ chức tuyên truyền, tập huấn và hướng dẫn chuyên môn để các đơn vị liên quan hiểu và áp dụng thống nhất; đồng thời ban hành quy trình nghiệp vụ để chuẩn hóa hoạt động điều hành, vận hành và phối hợp tác nghiệp (IMO, 1978; IMO, 2024c).

Trong triển khai đầu tư, nhiệm vụ trọng tâm là lập và tổ chức thực hiện danh mục dự án ưu tiên (nạo vét, duy tu luồng; nâng cấp báo hiệu; hiện đại hóa VTS/AIS; nền tảng dữ liệu…), bố trí nguồn lực và quản lý dự án theo tiếp cận vòng đời tài sản (World Bank, 1994). Việc lựa chọn công nghệ và phương án đầu tư cần bảo đảm tính tương thích, khả năng mở rộng và liên thông dữ liệu để tránh hình thành các hệ thống rời rạc (IMO, 2018b; World Bank & International Association of Ports and Harbors [IAPH], 2021).

Trong vận hành, Nhà nước (thông qua cơ quan chuyên trách hoặc đơn vị được giao quản lý khai thác) tổ chức duy tu, bảo trì, kiểm định định kỳ nhằm duy trì trạng thái hoạt động ổn định; vận hành liên tục các trung tâm giám sát, điều phối; bảo đảm cập nhật dữ liệu và thông tin hàng hải; và duy trì năng lực ứng phó khi có sự cố bất thường do thiên tai, tai nạn hoặc gián đoạn kỹ thuật (IALA, 2017a; Kystverket, n.d.; Kystverket, n.d.).

Điều phối liên ngành/liên cấp: do thực địa hàng hải là giao điểm giữa nhiều chủ thể (cảng vụ, VTS, SAR, đơn vị khai thác công trình…), tổ chức thực hiện cần dịch chuẩn pháp lý thành quy trình phối hợp, kênh dữ liệu và trách nhiệm theo tình huống (bình thường/khẩn cấp) (EMSA, n.d.; IMO, 2021; Kystverket, n.d.).

Ba là, giám sát, đánh giá quản lý hệ thống bảo đảm an toàn hàng hải

Giám sát, đánh giá có chức năng kiểm soát tuân thủ và đo lường hiệu quả vận hành hệ thống theo mục tiêu an toàn (Kusek & Rist, 2004; OECD, 2014). Hoạt động này bao gồm thanh tra, kiểm tra việc chấp hành pháp luật, tiêu chuẩn kỹ thuật; kiểm soát chất lượng công trình/thiết bị và an toàn thông tin; giám sát tiến độ, chất lượng và hiệu quả chi tiêu của các dự án đầu tư, duy tu (IMO, 2013; OECD, 2019b).

Song song với kiểm tra hành chính, xu hướng quốc tế là áp dụng giám sát dựa trên dữ liệu và chỉ số hiệu suất (KPI), ví dụ: mức độ sẵn sàng của báo hiệu, thời gian khắc phục báo hiệu lệch vị trí, tỷ lệ chiều dài luồng đạt chuẩn độ sâu thiết kế, độ phủ giám sát của VTS/AIS hoặc mức độ kịp thời và chính xác của dữ liệu thủy đạc – hải đồ (EMSA, 2024; IALA, 2017a; Kystverket, n.d.). Kết quả giám sát cần được tổng hợp định kỳ và công khai ở mức phù hợp để tăng minh bạch và trách nhiệm giải trình (OECD, 2014; OECD, 2019b). Các kết quả giám sát là cơ sở phản hồi chính sách: cập nhật quy hoạch, điều chỉnh tiêu chuẩn, ưu tiên đầu tư và hoàn thiện tổ chức vận hành theo tiếp cận cải tiến liên tục (Hollnagel, 2014; IMO, 2018a; OECD, 2014).

1.2.2.2. Quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

Nếu quản lý hệ thống bảo đảm an toàn hàng hải nhấn mạnh việc xác lập hệ thống tài sản phục vụ bảo đảm an toàn hàng hải, thì quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải nhấn mạnh đầu ra phục vụ người sử dụng. Dịch vụ bảo đảm an toàn hàng hải có đặc điểm là dịch vụ công thiết yếu, có nhu cầu ổn định, khó thay thế và thường có yếu tố độc quyền tự nhiên theo lĩnh vực (ví dụ: hoa tiêu, điều phối giao thông trên tuyến luồng, vận hành báo hiệu). Do đó, quản lý nhà nước cần thiết kế khung chuẩn dịch vụ, cơ chế cấp phép/ủy quyền, cơ chế kiểm soát chất lượng và cơ chế xử lý vi phạm, thay vì chỉ tập trung vào năng lực kỹ thuật của nhà cung cấp (OECD, 2014; World Bank, 1994).

Một là, ban hành cơ chế, tiêu chuẩn dịch vụ và điều kiện cung ứng dịch vụ bảo đảm an toàn hàng hải

Ban hành trong quản lý dịch vụ BĐATHH tập trung vào việc xác lập chuẩn đầu ra và cơ chế điều tiết để bảo đảm dịch vụ công ích được cung ứng liên tục, an toàn và công bằng. Cơ quan quản lý quy định rõ danh mục dịch vụ thiết yếu (báo hiệu, hoa tiêu, thông tin hàng hải, VTS, tìm kiếm cứu nạn…), tiêu chuẩn mức dịch vụ theo từng loại hình và vùng nước; đồng thời phân định vai trò giữa cơ quan quản lý nhà nước và đơn vị cung ứng (tránh đồng nhất Nhà nước với nhà cung cấp dịch vụ) (OECD, 2019a).

Trong quản trị công, tiêu chuẩn dịch vụ cần được cụ thể hóa bằng hệ chỉ số KPI/SLA (ví dụ thời gian chờ hoa tiêu, độ kịp thời thông báo hàng hải, độ sẵn sàng kênh VTS…), làm căn cứ cho cơ chế cấp phép/đặt hàng, cơ chế giá – phí, chế tài và đánh giá hiệu quả. Đồng thời, khung pháp lý cần quy định chế độ dữ liệu và báo cáo bắt buộc (chuẩn dữ liệu, tần suất cập nhật, chia sẻ liên thông) để phục vụ giám sát chất lượng dịch vụ (IMO, 2018b; Kystverket, n.d.).

Hai là, tổ chức thực hiện và điều tiết cung ứng dịch vụ BĐATHH

Tổ chức thực hiện thể hiện vai trò điều phối của Nhà nước trong vận hành dịch vụ: (i) tuyên truyền, tập huấn và hướng dẫn thực hiện pháp luật, quy trình và tiêu chuẩn dịch vụ; (ii) lựa chọn/đặt hàng đơn vị cung ứng phù hợp, quản trị hợp đồng theo kết quả; và (iii) tổ chức phối hợp tác nghiệp 24/7 giữa cơ quan quản lý, cảng vụ, trung tâm VTS, tổ chức hoa tiêu, lực lượng tìm kiếm cứu nạn (SAR) và các chủ thể liên quan nhằm bảo đảm liên tục của dịch vụ và xử lý kịp thời tình huống phát sinh (Chính phủ nước CHXHCN Việt Nam, 2019).

Một nội dung cốt lõi là quản lý thiết lập và vận hành các dịch vụ thông tin, giám sát và điều phối (như VTS). IMO coi VTS là dịch vụ được tiêu chuẩn hóa quốc tế, góp phần đảm bảo an toàn sinh mạng, hành hải an toàn và hiệu quả, đồng thời bảo vệ môi trường biển; SOLAS cho phép quốc gia thiết lập VTS khi lưu lượng và mức độ rủi ro biện minh và khi VTS có khả năng cải thiện an toàn và hiệu quả hành hải (IMO, 1974; IMO, 2021). Từ đó, quản lý nhà nước cần quan tâm đồng thời đến ba trụ cột: căn cứ thiết lập, năng lực vận hành (nhân lực, quy trình, công nghệ) và cơ chế phối hợp với tàu thuyền/đơn vị liên quan.

Một nội dung quan trọng khác là quản lý cung ứng thông tin hàng hải trong bối cảnh số hóa. Với hàng hải điện tử (e-navigation), nhu cầu trao đổi dữ liệu hành hải, dữ liệu hàng nguy hiểm, dữ liệu hành trình và dữ liệu cảng biển gia tăng, kéo theo yêu cầu chuẩn hóa dữ liệu và chuẩn hóa quy trình báo cáo. Các nền tảng số (như SafeSeaNet ở châu Âu) hay các nền tảng điều phối đúng thời điểm (just-in-time) tại cảng trung chuyển lớn cho thấy xu hướng chuyển từ phương thức báo cáo thủ công sang phương thức trao đổi dữ liệu điện tử để hỗ trợ quyết định điều phối và giảm thời gian chờ (EMSA, n.d.; IMO, 2018b).

Thực hiện điều tiết cung ứng dịch vụ hiện đại thường gắn với số hóa quy trình và tích hợp dữ liệu. Cơ quan quản lý thúc đẩy xây dựng các nền tảng số hỗ trợ điều độ hoa tiêu, tiếp nhận và công bố thông báo hàng hải điện tử, chia sẻ dữ liệu luồng lạch/hải đồ và thiết lập kênh phản hồi người sử dụng. Việc tiêu chuẩn hóa giao diện dữ liệu và liên thông giữa các hệ thống giúp giảm độ trễ thông tin và giảm rủi ro do thông tin không nhất quán (World Bank & International Association of Ports and Harbors [IAPH], 2021).

Song song, Nhà nước tổ chức đào tạo, cấp chứng chỉ và phát triển năng lực của lực lượng cung ứng dịch vụ (hoa tiêu, nhân viên VTS, kỹ thuật viên báo hiệu…), bảo đảm đáp ứng chuẩn nghề nghiệp và duy trì năng lực vận hành trong bối cảnh tàu lớn và mật độ giao thông hàng hải tăng (IMO, 1978).

Ba là, giám sát, đánh giá chất lượng dịch vụ bảo đảm an toàn hàng hải

Trong nội dung này, cơ quan quản lý nhà nước giữ vai trò trung tâm, bởi chính cơ quan quản lý là chủ thể quy định chuẩn chất lượng dịch vụ, xác lập KPI, SLA và yêu cầu công bố thông tin, báo cáo định kỳ để theo dõi kết quả cung ứng dịch vụ một cách thực chất. Trên cơ sở đó, cơ quan quản lý không chỉ kiểm tra việc tuân thủ thủ tục mà còn tổ chức thu thập, đối chiếu và phân tích dữ liệu vận hành; thiết lập hệ thống theo dõi thường xuyên bằng các bảng chỉ số, tiến hành kiểm tra hiện trường, kiểm tra hồ sơ tác nghiệp khi xuất hiện dấu hiệu rủi ro hoặc phát sinh khiếu nại từ người sử dụng dịch vụ (IMO, 2013).

Cùng với đó, cơ quan quản lý tiếp nhận, xử lý và phản hồi kiến nghị của hãng tàu, cảng, đại lý và các chủ thể liên quan thông qua cơ chế minh bạch, qua đó đánh giá mức độ đáp ứng dịch vụ từ góc nhìn thị trường. Kết quả giám sát và phản hồi này trở thành căn cứ để cơ quan quản lý áp dụng chế tài hoặc cơ chế khuyến khích phù hợp, điều chỉnh đơn giá, phương thức đặt hàng, mức phí, đồng thời cập nhật tiêu chuẩn dịch vụ và định hướng ưu tiên đầu tư trong dài hạn. Như vậy, giám sát dịch vụ không chỉ nhằm phát hiện sai sót, mà còn là công cụ để cơ quan quản lý nhà nước điều chỉnh hành vi cung ứng, nâng cao trách nhiệm giải trình và tạo lập vòng phản hồi chính sách nhằm cải thiện liên tục chất lượng dịch vụ công (Hollnagel, 2014; OECD, 2014).

Từ phân tích hai nhóm nội dung, có thể thấy quản lý nhà nước về bảo đảm an toàn hàng hải bao quát cả quản lý hệ thống và quản lý cung ứng dịch vụ, đồng thời được thực hiện qua ba chức năng là ban hành, tổ chức thực hiện và giám sát, đánh giá. Trên cơ sở đó, luận án khái quát nội dung này theo khung phân tích 2×3 tại Bảng 1.3.

Bảng 1.3. Nội dung quản lý nhà nước về bảo đảm an toàn hàng hải theo khung phân tích 2×3

[TABLE]

Nguồn: Nghiên cứu sinh đề xuất, 2025.

Bảng 1.3 cho thấy nội dung quản lý nhà nước về bảo đảm an toàn hàng hải được cấu trúc thống nhất theo hai nhóm nội dung và ba chức năng quản lý nhà nước. Cách tiếp cận này là cơ sở để luận án xây dựng hệ tiêu chí đánh giá kết quả quản lý và phân tích các yếu tố ảnh hưởng ở các mục tiếp theo.

1.2.3. Tiêu chí đánh giá và các yếu tố ảnh hưởng tới kết quả quản lý nhà nước về bảo đảm an toàn hàng hải

1.2.3.1. Tiêu chí đánh giá kết quả quản lý nhà nước về bảo đảm an toàn hàng hải

Tiêu chí đánh giá kết quả quản lý nhà nước về bảo đảm an toàn hàng hải được xây dựng trên ba căn cứ: kế thừa hệ thống pháp luật, quy hoạch, quy chuẩn, tiêu chuẩn kỹ thuật và cơ chế quản lý dịch vụ của Việt Nam; tham chiếu có chọn lọc các chuẩn mực, khuyến nghị và cách tiếp cận quốc tế về quản lý hàng hải, quản lý rủi ro, quản lý tài sản kết cấu hạ tầng, kiểm soát chất lượng dịch vụ và đo lường kết quả thực thi; đồng thời tích hợp các căn cứ này vào khung phân tích 2×3 để hình thành hệ tiêu chí phù hợp với đặc thù quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam. Trên cơ sở đó, luận án xác lập 6 nhóm tiêu chí trong Bảng 1.4 gồm H1, H2, H3, D1, D2, D3, bảo đảm sự liên thông giữa cơ sở lý luận, bảng tiêu chí, đánh giá thực trạng và lượng hóa các biến quan sát trong mô hình nghiên cứu định lượng (OECD, 2014; Rhodes, 1996).

Nhóm tiêu chí thứ nhất là tiêu chí đánh giá kết quả ban hành cơ chế, pháp luật, quy hoạch và tiêu chuẩn kỹ thuật hệ thống BĐATHH (H1) (OECD, 2014). Kết quả quản lý ở phương diện này không chỉ được phản ánh ở số lượng văn bản được ban hành, mà quan trọng hơn ở mức độ đầy đủ, đồng bộ, cập nhật và khả thi của hệ thống thể chế. Một hệ thống thể chế có chất lượng phải bảo đảm sự liên thông giữa luật, nghị định, thông tư, quy chuẩn, tiêu chuẩn và công cụ quy hoạch; phân định rõ trách nhiệm của các chủ thể quản lý; đồng thời tạo hành lang pháp lý cho đầu tư, duy tu, khai thác, số hóa và giám sát hệ thống bảo đảm an toàn hàng hải (IMO, 1974).

Nhóm tiêu chí thứ hai là tiêu chí đánh giá kết quả tổ chức thực hiện trong quản lý hệ thống bảo đảm an toàn hàng hải (H2) (Rhodes, 1996). Đây là nhóm tiêu chí phản ánh năng lực hiện thực hóa các định hướng chính sách, quy hoạch và tiêu chuẩn vào thực tiễn đầu tư, quản lý tài sản, bảo trì, vận hành và hiện đại hóa hệ thống (World Bank, 1994). Một kết quả quản lý tích cực không chỉ thể hiện ở việc có bố trí nguồn lực, mà còn ở khả năng phân bổ nguồn lực đúng trọng tâm, tổ chức phối hợp đồng bộ giữa các chủ thể, duy trì trạng thái kỹ thuật và trạng thái sẵn sàng phục vụ của hệ thống (IALA, 2017a).

Nhóm tiêu chí thứ ba là tiêu chí đánh giá kết quả giám sát, đánh giá đối với hệ thống bảo đảm an toàn hàng hải (H3) (IMO, 2013). Trong điều kiện quản lý công hiện đại, giám sát không chỉ là hoạt động hậu kiểm, mà còn phải trở thành một cấu phần của điều hành dự báo, quản trị rủi ro và phản hồi chính sách (Hollnagel, 2014). Do đó, kết quả quản lý ở phương diện này không nên chỉ phản ánh ở số cuộc thanh tra, kiểm tra hay số vụ việc được phát hiện, mà cần cho thấy năng lực theo dõi hiện trạng, cảnh báo sớm rủi ro, phát hiện sai lệch, xử lý vi phạm và điều chỉnh quản lý trên cơ sở bằng chứng (EMSA, 2024).

Nhóm tiêu chí thứ tư là tiêu chí đánh giá kết quả ban hành cơ chế, chính sách dịch vụ BĐATHH (D1) (OECD, 2014). Kết quả quản lý ở phương diện này được phản ánh ở mức độ Nhà nước xác lập được khung pháp lý rõ ràng cho danh mục dịch vụ, tiêu chuẩn chất lượng, điều kiện cung ứng, cơ chế giá, định mức, đặt hàng hoặc đấu thầu, cũng như trách nhiệm giải trình của chủ thể cung ứng (Musgrave & Musgrave, 1989). Một cơ chế quản lý dịch vụ có chất lượng phải bảo đảm phân định được ranh giới giữa dịch vụ công ích và dịch vụ mang tính thị trường, giữa trách nhiệm quản lý nhà nước và trách nhiệm cung ứng dịch vụ, đồng thời tạo cơ sở pháp lý cho việc kiểm soát đầu ra và chất lượng dịch vụ (Bộ Giao thông vận tải, 2021a, 2021b).

Nhóm tiêu chí thứ năm là tiêu chí đánh giá kết quả tổ chức thực hiện trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải (D2) (IMO, 2021). Đây là nhóm tiêu chí phản ánh năng lực của bộ máy quản lý trong việc tổ chức, điều phối, kiểm soát và bảo đảm hoạt động cung ứng dịch vụ được triển khai đúng chuẩn, đúng quy trình, đúng đối tượng và đúng yêu cầu an toàn hàng hải (IMO, 1978). Kết quả quản lý không chỉ thể hiện ở số lượng dịch vụ được cung cấp hay số lượt tàu thuyền được phục vụ, mà còn ở mức độ ổn định của chất lượng dịch vụ, năng lực của nhân lực chuyên môn, hiệu quả phối hợp giữa các chủ thể tham gia cung ứng và khả năng kiểm soát đầu ra của dịch vụ (IALA, 2022).

Nhóm tiêu chí thứ sáu là tiêu chí đánh giá kết quả giám sát, đánh giá chất lượng dịch vụ bảo đảm an toàn hàng hải (D3) (OECD, 2019b). Trong bối cảnh quản lý công theo kết quả, chất lượng dịch vụ không thể được đánh giá chỉ bằng nghiệm thu hành chính, mà cần được theo dõi bằng các chỉ số phản ánh đầu ra, mức độ đáp ứng nhu cầu, tính kịp thời, tính liên tục và khả năng cải tiến chất lượng (OECD, 2014). Từ góc độ quản lý nhà nước, cơ chế giám sát dịch vụ có hiệu quả phải đo lường được chất lượng thực tế, phát hiện được sai lệch, xử lý được nhà cung ứng không đáp ứng yêu cầu, đồng thời tạo động lực cải tiến liên tục (IMO, 2018b).

Sáu nhóm tiêu chí đánh giá kết quả quản lý nhà nước về bảo đảm an toàn hàng hải được xây dựng trên nền tảng những cách tiếp cận lý thuyết khác nhau tương ứng với từng chức năng và từng trục nội dung quản lý trong Bảng 1.4. Cụ thể, tiêu chí H1 được tham chiếu từ lý thuyết thể chế và chuẩn mực giám sát thực thi của North (1990) và IMO III Code (2013); tiêu chí D1 dựa trên cách tiếp cận điều tiết công và đánh giá chính sách của Majone (1994) và OECD Framework for Regulatory Policy Evaluation (2014); tiêu chí H2 kế thừa tư duy quản lý tài sản công, quản trị vòng đời và hiệu quả đầu tư từ ISO 55000 (2024), World Bank (1994), World Bank (2021); tiêu chí D2 tham chiếu quản lý chất lượng và hiệu quả cung ứng dịch vụ theo Praetorius (2014) và IALA G1111 (2025); tiêu chí H3 dựa trên các tiếp cận về giám sát công, hiệu quả khu vực công và quản trị theo kết quả của Hood và Peters (2004), ISO 55000 (2024), Pollitt và Bouckaert (2011); trong khi tiêu chí D3 được xây dựng trên cơ sở lý thuyết giá trị công, quản trị dịch vụ công và quản trị rủi ro của Moore (1995), Osborne (2010), Valdez Banda và Goerlandt (2018). Cụ thể chi tiết bộ 30 tiêu chí đánh giá (KPI) được luận án trình bày tại khung giải pháp.

Bảng 1.4. Tổng hợp các tiêu chí đánh giá kết quả quản lý nhà nước về bảo đảm an toàn hàng hải theo khung phân tích 2×3

[TABLE]

Nguồn: Nghiên cứu sinh tổng hợp và đề xuất, 2026.

Bảng 1.4 không chỉ hệ thống hóa các yêu cầu đánh giá, mà còn cụ thể hóa chúng thành những phương diện có thể quan sát, đối chiếu và lượng hóa trong nghiên cứu. Trên cơ sở đó, luận án sử dụng bộ tiêu chí này làm căn cứ rà soát thực trạng, nhận diện khoảng trống quản lý và lựa chọn các chỉ báo phù hợp cho phân tích định lượng ở các phần tiếp theo.

1.2.3.2. Các yếu tố ảnh hưởng tới kết quả quản lý nhà nước về bảo đảm an toàn hàng hải

Trên cơ sở tổng hợp lý thuyết quản trị công, kinh tế công cộng, quản trị rủi ro, quản trị dữ liệu và đặc thù của lĩnh vực hàng hải, luận án xác định bảy nhóm điều kiện có khả năng chi phối kết quả quản lý nhà nước về bảo đảm an toàn hàng hải gồm nhóm yếu tố bên trong (chủ quan) và nhóm yếu tố bên ngoài (khách quan) (IALA, 2017b; OECD, 2014; Rhodes, 1996; Stiglitz & Rosengard, 2015; World Bank, 1994; World Bank & International Association of Ports and Harbors [IAPH], 2021). Nội dung được tổng quát khoa học như sau:

Thứ nhất, thể chế và pháp luật là nền tảng của kết quả quản lý nhà nước về BĐATHH (Rhodes, 1996; World Bank Group, Asian Development Bank, European Bank for Reconstruction and Development, Inter-American Development Bank, Islamic Development Bank, OECD, UNECE & UNESCAP, 2017). Đây không chỉ là khuôn khổ điều chỉnh hành vi mà còn là công cụ xác lập trật tự quản lý, phân định thẩm quyền, trách nhiệm và cơ chế phối hợp giữa các chủ thể (World Bank, 1994). Một hệ thống pháp luật minh bạch, đồng bộ, ổn định và tương thích với chuẩn mực quốc tế sẽ tạo cơ sở cho việc ban hành chính sách đúng hướng, tổ chức thực hiện thống nhất và giám sát có hiệu lực (IMO, 1974). Ngược lại, nếu thể chế thiếu đồng bộ, chậm cập nhật hoặc còn khoảng trống pháp lý thì dễ phát sinh chồng chéo, phân tán trách nhiệm và làm giảm hiệu quả quản lý (World Bank, 1994; World Bank Group, Asian Development Bank, European Bank for Reconstruction and Development, Inter-American Development Bank, Islamic Development Bank, OECD, UNECE & UNESCAP, 2017). Vì vậy, đây là nhân tố tác động trực tiếp đến chức năng ban hành, đồng thời lan tỏa tới toàn bộ quá trình quản lý nhà nước.

Thứ hai, tổ chức bộ máy và nhân lực quản lý nhà nước giữ vai trò quyết định đối với chất lượng thực thi (Rhodes, 1996; World Bank, 1994). Trong lĩnh vực bảo đảm an toàn hàng hải, một bộ máy hợp lý phải bảo đảm phân công rõ chức năng, đầu mối quản lý minh bạch và phối hợp liên thông giữa các cấp, các ngành, các đơn vị thực thi (IMO, 2021). Tuy nhiên, hiệu quả của bộ máy chỉ được bảo đảm khi gắn với đội ngũ nhân lực có năng lực chuyên môn, kỹ năng quản trị, khả năng phối hợp và thích ứng với yêu cầu công nghệ mới (IMO, 2024b). Nếu tổ chức phân tán, quy trình thiếu thông suốt hoặc nhân lực hạn chế về năng lực thì chính sách khó được chuyển hóa thành kết quả quản lý cụ thể (World Bank Group, Asian Development Bank, European Bank for Reconstruction and Development, Inter-American Development Bank, Islamic Development Bank, OECD, UNECE & UNESCAP, 2017). Do đó, đây là nhân tố ảnh hưởng trực tiếp, đặc biệt đối với chức năng tổ chức thực hiện và giám sát, đánh giá.

Thứ ba, nguồn lực tài chính và cơ sở vật chất kỹ thuật là điều kiện vật chất bảo đảm cho tính liên tục và ổn định của hệ thống BĐATHH (Musgrave & Musgrave, 1989; Stiglitz & Rosengard, 2015). Đây là lĩnh vực đòi hỏi đầu tư lớn, chi phí duy tu cao và phụ thuộc nhiều vào chất lượng tài sản công chuyên ngành (World Bank, 1994). Nếu nguồn lực phân bổ không đủ, thiếu ổn định hoặc sử dụng kém hiệu quả thì hệ thống báo hiệu, luồng tuyến, điều phối giao thông, thông tin hàng hải và hạ tầng hỗ trợ khó duy trì ở trạng thái kỹ thuật đáp ứng yêu cầu (IALA, 2017a). Ngược lại, khi cơ chế tài chính ổn định, phân bổ hợp lý và gắn với quản trị vòng đời tài sản, Nhà nước sẽ có điều kiện duy trì năng lực vận hành hệ thống và nâng cao chất lượng dịch vụ công (World Bank, 1994). Vì vậy, đây là nhân tố tác động trực tiếp chủ yếu tới khâu tổ chức thực hiện và giám sát hệ thống.

Thứ tư, khoa học, công nghệ và dữ liệu ngày càng trở thành động lực quan trọng nâng cao chất lượng quản lý nhà nước về BĐATHH (IMO, 2018b; World Bank & International Association of Ports and Harbors [IAPH], 2021). Sự phát triển của hàng hải điện tử (e-Navigation), AIS, VTS, hải đồ điện tử, công nghệ cảm biến và phân tích dữ liệu thời gian thực đã làm thay đổi phương thức quản lý theo hướng hiện đại, dựa trên dữ liệu (IALA, 2022; IMO, 2024b). Khi công nghệ được đầu tư đồng bộ và dữ liệu được liên thông, cơ quan quản lý có thể nâng cao năng lực dự báo, phát hiện sớm rủi ro, điều hành linh hoạt và giám sát minh bạch hơn. Ngược lại, nếu số hóa phân tán, tiêu chuẩn dữ liệu không thống nhất hoặc năng lực vận hành công nghệ còn yếu thì công nghệ chưa thể chuyển hóa thành kết quả quản lý thực chất. Do đó, yếu tố này tác động trực tiếp đến hiệu quả tổ chức thực hiện và giám sát, đồng thời quyết định mức độ hiện đại hóa quản lý nhà nước (OECD, 2019a).

Thứ năm, hợp tác quốc tế và khu vực là đòn bẩy quan trọng để nâng cao năng lực quản lý nhà nước về BĐATHH trong điều kiện hội nhập (EMSA, n.d.; IMO, 1974). Thông qua các công ước quốc tế, cơ chế hợp tác chuyên ngành và chương trình hỗ trợ kỹ thuật, Nhà nước có điều kiện tiếp cận chuẩn mực quốc tế, công nghệ mới, mô hình quản lý tiên tiến và nguồn lực đào tạo. Yếu tố này không chỉ hỗ trợ hoàn thiện thể chế trong nước mà còn tăng cường năng lực thực thi, chuẩn hóa nghiệp vụ và mở rộng phối hợp xử lý các vấn đề xuyên biên giới (IALA, 2022). Do đó, hợp tác quốc tế chủ yếu tác động gián tiếp nhưng có ý nghĩa chiến lược đối với cả chức năng ban hành và tổ chức thực hiện.

Thứ sáu, hạ tầng và năng lực ứng phó phản ánh mức độ đáp ứng của nền tảng kỹ thuật và khả năng phản ứng trước sự cố trong bảo đảm an toàn hàng hải (IALA, 2017b). Yếu tố này chi phối trực tiếp điều kiện vận hành, mức độ sẵn sàng kỹ thuật của hệ thống và khả năng xử lý kịp thời các rủi ro phát sinh (IALA, 2017b). Về bản chất, đây là yếu tố nền tảng, được sử dụng như chỉ báo thành phần để phân tích năng lực tổ chức thực hiện và giám sát, không tách thành biến độc lập riêng trong mô hình (OECD, 2014).

Thứ bảy, bối cảnh kinh tế – xã hội tác động đến kết quả quản lý nhà nước qua việc làm thay đổi nhu cầu, mức độ ưu tiên chính sách và yêu cầu chất lượng dịch vụ (UNCTAD, 2023; UNCTAD, 2024). Khi lưu lượng vận tải biển gia tăng, yêu cầu kết nối chuỗi cung ứng cao hơn và áp lực cạnh tranh quốc tế lớn hơn, Nhà nước buộc phải nâng cao chất lượng quản lý hệ thống và dịch vụ BĐATHH. Ngược lại, các cú sốc kinh tế, dịch bệnh hay biến động thương mại toàn cầu có thể làm gia tăng áp lực thích ứng đối với hệ thống quản lý. Đây là yếu tố bên ngoài, tác động gián tiếp nhưng rộng khắp tới toàn bộ khung quản lý nhà nước (OECD, 2014; Rhodes, 1996).

Trên cơ sở phân tích bảy yếu tố nêu trên, có thể thấy mỗi yếu tố có cơ chế và mức độ tác động khác nhau đối với kết quả quản lý nhà nước về bảo đảm an toàn hàng hải. Để khái quát hóa các mối quan hệ này một cách hệ thống, luận án tổng hợp và quy chiếu các yếu tố ảnh hưởng vào khung phân tích 2×3 như trình bày tại Bảng 1.5.

Bảng 1.5. Tổng hợp các yếu tố ảnh hưởng đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải và sự quy chiếu vào khung phân tích 2×3

[TABLE]

Nguồn: Nghiên cứu sinh tổng hợp, 2026.

Như vậy, kết quả quản lý nhà nước về bảo đảm an toàn hàng hải chịu sự chi phối đồng thời của các yếu tố bên trong, bên ngoài và bối cảnh. Việc quy chiếu các yếu tố này vào khung phân tích 2×3 vừa làm rõ cơ sở lý luận của luận án, vừa tạo nền tảng cho thiết kế biến quan sát, xây dựng mô hình phân tích định lượng và đánh giá thực trạng ở các phần tiếp theo.

1.3. KINH NGHIỆM QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI CỦA MỘT SỐ QUỐC GIA TRÊN THẾ GIỚI VÀ BÀI HỌC RÚT RA CHO VIỆT NAM

Các kinh nghiệm quốc tế trong quản lý nhà nước về bảo đảm an toàn hàng hải thể hiện sự đa dạng do ảnh hưởng bởi yếu tố địa lý, quy mô đội tàu cũng như năng lực quản trị. Luận án tập trung phân tích các trường hợp tiêu biểu như Singapore (mô hình quản trị tích hợp và chuyển đổi số), Malaysia (lồng ghép quản lý nhà nước với khối doanh nghiệp), Nhật Bản (chuẩn hóa hệ thống và đào tạo), Liên minh châu Âu (chuẩn hóa dịch vụ và phối hợp khu vực) cùng một số quốc gia châu Phi (nhận diện rủi ro về thể chế và nguồn lực). Việc đối chiếu này không nhằm mục đích sao chép mô hình mà tập trung phân tích các yếu tố quyết định thành công hoặc thất bại, bao gồm thiết kế thể chế, cơ chế tài chính, chuẩn mực dịch vụ, dữ liệu và hoạt động giám sát. Mỗi trường hợp nghiên cứu được xem xét qua hai nội dung nghiên cứu của luận án (hệ thống và dịch vụ bảo đảm an toàn hàng hải) và ba cấp độ quản lý nhà nước (xây dựng chính sách, tổ chức thực hiện, kiểm tra giám sát), làm tiền đề cho việc so sánh và đề xuất giải pháp phù hợp cho thực tiễn Việt Nam.

1.3.1. Kinh nghiệm quản lý nhà nước về bảo đảm an toàn hàng hải của một số quốc gia trên thế giới

1.3.1.1. Kinh nghiệm của Singapore

Singapore là điển hình của mô hình quản trị tích hợp giữa quản lý hàng hải và quản lý cảng biển. Điểm nổi bật của mô hình này là sự gắn kết chặt giữa quy hoạch luồng tàu, quản lý cảng, điều phối giao thông và nền tảng dữ liệu dùng chung (MPA, 2023a, 2023b; MPA, n.d.).

Về tổ chức, quản lý hệ thống BĐATHH, ở khâu ban hành, mô hình tích hợp cho phép cơ quan quản lý đồng thời thiết kế định hướng phát triển và đặt yêu cầu quản trị an toàn như một cấu phần của chiến lược hàng hải–cảng biển (MPA, n.d.). Ở khâu thực hiện, Singapore ưu tiên đầu tư “hạ tầng số” như một phần của hạ tầng an toàn: thay vì chỉ tập trung vào mở rộng công trình, MPA đặt trọng tâm vào tối ưu hóa điều phối bằng dữ liệu, nâng năng lực dự báo và giảm thời gian chờ tại cảng (MPA, 2023a, 2023b). Cách tiếp cận này phù hợp với xu hướng quản trị công dựa trên dữ liệu, coi dữ liệu là tài sản công và coi năng lực phân tích là năng lực cốt lõi của cơ quan quản lý. Ở khâu giám sát, logic quản trị bằng dữ liệu làm nổi bật yêu cầu theo dõi hiệu quả hệ thống bằng các chỉ báo vận hành; trong thực tiễn quản trị, nhóm chỉ báo có thể gắn với “tính thông suốt của luồng tàu” và “tính sẵn sàng của hạ tầng điều phối” (ví dụ: thời gian chờ/độ lệch kế hoạch, mức độ dự báo chính xác, mức độ tuân thủ quy trình điều phối), qua đó hỗ trợ phản ứng nhanh trước rủi ro (MPA, 2023a, 2023b; OECD, 2019a).

Về quản lý cung ứng dịch vụ BĐATHH, ở khâu ban hành, Singapore thể hiện rõ xu hướng kết hợp chức năng điều tiết với chức năng hỗ trợ phát triển thông qua các hướng dẫn/chỉ đạo triển khai nền tảng số và chuẩn chia sẻ thông tin (MPA, 2023a). Cụ thể, nền tảng số digitalPORT@SG là minh họa rõ cho chuyển đổi số dịch vụ công hàng hải. Trong Thông tư hàng hải cảng số 10 năm 2023, Cơ quan Cảng biển và Hàng hải Singapore (MPA) giới thiệu nền tảng “Just-in-Time” (JIT - đúng thời điểm) nhằm hỗ trợ trao đổi thông tin hành trình và phối hợp giữa tàu thuyền, cảng, đơn vị dịch vụ, hướng tới giảm thời gian neo chờ và tăng hiệu quả điều phối (MPA, 2023a). Ở khâu thực hiện, JIT giúp giảm áp lực điều động trong thời gian ngắn, hỗ trợ lập kế hoạch tàu vào/ra và làm minh bạch thông tin – những yếu tố gián tiếp giảm rủi ro tai nạn tại vùng nước cảng (MPA, 2023a). Ở khâu giám sát, điểm đáng chú ý là Singapore kết hợp công cụ điều tiết với cơ chế khuyến khích: không chỉ yêu cầu tuân thủ mà còn tạo “lợi ích kinh tế” khi chia sẻ dữ liệu và tối ưu hành trình (MPA, 2023a). Điều này cho phép quản lý nhà nước chuyển từ mô hình “ra lệnh–kiểm soát” sang mô hình “định hướng và tạo điều kiện”, qua đó giảm chi phí tuân thủ và tăng tính hợp tác của khu vực tư nhân trong cung cấp dữ liệu và tham gia quy trình điều phối; đồng thời đặt ra yêu cầu kiểm soát rủi ro mới phát sinh liên quan đến dữ liệu, trách nhiệm giải trình và bảo mật (OECD, 2014; OECD, 2019b).

Bài học rút ra từ Singapore là: tăng mức tích hợp giữa quản lý luồng tàu, quản lý cảng và quản lý dịch vụ an toàn để tạo kiến trúc dữ liệu thống nhất; chuyển đổi số không nên chỉ dừng ở số hóa thủ tục mà cần gắn với tái thiết kế quy trình điều phối dựa trên dữ liệu; và chuẩn hóa thông tin, chia sẻ dữ liệu cần đi kèm cơ chế trách nhiệm giải trình, bảo mật và quản trị rủi ro mới phát sinh.

1.3.1.2. Kinh nghiệm của Malaysia

Malaysia là trường hợp tiêu biểu về quản lý giao thông tại khu vực có mật độ tàu cao và về sự kết hợp giữa điều tiết nhà nước với yếu tố doanh nghiệp hóa trong hệ sinh thái cảng biển (Ministry of Transport Malaysia, 2023; Ministry of Transport Malaysia, n.d.).

Về tổ chức, quản lý hệ thống BĐATHH, ở khâu ban hành, yêu cầu thiết lập và vận hành VTS được đặt trong logic quản trị rủi ro trên tuyến luồng trọng yếu, hàm ý việc xác định phạm vi, mức đầu tư và ưu tiên tuyến phải dựa trên tiêu chí rủi ro và tác động của mật độ tàu, giao cắt luồng, khu neo đậu, cũng như nguy cơ từ hàng nguy hiểm (Port Klang Authority, 2025). Ở khâu thực hiện, Malaysia tổ chức VTS và các công cụ giám sát như một phần của hạ tầng an toàn, qua đó chuyển thông điệp quản trị quan trọng: quy hoạch–đầu tư hệ thống an toàn không thể là “kế hoạch tĩnh”, mà cần dựa trên dữ liệu hành trình và dữ liệu rủi ro để cập nhật theo biến động luồng tàu (Ministry of Transport Malaysia, n.d.). Ở khâu giám sát, cách tiếp cận này đòi hỏi cơ chế theo dõi liên tục tình trạng “phù hợp của cấu hình hệ thống” so với rủi ro phát sinh; các chỉ báo có thể tập trung vào độ bao phủ giám sát, mức độ phát hiện–cảnh báo sớm, và năng lực duy trì hoạt động ổn định trong khu vực có mật độ cao (IALA, 2017b).

Về quản lý cung ứng dịch vụ BĐATHH, ở khâu ban hành, Malaysia cho thấy việc ban hành/ban bố các quy trình tác nghiệp ở cấp cảng có vai trò quan trọng trong bảo đảm an toàn tại thực địa. Chẳng hạn, Cơ quan Quản lý cảng Klang đã công bố Sổ tay Hàng hải năm 2025, trong đó mô tả chi tiết các yêu cầu liên quan tới công tác điều phối tàu thuyền, quy trình liên lạc, quản lý luồng tàu và các yêu cầu vận hành tại khu vực cảng và tuyến luồng liên quan (Port Klang Authority, 2025). Ở khâu thực hiện, tài liệu tác nghiệp này phản ánh đặc điểm thường gặp của quản trị an toàn: quá trình bảo đảm an toàn diễn ra tại “giao điểm” giữa quy định nhà nước và quy trình vận hành cảng–dịch vụ; vì vậy, nếu thiếu chuẩn hóa và thiếu kênh phối hợp, nguy cơ “lệch chuẩn” giữa quy định và vận hành sẽ làm giảm hiệu lực quản lý (OECD, 2014). Ở khâu giám sát, khi có sự tham gia của khu vực tư trong một số khâu vận hành (dù trực tiếp hay gián tiếp), nhu cầu giám sát càng tăng: phải có cơ chế đánh giá, công khai và kiểm toán/giám sát để bảo đảm lợi ích công, hạn chế rủi ro đạo đức và xung đột lợi ích (World Bank, 1994).

Bài học kinh nghiệm từ Malaysia là: VTS cần được đặt trong kiến trúc quản trị tổng thể gồm giám sát, tổ chức luồng và phối hợp ứng phó chứ không chỉ là một dự án công nghệ; cơ chế phối hợp nhà nước–cảng–doanh nghiệp dịch vụ cần được thiết kế thành quy trình chuẩn, kênh dữ liệu và trách nhiệm rõ ràng; và khi có yếu tố doanh nghiệp/PPP từng phần, càng cần tăng cường giám sát để bảo đảm lợi ích công và chất lượng dịch vụ.

1.3.1.3. Kinh nghiệm của Nhật Bản

Nhật Bản là quốc gia tiêu biểu cho mô hình chuẩn hóa hệ thống và chuẩn hóa năng lực con người trong bảo đảm an toàn hàng hải (Japan Coast Guard, 2025). Điểm nổi bật của Nhật Bản là sự kết hợp giữa hạ tầng giám sát từ bờ, hệ thống hướng dẫn điều hướng theo khu vực, chuẩn hóa nghiệp vụ và đào tạo liên tục.

Về tổ chức, quản lý hệ thống BĐATHH, ở khâu ban hành, Nhật Bản nhìn nhận dịch vụ thông tin và điều phối giao thông như một cấu phần của hạ tầng an toàn, vận hành theo nguyên tắc tiêu chuẩn hóa quốc tế và gắn mục tiêu an toàn–hiệu quả–môi trường tương tự cách tiếp cận của IMO đối với VTS (IMO, 2021). Ở khâu thực hiện, điều này được cụ thể hóa thành yêu cầu đầu tư không chỉ vào thiết bị mà còn vào chuẩn hóa quy trình, bố trí nguồn nhân lực có năng lực, và cơ chế vận hành liên tục ở các khu vực phức tạp (Japan Coast Guard, 2025). Ở khâu giám sát, sự nhấn mạnh vào tiêu chuẩn hóa hàm ý hệ thống phải được kiểm tra chất lượng theo quy trình và năng lực con người; nhóm chỉ báo phù hợp thường không chỉ là “có/không có thiết bị”, mà là mức độ đáp ứng chuẩn quy trình, mức độ sẵn sàng nhân lực, và hiệu quả cảnh báo/hỗ trợ trong tình huống phức tạp (IMO, 2024b).

Về quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải, ở khâu ban hành, Nhật Bản coi “hướng dẫn nghiệp vụ” là một công cụ quản trị quan trọng, bổ trợ cho quy phạm cứng (Japan Coast Guard, 2025). Tài liệu “Hướng dẫn An toàn Điều hướng” do Cục Giao thông Hàng hải (Phòng An toàn điều hướng) thuộc Lực lượng Bảo vệ Bờ biển Nhật Bản (Japan Coast Guard) công bố, tập hợp các hướng dẫn về điều hướng, thông tin luồng và lưu ý an toàn cho các khu vực trọng điểm. Ở khâu thực hiện, cách tiếp cận này cho thấy quản lý an toàn không chỉ là ban hành quy định mà còn bao gồm cung cấp hướng dẫn dựa trên dữ liệu và kinh nghiệm vận hành, giúp giảm sai sót của người điều khiển tàu trong tình huống phức tạp (Japan Coast Guard, 2025). Ở khâu giám sát, trọng tâm là bảo đảm “chất lượng dịch vụ”

thông qua cơ chế đào tạo, cập nhật tài liệu và chuẩn hóa nghiệp vụ; đặc biệt, các cấu phần như tần suất cập nhật hướng dẫn theo khu vực, chất lượng đào tạo, hoặc mức độ tuân thủ quy trình cung cấp thông tin có thể được lượng hóa thành KPI/SLA nhằm hỗ trợ giám sát (UNDP, 2009).

Bài học kinh nghiệm từ Nhật Bản là: chất lượng quản lý nhà nước không chỉ phụ thuộc vào văn bản quy phạm, mà còn phụ thuộc vào chất lượng chuẩn hóa nghiệp vụ, đào tạo liên tục và cơ chế cập nhật hướng dẫn an toàn theo khu vực, tuyến luồng và tình huống.

1.3.1.4. Kinh nghiệm của Liên minh châu Âu (EU)

Nhóm kinh nghiệm của Liên minh châu Âu (EU) cho thấy một mẫu hình chung: quản trị an toàn hàng hải dựa trên chuẩn dịch vụ, dựa trên dữ liệu, đồng thời sử dụng các công cụ chính sách dựa trên bằng chứng như RIA để nâng chất lượng quy định (OECD, 2014; OECD, 2019a). Đây là xu hướng phù hợp trong bối cảnh luồng tàu quốc tế dày đặc, môi trường điều tiết đa tầng và yêu cầu minh bạch cao (OECD, 2019a).

Về tổ chức, quản lý hệ thống BĐATHH, ở khâu ban hành, mẫu hình này nhấn mạnh vai trò của khung quy định/định hướng dựa trên bằng chứng, trong đó RIA được xem như công cụ giúp nâng chất lượng quy định và giảm rủi ro chính sách (OECD, 2014; OECD, 2019a). Ở khâu thực hiện, hệ thống an toàn được tổ chức gắn với năng lực điều phối theo thời gian thực và năng lực chia sẻ dữ liệu giữa các chủ thể: tại Hà Lan, quản trị an toàn gắn chặt với quản lý giao thông tại các cảng cửa ngõ và tuyến luồng nối cảng với biển; Cảng Rotterdam công bố quy trình và dịch vụ VTS, cho thấy giao thông tàu được giám sát liên tục từ các trung tâm điều phối và VTS cung cấp thông tin thời gian thực về tình hình giao thông (Port of Rotterdam, 2021). Ở khâu giám sát, việc coi “an toàn gắn với năng lực điều phối” hàm ý phải có cơ chế theo dõi tình trạng vận hành của hệ thống điều phối và mức độ phối hợp liên cơ quan, trong đó trách nhiệm của cơ quan quản lý cảng/harbour master và sự phối hợp với các cơ quan nhà nước là điều kiện để vận hành hiệu quả.

Về quản lý cung ứng dịch vụ BĐATHH, ở khâu ban hành, Na Uy cung cấp một cách tiếp cận có giá trị đặc biệt: Cơ quan quản lý bờ biển Na Uy vận hành hệ thống VTS như một dịch vụ được tiêu chuẩn hóa quốc tế để bảo đảm hành hải an toàn, hiệu quả và bảo vệ môi trường biển (Kystverket, n.d.). Cơ quan này mô tả ba nhóm dịch vụ VTS gồm Dịch vụ Thông tin, Dịch vụ Hỗ trợ Điều hướng và Dịch vụ Tổ chức Luồng, qua đó tạo nền tảng để lượng hóa mức dịch vụ, thiết kế quy trình vận hành và xây dựng KPI/SLA tương ứng (Kystverket, n.d.). Ở giai đoạn thực hiện, cách phân loại dịch vụ này giúp cơ quan quản lý nhà nước chuyển từ câu hỏi “có VTS hay không” sang “VTS đang cung cấp mức dịch vụ nào và hiệu quả ra sao”, từ đó tổ chức vận hành phù hợp với loại hình dịch vụ đã công bố hoặc đặt hàng (Kystverket, n.d.; Kystverket, n.d.). Ở khâu giám sát, KPI/SLA trở thành công cụ giám sát trực tiếp chất lượng dịch vụ, giảm khoảng cách giữa mục tiêu chính sách và chất lượng thực thi (OECD, 2019b).

Một khía cạnh bổ trợ quan trọng của nhóm kinh nghiệm này là phối hợp liên vùng, xuyên biên giới ở chuỗi luồng tàu (Joint Nautical Authority [VTS-Scheldt], n.d.). Tại khu vực Hà Lan– Flanders, Cơ quan Điều phối Hàng hải Liên vùng được giới thiệu như cơ chế phối hợp giữa Flanders và Hà Lan nhằm bảo đảm giao thông tàu thuyền thông suốt và an toàn trên sông Scheldt và các tuyến tiếp cận; cơ chế này vận hành hàng ngày và thể hiện rõ nhu cầu quản trị theo “hệ thống luồng” thay vì theo địa giới hành chính. Bài học nhấn mạnh rằng khi rủi ro di chuyển theo chuỗi luồng, cơ chế phối hợp và chia sẻ dữ liệu cũng cần được thiết kế theo chuỗi.

Ở cấp EU, thống giám sát và trao đổi thông tin tàu thuyền (SafeSeaNet) được EMSA mô tả là hệ thống giám sát và thông tin tàu thuyền, được thiết lập như mạng trao đổi dữ liệu hàng hải nhằm tăng cường an toàn, an ninh cảng và hàng hải, bảo vệ môi trường và hiệu quả vận tải; đồng thời tạo nền tảng để các cơ quan có thẩm quyền chia sẻ thông tin về tàu, hành trình và hàng nguy hiểm (EMSA, n.d.). Song song, EMSA vận hành cơ sở dữ liệu tai nạn (EMCIP) và công bố các phân tích tổng quan về tai nạn nhằm cung cấp bằng chứng cho cải thiện chính sách (EMSA, 2024). Từ góc độ quản trị, đây là sự kết hợp giữa hạ tầng dữ liệu và năng lực phân tích, qua đó hỗ trợ cả ban hành chính sách dựa trên bằng chứng lẫn điều phối ứng phó rủi ro (OECD, 2014).

Bài học kinh nghiệm từ EU là: chuẩn hóa dịch vụ và gắn chuẩn hóa với đo lường để tạo cơ sở cho quản lý theo hiệu quả; đồng thời phát triển nền tảng dữ liệu hàng hải quốc gia và cơ chế chia sẻ dữ liệu liên cơ quan, tăng năng lực phân tích rủi ro và RIA để nâng chất lượng quy định.

1.3.1.5. Kinh nghiệm của một số quốc gia châu Phi

Một số trường hợp châu Phi như Cabo Verde, Guinea-Bissau, São Tomé và Príncipe, Angola và Mozambique để nhận diện rủi ro quản trị khi thể chế, nguồn lực và dữ liệu thủy đạc nền chưa tương xứng với yêu cầu quản lý an toàn hàng hải (African Union, 2012; IHO, 2018; IHO, 2022; Vicente, 2022).

Về tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải, Ở khâu ban hành, định hướng chiến lược ở cấp châu lục đã xác lập mục tiêu phát triển không gian biển an toàn, an ninh và bền vững, nhưng ở cấp quốc gia, việc chuyển hóa định hướng đó thành quy hoạch, tiêu chuẩn kỹ thuật và cơ chế bảo đảm nguồn lực còn không đồng đều (African Union, 2012). Ở khâu thực hiện, các trường hợp nêu trên phản ánh khá rõ tình trạng thiếu khảo sát thủy đạc đầy đủ, thiếu cập nhật hải đồ thường xuyên và phụ thuộc đáng kể vào hỗ trợ kỹ thuật từ bên ngoài; trong khi đó, các chuẩn mực của Tổ chức Thủy đạc quốc tế đều nhấn mạnh rằng dịch vụ thủy đạc quốc gia, cơ sở dữ liệu thủy đạc chuẩn hóa và khả năng cập nhật thông tin hàng hải là nền tảng trực tiếp của an toàn hàng hải (IHO, 2022), (Vicente, 2022). Ở khâu giám sát, bài học rút ra là nếu không có cơ chế theo dõi vòng đời tài sản, kiểm soát chất lượng dữ liệu và duy trì cập nhật sản phẩm thủy đạc, thì hiệu quả đầu tư cho hệ thống bảo đảm an toàn hàng hải dễ suy giảm, đồng thời làm gia tăng rủi ro do thông tin nền thiếu hoặc chậm được điều chỉnh (IHO, 2018), (IHO, 2022).

Về quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải, kinh nghiệm một số quốc gia châu Phi cho thấy chất lượng dịch vụ không chỉ phụ thuộc vào việc đã có quy tắc hay chuẩn mực hay chưa, mà phụ thuộc quyết định vào năng lực tổ chức thực hiện, mức độ sẵn có của dữ liệu phục vụ vận hành và hiệu lực của cơ chế giám sát tuân thủ. Ở khâu ban hành, các cơ chế hợp tác và giám sát khu vực đã được hình thành nhằm tạo khung phối hợp chung cho các quốc gia ven biển châu Phi, song mức độ nội luật hóa và năng lực áp dụng thực tế giữa các nước vẫn có sự chênh lệch (Abuja Memorandum of Understanding on Port State Control, 2024; Abuja Memorandum of Understanding on Port State Control, 2025; African Union, 2012). Ở khâu thực hiện, khi nền tảng dữ liệu, nhân lực kỹ thuật và khả năng duy trì hệ thống còn hạn chế, các dịch vụ bảo đảm an toàn hàng hải khó đạt được tính ổn định, liên tục và đồng bộ trên toàn vùng biển quản lý (IHO, 2018; IHO, 2022; Vicente, 2022). Ở khâu giám sát, cơ chế kiểm tra tàu nước ngoài của Abuja Memorandum of Understanding là một kinh nghiệm đáng chú ý tại khu vực Tây và Trung Phi, vì cho thấy nỗ lực thiết lập giám sát tuân thủ trên cơ sở phối hợp khu vực, chia sẻ dữ liệu kiểm tra và duy trì áp lực đối với tàu dưới chuẩn; tuy nhiên, các báo cáo của cơ chế này đồng thời cũng phản ánh rằng sự khác biệt về năng lực thực thi, đào tạo và cơ sở dữ liệu giữa các quốc gia thành viên vẫn là một trở ngại đáng kể (Abuja Memorandum of Understanding on Port State Control, 2024; Abuja Memorandum of Understanding on Port State Control, 2025).

Bài học kinh nghiệm rút ra là: hiện đại hóa quản lý nhà nước về bảo đảm an toàn hàng hải không thể bền vững nếu thiếu nền tảng dữ liệu và hạ tầng tối thiểu; thiếu cơ chế giám sát tuân thủ và thiếu bảo đảm nguồn lực sẽ làm cho đầu tư mới nhanh chóng suy giảm hiệu quả.

1.3.2. Bài học kinh nghiệm cho Việt Nam

1.3.2.1. Bài học kinh nghiệm về tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải

Một là, cần chuyển đổi tư duy quản lý từ đầu tư theo danh mục sang ưu tiên dựa trên rủi ro và vòng đời tài sản. Thực tiễn quốc tế cho thấy, việc quy hoạch và đầu tư hệ thống bảo đảm an toàn hàng hải phải gắn chặt với phân tích rủi ro trên các tuyến luồng trọng điểm, thay vì phân bổ nguồn lực dàn trải. Điều này giúp tập trung đầu tư vào những khu vực có nguy cơ cao, tối ưu hóa hiệu quả sử dụng nguồn lực và nâng cao mức độ an toàn tổng thể của hệ thống. Đối với Việt Nam, bài học này nhấn mạnh sự cần thiết của việc xây dựng cơ chế lựa chọn ưu tiên đầu tư dựa trên phân tích rủi ro và tác động kinh tế – xã hội, thay vì chỉ dựa vào kế hoạch hành chính hoặc áp lực chia đều nguồn lực (IALA, 2017b; IMO, 2018a; OECD, 2014).

Hai là, đầu tư phát triển hạ tầng bảo đảm an toàn hàng hải phải gắn với kiến trúc dữ liệu và khả năng điều phối hiện đại. Kinh nghiệm từ Singapore và EU cho thấy, chỉ khi dữ liệu được chuẩn hóa, liên thông và tích hợp vào hệ thống điều phối, hệ thống BĐATHH mới có thể vận hành thông minh, phản ứng nhanh với các tình huống rủi ro và hỗ trợ ra quyết định hiệu quả. Điều này đòi hỏi Việt Nam cần đẩy mạnh số hóa, chuẩn hóa dữ liệu và xây dựng nền tảng quản trị dữ liệu tập trung cho toàn hệ thống (EMSA, n.d.; MPA, 2023a, 2023b; OECD, 2014).

Ba là, quản trị hệ thống hiệu quả phải dựa trên cơ chế giám sát liên tục, theo dõi tình trạng vận hành, mức độ sẵn sàng và mức độ phù hợp với mức rủi ro. Việc cân bằng giữa đầu tư mới và duy trì nền tảng hiện có là yếu tố then chốt để bảo đảm hệ thống luôn ở trạng thái tối ưu. Bài học này nhấn mạnh vai trò của các chỉ số giám sát (KPI), bảng điều khiển giám sát theo dõi trạng thái hệ thống và cơ chế phản hồi dữ liệu thực tế để kịp thời điều chỉnh chính sách, quy hoạch và ưu tiên đầu tư (IALA, 2017a, 2017b; Kusek & Rist, 2004; OECD, 2019b).

1.3.2.2. Bài học kinh nghiệm về quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

Một là, cần chuẩn hóa mức dịch vụ và mô tả dịch vụ theo cách đo lường được. Kinh nghiệm quốc tế cho thấy, việc xây dựng bộ tiêu chuẩn dịch vụ rõ ràng, có thể lượng hóa (ví dụ: dịch vụ VTS của EU được phân loại theo các nhóm chức năng thông tin – hỗ trợ – tổ chức) là nền tảng để quản lý, giám sát và nâng cao chất lượng dịch vụ. Việt Nam nên phát triển bộ chuẩn dịch vụ cho từng loại hình thiết yếu (báo hiệu, hoa tiêu, thông tin/VTS), kèm theo các chỉ số đo lường cụ thể (KPI/SLA) (Kystverket, n.d.; Kystverket, n.d.).

Hai là, hiệu quả cung cấp dịch vụ phụ thuộc mạnh vào quy trình tác nghiệp, đào tạo, cơ chế phối hợp thực địa và kênh dữ liệu. Các quốc gia như Nhật Bản, EU đã chứng minh rằng, chỉ khi quy trình nghiệp vụ được chuẩn hóa, nhân lực được đào tạo bài bản và các bên liên quan phối hợp chặt chẽ, dịch vụ BĐATHH mới đạt hiệu quả cao, đáp ứng yêu cầu an toàn và thông suốt. Việt Nam cần chú trọng xây dựng quy trình phối hợp rõ ràng giữa nhà nước – cảng – doanh nghiệp dịch vụ, đồng thời tăng cường đào tạo, cập nhật kiến thức cho đội ngũ nhân sự (Japan Coast Guard, 2025; Joint Nautical Authority (VTS-Scheldt), n.d.; Port of Rotterdam, 2021).

Ba là, chuẩn hóa dịch vụ chỉ có ý nghĩa thực tiễn khi gắn với cơ chế giám sát dựa trên dữ liệu, sử dụng KPI/SLA để theo dõi thời gian, độ tin cậy, độ bao phủ và phản hồi người dùng. Đây là cơ sở để đặt hàng dịch vụ công, nghiệm thu và giám sát chất lượng theo kết quả thực tế, thay vì chỉ dựa vào kiểm tra thủ tục. Việt Nam cần thiết kế hệ thống giám sát chất lượng dịch vụ dựa trên dữ liệu thực, công khai kết quả đánh giá và thiết lập cơ chế phản hồi từ người sử dụng dịch vụ (Kusek & Rist, 2004; OECD, 2014; OECD, 2019b).

Bảng 1.6. Tổng hợp kinh nghiệm quốc tế trong quản lý nhà nước về bảo đảm an toàn hàng hải theo khung phân tích 2×3

[TABLE]

Nguồn: Nghiên cứu sinh tổng hợp từ kinh nghiệm Singapore, Malaysia, Nhật Bản, EU, Châu Phi, 2025.

Tuy nhiên, việc vận dụng kinh nghiệm quốc tế trong quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam cần được điều chỉnh phù hợp với đặc thù trong nước. Trước hết, cấu trúc tuyến luồng phức tạp, điều kiện tự nhiên biến động mạnh và tác động ngày càng rõ của biến đổi khí hậu khiến yêu cầu khảo sát, duy tu, nạo vét và cập nhật thông tin hàng hải tại Việt Nam cao hơn đáng kể so với nhiều mô hình tham chiếu quốc tế. Bên cạnh đó, hạn chế về nguồn lực tài chính, nhân lực và hạ tầng số cho thấy việc số hóa cần được triển khai theo lộ trình, có trọng tâm, dựa trên phân tích rủi ro thay vì thực hiện đồng loạt. Đồng thời, sự khác biệt về thể chế và phân cấp quản lý khiến các mô hình tích hợp cao khó áp dụng nguyên vẹn, đòi hỏi cải cách phải bắt đầu từ chuẩn hóa chức năng, làm rõ thẩm quyền và tăng cường trách nhiệm giải trình. Cuối cùng, trong bối cảnh mức độ hội nhập và liên thông dữ liệu còn hạn chế, bài học cốt lõi không phải là sao chép nền tảng công nghệ, mà là xây dựng lộ trình quản trị dữ liệu từng bước, từ chuẩn hóa dữ liệu cốt lõi đến mở rộng chia sẻ khi năng lực quản trị cho phép.

Chương 2THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM

2.1. KHÁI QUÁT NGÀNH HÀNG HẢI VÀ BỘ MÁY QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM

2.1.1. Khái quát ngành hàng hải Việt Nam

Ngành hàng hải là bộ phận quan trọng của kinh tế biển Việt Nam, giữ vai trò kết nối thương mại và logistics toàn cầu. Trên thế giới, vận tải biển đảm nhận hơn 80% khối lượng hàng hóa thương mại, nên năng lực khai thác cảng và dịch vụ phụ trợ tác động trực tiếp đến chi phí logistics, độ tin cậy lịch trình và sức cạnh tranh hàng xuất khẩu (UNCTAD, 2025b). Việt Nam sở hữu 3.260 km bờ biển, nằm trên tuyến giao thương huyết mạch Đông Á và tiếp cận thuận lợi các trung tâm công nghiệp lớn như Trung Quốc, Nhật Bản, Hàn Quốc và ASEAN – tạo lợi thế chiến lược trong phát triển cảng biển và logistics (Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam, 2018).

Giai đoạn 2015–2025 ghi nhận sự chuyển dịch về chất trong cấu trúc hạ tầng ngành hàng hải, được thúc đẩy bởi xu hướng container hóa và quá trình tái cấu trúc tuyến vận tải quốc tế. Hệ thống cảng biển đã phát triển theo mô hình phân tầng chức năng rõ rệt. Tại khu vực phía Nam, cụm cảng Cái Mép – Thị Vải đã khẳng định năng lực vận hành tiệm cận chuẩn trung chuyển quốc tế khi tiếp nhận thành công các tàu mẹ có trọng tải lớn. Tại khu vực phía Bắc, cảng Lạch Huyện đã thiết lập các tuyến dịch vụ đi thẳng xuyên Thái Bình Dương, nâng cao vị thế của Việt Nam trong chuỗi giá trị hàng hải toàn cầu (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025a).

Hiệu quả của chiến lược đầu tư hạ tầng được phản ánh qua các chỉ tiêu tăng trưởng sản lượng cao. Năm 2024, tổng sản lượng hàng hóa thông qua hệ thống cảng biển đạt 864,4 triệu tấn, trong đó hàng container đạt 29,9 triệu TEU. Sang năm 2025, tổng lượng hàng hóa thông qua cảng biển và cảng thủy nội địa đạt khoảng 1,17 tỷ tấn, trong đó hàng container đạt 34,36 triệu TEU. Cùng thời điểm, đội tàu biển Việt Nam có 1.434 tàu với tổng trọng tải khoảng 9,4 triệu DWT. Những số liệu này cho thấy cường độ khai thác tăng nhanh, qua đó tạo áp lực lớn hơn lên hệ thống luồng hàng hải, báo hiệu, VTS, thông tin duyên hải, hoa tiêu và cơ chế giám sát chuyên ngành (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025a).

[IMAGE]

Hình 2.1. Sản lượng hàng hóa thông qua hệ thống cảng biển Việt Nam giai đoạn 2015–2025.

Nguồn: Cục Hàng hải và Đường thủy Việt Nam (tổng kết 2025); Market Times (2026); VnEconomy (2024–2025).

Tương thích với phát triển hạ tầng cảng, đội tàu biển quốc gia cũng tăng về quy mô và năng lực vận tải. Tính đến hết năm 2025, đội tàu mang cờ quốc tịch Việt Nam có 1.434 tàu với tổng trọng tải khoảng 9,4 triệu DWT, xếp thứ 4 trong khu vực Đông Nam Á (Cục Hàng hải và Đường thủy Việt Nam, 2025a). Vị thế kết nối quốc tế được lượng hóa qua Chỉ số kết nối hàng hải (LSCI): Quý IV/2025, LSCI của Việt Nam đạt 63,2 điểm, duy trì vị trí thứ 7 toàn cầu và tăng trưởng 6% so với Quý I/2024 (UNCTADstat, n.d.). Tuy nhiên, khoảng cách so với Singapore (114,5 điểm) và Malaysia (99,2 điểm) cho thấy chênh lệch không chỉ về “điểm số”, mà về mô hình quản trị hạ tầng– dịch vụ: quốc gia dẫn đầu dựa nhiều vào số hóa đồng bộ, điều tiết động và quản trị theo dữ liệu; trong khi Việt Nam tiếp tục phải xử lý đồng thời hai nhiệm vụ: mở rộng dung lượng hệ thống và nâng cấp năng lực điều tiết an toàn theo chuẩn mực mới.

[IMAGE]

Hình 2.2. Chỉ số kết nối vận tải biển (LSCI) của Việt Nam và một số quốc gia ASEAN (2024–2025)

Nguồn: UNCTAD Review of Maritime Transport 2025.

Thực tiễn bối cảnh nêu trên không chỉ mang ý nghĩa đơn thuần về sự gia tăng sản lượng hay mở rộng quy mô không gian hạ tầng cảng biển (UNCTAD, 2025b). Quan trọng hơn, quy mô vận tải gia tăng đã tạo ra áp lực lớn lên hệ thống luồng tuyến, mạng lưới báo hiệu hàng hải, hệ thống quản lý giao thông tàu thuyền (VTS), thông tin duyên hải, dịch vụ hoa tiêu và các cơ chế giám sát chuyên ngành (Cục Hàng hải và Đường thủy Việt Nam, 2025c). Có thể thấy, sự phát triển nhanh chóng của ngành hàng hải chính là điều kiện thực tiễn khách quan yêu cầu cấp thiết: phương thức quản lý phải được đổi mới đồng bộ nhằm nâng cao kết quả quản lý nhà nước về bảo đảm an toàn hàng hải tại Việt Nam trong giai đoạn phát triển mới (Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam, 2018).

2.1.2. Bộ máy quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

2.1.2.1. Cơ cấu quản lý nhà nước về bảo đảm an toàn hàng hải

Bộ máy quản lý nhà nước về bảo đảm an toàn hàng hải được tổ chức theo trục ngành dọc ở trung ương và địa bàn, kết hợp với các đơn vị cung ứng dịch vụ công ích. Điểm cần nhấn mạnh trong cấu trúc tổ chức không nằm ở việc có bao nhiêu đầu mối, mà ở khả năng phân định rành mạch: (i) quản lý nhà nước; (ii) tổ chức thực thi; (iii) cung ứng dịch vụ công và tương tác thị trường, từ đó hình thành chu trình ban hành, tổ chức thực hiện, giám sát đánh giá theo khung 2×3 của luận án. Cơ cấu quản lý được trình bày tại Bảng 2.1.

Bảng 2.1. So sánh cơ cấu quản lý nhà nước về bảo đảm an toàn hàng hải trước và sau hợp nhất

[TABLE]

Nguồn: Nghiên cứu sinh tổng hợp từ hệ thống văn bản pháp luật hàng hải, 2026.

Bảng 2.1 cho thấy việc đổi chủ thể quản lý cấp bộ từ tháng 3/2025 không chỉ là thay tên gọi mà còn yêu cầu chuẩn hóa phối hợp, phân cấp và trách nhiệm giải trình giữa Bộ Xây dựng với các cơ quan tham mưu, thực thi và các đơn vị cung ứng dịch vụ liên quan. Giai đoạn 2015–2025 gồm mô hình cũ trước tháng 3/2025 và giai đoạn chuyển tiếp sau đó, đòi hỏi xác định rõ trách nhiệm khi kế thừa chính sách, dữ liệu, tài sản và hợp đồng dịch vụ công.

2.1.2.2. Vị trí, vai trò của Bộ Xây dựng trong quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

Sau khi hợp nhất Bộ Giao thông vận tải và Bộ Xây dựng (trước hợp nhất) theo mốc tháng 3/2025, Bộ Xây dựng (sau hợp nhất) trở thành chủ thể quản lý nhà nước cấp Bộ đối với lĩnh vực hàng hải, trong đó có bảo đảm an toàn hàng hải. Xét theo logic quản lý nhà nước, vai trò của Bộ không chỉ dừng ở việc ban hành văn bản quy phạm pháp luật, mà còn bao gồm định hướng quy hoạch, phân bổ nguồn lực, tổ chức thực thi và giám sát kết quả quản lý trên phạm vi cả nước. Nói cách khác, Bộ giữ vai trò đầu mối điều tiết, bảo đảm tính thống nhất của chính sách và sự liên thông của bộ máy thực thi (Chính phủ nước CHXHCN Việt Nam, 2025b). Vai trò này càng trở nên quan trọng trong bối cảnh hệ thống hàng hải mở rộng về quy mô, công nghệ thay đổi nhanh, yêu cầu số hóa tăng mạnh và mô hình cung ứng dịch vụ dần chuyển từ cơ chế hành chính sang cơ chế quản trị theo kết quả.

[IMAGE]

Hình 2.3. Sơ đồ tổ chức bộ máy quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam sau hợp nhất.

Nguồn: Nghiên cứu sinh tổng hợp từ các văn bản pháp luật (Bộ Xây dựng, 2025a, 2025f, 2025g, 2025h, 2025i; Chính phủ nước CHXHCN Việt Nam, 2025b, 2025c, 2025d), 2026.

Từ cấu trúc bộ máy và mạng lưới thực thi có thể rút ra một đặc điểm quản trị nổi bật của lĩnh vực bảo đảm an toàn hàng hải giai đoạn 2015–2025: cơ chế quản lý nhà nước mang tính “vừa tập trung theo ngành, vừa phân tán theo điểm thực thi” và phụ thuộc mạnh vào chất lượng phối hợp liên ngành – liên cấp. Điều này tạo điều kiện cho chuyên môn hóa và duy trì tính liên tục của dịch vụ, nhưng cũng làm tăng nguy cơ chồng chéo hoặc “khoảng trống trách nhiệm” nếu thiếu tiêu chuẩn hóa quy trình và thiếu cơ chế giám sát dựa trên dữ liệu.

2.1.2.3. Chức năng, quyền hạn của Bộ Xây dựng trong quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

Theo khung phân tích 2×3 của luận án, chức năng và quyền hạn của Bộ Xây dựng được nhìn nhận theo hai nhóm nội dung và ba chức năng quản lý nhà nước. Đối với tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải, Bộ thực hiện chức năng ban hành hoặc trình ban hành thể chế, quy hoạch, tiêu chuẩn, định mức; tổ chức đầu tư, quản lý, khai thác và bảo trì kết cấu hạ tầng; đồng thời kiểm tra, thanh tra, giám sát, xử lý vi phạm và điều tra sự cố trong phạm vi quản lý. Đối với quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải, Bộ thực hiện chức năng ban hành danh mục dịch vụ, điều kiện cung ứng, khung giá và tiêu chuẩn chất lượng; tổ chức cấp phép, đặt hàng hoặc kiểm soát cung ứng dịch vụ; đồng thời giám sát chất lượng, xử lý vi phạm và giải quyết khiếu nại liên quan đến dịch vụ (Bộ Xây dựng, 2025a, 2025f, 2025g, 2025h, 2025i; Chính phủ nước CHXHCN Việt Nam, 2025b, 2025c, 2025d). Cách tiếp cận này cho phép làm rõ phạm vi quản lý nhà nước của Bộ Xây dựng và tạo cơ sở để đánh giá thực trạng ở mục 2.2 theo đúng logic khung 2x3.

Tóm lại, sự gia tăng nhanh chóng về quy mô và cường độ hoạt động của ngành hàng hải Việt Nam đã tạo ra những áp lực lớn, đòi hỏi hệ thống bảo đảm an toàn hàng hải phải không ngừng nâng cao năng lực đáp ứng (Cục Hàng hải và Đường thủy Việt Nam, 2025b, 2025c). Để giải quyết yêu cầu thực tiễn này, bộ máy quản lý nhà nước từng bước được kiện toàn xuyên suốt từ trung ương đến các cơ quan thực thi tại địa bàn và mạng lưới đơn vị cung ứng dịch vụ công ích. Đặc biệt, sự chuyển giao vai trò chủ thể hoạch định chính sách vĩ mô sang Bộ Xây dựng từ tháng 3/2025 đánh dấu một bước ngoặt quan trọng về tổ chức bộ máy (Chính phủ nước CHXHCN Việt Nam, 2025b, 2025e). Dù vậy, việc nhận diện cấu trúc các cơ quan quản lý và phân định thẩm quyền mới chỉ phác họa được bộ khung nền tảng. Để đo lường chính xác năng lực điều tiết và kết quả quản lý nhà nước trên thực địa trong giai đoạn 2015–2025, công tác phân tích cần đi sâu vào các khâu vận hành cụ thể. Quá trình đánh giá thực trạng này sẽ được triển khai chi tiết tại mục 2.2, bám sát sáu cấu phần của khung phân tích 2×3 nhằm làm rõ hai nội dung cốt lõi: (i) thực trạng tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải; và (ii) thực trạng quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải.

2.2. PHÂN TÍCH THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025

2.2.1. Thực trạng tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải

2.2.1.1. Ban hành cơ chế, pháp luật, quy hoạch hệ thống bảo đảm an toàn hàng hải

Trong quản lý nhà nước về bảo đảm an toàn hàng hải, việc ban hành văn bản pháp luật, quy hoạch và tiêu chuẩn đối với hệ thống giữ vai trò kiến tạo nền tảng thể chế, quyết định định hướng phát triển, phạm vi điều chỉnh và chuẩn mực kỹ thuật của toàn bộ hệ thống bảo đảm an toàn hàng hải. Chất lượng của khâu này không được quyết định chủ yếu bởi số lượng văn bản được ban hành, mà bởi mức độ đầy đủ, thống nhất, cập nhật và khả năng điều chỉnh toàn bộ vòng đời tài sản kết cấu hạ tầng hàng hải, từ quy hoạch, đầu tư, khai thác, bảo trì đến kiểm soát kỹ thuật.

Theo Báo cáo tổng kết thi hành Bộ luật Hàng hải, giai đoạn 2015–2025, cơ quan quản lý chuyên ngành cấp Bộ đã tham mưu Chính phủ ban hành 17 nghị định, trực tiếp ban hành 24 thông tư cùng nhiều quyết định liên quan đến quy hoạch, tiêu chuẩn, định mức kinh tế – kỹ thuật và các nội dung quản lý chuyên ngành (Bộ Xây dựng, 2026a). Xét về phạm vi điều chỉnh, hệ thống văn bản này bao quát các nhóm vấn đề chủ yếu như kinh doanh và thủ tục hành chính, quy hoạch cảng biển, phân luồng giao thông, bảo vệ công trình, đăng ký tàu, tiêu chuẩn kỹ thuật, báo hiệu hàng hải, AIS và bảo trì. Điều này cho thấy chức năng ban hành đã từng bước chuyển từ xử lý từng mảng nghiệp vụ riêng lẻ sang tạo lập khung điều chỉnh tương đối toàn diện đối với hệ thống bảo đảm an toàn hàng hải ở Việt Nam (Bộ Xây dựng, 2025i; Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2017).

(1) Hoàn thiện khung pháp lý quản lý vòng đời tài sản hạ tầng BĐATHH

Một chuyển biến đáng chú ý trong giai đoạn nghiên cứu là xu hướng chuyển từ tư duy quản lý “tài sản tĩnh” sang tư duy quản trị vòng đời tài sản. Các văn bản mới, đặc biệt là các quy định liên quan đến quản lý, sử dụng và khai thác tài sản kết cấu hạ tầng hàng hải, đã từng bước đặt nền pháp lý cho việc kiểm soát đầy đủ hơn các khâu đầu tư, khai thác, bảo trì, sử dụng và huy động nguồn lực ngoài ngân sách. Điểm thay đổi ở đây không chỉ nằm ở việc bổ sung thêm quy định, mà ở chỗ hệ thống pháp luật đã bắt đầu hình thành logic quản lý liên tục đối với tài sản hạ tầng hàng hải, thay vì chỉ điều chỉnh từng khâu riêng lẻ. Tuy nhiên, sự chuyển đổi này mới thể hiện rõ ở tầng khung pháp lý; còn ở tầng thực thi, cơ chế cập nhật định mức, phân bổ nguồn lực, dữ liệu vận hành và đo lường kết quả vẫn còn độ trễ nhất định (Bộ Giao thông vận tải, 2022; Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2024; Chính phủ nước CHXHCN Việt Nam, 2025d).

Bảng 2.2. Hệ thống văn bản quy phạm pháp luật quản lý vòng đời tài sản

[TABLE]

Nguồn: Nghiên cứu sinh tổng hợp từ hệ thống văn bản quy phạm pháp luật, 2025.

Về công tác bảo trì, duy tu công trình hàng hải, sự hoàn thiện của khung pháp lý về quản lý chất lượng và cơ chế tài chính (Chính phủ nước CHXHCN Việt Nam, 2019; Chính phủ nước CHXHCN Việt Nam, 2021a, 2021b) đã tạo ra chuẩn mực thống nhất về quy trình, hồ sơ và đánh giá an toàn, góp phần đặt công tác này vào hệ quy chiếu quản lý chất lượng công trình quốc gia. Qua đó, công tác bảo trì được thể chế hóa như một dịch vụ công có kế hoạch, có hợp đồng và có trách nhiệm giải trình, thay vì hoạt động xử lý sự cố mang tính tình thế. Ở cấp độ chuyên ngành, các quy định hướng dẫn hiện hành (Bộ Giao thông vận tải, 2022; Bộ Xây dựng, 2026d; Chính phủ nước CHXHCN Việt Nam, 2024) tiếp tục chuẩn hóa quy trình lập, phê duyệt và điều chỉnh kế hoạch bảo trì, bổ sung các công cụ định lượng như tiêu chí xác định tần suất khảo sát; đồng thời hoàn thiện cơ chế nạo vét duy tu theo chuẩn tắc, tăng cường giám sát thi công và nghiệm thu dựa trên chất lượng thực hiện.

Hệ thống văn bản nêu trên phản ánh cấu trúc ba tầng của khung pháp lý: từ việc thiết lập nền tảng quản lý, tạo bước đột phá về quản trị tài sản thông qua các cơ chế cho thuê, nhượng quyền khai thác và xã hội hóa, đến nỗ lực hệ thống hóa toàn diện. Thực tiễn này được minh chứng qua kết quả phân tích định lượng, khi các tiêu chí về mức độ đầy đủ và khả năng cập nhật chuẩn mực quốc tế của khung pháp lý đều đạt mức khá (đạt tương ứng 3,68/5 và 3,65/5). Tuy nhiên, tính đồng bộ và thống nhất của hệ thống thể chế vẫn là một hạn chế (đạt 3,58/5) (kết quả khảo sát của nghiên cứu sinh, 2025). Chi tiết các văn bản chính về tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải ở Việt Nam được thống kê trong hệ thống văn bản pháp luật và báo cáo chuyên ngành đã được tổng hợp trong luận án.

Nguyên nhân sâu xa của hạn chế này xuất phát từ sự phân mảnh trong công tác quản lý vòng đời tài sản, khi các giai đoạn đầu tư, khai thác và bảo trì đang chịu sự chi phối đan chéo của nhiều đạo luật chuyên ngành khác nhau (như Luật Xây dựng, Luật Đầu tư công, Luật Quản lý, sử dụng tài sản công). Bên cạnh đó, công tác đánh giá tác động chính sách (RIA) trong quá trình hoạch định chưa được thực hiện thực chất, dẫn đến rủi ro một số văn bản vừa ban hành đã bộc lộ bất cập.

(2) Về công tác quy hoạch hệ thống bảo đảm an toàn hàng hải.

Định hình không gian chiến lược và dự báo rủi ro vĩ mô. Ở cấp độ vĩ mô, Bộ Xây dựng đã tham mưu trực tiếp Thủ tướng Chính phủ ban hành Quyết định phê duyệt quy hoạch tổng thể và chi tiết hệ thống cảng biển. Điển hình là Quyết định số 1579/QĐ-TTg (2021) và các văn bản điều chỉnh bổ sung như Quyết định 442/QĐ-TTg (2024), Quyết định 140/QĐ-TTg (2025). Các văn bản này đã thiết lập một khuôn khổ quy hoạch tổng thể cho hệ thống bảo đảm an toàn hàng hải quốc gia, bao gồm 5 nhóm cảng biển với phân cấp luồng lạch, hệ thống bảo đảm an toàn hàng hải rõ ràng. Trên cơ sở đó Bộ đã trực tiếp ban hành hàng loạt các “quyết định phê duyệt quy hoạch chi tiết phát triển vùng đất, vùng nước cảng biển thời kỳ 2021 – 2030, tầm nhìn đến năm 2050” cho từng tỉnh, thành phố có biển được triển khai năm 2025 (Bộ Xây dựng, 2026a).

Trong bối cảnh biến động quốc tế và sự thay đổi của dòng chảy logistics toàn cầu, tư duy quy hoạch trong lĩnh vực hàng hải đã mở rộng theo hướng tích hợp các yếu tố rủi ro địa chính trị, an ninh phi truyền thống và phát triển cảng xanh vào hệ thống bảo đảm an toàn hàng hải. Theo đó, định hướng ưu tiên thiết lập các tuyến luồng nước sâu nhằm tiếp nhận tàu lớn không chỉ phục vụ mục tiêu nâng cao hiệu quả vận chuyển, mà còn hỗ trợ kiểm soát rủi ro trong bối cảnh khối lượng hàng hóa gia tăng. Quy hoạch mạng lưới an toàn hàng hải được xây dựng trên ba trụ cột chính: đồng bộ hóa với quy hoạch cảng biển; phát triển hệ thống đèn và trạm xa bờ không chỉ phục vụ bảo đảm an toàn mà còn gắn với yêu cầu khẳng định chủ quyền quốc gia; và phân định rõ giữa luồng công cộng với luồng chuyên dùng nhằm tối ưu hóa nguồn lực. Trên cơ sở đó, các quyết định quy hoạch chi tiết vùng đất, vùng nước cảng biển giai đoạn 2021–2030 đã tạo căn cứ cho việc bố trí báo hiệu, khu neo đậu và xác định các điểm trọng yếu cần ưu tiên đầu tư. Đồng thời, Nhà nước tập trung duy tu tại các khu vực có mức độ rủi ro cao, qua đó nâng cao tính chủ động trong bảo đảm an toàn hàng hải quốc gia.

Mặc dù đã ghi nhận một số kết quả tích cực trong định hình không gian phát triển, công cụ quy hoạch hiện hành của Việt Nam vẫn bộc lộ hạn chế khi đối sánh với các mô hình điều hành luồng thông minh ở một số quốc gia phát triển. Kinh nghiệm của Singapore và Nhật Bản cho thấy quy hoạch hiện đại ngày càng gắn chặt với dữ liệu thời gian thực, hệ thống VTIS/VTS và hướng dẫn điều hành số, trong khi quy hoạch của Việt Nam vẫn chủ yếu thiên về cấu trúc không gian và khảo sát định kỳ (Heikkilä et al., 2024; Japan Coast Guard, 2025; Japan Coast Guard – Osaka Wan Vessel Traffic Service Center (OSAKA MARTIS), 2025; MPA, 2025). Sự thiếu gắn kết giữa quy hoạch và dữ liệu vận hành làm giảm khả năng dự báo rủi ro sa bồi, tắc nghẽn cục bộ và ứng phó với các biến động bất thường của môi trường hàng hải (Bộ Xây dựng, 2026a). Bảng tổng hợp các văn bản về quy hoạch hệ thống bảo đảm an toàn hàng hải ở Việt Nam được trình bày chi tiết trong hệ thống văn bản pháp luật và báo cáo chuyên ngành đã được tổng hợp trong luận án.

(3) Công tác ban hành quy chuẩn/tiêu chuẩn kỹ thuật quốc gia về hệ thống bảo đảm an toàn hàng hải; Định mức kinh tế kỹ thuật và nội luật hóa các cam kết quốc tế

Hệ thống văn bản hiện tại đã bao quát các quy chuẩn, tiêu chuẩn kỹ thuật và định mức bảo đảm an toàn hàng hải, tạo điều kiện tốt cho công tác quản lý của nhà nước, tiệm cận dần tới các tiêu chuẩn quốc tế, điều này thể hiện qua kết quả phân tích định lượng: điểm số khả quan về hội nhập quốc tế (3,72/5) và nội luật hóa (3,65/5) (kết quả khảo sát của nghiên cứu sinh, 2025). Hệ thống văn bản định mức kinh tế kỹ thuật và tiêu chuẩn/quy chuẩn được trình bày chi tiết trong hệ thống văn bản pháp luật và báo cáo chuyên ngành đã được tổng hợp trong luận án.

Về thiết lập nền tảng kỹ thuật và chuẩn hóa an toàn hàng hải, hệ thống quy chuẩn và tiêu chuẩn kỹ thuật quốc gia trong lĩnh vực bảo đảm an toàn hàng hải từng bước được hoàn thiện theo hướng tương thích hơn với chuẩn mực quốc tế. Các tiêu chuẩn như TCVN 10703:2015 về đèn biển, TCVN 10704:2015 về hệ thống báo hiệu trên luồng hàng hải và TCVN 14141:2024 về phương pháp xác định tầm hiệu lực của báo hiệu đã chuẩn hóa yêu cầu kỹ thuật đối với thiết kế, vận hành và đánh giá chất lượng hệ thống (Bộ Khoa học và Công nghệ, 2015a, 2015b; Bộ Khoa học và Công nghệ, 2024). Cùng với đó, quy chuẩn QCVN 21:2025/BGTVT tiếp tục cập nhật yêu cầu phân cấp và đóng tàu biển vỏ thép, góp phần bảo đảm tính đồng bộ giữa kết cấu hạ tầng hàng hải, báo hiệu và phương tiện khai thác (Bộ Giao thông vận tải, 2025). Nhìn tổng thể, khung kỹ thuật hiện hành tạo cơ sở quan trọng cho nội luật hóa các chuẩn mực quốc tế về an toàn và môi trường hàng hải (IMO, 1973/1978; IMO, 1974).

Về ban hành định mức kinh tế – kỹ thuật, hiệu quả của công tác duy tu, bảo trì chỉ được bảo đảm khi hệ thống định mức bám sát điều kiện thi công thực tế và biến động của môi trường hàng hải. Thực tiễn Việt Nam cho thấy quá trình cập nhật định mức còn chậm so với biến động giá nhiên liệu, vật tư và tốc độ sa bồi tại nhiều khu vực, nhất là khu vực hạ nguồn đồng bằng sông Cửu

Long. Điều này làm gia tăng độ trễ trong công tác duy tu, nạo vét và tạo áp lực lên hiệu quả sử dụng ngân sách (Bộ Giao thông vận tải, 2023b; Bộ Xây dựng, 2026a). So với yêu cầu quản trị hiện đại dựa trên dữ liệu và rủi ro, cơ chế điều chỉnh định mức hiện nay vẫn còn nặng về thủ tục hành chính và chưa thật sự linh hoạt.

Không chỉ mở rộng về phạm vi thể chế trong nước, hệ thống văn bản pháp lý còn phản ánh mức độ hội nhập pháp lý quốc tế ngày càng sâu. Đến nay, Việt Nam đã là thành viên của 27 công ước quốc tế, 28 hiệp định vận tải biển và 34 thỏa thuận hàng hải với các nước (Bộ Xây dựng, 2026a). Điểm cần nhấn mạnh ở đây không chỉ là số lượng điều ước tham gia, mà là tác động của chúng đến cấu trúc quản lý nhà nước. Khi Việt Nam tham gia và thực thi các công ước như SOLAS 1974, MARPOL 73/78, STCW, BWM 2004, cùng các khuôn khổ hợp tác như IMO, IHO và ReCAAP ISC, hoạt động quản lý nhà nước về bảo đảm an toàn hàng hải không còn vận hành theo logic thuần túy nội địa, mà phải chuyển dần sang logic nội luật hóa tiêu chuẩn quốc tế, cập nhật quy chuẩn kỹ thuật, điều chỉnh cơ chế giám sát và nâng cao năng lực bộ máy. Điều đó cho thấy thể chế hàng hải của Việt Nam ngày càng chịu tác động trực tiếp từ môi trường pháp lý quốc tế và các chuẩn mực toàn cầu đang thay đổi theo xu hướng xanh hóa, số hóa và tăng cường an ninh hàng hải (IMO, 1973/1978; IMO, 1974; IMO, 1978; IMO, n.d.).

Xét tổng thể, nền tảng thể chế đối với hệ thống bảo đảm an toàn hàng hải đã được củng cố rõ hơn trong giai đoạn 2015–2025, tạo cơ sở pháp lý quan trọng cho quản lý đầu tư, khai thác và bảo trì hệ thống. Tuy nhiên, độ vênh giữa các tầng nấc pháp lý, độ trễ trong cập nhật chuẩn kỹ thuật và sự thiếu gắn kết giữa quy hoạch với dữ liệu vận hành vẫn làm suy giảm một phần kết quả quản lý nhà nước, đồng thời cho thấy yêu cầu tiếp tục hoàn thiện đồng bộ hơn khung thể chế quản lý hệ thống trong thời gian tới.

2.2.1.2. Tổ chức thực hiện quản lý và vận hành hệ thống bảo đảm an toàn hàng hải

Nếu khâu ban hành tạo ra khuôn khổ thể chế, thì tổ chức thực hiện phản ánh trực tiếp năng lực chuyển hóa khuôn khổ đó thành kết quả vận hành của hệ thống bảo đảm an toàn hàng hải. Trọng tâm của khâu này nằm ở hiệu quả huy động, phân bổ và sử dụng nguồn lực đầu tư, bảo trì, khai thác; ở khả năng duy trì vùng phủ, độ tin cậy kỹ thuật và tính liên tục của hệ thống; đồng thời ở trình độ số hóa quản lý và chất lượng phối hợp giữa các chủ thể thực hiện. Do đó, giai đoạn 2015–2025 cần được đánh giá qua các phương diện như phát triển hệ thống gắn với hiện thực hóa quy hoạch, quản lý bảo trì và duy tu tài sản, tổ chức số hóa và quản trị dữ liệu, cũng như phát triển năng lực đội ngũ quản lý hệ thống.

Bảng 2.3. Đối chiếu sự chuyển dịch mô hình quản trị hệ thống bảo đảm an toàn hàng hải

[TABLE]

Nguồn: Nghiên cứu sinh tổng hợp và phân tích từ hệ thống pháp luật hàng hải Việt Nam, 2025.

Dữ liệu giai đoạn 2015–2025 cho thấy quá trình này đã từng bước chuyển từ cách tiếp cận quản lý nặng về mệnh lệnh hành chính sang tiếp cận coi trọng hiệu quả đầu tư, tiêu chuẩn kỹ thuật, sự tách bạch giữa vai trò quản lý và kinh doanh, cũng như trách nhiệm giải trình trong quản lý dự án và vận hành hệ thống. Trên cơ sở đó, thực trạng giai đoạn 2015–2025, công tác tổ chức thực hiện quản lý và vận hành hệ thống bảo đảm an toàn hàng hải ở Việt Nam được phân tích qua các khía cạnh sau.

(1) Về quản lý đầu tư, phát triển hệ thống và hiện thực hóa quy hoạch

Về mở rộng vùng phủ và hiện đại hóa công nghệ, tính đến cuối năm 2025: hệ thống đèn biển duy trì 100 đèn, trong đó cuối năm 2025 nghiệm thu đưa vào sử dụng 5 đèn biển mới, gồm 26 đèn cấp I, 31 đèn cấp II và 38 đèn cấp III; hệ thống báo hiệu vận hành với 1.061 phao và 201 tiêu trên 44 tuyến luồng hàng hải công cộng. Hệ thống nhận dạng tự động (AIS) mở rộng với trên 100 trạm thu; hệ thống quản lý giao thông hàng hải (VTS) gồm 14 hệ thống, trong đó 7 đã đầu tư hoàn thành, 3 đang thực hiện đầu tư và 4 đang chuẩn bị đầu tư. Đối với hệ thống luồng hàng hải, Bộ phê duyệt và giao nhiệm vụ duy trì vận hành 44 tuyến luồng hàng hải công cộng với tổng chiều dài 1.110,211 km; năm 2025 hoàn thành 100% khối lượng khảo sát cho 43 tuyến luồng và 15 vùng đón trả hoa tiêu bảo đảm cung cấp kịp thời thông tin chính xác cho người đi biển. Các thiết bị ra đa dẫn đường (Racon), chớp đồng bộ và hải đồ điện tử (ENC) được triển khai đồng bộ, qua đó mở rộng khả năng cung cấp thông tin phục vụ hành hải (Bộ Xây dựng, 2026a).

[IMAGE]

Hình 2.4. Biểu đồ tăng trưởng hệ thống bảo đảm an toàn hàng hải Việt Nam, giai đoạn 2015–2025

Nguồn: Thống kê Bộ Xây dựng, Cục Hàng hải và Đường thủy Việt Nam, 2025c (số liệu chi tiết do nghiên cứu sinh tổng hợp) (Bộ Xây dựng, 2026a).

Biểu đồ trên phản ánh kết quả triển khai thực hiện các quy hoạch, kế hoạch do Bộ phê duyệt. Theo báo cáo của Tổng công ty bảo đảm an toàn hàng hải Việt Nam, 100% thời gian hoạt động của hệ thống đèn biển và luồng hàng hải đạt chất lượng yêu cầu, không để xảy ra sự cố, tai nạn hàng hải nào do lỗi của hệ thống báo hiệu. Việc hiện đại hóa công nghệ với các ứng dụng AIS, VTS và hải đồ điện tử đã góp phần nâng cao năng lực giám sát và hỗ trợ dẫn tàu, tiệm cận khuyến nghị của Hiệp hội các cơ quan quản lý báo hiệu hàng hải quốc tế (IALA).

Thực hiện chiến lược hiện đại hóa hạ tầng và phát triển hệ thống bảo đảm an toàn hàng hải, Bộ chuyên ngành đã tập trung phân bổ ngân sách cho xây dựng mới các công trình bảo đảm an toàn hàng hải và mua sắm trang thiết bị trọng điểm phục vụ cho công tác quản lý, vận hành hệ thống. Số liệu cụ thể theo Bảng 2.4 dưới đây:

Bảng 2.4. Tổng hợp các dự án đầu tư và mua sắm trọng điểm liên quan tới hệ thống bảo đảm an toàn hàng hải

[TABLE]

Nguồn: Tổng hợp từ các Quyết định của Bộ Xây dựng/GTVT và Báo cáo số 8509/BXD-KHTC về kế hoạch đầu tư công trung hạn giai đoạn 2026–2030.

Bảng 2.4 cho thấy Bộ đầu tư hệ thống báo hiệu hàng hải với dự án 13 đèn biển tại các vị trí chiến lược và điều chỉnh các dự án theo yêu cầu thực tế. Đối với hạ tầng luồng tuyến, Bộ ưu tiên hoàn thiện Luồng cho tàu lớn vào sông Hậu (giai đoạn 2) với tổng số vốn gần 8.000 tỷ đồng để nâng cao khả năng tiếp cận cảng khu vực đồng bằng sông Cửu Long. Trong kế hoạch 2021–2025, các vùng miền Bắc và Nam đều được phân bổ vốn xây dựng cùng mua sắm phương tiện và trang thiết bị chuyên dụng, nhấn mạnh nâng cấp hệ thống đèn biển Trường Sa. Bộ cũng đã triển khai dự án đóng 02 tàu tiếp tế cho Trường Sa và đảo xa bờ. Định hướng 2026–2030 sẽ tiếp tục đầu tư hạ tầng hàng hải, đường thủy với các cấu phần ưu tiên như luồng tàu, kênh, Trung tâm tìm kiếm cứu nạn, hệ thống VTS và tàu cứu nạn, chuyển từ đầu tư đơn lẻ sang các gói năng lực tổng hợp.

Về phương thức huy động vốn, cấu trúc đầu tư hạ tầng hàng hải đã có sự chuyển dịch mang tính đột phá theo hướng giảm dần sự phụ thuộc vào ngân sách công. Theo Bộ Xây dựng (2026a), giai đoạn 2011–2020, tổng vốn đầu tư hệ thống hạ tầng hàng hải đạt 202 nghìn tỷ đồng, nhưng nguồn vốn ngoài ngân sách đã chiếm tới 86%. Định hướng đến năm 2030, tỷ lệ xã hội hóa dự kiến sẽ được đẩy lên mức 95% trong tổng nhu cầu vốn 312,6 nghìn tỷ đồng. Từ góc độ quản lý, việc sử dụng 5% vốn ngân sách như nguồn vốn dẫn dắt ban đầu nhằm huy động 297 nghìn tỷ đồng từ khu vực tư nhân thông qua các mô hình PPP cho thấy một minh chứng cho tư duy quản trị kiến tạo. Tuy nhiên, mô hình sử dụng vốn nhà nước có tính chất dẫn dắt ban đầu chỉ bền vững khi đi kèm cơ chế giám sát chất lượng thực thi PPP, tiêu chuẩn đầu ra và hệ thống dữ liệu đánh giá hiệu quả theo KPI, nếu không, rủi ro thiên lệch lợi ích và hiệu quả đầu tư thấp có thể gia tăng (World Bank, 1994).

(2) Về quản lý bảo trì, sử dụng, khai thác và duy tu tài sản kết cấu hạ tầng bảo đảm an toàn hàng hải

Trong giai đoạn 2015–2025, công tác duy tu, bảo trì hệ thống bảo đảm an toàn hàng hải được hoạch định và quản lý thông qua cơ chế giao dự toán chi sự nghiệp kinh tế hằng năm, dựa trên kế hoạch bảo trì được Bộ phê duyệt.

Nguồn lực được phân bổ tập trung vào hai cấu phần cốt lõi là nạo vét duy tu luồng hàng hải công cộng và sửa chữa công trình hàng hải (báo hiệu, đê kè, cầu cảng). Đối với hạng mục sửa chữa, kinh phí đã được điều chỉnh tăng dần từ 1,3 tỷ đồng (năm 2015) lên 71,3 tỷ đồng (năm 2017) và đạt 111,1 tỷ đồng (năm 2024) nhằm giải quyết tình trạng xuống cấp của hệ thống tài sản sau thời gian dài khai thác; đồng thời, khoản kinh phí bổ sung 53,5 tỷ đồng cũng được bố trí vào năm 2025 để xử lý dứt điểm khối lượng công việc tồn đọng từ giai đoạn 2017–2018 (Bộ Xây dựng, 2026a). Thực tiễn này phản ánh những hạn chế mang tính hệ thống khi kế hoạch ngân sách được lập theo từng năm tài khóa mà chưa bao quát trọn vẹn chu kỳ vòng đời tài sản, dẫn đến việc các hạng mục sửa chữa ngoài kế hoạch bị phát sinh. Kể từ năm 2025, trong quá trình tiếp nhận chức năng quản lý chuyên ngành, tổng dự toán chi hoạt động kinh tế đã được rà soát và điều chỉnh lên mức 3.250 tỷ đồng; tuy nhiên, cơ cấu phân bổ buộc phải thiết lập lại để tham mưu, trình Chính phủ nhằm đáp ứng yêu cầu tiết kiệm chi theo Nghị quyết số 173/NQ-CP, cho thấy tính ổn định của nguồn lực duy tu hạ tầng đang chịu sức ép nhất định trong giai đoạn chuyển tiếp thể chế (số liệu cụ thể, xem hồ sơ số liệu chi tiết).

[IMAGE]

Hình 2.5. Kinh phí bảo trì kết cấu hạ tầng hàng hải giai đoạn 2015–2026

Nguồn: Tổng hợp từ Báo cáo tổng kết việc thi hành Bộ luật Hàng hải Việt Nam năm 2015 (Bộ Xây dựng, 2026a).

Một bước chuyển đáng chú ý khác là xu hướng thị trường hóa từng phần và tăng cường trách nhiệm giải trình. Việc áp dụng triệt để phương thức đặt hàng và đấu thầu dịch vụ công ích theo Nghị định số 32/2019/NĐ-CP (Chính phủ nước CHXHCN Việt Nam, 2019) và được sửa đổi, bổ sung bằng Nghị định số 214/2025/NĐ-CP (Chính phủ nước CHXHCN Việt Nam, 2025a) đã từng bước làm thay đổi vai trò của cơ quan quản lý nhà nước, từ can thiệp trực tiếp sang kiểm soát sản phẩm đầu ra. Quy trình nghiệm thu và quyết toán chi phí duy tu hiện nay được căn cứ trực tiếp trên kết quả đo đạc bình đồ thực tế và trạng thái chiếu sáng của báo hiệu, qua đó góp phần nâng cao hiệu quả sử dụng ngân sách nhà nước và tạo áp lực buộc các đơn vị thực hiện nâng cao năng lực kỹ thuật, tính minh bạch trong quá trình cung ứng.

Kết quả quản lý giai đoạn 2015–2025 ghi nhận mức độ ổn định tương đối cao của các chỉ số hiệu suất kỹ thuật và độ tin cậy của hệ thống. Dữ liệu tổng hợp cho thấy tỷ lệ hoạt động tin cậy của mạng lưới 95 trạm đèn biển quốc gia cùng hệ thống báo hiệu trên 45 tuyến luồng hàng hải công cộng luôn duy trì ở mức trên 99%, tăng trên 2% so với năm 2015. Chỉ số này không chỉ đáp ứng các quy chuẩn kỹ thuật quốc gia về hạ tầng kỹ thuật (QCVN 07:2016/BXD) mà còn đạt mức tương thích cao với các tiêu chuẩn quốc tế của IALA. Công tác bảo trì định kỳ trên 1.091 km luồng hàng hải đã giúp duy trì tương đối ổn định chuẩn tắc độ sâu thiết kế, cho phép tàu trọng tải lớn hành hải an toàn 24/7, qua đó giảm thiểu rủi ro mắc cạn và ùn tắc tại các cửa ngõ kinh tế trọng điểm (Bộ Khoa học và Công nghệ, 2015a, 2015b; Bộ Xây dựng, 2026a; IALA, 2017a).

Bảng 2.5. Chỉ số độ tin cậy vận hành hệ thống bảo đảm an toàn hàng hải

[TABLE]

Nguồn: NCS tổng hợp từ Báo cáo Tổng kết thi hành Bộ luật hàng hải (Bộ Xây dựng, 2026a), 2026.

Tuy nhiên, công tác quản lý bảo trì, duy tu công trình và luồng hàng hải vẫn đối mặt với những thách thức mang tính hệ thống khi phần lớn quá trình ra quyết định duy tu còn dựa trên mô hình bảo trì khắc phục hoặc bảo trì định kỳ mang tính cơ học. Việc thiếu các công cụ phân tích dữ liệu lớn và công nghệ dự báo xu hướng sa bồi khiến công tác nạo vét duy tu có thời điểm rơi vào trạng thái bị động trước những biến động bất thường của tự nhiên. Bên cạnh đó, nguồn vốn bảo trì, duy tu hạ tầng dùng chung hiện vẫn lệ thuộc gần như hoàn toàn vào ngân sách nhà nước; trong khi đó, giai đoạn 2011–2020 nhu cầu vốn bảo trì, duy tu là 15 nghìn tỷ đồng nhưng vốn thực tế chỉ bố trí được khoảng 7,6 nghìn tỷ đồng, tương đương khoảng 51% nhu cầu (Androjna et al., 2021). Điều này cho thấy chưa hình thành được hành lang pháp lý đủ mạnh để thu hút nguồn lực xã hội hóa tham gia thực chất vào công tác duy tu, bảo trì, qua đó làm gia tăng áp lực tài chính công khi quy mô hệ thống bảo đảm an toàn hàng hải tiếp tục mở rộng.

(3) Về số hóa, cải cách thủ tục hành chính và quản lý dữ liệu BĐATHH Trong giai đoạn 2015–2025, công tác quản lý nhà nước về bảo đảm an toàn hàng hải được triển khai song song với lộ trình chuyển đổi số và cải cách thủ tục hành chính ở các cấp. Ở giai đoạn đầu, định hướng chuyển đổi số tập trung vào việc xây dựng nền tảng dữ liệu và nâng cao hiệu quả công tác quản lý, phục vụ. Sau quá trình sắp xếp tổ chức, Bộ Xây dựng đã tiếp nhận và thống nhất quản lý lĩnh vực hàng hải, ban hành chiến lược chuyển đổi số giai đoạn 2025–2030 theo hướng hiện đại hóa, chuẩn hóa dữ liệu (Bộ Xây dựng, 2025b) và bảo đảm an toàn, an ninh mạng (Bộ Chính trị, 2024), với hai trọng tâm xuyên suốt là hoàn thiện cơ sở dữ liệu chuyên ngành và triển khai dịch vụ công trực tuyến gắn với cải cách thủ tục hành chính (Bộ Xây dựng, 2025d).

Thực tiễn cho thấy việc thiết lập nền tảng dữ liệu tài sản tập trung trong giai đoạn 2020–2025 đã ghi nhận những bước tiến đáng chú ý, thể hiện qua việc 100% dữ liệu đăng ký tàu biển và kiểm định kỹ thuật, với 11.497 lượt kiểm định từ năm 2017 đến 2022, được đồng bộ hóa trên môi trường số (Bộ Xây dựng, 2026a). Việc số hóa toàn bộ lý lịch kỹ thuật của 95 trạm đèn biển và 45 tuyến luồng công cộng đã cung cấp căn cứ khoa học hơn cho lập kế hoạch đầu tư và công tác bảo trì, góp phần hạn chế lãng phí nguồn lực nhà nước. Song song với quản lý tài sản tĩnh, việc ứng dụng công nghệ giám sát và điều tiết giao thông động cũng hỗ trợ nâng cao kết quả công tác bảo đảm an toàn hàng hải thông qua hệ thống thông tin địa lý (GIS), cho phép giám sát 1.061 phao báo hiệu bằng tín hiệu AIS/GSM. Theo lộ trình chính sách đã được phê duyệt, việc tích hợp dữ liệu từ hệ thống (VTS) và hải đồ điện tử (ENC) đã bước đầu tạo ra cơ sở dữ liệu tổng thể phục vụ điều tiết phương tiện và giảm thiểu rủi ro (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025c).

Bảng 2.6. Mức độ số hóa các thành phần quản lý tài sản hệ thống bảo đảm an toàn hàng hải

[TABLE]

Nguồn: Tổng hợp từ dữ liệu Cục Hàng hải Việt Nam, Quyết định 1009/QĐ-BGTVT và Báo cáo tổng kết thi hành Bộ luật Hàng hải Việt Nam năm 2015 (Bộ Xây dựng, 2026a).

Mặc dù đạt được những kết quả tích cực, thực trạng quản trị số vẫn bộc lộ những khoảng trống về tính liên thông và mức độ hiện đại hóa chuyên sâu. Dữ liệu hạ tầng hàng hải hiện vẫn tồn tại dưới dạng chuyên biệt, chưa thiết lập được cơ chế kết nối hoàn toàn với hệ thống ngành cũng như dữ liệu đường thủy nội địa. Sự thiếu đồng bộ này gây ra những điểm mù trong quản trị tại các tuyến luồng hỗn hợp, nơi giao thoa giữa hai thẩm quyền quản lý (Bộ Xây dựng, 2025a). Thêm vào đó, việc xây dựng mô hình bản sao số (Digital Twin) cho hạ tầng bảo đảm an toàn hàng hải, công cụ cho phép mô phỏng các kịch bản hỏng hóc và dự báo sa bồi vẫn đang ở giai đoạn sơ khởi.

(4) Về đào tạo và phát triển nguồn nhân lực quản lý hệ thống BĐATHH Giai đoạn 2015–2025 ghi nhận sự chuyển dịch đáng chú ý trong yêu cầu năng lực nhằm hình thành đội ngũ quản lý đầu tư có tính chuyên nghiệp hơn. Đội ngũ cán bộ hàng hải đã được tập trung bồi dưỡng chuyên sâu về kỹ năng quản lý hợp đồng theo chuẩn quốc tế (FIDIC), giám sát tiến độ và kiểm soát chất lượng dựa trên bằng chứng kỹ thuật. Quá trình chuyên nghiệp hóa này bước đầu mang lại kết quả thực tế thông qua việc giảm thiểu sai sót trong giai đoạn chuẩn bị đầu tư, góp phần nâng cao tỷ lệ giải ngân vốn đầu tư công hằng năm và hỗ trợ các công trình hạ tầng an toàn hàng hải hoàn thành đúng tiến độ phê duyệt (Bộ Giao thông vận tải, 2023a, 2023c).

Đi đôi với năng lực quản lý dự án, thực trạng đào tạo còn tập trung vào khả năng thích ứng với kỹ năng quản trị dữ liệu và công nghệ số. Nhằm đáp ứng lộ trình số hóa, các chương trình tập huấn về vận hành VTS, AIS và khai thác dữ liệu GIS đã được triển khai trên diện rộng. Tuy nhiên, kết quả giám sát thực tế cho thấy sự phân hóa tương đối rõ: trong khi đội ngũ tại các khu vực cảng biển cửa ngõ quốc tế đã từng bước làm chủ công nghệ giám sát hiện đại, thì năng lực công nghệ của nhân sự tại các cảng địa phương vẫn còn bộc lộ hạn chế, gây khó khăn cho việc đồng bộ hóa dữ liệu trên toàn hệ thống (Bộ Xây dựng, 2025h).

Dù đã chú trọng đào tạo, phát triển nhân lực quản lý vẫn gặp nhiều khó khăn như thiếu chuyên gia phân tích dữ liệu lớn, cơ chế đãi ngộ còn hạn chế khiến khó giữ chân nhân sự kỹ thuật cao, và chương trình đào tạo chưa thật sự đồng bộ, còn nặng về lý thuyết và thiếu tính thực hành. Những điểm yếu này cho thấy năng lực nhân sự vẫn là một hạn chế đáng chú ý trong quá trình hiện đại hóa quản lý hệ thống bảo đảm an toàn hàng hải (Bộ Xây dựng, 2025h).

Thực tiễn cho thấy tổ chức thực hiện quản lý và vận hành hệ thống bảo đảm an toàn hàng hải đã có bước chuyển theo hướng hiện đại hơn, góp phần nâng cao vùng phủ, độ tin cậy kỹ thuật và tính liên tục của hệ thống. Dẫu vậy, cơ chế bảo trì theo vòng đời, chất lượng liên thông dữ liệu, năng lực dự báo rủi ro và chất lượng nhân lực quản lý vẫn chưa đáp ứng đồng đều yêu cầu nâng cao hiệu lực, hiệu quả quản lý nhà nước, qua đó cho thấy khâu tổ chức thực hiện tuy đã chuyển biến nhưng chưa thật sự theo kịp yêu cầu của mô hình quản trị hiện đại.

2.2.1.3. Giám sát, đánh giá hệ thống bảo đảm an toàn hàng hải

Giám sát và đánh giá là khâu bảo đảm kỷ luật vận hành và khả năng tự điều chỉnh của hệ thống bảo đảm an toàn hàng hải. Giá trị của khâu này không chỉ nằm ở tần suất thanh tra, kiểm tra, mà còn ở khả năng phát hiện rủi ro, nhận diện sai lệch trong vận hành, chuyển từ giám sát định kỳ sang giám sát dựa trên rủi ro và dữ liệu, đồng thời tạo ra vòng phản hồi chính sách từ kết quả giám sát và điều tra sự cố. Vì vậy, giai đoạn 2015–2025 cần được xem xét qua các phương diện như thanh tra, kiểm tra hệ thống; nghiệm thu và kiểm toán kỹ thuật; giám sát an toàn hàng hải và môi trường biển; điều tra sự cố; và mối liên hệ giữa giám sát hệ thống với kết quả an toàn hàng hải trên thực tế.

(1) Về hoạt động giám sát, đánh giá hệ thống bảo đảm an toàn hàng hải.

Hoạt động giám sát, đánh giá đối với hệ thống kết cấu hạ tầng bảo đảm an toàn hàng hải được tổ chức thông qua thanh tra chuyên ngành và hệ thống

Cảng vụ hàng hải. Theo các báo cáo tổng kết, công tác kiểm tra định kỳ, đột xuất đã được duy trì hằng năm trên phạm vi cả nước, tập trung vào luồng hàng hải, báo hiệu, vùng nước cảng biển, công trình hàng hải và các dịch vụ công ích có liên quan (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025a).

Bên cạnh hoạt động thanh tra chuyên ngành, các Cảng vụ hàng hải khu vực được Bộ phân cấp thực hiện kiểm tra thường xuyên đối với tình trạng báo hiệu, luồng và vùng nước trong phạm vi quản lý. Tổng công ty Bảo đảm an toàn hàng hải Việt Nam cũng thực hiện hoạt động tự kiểm tra, đánh giá nội bộ theo quy định do Bộ ban hành. Kết quả khảo sát cho thấy điểm trung bình của biến "Thanh tra, kiểm tra an toàn hàng hải được thực hiện thường xuyên" (B3_1) đạt 3,48/5, phản ánh nhận định tương đối tích cực về tần suất hoạt động thanh tra (kết quả khảo sát của nghiên cứu sinh, 2025).

Tuy nhiên, phương pháp tiếp cận trong hoạt động thanh tra, kiểm tra vẫn còn một số hạn chế. Biến "Công tác thanh tra an toàn hàng hải được áp dụng theo hướng dựa trên rủi ro, không chỉ thực hiện định kỳ" (B3_3) chỉ đạt điểm trung bình 3,25/5, cho thấy việc chuyển đổi từ giám sát định kỳ sang giám sát dựa trên rủi ro còn chậm (kết quả khảo sát của nghiên cứu sinh, 2025). Đối với các hệ thống kỹ thuật hiện đại như VTS và AIS, hoạt động kiểm tra, giám sát đòi hỏi chuyên môn sâu và thiết bị chuyên dụng, trong khi năng lực đội ngũ cán bộ kiểm tra còn hạn chế, nhất là đối với các công nghệ mới.

(2) Về nghiệm thu chất lượng công trình và kiểm toán kỹ thuật hệ thống

Công tác này hiện nay đang đối mặt với thách thức kép về công nghệ giám sát và khung pháp lý điều chỉnh. Đối với nạo vét duy tu luồng hàng hải, tức hạng mục chiếm tỷ trọng lớn trong ngân sách bảo trì, cơ chế giám sát đã có bước chuyển dịch tích cực thông qua ứng dụng công nghệ. Từ năm 2019, Bộ Xây dựng đã yêu cầu tất cả phương tiện thi công nạo vét lắp đặt thiết bị nhận dạng tự động và camera giám sát hành trình để kiểm soát vị trí đổ thải. Quy định này, được củng cố bởi Thông tư số 43/2024/TT-BGTVT ngày 19/11/2024 của Bộ, đã góp phần hạn chế tình trạng gian lận khối lượng và nhận chìm chất nạo vét sai vị trí. Tuy nhiên, trong một thời gian dài, việc chưa sử dụng hệ thống

AIS để giám sát hoạt động nạo vét duy tu luồng hàng hải đã tạo ra khoảng trống đáng kể, làm gia tăng rủi ro thất thoát, lãng phí ngân sách nhà nước. Ngoài ra, Bộ luật Hàng hải Việt Nam năm 2015 hiện chưa có quy định cụ thể ở cấp luật đối với dịch vụ nạo vét duy tu luồng hàng hải công cộng để bảo đảm chuẩn tắc thiết kế, dẫn đến thiếu cơ sở cho các chế tài kiểm toán chuyên biệt (Bộ Xây dựng, 2026a). Mặc dù hệ thống văn bản pháp luật đã quy định tương đối chi tiết về quản lý chất lượng và bảo trì công trình hàng hải, điển hình là Thông tư số 19/2022/TT-BGTVT, Thông tư số 40/2023/TT-BGTVT và Thông tư số 42/2019/TT-BGTVT quy định về tiêu chí kiểm tra, giám sát, đánh giá, nghiệm thu chất lượng dịch vụ sự nghiệp công bảo đảm an toàn hàng hải, nhưng thực tiễn cho thấy công tác này vẫn mang nặng tính hậu kiểm hành chính hơn là kiểm toán kỹ thuật độc lập. Các chuyên gia trong ngành cho rằng việc thiếu vắng cơ chế kiểm toán độc lập về kỹ thuật làm gia tăng rủi ro thất thoát ngầm về ngân sách, khi tuổi thọ thực tế của công trình có thể thấp hơn tuổi thọ thiết kế, qua đó tạo áp lực lên ngân sách bảo trì trong dài hạn (Bộ Giao thông vận tải, 2019; Bộ Giao thông vận tải, 2022; Bộ Giao thông vận tải, 2023b).

(3) Về hoạt động giám sát an toàn hàng hải và môi trường biển

Trong giai đoạn từ năm 2017 đến ngày 21/10/2024, trong khu vực Tokyo

MOU đã có 7.194 lượt tàu biển Việt Nam bị kiểm tra, phát hiện 17.622 khiếm khuyết liên quan đến 4.909 lượt tàu; có 191 lượt tàu bị lưu giữ, tương ứng tỷ lệ lưu giữ 3,23% (Bộ Xây dựng, 2026a). Sau nhiều năm ở Danh sách đen, đội tàu biển Việt Nam đã duy trì trong danh sách trắng kể từ năm 2014. Đây là chỉ dấu quan trọng cho thấy năng lực giám sát và tuân thủ chuẩn mực quốc tế của hệ thống quản lý nhà nước đã được cải thiện, đồng thời được “thẩm định” bởi cơ chế kiểm soát cảng biển khu vực (Bộ Xây dựng, 2026a; Tokyo Memorandum of Understanding on Port State Control, n.d.).

Ngoài giám sát an toàn khai thác tàu, năng lực cưỡng chế và xử lý các quan hệ pháp lý phức tạp phát sinh trong hoạt động hàng hải cũng từng bước được nâng lên. Giai đoạn 2017–2023, các cảng vụ hàng hải đã thực hiện bắt giữ 43 tàu biển theo quyết định của tòa án. Trong lĩnh vực xử lý tài sản chìm đắm, Cục Hàng hải và Đường thủy Việt Nam đã phê duyệt 1 phương án trục vớt thuộc thẩm quyền của Bộ; riêng khối cảng vụ hàng hải ghi nhận khoảng 44 vụ việc xử lý tài sản chìm đắm (Bộ Xây dựng, 2026a). Các số liệu này cho thấy công tác kiểm tra, giám sát không chỉ giới hạn trong kiểm tra hành chính, mà còn bao gồm khả năng quản lý các rủi ro pháp lý, tài sản và môi trường phát sinh từ tai nạn, đắm chìm, tranh chấp hàng hải và xử lý hậu quả. Đây là biểu hiện của năng lực giám sát hệ thống theo nghĩa rộng, tức giám sát cả quá trình vận hành lẫn hậu quả phát sinh từ vận hành.

Giám sát môi trường trong hoạt động nạo vét và nhận chìm vật chất ở biển vẫn là một hạn chế chưa được xử lý triệt để. Báo cáo tổng kết thi hành Bộ luật Hàng hải Việt Nam năm 2015 cho thấy quá trình thực thi còn gặp khó khăn do thiếu quy hoạch vị trí nhận chìm ổn định, lâu dài và do khung pháp lý chưa bao quát đầy đủ một số dịch vụ mới phát sinh như nạo vét duy tu luồng công cộng (Bộ Xây dựng, 2026a). Bên cạnh đó, công tác quan trắc sa bồi và dự báo biến động luồng tuyến còn thụ động, làm tăng nguy cơ bồi lắng cục bộ trước khi thủ tục nạo vét được kích hoạt.

(4) Về điều tra sự cố hệ thống bảo đảm an toàn hàng hải

Quy trình điều tra tai nạn, sự cố hàng hải đã được Bộ quy định tại Thông tư số 01/2020/TT-BGTVT. Tuy nhiên, trọng tâm của các cuộc điều tra thường nghiêng về việc xác định trách nhiệm bồi thường và xử phạt hành chính hơn là phân tích nguyên nhân gốc rễ để cải tiến hệ thống (Bộ Giao thông vận tải, 2025). Dữ liệu khảo sát chuyên gia cho thấy các chỉ số kỹ thuật quan trọng như thời gian trung bình để khắc phục sự cố chưa được đo lường và công bố rộng rãi như một chỉ số hiệu suất bắt buộc (World Bank & International Association of Ports and Harbors [IAPH], 2021). Hơn nữa, kết quả điều tra sự cố chưa thực sự tạo ra cơ chế phản hồi để điều chỉnh quy hoạch hoặc quy trình vận hành. Chẳng hạn, các sự cố đâm va làm hư hỏng cầu cảng hoặc phao tiêu thường được xử lý cục bộ, thiếu sự tổng hợp dữ liệu để nhận diện các điểm đen hạ tầng nhằm điều chỉnh thiết kế luồng hoặc phương án phân luồng giao thông một cách căn cơ.

Báo cáo tổng kết cho thấy công tác thanh tra, kiểm tra đối với lĩnh vực bảo đảm an toàn hàng hải đã được tăng cường rõ hơn trong giai đoạn sau năm 2020; đồng thời, năng lực khắc phục sự cố báo hiệu và duy trì trạng thái vận hành an toàn của hệ thống cũng được cải thiện nhờ ứng dụng dữ liệu tập trung và các công cụ giám sát tự động (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025a). Tuy vậy, hiệu quả của giám sát vẫn chưa đồng đều giữa các nhóm công việc, đặc biệt ở các dự án nạo vét duy tu luồng hàng hải.

Việc tăng số lượng các cuộc thanh tra, kiểm tra đã góp phần phát hiện và xử lý kịp thời hơn các nguy cơ tiềm ẩn, đồng thời nâng cao ý thức tuân thủ của các đơn vị vận hành hàng hải. Đặc biệt tại các vùng nước có mật độ tàu thuyền cao, giám sát thường xuyên tạo thêm điều kiện hỗ trợ kiểm soát rủi ro, góp phần giảm nguy cơ xảy ra tai nạn và duy trì sự thông suốt của hoạt động thương mại, vận tải biển. Bên cạnh đó, tỷ lệ khắc phục sự cố báo hiệu kịp thời gia tăng cũng phản ánh hiệu quả bước đầu của việc đầu tư vào công nghệ quản lý hiện đại. Tuy nhiên, các kết quả này chưa đồng đều giữa các nhóm công việc; vi phạm vẫn còn tồn tại, nhất là trong các dự án nạo vét duy tu luồng hàng hải.

Qua công tác kiểm tra, thanh tra, nhiều vi phạm tại các doanh nghiệp và đơn vị khai thác cảng đã được phát hiện. Minh chứng điển hình là Kết luận thanh tra số 39/KL-TTr ngày 24/10/2025 đối với Công ty Cảng Container Trung tâm Sài Gòn, trong đó cơ quan thanh tra chỉ ra các sai phạm liên quan đến khảo sát, bảo trì công trình, quản lý giá dịch vụ và công tác môi trường (Thanh tra, 2025). Trường hợp này cho thấy khoảng cách đáng kể giữa yêu cầu của khung pháp lý với năng lực tuân thủ và giám sát ở cấp cơ sở.

(5) Mối quan hệ giữa giám sát hệ thống và kết quả an toàn hàng hải

Một trong những mục tiêu quan trọng của công tác kiểm tra, giám sát hệ thống là góp phần giảm thiểu tai nạn, sự cố hàng hải. Thống kê tai nạn hàng hải giai đoạn 2018–2025 cho thấy xu hướng giảm cả về số vụ và mức độ nghiêm trọng; số vụ tai nạn giảm từ 18 vụ năm 2018 xuống còn 6 vụ năm 2023 và tiếp tục duy trì con số này đến năm 2025, trong khi số người chết và mất tích cũng giảm đáng kể (Cục Hàng hải và Đường thủy Việt Nam, 2025c). Xu hướng này phản ánh những nỗ lực trong công tác quản lý an toàn hàng hải nói chung, trong đó có đóng góp của việc duy trì và nâng cấp hệ thống bảo đảm an toàn hàng hải.

[IMAGE]

Hình 2.6. Biểu đồ diễn biến tai nạn hàng hải giai đoạn 2015–2025.

Nguồn: Báo cáo tổng kết thi hành Bộ luật Hàng hải 2015 (Bộ Xây dựng, 2026a).

Tuy nhiên, số liệu hiện có chưa cho phép xác định một cách định lượng mối quan hệ nhân quả trực tiếp giữa chất lượng giám sát hệ thống và tỷ lệ tai nạn. Nguyên nhân là do: (i) chưa có phân loại tai nạn theo nguyên nhân liên quan đến hệ thống bảo đảm an toàn hàng hải; (ii) dữ liệu về tình trạng kỹ thuật của hệ thống tại thời điểm xảy ra tai nạn chưa được thu thập và phân tích một cách hệ thống; (iii) còn nhiều yếu tố nhiễu khác (lỗi con người, thời tiết, điều kiện hàng hải...). Kết quả phân tích định lượng cũng cho thấy nhân tố H3 (Giám sát hệ thống) phản ánh mức độ tác động chưa có ý nghĩa thống kê, qua đó cho thấy chất lượng và hiệu quả của công tác giám sát hiện tại vẫn còn những khoảng trống cần tiếp tục được nhận diện và xử lý (kết quả phân tích định lượng của nghiên cứu sinh, 2025).

Có thể khái quát rằng hoạt động giám sát và đánh giá hệ thống đã được duy trì và từng bước tăng cường, góp phần hỗ trợ kiểm soát vận hành hệ thống bảo đảm an toàn hàng hải. Tuy nhiên, khâu này vẫn nghiêng về hậu kiểm hành chính, chưa đạt chiều sâu kỹ thuật cần thiết và chưa hình thành được cơ chế phản hồi chính sách đủ mạnh để tạo chuyển biến rõ rệt về chất lượng quản lý hệ thống. Đây cũng là dấu hiệu cho thấy giám sát vẫn là một mắt xích còn yếu so với yêu cầu quản lý nhà nước trong bối cảnh mới.

2.2.2. Thực trạng quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

2.2.2.1. Ban hành cơ chế, chính sách về dịch vụ bảo đảm an toàn hàng hải

Trên phương diện quản lý cung ứng dịch vụ, việc ban hành cơ chế, chính sách phản ánh năng lực xác lập trật tự pháp lý của Nhà nước đối với các dịch vụ bảo đảm an toàn hàng hải. Cốt lõi của khâu này là xác định rõ phạm vi dịch vụ, chuẩn hóa tiêu chuẩn chất lượng có thể đo lường, quy định điều kiện năng lực của chủ thể cung ứng phù hợp với yêu cầu công nghệ và hội nhập, đồng thời thiết kế cơ chế giá, cơ chế tài chính và chuẩn nhân lực có khả năng định hướng nâng cao chất lượng dịch vụ. Từ góc nhìn đó, giai đoạn 2015–2025 cần được phân tích theo ba phương diện chính là thiết lập danh mục dịch vụ và chuẩn chất lượng, xây dựng khung giá và cơ chế tài chính, và chuẩn hóa năng lực nhân lực dịch vụ bảo đảm an toàn hàng hải.

(1) Thiết lập danh mục dịch vụ, tiêu chuẩn chất lượng và điều kiện kinh doanh dịch vụ bảo đảm an toàn hàng hải

Trên cơ sở Bộ luật Hàng hải Việt Nam năm 2015, hệ thống văn bản hướng dẫn được ban hành qua các giai đoạn đã từng bước cụ thể hóa các loại hình dịch vụ bảo đảm an toàn hàng hải, làm rõ phạm vi dịch vụ sử dụng ngân sách nhà nước, dịch vụ thực hiện theo cơ chế đặt hàng, giao nhiệm vụ hoặc đấu thầu, cũng như trách nhiệm của cơ quan quản lý chuyên ngành. Các nghị định sửa đổi trong lĩnh vực hàng hải ban hành năm 2025 tiếp tục điều chỉnh, cập nhật cơ chế quản lý đối với các dịch vụ công ích và dịch vụ hỗ trợ an toàn hàng hải theo hướng rõ hơn về phạm vi điều chỉnh và trách nhiệm tổ chức thực hiện (Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2025c; Quốc hội nước CHXHCN Việt Nam, 2015). Bảng danh mục các dịch vụ bảo đảm an toàn hàng hải và các văn bản pháp luật điều chỉnh được trình bày trong hệ thống văn bản pháp luật và báo cáo chuyên ngành đã được tổng hợp trong luận án.

Bảng 2.7. Phân loại danh mục dịch vụ bảo đảm an toàn hàng hải

[TABLE]

Nguồn: NCS tổng hợp từ hệ thống văn bản pháp luật (Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2016; Chính phủ nước CHXHCN Việt Nam, 2017; Chính phủ nước CHXHCN Việt Nam, 2022; Chính phủ nước CHXHCN Việt Nam, 2025c, 2025d; Quốc hội nước CHXHCN Việt Nam, 2015).

Giai đoạn này ghi nhận sự chuyển dịch từ cơ chế chỉ định hành chính sang cơ chế quản lý ngành nghề kinh doanh có điều kiện dựa trên năng lực thực tế. Các nghị định về điều kiện kinh doanh dịch vụ hàng hải, sửa đổi năm 2018 và năm 2022, đã tạo hành lang pháp lý cụ thể hơn đối với các dịch vụ cốt lõi như bảo đảm an toàn hàng hải, hoa tiêu, trục vớt cứu hộ và các dịch vụ hỗ trợ liên quan (Chính phủ nước CHXHCN Việt Nam, 2016; Chính phủ nước CHXHCN Việt Nam, 2022). Hệ thống văn bản này thiết lập các nhóm điều kiện về năng lực tài chính, phương tiện chuyên dùng và nhân sự có chứng chỉ chuyên môn, qua đó chuẩn hóa đầu vào của thị trường dịch vụ.

Bảng 2.8. Hệ thống văn bản thiết lập tiêu chuẩn chất lượng dịch vụ bảo đảm an toàn hàng hải

[TABLE]

Nguồn: NCS tổng hợp từ hệ thống văn bản quy phạm pháp luật (Bộ Giao thông vận tải, 2019; Bộ Giao thông vận tải, 2023a, 2023b, 2023c; Bộ Khoa học và Công nghệ, 2015a, 2015b; Bộ Xây dựng, 2025f, 2025g, 2025h, 2025i).

Tiêu chuẩn chất lượng dịch vụ bảo đảm an toàn hàng hải đã từng bước được nội luật hóa dựa trên khuyến nghị của IALA và IMO. Đối với đèn biển, TCVN 10703:2015 quy định chỉ số khả dụng theo nhóm đèn; đối với hệ thống báo hiệu trên luồng, TCVN 10704:2015 quy định ngưỡng chỉ số khả dụng tổng hợp của hệ thống báo hiệu; còn đối với quản lý chất lượng dịch vụ sự nghiệp công, Thông tư số 42/2019/TT-BGTVT và Thông tư số 40/2023/TT-BGTVT đã bổ sung tiêu chí kiểm tra, giám sát và nghiệm thu đối với các nhóm dịch vụ chủ yếu (Bộ Giao thông vận tải, 2019; Bộ Giao thông vận tải, 2023b; Bộ Khoa học và Công nghệ, 2015a, 2015b). Tuy vậy, hệ thống hiện hành vẫn thiên về chuẩn hóa yêu cầu kỹ thuật đầu ra, chưa phát triển đầy đủ thành các cam kết mức dịch vụ (SLA) có tính tích hợp cho toàn hệ thống bảo đảm an toàn hàng hải (IALA, 2017a; IALA, 2023).

(2) Xây dựng và ban hành khung giá và cơ chế tài chính dịch vụ bảo đảm an toàn hàng hải

Giai đoạn 2015–2025 chứng kiến xu hướng chuyển từ quản lý phí, lệ phí sang quản lý giá dịch vụ đối với nhiều dịch vụ tại cảng biển và dịch vụ hỗ trợ hàng hải. Việc thực hiện Thông tư số 261/2016/TT-BTC và sau đó là Thông tư số 12/2024/TT-BGTVT đã làm rõ hơn cơ chế thu, nộp, quản lý phí, lệ phí hàng hải và cơ chế chính sách quản lý giá dịch vụ tại cảng biển (Bộ Giao thông vận tải, 2024b; Bộ Tài chính, 2016). Đây không chỉ là sự thay đổi về công cụ tài chính, mà còn tác động trực tiếp đến cách thức điều tiết thị trường dịch vụ hàng hải.

Bộ đã cụ thể hóa khung pháp lý điều chỉnh hoạt động của nhiều loại hình dịch vụ bảo đảm an toàn hàng hải thông qua các văn bản về giá dịch vụ, định mức kinh tế – kỹ thuật và cơ chế đặt hàng. Điển hình là Thông tư số 37/2021/TT-BGTVT về giá dịch vụ sự nghiệp công bảo đảm an toàn hàng hải, Thông tư số 44/2018/TT-BGTVT về định mức nạo vét công trình hàng hải, Thông tư số 12/2024/TT-BGTVT về cơ chế, chính sách quản lý giá dịch vụ tại cảng biển và Quyết định số 814/QĐ-BGTVT về giá tối đa dịch vụ hoa tiêu hàng hải tại cảng biển Việt Nam (Bộ Giao thông vận tải, 2021a; Bộ Giao thông vận tải, 2024a, 2024b). Các quy định này yêu cầu xây dựng định mức, đơn giá và tiêu chí chất lượng, qua đó tăng trách nhiệm của doanh nghiệp cung ứng và từng bước giảm tính bao cấp trong cung ứng dịch vụ. Tuy nhiên, cơ chế “giá dịch vụ” vẫn còn một số bất cập như độc quyền hoa tiêu, thiếu lựa chọn nhà cung cấp, khung giá đồng loạt trong khi điều kiện phục vụ khác nhau, và việc điều chỉnh giá chưa dựa trên kết quả đầu ra (SLA/KPI), khiến công cụ giá chưa thật sự trở thành đòn bẩy nâng cao chất lượng dịch vụ và hiệu quả quản lý.

Bảng 2.9. Hệ thống văn bản về cơ chế tài chính và điều kiện năng lực đơn vị cung ứng

[TABLE]

Nguồn: NCS tổng hợp từ hệ thống văn bản quy phạm pháp luật, 2025.

Quy định tiêu chuẩn đào tạo, cấp/thu hồi chứng chỉ hoa

tiêu hàng hải.

Mặc dù vậy, đối với nhóm dịch vụ công ích thiết yếu như vận hành đèn biển và nạo vét luồng công cộng, cơ chế tài chính vẫn còn nhiều bất cập. Việc áp dụng cơ chế đặt hàng theo Nghị định số 32/2019/NĐ-CP và hệ thống định mức kinh tế – kỹ thuật hiện hành đã minh bạch hơn cơ chế giao dự toán cũ, nhưng vẫn chịu độ trễ lớn so với biến động giá nhiên liệu, vật tư và điều kiện thi công thực tế (Bộ Giao thông vận tải, 2021b; Chính phủ nước CHXHCN Việt Nam, 2019). Báo cáo tổng kết cũng cho thấy nguồn vốn ngân sách bố trí cho bảo trì kết cấu hạ tầng hàng hải giai đoạn 2011–2020 chỉ đáp ứng khoảng 51% nhu cầu tính toán, làm gia tăng rủi ro “cắt khúc nhiệm vụ” và suy giảm hiệu quả bảo trì theo vòng đời tài sản (Bộ Xây dựng, 2026a). Danh mục các văn bản về cơ chế tài chính dịch vụ bảo đảm an toàn hàng hải được trình bày trong hệ thống văn bản pháp luật và báo cáo chuyên ngành đã được tổng hợp trong luận án.

(3) Chuẩn hóa năng lực nhân lực dịch vụ bảo đảm an toàn hàng hải

Nhà nước luôn xác định yếu tố con người là trung tâm trong việc nâng cao chất lượng dịch vụ bảo đảm an toàn hàng hải và đã được thể hiện qua Quyết định số 1901/QĐ-TTg về phát triển Trường Đại học Hàng hải Việt Nam thành trường trọng điểm quốc gia. Quyết định này nhấn mạnh mối liên hệ giữa đào tạo nhân lực và yêu cầu vận hành an toàn các dịch vụ hàng hải. Bộ Xây dựng tiếp tục cụ thể hóa mục tiêu chuẩn hóa năng lực nhân lực bằng Quyết định số 2287/QĐ-BXD, chuyển trọng tâm từ quản lý số lượng sang chất lượng và đầu ra. Các nhiệm vụ như mở rộng quy mô đào tạo, phát triển chương trình chuyên sâu, tăng cường thực hành kỹ thuật cao, thúc đẩy chuyển đổi số, kiểm định chất lượng quốc tế và hợp tác quốc tế đều nhằm chuẩn hóa năng lực nghề nghiệp cho nhân lực hàng hải, đáp ứng yêu cầu dịch vụ hiện đại (Bộ Xây dựng, 2025c; Thủ tướng Chính phủ, 2025b).

Ở tầng thực thi chuyên ngành, công tác chuẩn hóa năng lực nhân lực dịch vụ bảo đảm an toàn hàng hải được củng cố thông qua hệ thống thông tư quy định tiêu chuẩn chuyên môn, điển hình như Thông tư số 20/2023/TT-BGTVT quy định tiêu chuẩn chuyên môn, chứng chỉ chuyên môn, đào tạo, huấn luyện thuyền viên và định biên an toàn tối thiểu của tàu biển Việt Nam; Thông tư số 57/2023/TT-BGTVT quy định chương trình đào tạo, huấn luyện thuyền viên, hoa tiêu hàng hải; và Thông tư số 31/2025/TT-BXD tiếp tục hoàn thiện khung pháp lý về tiêu chuẩn đào tạo hoa tiêu hàng hải, cấp và thu hồi chứng chỉ chuyên môn, giấy chứng nhận vùng hoạt động (Bộ Giao thông vận tải, 2023a, 2023c; Bộ Xây dựng, 2025h). Nhìn chung, hệ thống này đã hỗ trợ quá trình nội luật hóa chuẩn STCW và từng bước chuẩn hóa năng lực của đội ngũ thuyền viên, hoa tiêu và nhân lực vận hành dịch vụ (IMO, 1978).

Tổng hợp lại, khung thể chế quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải giai đoạn 2015–2025 đã góp phần thiết lập trật tự pháp lý cho thị trường dịch vụ, nâng cao mức độ chuẩn hóa điều kiện kinh doanh và từng bước minh bạch hóa cơ chế giá, đặt hàng và đào tạo nhân lực. Tuy nhiên, quản lý vẫn còn thiên về kiểm soát đầu vào; hệ thống KPI/SLA và cơ chế đánh giá đầu ra chưa được thiết kế đầy đủ để tạo áp lực cải thiện chất lượng dịch vụ một cách thực chất (Bộ Xây dựng, 2025g, 2025h; Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2016; Chính phủ nước CHXHCN Việt Nam, 2022).

Xét tổng thể, khuôn khổ chính sách đối với dịch vụ bảo đảm an toàn hàng hải đã rõ hơn trước, góp phần định hình trật tự pháp lý cho thị trường dịch vụ và nâng cao mức độ chuẩn hóa trong quản lý. Tuy nhiên, hệ thống chính sách hiện hành vẫn đậm dấu ấn kiểm soát đầu vào, trong khi các công cụ quản lý theo đầu ra, cam kết mức dịch vụ và cơ chế thúc đẩy cạnh tranh bằng chất lượng còn chưa được thiết kế đầy đủ. Điều đó cho thấy khâu ban hành chính sách về dịch vụ đã tiến bộ, nhưng chưa thật sự tạo được sức ép đủ mạnh đối với nâng cao chất lượng cung ứng.

2.2.2.2. Tổ chức thực hiện, quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

Bản chất của khâu này là tổ chức để dịch vụ được cung ứng liên tục, an toàn, đúng tiêu chuẩn; vận hành hiệu quả các cơ chế đặt hàng, giao nhiệm vụ, đấu thầu và điều tiết dịch vụ; sử dụng hợp lý các nguồn lực tài chính, nhân lực, công nghệ; đồng thời duy trì sự phối hợp có hiệu lực giữa cơ quan quản lý nhà nước và các đơn vị cung ứng. Bởi vậy, giai đoạn 2015–2025 cần được xem xét qua các phương diện như tổ chức lựa chọn đơn vị cung ứng, điều tiết hoạt động cung ứng dịch vụ, quản lý đào tạo và cấp chứng chỉ nhân lực dịch vụ, cũng như ứng dụng công nghệ trong điều hành và quản lý.

(1) Công tác đặt hàng, đấu thầu, giao nhiệm vụ dịch vụ bảo đảm an toàn hàng hải

Giai đoạn 2015–2025 chứng kiến nỗ lực chuyển đổi cung ứng dịch vụ công ích từ cơ chế giao nhiệm vụ, giao dự toán sang cơ chế đặt hàng hoặc đấu thầu theo Nghị định số 32/2019/NĐ-CP và các quy định về lựa chọn nhà thầu (Chính phủ nước CHXHCN Việt Nam, 2019; Chính phủ nước CHXHCN Việt Nam, 2025a). Dữ liệu của cơ quan quản lý cho thấy số lượng hợp đồng dịch vụ công ích thực hiện theo các cơ chế này tăng lên, phản ánh xu hướng thị trường hóa có kiểm soát (Bộ Xây dựng, 2026a). Tuy nhiên, quy trình phê duyệt đơn giá, định mức và kế hoạch lựa chọn nhà thầu vẫn còn kéo dài, tạo khoảng trống thực thi đối với các dịch vụ phải duy trì liên tục 24/7. So với kinh nghiệm quốc tế, hợp đồng dịch vụ của Việt Nam vẫn thiên về chu kỳ ngắn và kiểm soát hành chính hơn là hợp đồng dài hạn gắn với chỉ số kết quả (MPA, 2025; World Bank, 1994).

Theo logic quản trị vòng đời tài sản được xác lập trong Nghị định số 84/2025/NĐ-CP, hiệu quả bảo trì phụ thuộc nhiều vào khả năng can thiệp đúng thời điểm và dựa trên dữ liệu (Chính phủ nước CHXHCN Việt Nam, 2025d). Trong khi đó, thực tế vận hành cho thấy biến động sa bồi tự nhiên thường không trùng với chu kỳ lập và phê duyệt dự toán hằng năm; vì vậy, độ trễ trong kế hoạch nạo vét và bảo trì tiếp tục làm giảm hiệu quả kỹ thuật và gia tăng chi phí thực hiện (Bộ Xây dựng, 2026a).

Bảng 2.10. Tổng hợp kết quả quản lý giữa dịch vụ thông tin và dịch vụ hạ tầng cứng (2020–2025)

[TABLE]

Nguồn: Nghiên cứu sinh tổng hợp từ Báo cáo Kiểm toán Nhà nước, 2023.

(2) Về điều tiết cung ứng dịch vụ bảo đảm an toàn hàng hải

Đối với dịch vụ hoa tiêu hàng hải, dưới sự điều tiết và giám sát của cơ quan quản lý nhà nước, hoạt động dẫn tàu đã phục hồi và tăng trưởng trở lại sau giai đoạn bị ảnh hưởng bởi dịch bệnh. Theo Quyết định số 143/QĐ-BXD, số lượt hoa tiêu dẫn tàu thực hiện năm 2025 đạt 79.307 lượt; chỉ tiêu định hướng năm 2026 được giao là 87.238 lượt (Bộ Xây dựng, 2026b). Điều này cho thấy nhu cầu dịch vụ tăng lên cùng với yêu cầu ngày càng cao về năng lực tổ chức điều độ và chất lượng cung ứng dịch vụ.

Đối với dịch vụ thông tin và thông báo hàng hải, thông qua cơ chế đặt hàng và phân bổ ngân sách nhà nước, hệ thống 29 đài thông tin duyên hải (do VISHIPEL vận hành) đã được duy trì trạng thái trực canh 24/7, thực hiện phát sóng chuẩn xác các bản tin an toàn hàng hải (MSI). Đồng thời, kế hoạch khảo sát định kỳ được triển khai nghiêm ngặt, hoàn thành 100% khối lượng tại 43 tuyến luồng công cộng và 15 vùng đón trả hoa tiêu trong năm 2025, bảo đảm cung cấp dữ liệu thủy văn tức thời cho các Cảng vụ hàng hải khu vực ban hành thông báo an toàn (Bộ Xây dựng, 2026a; Công ty TNHH MTV Thông tin Điện tử Hàng hải Việt Nam [VISHIPEL], 2026).

Đối với dịch vụ nạo vét duy tu luồng hàng hải công cộng, là hạng mục sử dụng ngân sách nhà nước có quy mô lớn trong toàn bộ hoạt động bảo trì kết cấu hạ tầng hàng hải. Dữ liệu kế hoạch và báo cáo tổng kết cho thấy kinh phí nạo vét duy tu đã tăng mạnh so với giai đoạn đầu kỳ, từ khoảng 700,2 tỷ đồng năm 2015 lên mức trên 1,8 nghìn tỷ đồng trong kế hoạch năm 2024; sau đó việc bố trí vốn tiếp tục được điều chỉnh theo cân đối ngân sách và yêu cầu ưu tiên các tuyến luồng trọng điểm (Bộ Xây dựng, 2026a). Cơ chế bố trí vốn theo năm tài khóa vẫn bộc lộ mâu thuẫn với đặc tính sa bồi liên tục của luồng, vì vậy nhu cầu xây dựng cơ chế nạo vét đa năm và quản trị rủi ro theo chu kỳ tài sản là rất rõ ràng (Bộ Xây dựng, 2026a).

[IMAGE]

Hình 2.7. Xu hướng kinh phí nạo vét duy tu luồng hàng hải giai đoạn 2015–2025

Nguồn: Tổng hợp và xử lý từ các quyết định giao dự toán, điều chỉnh kế hoạch của Bộ Giao thông vận tải (2014–2024) và Bộ Xây dựng (2025g). (số liệu cụ thể do nghiên cứu sinh tổng hợp)

Trong lĩnh vực tìm kiếm cứu nạn, cơ chế phối hợp liên ngành được thiết lập thông qua 4 trung tâm khu vực. Giai đoạn 2015–2021, lực lượng chuyên trách đã tổ chức điều phối và xử lý thành công trên 1.000 sự cố, cứu sống hàng nghìn sinh mạng (Bộ Xây dựng, 2026a; Trung tâm Phối hợp tìm kiếm, cứu nạn hàng hải Việt Nam [VMRCC], n.d.). Dẫu vậy, năng lực ứng phó khẩn nguy tại các vùng biển xa bờ vẫn bị giới hạn bởi sự thiếu hụt phương tiện chuyên dụng và cơ chế phối hợp tác chiến liên lực lượng chưa thực sự đồng bộ.

Bảng 2.11. Năng lực cung ứng dịch vụ hoa tiêu hàng hải (2019–2025)

[TABLE]

Nguồn: Tổng hợp dữ liệu quản lý vận hành từ các doanh nghiệp cung ứng dịch vụ.

(3) Về quản lý cơ sở đào tạo và đào tạo, cấp chứng chỉ nhân lực dịch vụ

Công tác quản lý nhà nước của Bộ Xây dựng đối với nội dung này được phản ánh qua hệ thống số liệu về nguồn nhân lực dịch vụ trong giai đoạn 2015–2025 do cơ quan quản lý chuyên ngành tổng hợp trong báo cáo tổng kết thi hành Bộ luật Hàng hải Việt Nam năm 2015 (Bộ Xây dựng, 2026a).

[IMAGE]

Hình 2.8. Biểu đồ tỷ trọng và cơ cấu nguồn nhân lực dịch vụ hàng hải giai đoạn 2015–2024

Số liệu giai đoạn 2015–2024 cho thấy nguồn nhân lực hàng hải có xu hướng tăng tương đối rõ, từ 44.720 người năm 2015 lên 65.033 người năm 2024. Trong đó, nhóm sỹ quan quản lý tăng từ 10.578 lên 14.247 người, nhóm sỹ quan vận hành duy trì ở mức trên 9 nghìn người, còn nhóm thủy thủ, thợ máy tăng mạnh từ 24.469 lên 41.247 người (Bộ Xây dựng, 2026a). Xu hướng này phản ánh hệ thống đào tạo và cấp chứng chỉ hàng hải đã góp phần mở rộng nền nhân lực phục vụ hoạt động dịch vụ, song cũng cho thấy yêu cầu tiếp tục hoàn thiện chính sách đào tạo theo hướng gắn chặt hơn giữa cơ cấu đầu ra và nhu cầu nhân lực của từng lĩnh vực dịch vụ.

[IMAGE]

Hình 2.9. Cơ cấu phân hạng hoa tiêu hàng hải Việt Nam hiện nay

Về hệ thống phân hạng nghề nghiệp và cấp chứng chỉ chuyên môn trong lĩnh vực hoa tiêu hàng hải, báo cáo tổng kết cho thấy cả nước có 473 hoa tiêu các hạng, gồm 229 ngoại hạng, 70 hạng nhất, 79 hạng II, 61 hạng III và 34 tập sự; lực lượng này đang thực hiện dẫn tàu trên 185 tuyến thuộc 8 vùng hoa tiêu hàng hải bắt buộc (Bộ Xây dựng, 2026a). Số liệu này cho thấy Nhà nước không chỉ duy trì được lực lượng có chứng chỉ hành nghề, mà còn từng bước chuẩn hóa năng lực theo cấp độ chuyên môn để đáp ứng yêu cầu dẫn tàu tại các vùng nước có mức độ phức tạp khác nhau.

Đối với lực lượng kiểm tra tàu biển, báo cáo tổng kết cho thấy hiện có 175 sỹ quan kiểm tra tàu biển, gồm 63 sỹ quan kiểm tra tàu biển Việt Nam và 112 sỹ quan kiểm tra cảng biển. Từ năm 2017 đến ngày 21/10/2024, lực lượng này đã thực hiện khối lượng công việc rất lớn đối với tàu VR-SB, tàu nội địa, tàu chạy tuyến quốc tế và tàu nước ngoài; riêng hoạt động kiểm tra tàu biển nước ngoài đã ghi nhận 30 lượt tàu bị lưu giữ (Bộ Xây dựng, 2026a). Điều đó cho thấy hiệu quả quản lý không thể đánh giá chỉ bằng số lượng nhân lực được đào tạo hay được cấp chứng chỉ, mà phải xem xét cả khả năng chuyển hóa năng lực chuyên môn thành kết quả thực thi công vụ.

(4) Về ứng dụng công nghệ trong tổ chức thực hiện quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

Nhờ cải cách thủ tục hành chính và mở rộng xử lý hồ sơ trên môi trường điện tử, đến cuối năm 2025, 100% thủ tục hành chính được tiếp nhận qua Hệ thống thông tin một cửa điện tử của Bộ Xây dựng (Cổng Thông tin điện tử Chính phủ, 2025). Tuy nhiên, dữ liệu vận hành chuyên ngành vẫn chưa được liên kết liền mạch giữa các hệ thống như VTS, AIS, LRIT, SAR và các lực lượng thực thi trên biển. Vì vậy, công nghệ hiện mới phát huy rõ nhất ở khâu xử lý hành chính, trong khi điều hành tác nghiệp theo thời gian thực vẫn thiếu đồng bộ (Bộ Xây dựng, 2025b, 2025d; Bộ Xây dựng, 2026a). Thực trạng này cho thấy khoảng cách lớn giữa mục tiêu chuyển đổi số và năng lực thực thi hiện nay.

Tóm lại, thực trạng quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải giai đoạn 2015–2025 cho thấy quá trình tổ chức thực hiện đã có chuyển dịch nhất định từ cơ chế giao nhiệm vụ, giao dự toán sang các phương thức quản lý gắn với đặt hàng, đấu thầu và kiểm soát đầu ra. Tuy nhiên, sự chuyển dịch này diễn ra chưa đồng đều giữa các nhóm dịch vụ; khoảng cách giữa yêu cầu vận hành linh hoạt của dịch vụ bảo đảm an toàn hàng hải với cơ chế điều hành hành chính hiện nay vẫn còn tương đối rõ, qua đó ảnh hưởng trực tiếp đến kết quả hệ thống và khả năng cung ứng dịch vụ.

2.2.2.3. Giám sát, đánh giá chất lượng dịch vụ bảo đảm an toàn hàng hải

Trong quản lý nhà nước đối với dịch vụ, kiểm tra và giám sát chất lượng là khâu kiểm soát đầu ra và duy trì kỷ cương của thị trường dịch vụ bảo đảm an toàn hàng hải. Trọng tâm của khâu này không dừng ở việc kiểm tra hồ sơ hay sự tuân thủ hình thức, mà phải hướng tới giám sát được chất lượng thực tế của dịch vụ, phát hiện và xử lý kịp thời sai phạm, gắn chặt giám sát với nghiệm thu, thanh toán, chế tài và điều chỉnh chính sách. Do đó, giai đoạn 2015–2025 cần được xem xét qua các phương diện như giám sát theo cam kết chất lượng, nghiệm thu và thanh quyết toán, thanh tra năng lực thực tế của đơn vị cung ứng, đánh giá sự hài lòng và xếp hạng nhà cung cấp, cùng với xử lý vi phạm và cưỡng chế thực thi.

(1) Giám sát chất lượng dịch vụ bảo đảm an toàn hàng hải qua tuân thủ cam kết KPI/SLA

Công tác được Bộ triển khai thông qua Cục Hàng hải và Đường thủy Việt Nam và các Cảng vụ hàng hải chủ yếu thực hiện giám sát thông qua việc xét duyệt hồ sơ, báo cáo định kỳ hoặc các đoàn thanh tra theo kế hoạch báo trước. Tư duy giám sát dựa trên tuân thủ quy trình (giám sát vẫn nặng tính thủ công và hành chính hóa) vẫn chiếm ưu thế áp đảo so với tư duy giám sát dựa trên hiệu quả thực tế. Điều này dẫn đến một nghịch lý là mặc dù số lượng các cuộc thanh tra, kiểm tra tăng đều qua các năm, nhưng phần lớn các lỗi vi phạm được phát hiện chỉ dừng lại ở lỗi hành chính, giấy tờ, trong khi các vi phạm về chất lượng dịch vụ thực tế (như độ sâu luồng không đạt, thời gian khắc phục sự cố chậm) lại ít được công khai hoặc xử lý triệt để.

Phân tích số liệu từ Bảng 2.12 dưới đây cho thấy một thực trạng đáng chú ý là tỷ trọng các vi phạm hành chính (như thiếu nhật ký thi công, chậm báo cáo, sai mẫu biểu) luôn chiếm áp đảo từ 76% đến 88% tổng số lỗi phát hiện. Trong khi đó, các vi phạm trực tiếp ảnh hưởng đến an toàn hàng hải và hiệu quả khai thác (như phương tiện thi công không đảm bảo thông số kỹ thuật, nạo vét không đúng chuẩn tắc, thả phao sai vị trí) chỉ chiếm tỷ lệ khiêm tốn dưới 25%. Điều này không đồng nghĩa với việc chất lượng dịch vụ đã hoàn hảo, mà phản ánh năng lực phát hiện lỗi kỹ thuật của cơ quan giám sát còn hạn chế. Do thiếu các công cụ quan trắc tự động và dữ liệu thời gian thực, cán bộ thanh tra thường có xu hướng tập trung vào phát hiện sai sót về hồ sơ thủ tục, văn bản – những lỗi dễ nhìn thấy bằng mắt thường, thay vì đi sâu vào đánh giá các chỉ số hiệu năng kỹ thuật phức tạp.

Bảng 2.12. Tổng hợp kết quả thanh tra, kiểm tra chuyên ngành đối với doanh nghiệp cung ứng dịch vụ hàng hải (2019–2023)

[TABLE]

Nguồn: NCS tổng hợp từ Báo cáo tổng kết công tác Thanh tra ngành Giao thông vận tải và Cục Hàng hải Việt Nam các năm 2019, 2020, 2021, 2022, 2023.

Hệ quả của phương thức giám sát này là tính răn đe của chế tài xử lý chưa cao. Tỷ lệ xử phạt vi phạm hành chính trên tổng số lỗi phát hiện chỉ dao động quanh mức 30-40%, phần còn lại chủ yếu được xử lý bằng hình thức nhắc nhở hoặc yêu cầu khắc phục. Việc thiếu vắng các chế tài kinh tế mạnh (như trừ tiền nghiệm thu, đình chỉ tham gia đấu thầu) đối với các vi phạm chất lượng dịch vụ đã tạo ra tâm lý nhờn luật ở một bộ phận đơn vị cung ứng.

(2) Về giám sát nghiệm thu và thanh quyết toán dịch vụ bảo đảm an toàn hàng hải

Giai đoạn 2019–2025, công tác giám sát nghiệm thu và thanh quyết toán dịch vụ từng bước được thể chế hóa rõ hơn thông qua Thông tư số 42/2019/TT-BGTVT và Thông tư số 40/2023/TT-BGTVT (Bộ Giao thông vận tải, 2019; Bộ Giao thông vận tải, 2023b). Xét về phương diện pháp lý, đây là bước chuyển từ kiểm tra hành chính thuần túy sang giám sát có tiêu chí và có căn cứ nghiệm thu chất lượng. Tuy vậy, việc giám sát theo thời gian thực và gắn trực tiếp thanh toán với kết quả đầu ra vẫn chưa được triển khai đồng đều trên toàn hệ thống.

Đối với các dịch vụ thiết yếu như nạo vét duy tu và bảo trì báo hiệu, đèn biển, luồng hàng hải, công tác giám sát đã có bước tiến đáng kể về công nghệ. Việc Chính phủ ban hành Nghị định số 57/2024/NĐ-CP và Bộ Giao thông vận tải ban hành Thông tư số 43/2024/TT-BGTVT đã tạo cơ sở pháp lý cho tăng cường giám sát thời gian thực thông qua thiết bị nhận dạng tự động, camera hành trình và dữ liệu vị trí phương tiện thi công (Bộ Giao thông vận tải, 2022; Chính phủ nước CHXHCN Việt Nam, 2024). Sự thay đổi này góp phần giảm phụ thuộc vào hồ sơ thủ công và tăng khả năng truy vết trong quá trình nghiệm thu.

(3) Về thanh tra năng lực thực tế và tuân thủ quy định tại cảng biển

Mặc dù hệ thống văn bản quy phạm pháp luật về quản lý cảng biển đã được thiết lập tương đối đầy đủ, kết quả thanh tra thực tế tại doanh nghiệp vẫn bộc lộ khoảng trống lớn trong tuân thủ quy định về bảo trì kết cấu hạ tầng và quản lý giá dịch vụ. Minh chứng điển hình là Kết luận thanh tra số 39/KL-TTr ngày 24/10/2025 đối với Công ty Cảng Container Trung tâm Sài Gòn (SPCT), trong đó cơ quan thanh tra chỉ ra các sai phạm liên quan đến khảo sát độ sâu vùng nước, kế hoạch và báo cáo bảo trì, cũng như việc quan trắc công trình bến cảng trong quá trình khai thác (Bộ Giao thông vận tải, 2022; Thanh tra, 2025).

Không những vậy, công tác giám sát của cơ quan quản lý nhà nước trực tiếp tại khu vực cũng bị đánh giá là thiếu chặt chẽ khi chưa kịp thời phát hiện các sai sót trong kê khai giá dịch vụ và sự thiếu hụt nội dung phòng ngừa ô nhiễm môi trường trong biên bản kiểm tra định kỳ. Trường hợp của SPCT phản ánh một thực tế rằng, năng lực thực thi và giám sát tuân thủ ở cấp cơ sở vẫn còn khoảng cách lớn so với yêu cầu, dẫn đến tình trạng các quy định chưa được thực hiện nghiêm túc, tiềm ẩn rủi ro mất an toàn hàng hải.

(4) Về công tác đánh giá sự hài lòng và xếp hạng nhà cung cấp

Bên cạnh các vấn đề về giám sát kỹ thuật, công tác quản lý chất lượng dịch vụ hỗ trợ như hoa tiêu, lai dắt cũng đang tồn tại bất cập về cơ chế sàng lọc thị trường. Hiện chưa có một hệ thống chính thức để đánh giá mức độ hài lòng của khách hàng và xếp hạng tín nhiệm các doanh nghiệp cung ứng dịch vụ trên cơ sở dữ liệu vận hành.

Kết quả phỏng vấn chuyên gia của luận án cho thấy cơ chế quản lý hiện nay vẫn thiên về đánh giá năng lực “tĩnh” thông qua hồ sơ pháp lý và chứng chỉ, trong khi lịch sử an toàn, chất lượng phục vụ và phản hồi của người sử dụng chưa trở thành căn cứ giám sát thường xuyên. Điều này làm giảm động lực cạnh tranh nâng cao chất lượng dịch vụ.

(5) Về công tác xử lý vi phạm và cưỡng chế thực thi.

Công tác xử lý vi phạm và cưỡng chế thực thi giữ vai trò răn đe cuối cùng để bảo vệ kỷ cương thị trường. Mặc dù hệ thống chế tài xử phạt vi phạm hành chính đã được thiết lập, nhưng hiệu lực răn đe trong thực tế vẫn chưa đồng đều. Các báo cáo tổng kết và kết luận thanh tra cho thấy vẫn còn những trường hợp vi phạm về giá dịch vụ, bảo trì hạ tầng, môi trường hoặc hồ sơ quản lý bị phát hiện muộn hoặc xử lý chưa triệt để, một phần do lo ngại ảnh hưởng đến tính liên tục của chuỗi cung ứng dịch vụ tại cảng biển (Bộ Xây dựng, 2026a; Thanh tra, 2025).

Nhìn tổng thể, giai đoạn 2015–2025 cho thấy khung thể chế về kiểm tra, giám sát chất lượng dịch vụ bảo đảm an toàn hàng hải đã chuyển dần từ logic kiểm soát thủ tục sang tiếp cận quản lý theo kết quả. Việc ban hành các quy định về tiêu chí giám sát, nghiệm thu, giá dịch vụ sự nghiệp công và cơ chế đặt hàng không chỉ hoàn thiện căn cứ pháp lý cho hoạt động kiểm tra mà còn bước đầu liên kết giám sát với phân bổ tài chính, lựa chọn đơn vị cung ứng và đánh giá chất lượng dịch vụ. Tuy nhiên, sự hoàn thiện về quy định chưa đồng nghĩa với sự chuyển biến tương ứng về năng lực giám sát thực tế. Phương thức giám sát hiện hành vẫn chủ yếu dựa vào hậu kiểm và nghiệm thu hồ sơ, trong khi giám sát liên tục theo dữ liệu thời gian thực, theo chất lượng đầu ra và theo mức độ hoàn thành cam kết dịch vụ còn hạn chế. Vì vậy, khoảng cách giữa yêu cầu quản lý chất lượng dịch vụ với năng lực kiểm soát thực thi vẫn còn khá rõ. Xét từ góc độ hiệu lực quản lý nhà nước, đây vẫn là khâu yếu trên trục quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải. Sự thiếu vắng cơ chế đánh giá tín nhiệm doanh nghiệp, công cụ giám sát hiệu suất dựa trên dữ liệu thực và chế tài cưỡng chế đủ mạnh khiến hoạt động kiểm tra, giám sát chưa tạo được áp lực cải thiện chất lượng một cách thực chất, đặc biệt trong quản lý doanh nghiệp cảng và các dịch vụ hỗ trợ. Do đó, vấn đề đặt ra không chỉ là tiếp tục bổ sung quy định, mà quan trọng hơn là chuyển trọng tâm từ kiểm tra tuân thủ hình thức sang giám sát đầu ra, giám sát rủi ro và giám sát dựa trên bằng chứng, qua đó nâng cao hiệu lực quản lý nhà nước và chất lượng dịch vụ bảo đảm an toàn hàng hải.

2.3. ĐÁNH GIÁ ĐỊNH LƯỢNG CÁC YẾU TỐ ẢNH HƯỞNG TỚI KẾT QUẢ QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM

2.3.1. Thiết kế mô hình nghiên cứu

Để bổ sung bằng chứng định lượng cho phần phân tích ở mục 2.2, trên cơ sở khung phân tích 2×3, luận án sử dụng mô hình hồi quy tuyến tính bội (multiple linear regression model) với hệ số beta chuẩn hóa để kiểm định mức độ tác động của sáu biến độc lập H1, H2, H3, D1, D2 và D3 đến biến phụ thuộc Y. Về bản chất, đây là mô hình hồi quy được ước lượng trên các biến nghiên cứu tính từ thang đo Likert 5 mức; vì vậy, trong mục này luận án sử dụng cách gọi trực tiếp là mô hình hồi quy tuyến tính bội nhằm tránh gây hiểu nhầm về kỹ thuật ước lượng. Phương trình nghiên cứu được viết như sau: Y = β0 + β1H1 + β2H2 + β3H3 + β4D1 + β5D2 + β6D3 + ε (Hair et al., 2010; Hair et al., 2019; Kline, 2016).

Liên kết giữa câu hỏi khảo sát và các biến nghiên cứu được khái quát như sau. Cụ thể, H1 được tính từ 13 chỉ báo thuộc các nhóm B1, B6, X1 và X5; H2 được tính từ 21 chỉ báo thuộc các nhóm B2, B5, B7, X2, X4 và X6; H3 được tính từ 3 chỉ báo thuộc nhóm B3; D1 được tính từ 2 chỉ báo S1 và S2; D2 được tính từ 8 chỉ báo thuộc nhóm B4 và X3; D3 được tính từ 2 chỉ báo S3 và S4; Y được tính từ 10 chỉ báo Y1–Y10. Các ký hiệu B, S, X và Y là mã nhóm câu hỏi trong bảng hỏi, không phải là các biến độc lập của phương trình hồi quy. Trên cơ sở mô hình nghiên cứu, các giả thuyết được phát biểu như sau:

GT1: Chất lượng ban hành trong quản lý hệ thống bảo đảm an toàn hàng hải (H1) tác động tích cực đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải (Y).

GT2: Chất lượng tổ chức thực hiện trong quản lý hệ thống bảo đảm an toàn hàng hải (H2) tác động tích cực đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải (Y).

GT3: Chất lượng giám sát trong quản lý hệ thống bảo đảm an toàn hàng hải (H3) tác động tích cực đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải (Y).

GT4: Chất lượng ban hành trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải (D1) tác động tích cực đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải (Y).

GT5: Chất lượng tổ chức thực hiện trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải (D2) tác động tích cực đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải (Y).

GT6: Chất lượng giám sát trong quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải (D3) tác động tích cực đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải (Y).

[IMAGE]

Hình 2.10. Mô hình hồi quy tuyến tính bội theo khung 2×3.

Nguồn: Nghiên cứu sinh đề xuất, 2025.

2.3.2. Dữ liệu nghiên cứu

Mẫu khảo sát phục vụ phân tích định lượng gồm 250 phiếu hợp lệ. Quy mô này bảo đảm số quan sát cần thiết để kiểm định độ tin cậy của thang đo, tính giá trị trung bình cho các biến nghiên cứu và ước lượng mô hình hồi quy tuyến tính bội. Cơ cấu mẫu phản ánh khá đầy đủ các góc nhìn quản trị từ ba nhóm chủ đạo: nhóm quản lý nhà nước, nhóm cung ứng dịch vụ và nhóm sử dụng dịch vụ hoặc chịu tác động. Chi tiết phân bố theo giới tính, độ tuổi, vai trò công tác và thâm niên làm việc được trình bày tại Hình 2.11 và dữ liệu khảo sát của luận án.

Dữ liệu được thu thập từ tháng 3 đến tháng 5 năm 2025 theo phương pháp chọn mẫu thuận tiện kết hợp có chủ đích, nhằm bảo đảm sự tham gia của các nhóm đối tượng liên quan trực tiếp đến quản lý nhà nước về bảo đảm an toàn hàng hải. Địa bàn khảo sát trải rộng trên cả ba miền Bắc, Trung và Nam. Người trả lời gồm cán bộ quản lý nhà nước, doanh nghiệp cảng biển, logistics, dịch vụ hàng hải, lực lượng hoa tiêu, dịch vụ quản lý giao thông tàu thuyền, thuyền viên và giảng viên, nhà nghiên cứu (Creswell & Plano Clark, 2018; Palinkas et al., 2015).

[IMAGE]

Hình 2.11. Cơ cấu mẫu khảo sát phân bổ theo giới tính, độ tuổi, vai trò công tác và thâm niên làm việc (N=250 mẫu)

Nguồn: Kết quả khảo sát của nghiên cứu sinh, 2025.

Về xử lý dữ liệu, bộ số liệu được làm sạch, kiểm tra tính hợp lệ và mã hóa thống nhất trước khi phân tích. Các câu hỏi đảo chiều được quy đổi theo công thức 6 - x. Sau đó, các biến H1, H2, H3, D1, D2, D3 và Y được tính bằng giá trị trung bình của các chỉ báo hợp lệ thuộc từng biến; các biến độc lập tiếp tục được chuẩn hóa để ước lượng hệ số beta chuẩn hóa trong mô hình hồi quy tuyến tính bội.

2.3.3. Kết quả phân tích mô hình nghiên cứu

2.3.3.1. Kiểm định độ tin cậy của thang đo và xây dựng biến nghiên cứu

Luận án sử dụng hệ số Cronbach’s Alpha để đánh giá độ tin cậy nội tại của các thang đo trước khi tính giá trị trung bình cho từng biến H1, H2, H3, D1, D2, D3 và Y. Cách xử lý này phù hợp với cấu trúc dữ liệu khảo sát và mục tiêu ước lượng mô hình hồi quy tuyến tính bội (Hair et al., 2010).

Bảng 2.13. Độ tin cậy của các thang đo tổng hợp trong mô hình định lượng

[TABLE]

Nguồn: Kết quả phân tích định lượng qua khảo sát bằng bảng hỏi (N=250), năm 2025.

Kết quả ở Bảng 2.13 cho thấy các thang đo H1, H2, D2 và Y đạt độ tin cậy tốt; H3 đạt mức chấp nhận được; D1 và D3 có hệ số alpha thấp hơn nhưng vẫn có thể sử dụng trong nghiên cứu ứng dụng do số lượng chỉ báo ít và nội dung đo lường tương đối tập trung. Trên cơ sở đó, luận án giữ lại toàn bộ bảy thang đo để tính các biến nghiên cứu cho mô hình định lượng chính thức.

2.3.3.2. Ma trận tương quan giữa các cấu phần và kiểm tra đa cộng tuyến

Sau khi tính giá trị trung bình cho các biến H1, H2, H3, D1, D2, D3 và Y, luận án kiểm tra tương quan Pearson và chỉ số VIF để đánh giá nguy cơ đa cộng tuyến trước khi ước lượng mô hình. Kết quả được trình bày tại Bảng 2.14.

Bảng 2.14. Ma trận tương quan Pearson giữa các biến nghiên cứu và chỉ số VIF

[TABLE]

Nguồn: Kết quả phân tích định lượng qua khảo sát bằng bảng hỏi (N = 250), năm 2025.

Bảng 2.14 cho thấy Y có tương quan dương với cả sáu biến độc lập, trong đó mức tương quan cao nhất thuộc về H2 (r = 0,800) và H1 (r = 0,767). Các hệ số VIF dao động từ 1,330 đến 2,021, thấp hơn ngưỡng thường được sử dụng trong nghiên cứu thực nghiệm, cho thấy mô hình không có dấu hiệu đa cộng tuyến nghiêm trọng. Điều này cho phép tiếp tục ước lượng mô hình hồi quy tuyến tính bội theo khung 2×3 (Hair et al., 2010; Kline, 2016).

2.3.3.3. Kết quả kiểm định giả thuyết nghiên cứu

Sau khi tính giá trị trung bình của các chỉ báo cho từng biến, luận án ước lượng mô hình bằng phương pháp hồi quy tuyến tính bội với hệ số beta chuẩn hóa (standardized beta coefficients) và kiểm định 6 giả thuyết nghiên cứu. Kết quả cho thấy mô hình giải thích được 77,6% (R² = 0,776) sự biến thiên của biến Y. Hệ số xác định hiệu chỉnh đạt 0,770; kiểm định F của toàn mô hình có ý nghĩa thống kê ở mức p < 0,001. Đây là mức giải thích khá cao đối với một nghiên cứu quản lý nhà nước sử dụng dữ liệu khảo sát thu thập tại một thời điểm.

Bảng 2.15. Kết quả ước lượng mô hình hồi quy tuyến tính bội theo khung 2×3

[TABLE]

Nguồn: Kết quả phân tích định lượng qua khảo sát bằng bảng hỏi (N=250), năm 2025.

Kết quả ở Bảng 2.15 cho thấy bốn biến có tác động dương và có ý nghĩa thống kê đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải, bao gồm: H2, H1, D2 và D3. Trong đó, H2 có hệ số tác động chuẩn hóa lớn nhất (β = 0,438), tiếp đến là H1 (β = 0,348), D2 (β = 0,152) và D3 (β = 0,088). Ngược lại, H3 và D1 không có ý nghĩa thống kê trong mô hình tổng thể, mặc dù hệ số tác động vẫn mang dấu dương.

2.3.4. Thảo luận về kết quả nghiên cứu

Kết quả định lượng cho thấy kết quả quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam chịu tác động rõ rệt nhất từ chất lượng tổ chức thực hiện trong quản lý hệ thống (H2). Điều này hàm ý rằng, trong một lĩnh vực có tính liên thông cao, kết quả quản lý không phụ thuộc chủ yếu vào việc có quy định hay không, mà phụ thuộc nhiều hơn vào khả năng chuyển hóa quy định thành hoạt động vận hành, phối hợp và triển khai trên thực tế.

Đứng thứ hai về mức độ tác động là chất lượng ban hành trong quản lý hệ thống (H1). Kết quả này khẳng định vai trò nền tảng của thể chế, quy hoạch, kế hoạch và tiêu chuẩn đối với toàn bộ chu trình quản lý. Tuy nhiên, hệ số của H1 thấp hơn H2 cho thấy ban hành là điều kiện cần, còn hiệu lực quản lý thực chất vẫn phụ thuộc lớn hơn vào chất lượng tổ chức thực hiện.

Ở trục quản lý cung ứng dịch vụ, biến D2 có tác động dương và có ý nghĩa thống kê, phản ánh vai trò của cơ chế điều phối cung ứng, chuẩn hóa năng lực chủ thể và kiểm soát quá trình thực hiện dịch vụ. Đồng thời, biến D3 cũng có tác động dương, dù mức tác động khiêm tốn hơn, cho thấy công tác đánh giá chất lượng đầu ra và điều tiết chất lượng dịch vụ vẫn là một kênh cải thiện kết quả quản lý quan trọng.

Ngược lại, giám sát hệ thống (H3) và ban hành dịch vụ (D1) không có ý nghĩa thống kê trong mô hình tổng thể. Kết quả này không phủ định vai trò lý thuyết của hai khâu này, mà gợi ý rằng trong điều kiện nghiên cứu hiện nay, giám sát hệ thống vẫn chưa đủ mạnh để tạo ra khác biệt độc lập rõ rệt; đồng thời cơ chế ban hành đối với dịch vụ bảo đảm an toàn hàng hải vẫn chưa vận hành như một đòn bẩy điều tiết đủ mạnh để chuyển hóa trực tiếp thành kết quả quản lý.

Từ đó có thể rút ra một hàm ý trọng tâm cho Chương 2: ưu tiên cải cách nên tập trung vào nâng cao năng lực tổ chức thực hiện đối với hệ thống bảo đảm an toàn hàng hải, đồng thời tiếp tục hoàn thiện chất lượng ban hành ở trục hệ thống và cải thiện cơ chế tổ chức thực hiện, giám sát chất lượng ở trục dịch vụ. Đây là hướng đi phù hợp với kết quả định lượng của mô hình chính thức.

2.4. ĐÁNH GIÁ CHUNG THỰC TRẠNG QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM, GIAI ĐOẠN 2015–2025

Trong phạm vi nghiên cứu của luận án, các thành tựu quản lý đạt được và hạn chế trong quản lý sau đây tập trung vào hoạt động quản lý nhà nước của Bộ Xây dựng (trước tháng 3/2025 là Bộ Giao thông vận tải, sau đây gọi chung là Bộ) đối với công tác bảo đảm an toàn hàng hải. Các chủ thể khác như Chính phủ, các bộ, ngành, địa phương và lực lượng phối hợp được xem là chủ thể liên quan, không phải đối tượng phân tích trực tiếp của mục 2.4 này.

2.4.1. Thành tựu quản lý đạt được

2.4.1.1. Thành tựu về tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải

Một là, trong khâu ban hành đối với trục hệ thống, Bộ Xây dựng đã từng bước hoàn thiện khung pháp lý và tiêu chuẩn kỹ thuật cho hệ thống bảo đảm an toàn hàng hải theo hướng ngày càng đồng bộ hơn với yêu cầu phát triển của ngành và tiệm cận gần hơn với các thông lệ, quy chuẩn quốc tế. Xét về bản chất quản lý nhà nước, thành tựu này không chỉ là sự gia tăng về số lượng văn bản, mà quan trọng hơn là Bộ đã tạo lập được nền tảng thể chế tương đối rõ cho quản lý báo hiệu, luồng hàng hải, thông tin hàng hải và các cấu phần hạ tầng liên quan. Nhờ đó, hoạt động đầu tư, vận hành và bảo trì hệ thống có cơ sở pháp lý chặt chẽ hơn, mức độ phối hợp giữa các chủ thể thực thi được cải thiện, đồng thời vị thế và khả năng hội nhập của hệ thống bảo đảm an toàn hàng hải Việt Nam cũng từng bước được nâng lên (Bộ Xây dựng, 2026a; IMO, 1973/1978; IMO, 1974).

Hai là, trong khâu tổ chức thực hiện, Bộ đã kiện toàn bộ máy thực thi và duy trì mô hình doanh nghiệp công ích trong lĩnh vực bảo đảm an toàn hàng hải, qua đó hỗ trợ vận hành tương đối đồng bộ hệ thống báo hiệu, luồng tuyến và hạ tầng thiết yếu. Điều đáng ghi nhận ở đây không chỉ là sự ổn định về mặt tổ chức, mà là việc Bộ đã duy trì được một cơ chế thực thi tương đối thống nhất từ khâu chỉ đạo, phân công đến vận hành thực tế. Thành tựu này phản ánh rõ hơn năng lực tổ chức thực hiện của chủ thể quản lý, bởi hệ thống chỉ có thể vận hành an toàn và thông suốt khi bộ máy thực thi đủ khả năng chuyển hóa yêu cầu thể chế thành kết quả vận hành cụ thể (Bộ Xây dựng, 2025a, 2025e, 2025f; Chính phủ nước CHXHCN Việt Nam, 2025b, 2025e).

Ba là, Bộ đã chỉ đạo đầu tư, duy tu, bảo trì và vận hành hệ thống bảo đảm an toàn hàng hải theo hướng gắn chặt hơn với yêu cầu an toàn, thông suốt và hội nhập. Xét từ góc độ quản lý nhà nước, kết quả này cho thấy Bộ không chỉ dừng ở vai trò ban hành quy định, mà đã từng bước chuyển hóa các định hướng chính sách và chuẩn kỹ thuật thành năng lực vận hành thực tế của hệ thống. Việc cải thiện mức độ sẵn sàng vận hành của nhiều cấu phần hệ thống, nâng cao khả năng phục vụ tàu thuyền trên các tuyến luồng trọng điểm và bảo đảm tính liên tục của các công trình hàng hải cho thấy chất lượng điều hành hệ thống đã có chuyển biến theo hướng chủ động hơn, thay vì chỉ xử lý khi phát sinh vấn đề (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025c; IALA, 2017a).

Bốn là, Bộ đã thúc đẩy ứng dụng công nghệ và từng bước đẩy mạnh số hóa trong quản lý hệ thống bảo đảm an toàn hàng hải, nhất là ở các khâu thông tin, giám sát và điều hành. Ý nghĩa quản lý của thành tựu này nằm ở chỗ phương thức quản lý đã bắt đầu dịch chuyển từ dựa chủ yếu vào thủ tục hành chính sang kết hợp ngày càng rõ hơn với dữ liệu và công nghệ. Đây là bước tiến quan trọng, bởi trong điều kiện ngành hàng hải phát triển nhanh, yêu cầu quản lý hiện đại không chỉ là có quy định đầy đủ, mà còn là có khả năng quan sát hệ thống tốt hơn, hỗ trợ ra quyết định nhanh hơn và nâng cao tính minh bạch trong điều hành (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025c).

Năm là, thông qua việc đồng thời thực hiện các chức năng ban hành, tổ chức thực hiện và duy trì kiểm soát đối với hệ thống, Bộ đã góp phần tạo ra chuyển biến tích cực về an toàn hàng hải. Thành tựu này cần được hiểu như kết quả quản lý tổng hợp của chủ thể nghiên cứu, thể hiện ở sự cải thiện về tính ổn định, độ tin cậy và mức độ an toàn của hệ thống, dù vẫn có sự hỗ trợ của các chủ thể phối hợp khác. Trên phương diện rộng hơn, kết quả đó không chỉ góp phần làm cho môi trường hàng hải trở nên an toàn và tin cậy hơn, mà còn tạo nền tảng thuận lợi hơn cho hội nhập, cạnh tranh và phát triển bền vững của ngành hàng hải Việt Nam (Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025c).

2.4.1.2. Thành tựu về quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

Một là, trong khâu ban hành đối với trục dịch vụ, Bộ đã duy trì và từng bước mở rộng khuôn khổ quản lý đối với cung ứng dịch vụ bảo đảm an toàn hàng hải theo diễn biến thực tiễn của ngành, bao gồm cả các dịch vụ thông tin, giám sát và hỗ trợ kỹ thuật số. Xét về phương diện quản lý nhà nước, thành tựu này cho thấy Bộ không chỉ theo kịp sự mở rộng của phạm vi dịch vụ, mà còn từng bước củng cố vai trò điều tiết đối với một lĩnh vực có tính kỹ thuật cao và chịu tác động mạnh của chuyển đổi số. Việc hoàn thiện dần các quy định liên quan đã góp phần nâng cao tính minh bạch, đồng bộ và khả năng phối hợp trong quản lý, đồng thời tạo cơ sở cho việc định hướng chất lượng dịch vụ phù hợp hơn với yêu cầu của hoạt động hàng hải hiện đại (Bộ Xây dựng, 2025g, 2025h; Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2025c, 2025d).

Hai là, Bộ đã tổ chức, quản lý và kiểm soát hoạt động hoa tiêu hàng hải theo hướng ngày càng chuyên nghiệp hơn, từ khâu tổ chức mạng lưới, phân công dẫn tàu đến kiểm soát điều kiện hành nghề và phối hợp tác nghiệp. Thành tựu ở đây không chỉ là sự chuyển biến về mặt tổ chức hay chất lượng chuyên môn của riêng lực lượng hoa tiêu, mà sâu hơn là việc Bộ đã từng bước thiết lập được một cơ chế quản lý tương đối ổn định đối với một dịch vụ đặc thù, có rủi ro cao và tác động trực tiếp đến an toàn tàu thuyền. Điều đó phản ánh rõ năng lực của cơ quan quản lý nhà nước trong việc duy trì trật tự, kỷ luật và chất lượng cung ứng của một dịch vụ cốt lõi trong chuỗi bảo đảm an toàn hàng hải (Bộ Xây dựng, 2025h; Bộ Xây dựng, 2026a).

Ba là, trong khâu giám sát và điều tiết dịch vụ, Bộ đã chỉ đạo duy trì hoạt động của các dịch vụ bảo đảm an toàn hàng hải thiết yếu, đồng thời từng bước gắn quản lý dịch vụ với yêu cầu chất lượng, an toàn và trách nhiệm giải trình. Xét theo góc độ quản lý nhà nước, đây là bước chuyển có ý nghĩa vì thực tế cho thấy hoạt động điều tiết dịch vụ không chỉ dừng ở việc bảo đảm dịch vụ được cung ứng liên tục, mà đã bắt đầu hướng tới kiểm soát đầu ra và rủi ro dịch vụ. Nhờ đó, chất lượng cung ứng dịch vụ có chuyển biến tích cực hơn, đáp ứng tốt hơn yêu cầu của chủ tàu, thuyền viên và doanh nghiệp vận tải biển, đồng thời củng cố vai trò của Nhà nước trong việc duy trì sự an toàn và thông suốt của hoạt động hàng hải (Bộ Giao thông vận tải, 2019; Bộ Giao thông vận tải, 2023b; Bộ Xây dựng, 2026a; OECD, 2019b).

2.4.2. Hạn chế trong quản lý

2.4.2.1. Hạn chế về tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải

Một là, trong khâu ban hành đối với trục hệ thống, Bộ chưa khắc phục triệt để tình trạng chồng chéo, thiếu đồng bộ giữa một số quy định pháp luật, tiêu chuẩn kỹ thuật và cơ chế quản lý. Hạn chế này thể hiện không phải ở chỗ Bộ thiếu văn bản, mà ở chỗ một số văn bản do Bộ tham mưu hoặc ban hành chưa tạo được khuôn khổ điều tiết đủ rõ và đủ đồng bộ cho toàn bộ quá trình quản lý hệ thống. Một số nội dung quan trọng như nạo vét luồng lạch, quản lý tài sản kết cấu hạ tầng hàng hải, quản trị dữ liệu, chuẩn KPI/SLA và điều tiết rủi ro liên ngành còn chưa được quy định đầy đủ hoặc chưa theo kịp yêu cầu phát triển mới. Kết quả là, trong quá trình tổ chức thực hiện, các cơ quan thuộc Bộ và các đơn vị thực thi vẫn gặp khó khăn khi áp dụng quy định vào các tình huống cụ thể, nhất là các tình huống đòi hỏi phối hợp liên ngành, xử lý theo thời gian thực hoặc ra quyết định trên cơ sở dữ liệu. Điều đó cho thấy hạn chế của Bộ ở đây không chỉ là độ trễ cập nhật thể chế, mà còn là chất lượng kết nối giữa khâu ban hành với yêu cầu điều hành thực tế của hệ thống bảo đảm an toàn hàng hải (Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2017; Chính phủ nước CHXHCN Việt Nam, 2025c, 2025d).

Hai là, trong khâu tổ chức thực hiện đối với trục hệ thống, Bộ chưa xử lý dứt điểm các điểm nghẽn về hạ tầng, công nghệ, nguồn nhân lực và nguồn lực bảo trì. Thông qua các cơ quan chuyên ngành và các đơn vị thuộc hệ thống thực thi, Bộ đã tổ chức đầu tư, duy tu, bảo trì và vận hành hệ thống báo hiệu, luồng hàng hải, VTS, AIS và các cấu phần hạ tầng thiết yếu; tuy nhiên, việc tổ chức thực hiện ở một số khâu vẫn còn chậm, chưa đồng đều và chưa gắn kết chặt với quản trị vòng đời tài sản. Hạn chế này biểu hiện ở chỗ nhiều hạng mục hạ tầng và công nghệ chưa được hiện đại hóa tương xứng, cơ chế phân bổ nguồn lực còn nặng theo chu kỳ ngân sách hằng năm, dữ liệu vận hành chưa thật sự liên thông, trong khi đội ngũ nhân lực kỹ thuật và nhân lực quản trị dữ liệu còn thiếu về chiều sâu chuyên môn. Kết quả quản lý vì vậy tuy có cải thiện, nhưng chưa tạo được mức chủ động cao trong bảo trì dự phòng, trong điều hành theo rủi ro và trong khả năng thích ứng nhanh trước yêu cầu phát triển mới của ngành hàng hải (Bộ Xây dựng, 2025b, 2025h; Bộ Xây dựng, 2026a; Cục Hàng hải và Đường thủy Việt Nam, 2025c).

Ba là, trong khâu giám sát, đánh giá đối với trục hệ thống, Bộ chưa chuyển mạnh từ cách tiếp cận kiểm tra thủ tục sang giám sát dựa trên rủi ro và dữ liệu. Mặc dù hoạt động thanh tra, kiểm tra và giám sát hệ thống đã được duy trì, nhưng cách thức giám sát vẫn còn thiên về hậu kiểm hành chính, tập trung nhiều vào hồ sơ, giấy tờ và tuân thủ hình thức hơn là đo lường chất lượng vận hành thực tế của hệ thống. Bên cạnh đó, tình trạng trùng lặp giữa các lực lượng tham gia giám sát, dữ liệu còn phân tán ở nhiều hệ thống riêng lẻ, năng lực khai thác dữ liệu còn hạn chế, cùng với yêu cầu an ninh mạng ngày càng cao đối với VTS và AIS, đã làm giảm đáng kể tính chủ động của quản lý. Việc ứng dụng công nghệ số vào giám sát tuy đã được đặt ra nhưng mới dừng ở mức độ cục bộ, chưa hình thành được một cơ chế giám sát số hóa đồng bộ trên quy mô toàn hệ thống. Kết quả là Bộ chưa tạo được vòng phản hồi chính sách đủ nhanh và đủ sâu, nên năng lực phát hiện sớm, cảnh báo sớm và điều chỉnh quản lý trước những biến động thực tiễn còn hạn chế (Bộ Xây dựng, 2025b; Bộ Xây dựng, 2026a; Androjna et al., 2021).

2.4.2.2. Hạn chế về quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

Một là, trong khâu ban hành đối với trục dịch vụ, Bộ chưa hoàn thiện đồng bộ cơ chế giá, cơ chế tài chính, tiêu chuẩn chất lượng và điều kiện năng lực của các đơn vị cung ứng dịch vụ. Hạn chế cốt lõi ở đây là việc ban hành cơ chế quản lý dịch vụ vẫn còn thiên về kiểm soát đầu vào và thủ tục, trong khi cơ chế quản lý theo chuẩn đầu ra, theo KPI/SLA và theo mức độ hoàn thành dịch vụ chưa thật sự rõ. Điều đó dẫn tới tình trạng dù Bộ đã ban hành được một số quy định về giá, định mức và điều kiện kinh doanh, nhưng các công cụ này chưa tạo được một khuôn khổ điều tiết đủ mạnh để gắn chất lượng dịch vụ với trách nhiệm của nhà cung ứng. Khi cơ chế giá và cơ chế tài chính chưa phản ánh sát kết quả dịch vụ đầu ra, động lực cải thiện chất lượng, tối ưu hóa chi phí và đổi mới phương thức cung ứng vẫn còn chưa đủ mạnh. Vì vậy, hạn chế trong quản lý của Bộ ở khâu này không chỉ nằm ở nội dung từng văn bản, mà còn nằm ở việc chưa thiết kế được một cơ chế thể chế đủ rõ để điều tiết thị trường dịch vụ theo chất lượng thực tế (Bộ Giao thông vận tải, 2021a, 2021b; Bộ Giao thông vận tải, 2024a, 2024b; Bộ Tài chính, 2016; Bộ Xây dựng, 2026a).

Hai là, trong khâu tổ chức thực hiện đối với trục dịch vụ, Bộ chưa tổ chức được cơ chế lựa chọn nhà cung ứng và quản lý hợp đồng thật sự hiệu quả, khách quan và minh bạch. Dù Bộ đã từng bước chuyển từ cách thức giao nhiệm vụ mang tính hành chính sang quản lý dịch vụ theo điều kiện năng lực, đặt hàng hoặc đấu thầu đối với một số loại hình dịch vụ, nhưng việc tổ chức cung ứng trên thực tế vẫn chưa hình thành được một chuỗi quản lý thống nhất từ lựa chọn nhà cung ứng, điều phối thực hiện, theo dõi kết quả đến xử lý trách nhiệm hợp đồng. Hạn chế này thể hiện ở việc quản lý hợp đồng còn nặng thủ công, thiếu cơ chế chia sẻ rủi ro và thiếu các điều khoản khuyến khích đổi mới; liên thông dữ liệu giữa các cơ quan quản lý, Cảng vụ và đơn vị cung ứng còn hạn chế; trong khi việc áp dụng KPI/SLA vào điều hành cung ứng dịch vụ chưa trở thành thông lệ quản lý. Kết quả là, Bộ mới chủ yếu duy trì được sự vận hành liên tục của dịch vụ, nhưng chưa kiểm soát thật chặt được tính cạnh tranh, tính minh bạch và chất lượng đầu ra của toàn bộ chuỗi cung ứng dịch vụ bảo đảm an toàn hàng hải (Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2019; Chính phủ nước CHXHCN Việt Nam, 2025a; Issa-Zadeh & Garay-Rondero, 2025).

Ba là, trong khâu giám sát, đánh giá đối với trục dịch vụ, Bộ vẫn chủ yếu nghiệm thu và kiểm tra chất lượng dựa trên hồ sơ giấy tờ, chưa hình thành được cơ chế giám sát thời gian thực và phản hồi hiệu quả từ phía người sử dụng dịch vụ. Đây là hạn chế đáng chú ý vì trong quản lý dịch vụ, giám sát phải là công cụ kiểm soát đầu ra, duy trì kỷ cương thị trường và tạo áp lực cải thiện chất lượng. Tuy nhiên, cách thức giám sát hiện nay vẫn nghiêng về xem xét hồ sơ, báo cáo định kỳ hoặc kiểm tra theo đợt, trong khi các cơ chế tiếp nhận phản hồi của hãng tàu, cảng, đại lý và người sử dụng dịch vụ chưa vận hành thật hiệu quả. Việc thiếu tiêu chuẩn giám sát thống nhất, thiếu chỉ số theo dõi liên tục, thiếu đánh giá độc lập và thiếu dữ liệu đủ mạnh để nghiệm thu theo kết quả đã làm cho hoạt động giám sát nhiều khi còn hình thức. Kết quả là vai trò điều tiết và sức ép nâng cao chất lượng từ phía cơ quan quản lý nhà nước chưa phát huy đầy đủ; trách nhiệm giải trình của đơn vị cung ứng dịch vụ chưa thật rõ; và quá trình điều chỉnh chính sách, điều chỉnh giá, điều chỉnh tiêu chuẩn dịch vụ còn chậm so với yêu cầu thực tiễn (Chính phủ nước CHXHCN Việt Nam, 2019; Chính phủ nước CHXHCN Việt Nam, 2025c; World Bank, 1994).

2.4.3. Nguyên nhân của hạn chế trong quản lý

2.4.3.1. Nguyên nhân khách quan

Một là, lĩnh vực hàng hải có tính liên ngành, đa chủ thể và đòi hỏi sự phối hợp thường xuyên giữa nhiều cấp, nhiều lực lượng, nên nếu thiếu cơ chế điều phối đủ mạnh rất dễ phát sinh phân tán thẩm quyền, chồng chéo trách nhiệm và giảm kết quả quản lý. Đối với lĩnh vực bảo đảm an toàn hàng hải, mặc dù Bộ Xây dựng là chủ thể quản lý trực tiếp trong phạm vi luận án, nhưng quá trình thực hiện nhiệm vụ lại luôn gắn với Chính phủ, các bộ, ngành liên quan, địa phương, lực lượng bảo đảm an ninh, an toàn và các đơn vị cung ứng dịch vụ. Chính tính chất đa chủ thể đó làm cho chi phí phối hợp cao hơn, ranh giới trách nhiệm dễ chồng lấn hơn, nhất là ở các nội dung liên quan đến luồng lạch, vùng nước, ứng phó sự cố, bảo vệ công trình, an ninh hàng hải và chia sẻ dữ liệu. Vì vậy, ngay cả khi Bộ chủ động điều hành, kết quả quản lý vẫn chịu tác động đáng kể bởi chất lượng phối hợp liên ngành và liên cấp (Bộ Xây dựng, 2025a; Chính phủ nước CHXHCN Việt Nam, 2025b; Rhodes, 1996).

Hai là, công nghệ, chuẩn mực quốc tế và yêu cầu hội nhập trong lĩnh vực hàng hải thay đổi nhanh, nhất là về số hóa, an ninh mạng và xanh hóa, làm gia tăng độ trễ thể chế nếu hệ thống tiêu chuẩn, định mức và dữ liệu không được cập nhật kịp thời. Sự phát triển mạnh của các công nghệ mới trong quản lý luồng tàu, giám sát hành trình, vận hành cảng biển, cảnh báo an toàn và quản trị dữ liệu tạo ra áp lực rất lớn đối với việc sửa đổi văn bản, chuẩn hóa quy trình và nâng cấp phương thức quản lý. Trong khi đó, chu kỳ xây dựng và điều chỉnh thể chế thường chậm hơn tốc độ thay đổi của công nghệ và chuẩn mực quốc tế, nên dễ xuất hiện khoảng cách giữa yêu cầu quản lý mới với khả năng đáp ứng của khuôn khổ pháp lý hiện hành. Đây là nguyên nhân khách quan làm cho nhiều hạn chế trong ban hành và giám sát chưa thể được khắc phục nhanh, dù yêu cầu thực tiễn đã thay đổi rõ (Bộ Chính trị, 2024; Bộ Xây dựng, 2025b; Mao & Wang, 2020).

Ba là, nhu cầu đầu tư cho hạ tầng, công nghệ, bảo trì và dữ liệu trong lĩnh vực bảo đảm an toàn hàng hải rất lớn, trong khi nguồn lực tài chính, nhân lực chất lượng cao và nền tảng dữ liệu dùng chung còn hạn chế. Đây là nguyên nhân khách quan làm chậm quá trình hiện đại hóa hệ thống, làm cho công tác bảo trì, điều hành, giám sát và quản lý dịch vụ khó chuyển nhanh sang mô hình quản lý dựa trên bằng chứng, dữ liệu và rủi ro. Sự phân tán dữ liệu, thiếu liên thông giữa các hệ thống thông tin, cùng với hạn chế về đầu tư cho hạ tầng số và đào tạo nhân lực dữ liệu, cũng trực tiếp làm giảm khả năng thiết kế cơ chế giá, hợp đồng và giám sát chất lượng dịch vụ theo kết quả. Vì vậy, nhiều hạn chế trong tổ chức thực hiện và giám sát không chỉ do cách làm của chủ thể quản lý, mà còn do điều kiện nền tảng khách quan chưa đáp ứng yêu cầu quản trị hiện đại (Bộ Xây dựng, 2025b; Bộ Xây dựng, 2026a; World Bank, 1994; World Bank & International Association of Ports and Harbors [IAPH], 2021).

2.4.3.2. Nguyên nhân chủ quan

Một là, về phía Bộ Xây dựng và các cơ quan thuộc Bộ, chất lượng xây dựng chính sách, đánh giá tác động và phân định trách nhiệm trong một số trường hợp còn chưa thật rõ, làm giảm tính kịp thời và tính điều tiết thực chất của các văn bản do Bộ tham mưu hoặc ban hành. Hạn chế này thể hiện ở chỗ nhiều văn bản tuy đã được ban hành nhưng chưa theo kịp biến đổi thực tiễn, chưa gắn chặt với yêu cầu quản lý theo kết quả, chưa tạo được khuôn khổ điều tiết đủ rõ cho phối hợp liên ngành và chưa chuyển mạnh sang logic quản lý theo chuẩn đầu ra. Nói cách khác, nguyên nhân chủ quan đầu tiên không nằm ở việc

Bộ không ban hành chính sách, mà ở chất lượng thiết kế chính sách và khả năng chuyển chính sách thành công cụ quản lý thực chất còn hạn chế (Bộ Xây dựng, 2026a; OECD, 2014; OECD, 2019a).

Hai là, năng lực tổ chức thực hiện và quản trị thay đổi của trục quản lý thuộc Bộ còn chưa theo kịp yêu cầu của giai đoạn chuyển tiếp, nhất là trong bối cảnh điều chỉnh tổ chức bộ máy theo mốc tháng 3/2025. Việc sắp xếp đầu mối, kế thừa dữ liệu, tài sản, hợp đồng dịch vụ công và phân định lại vai trò giữa Bộ, Cục Hàng hải và Đường thủy Việt Nam, Cảng vụ và các đơn vị cung ứng đã làm gia tăng áp lực phối hợp và làm lộ rõ những hạn chế về quản lý hiệu suất, quản lý hợp đồng và quản trị dữ liệu. Khi chưa có đủ công cụ quản trị hiện đại như KPI, SLA và hệ thống dữ liệu đồng bộ, quá trình phân cấp, điều phối và kiểm soát chất lượng đầu ra khó đạt hiệu quả như yêu cầu. Vì vậy, không ít hạn chế trong khâu tổ chức thực hiện bắt nguồn từ chính năng lực vận hành bộ máy và quản trị chuyển đổi của chủ thể quản lý (Bộ Xây dựng, 2025a, 2025b, 2025e; Chính phủ nước CHXHCN Việt Nam, 2019; Chính phủ nước CHXHCN Việt Nam, 2025b, 2025e).

Ba là, phương thức quản lý của Bộ và các cơ quan thuộc Bộ vẫn còn chịu ảnh hưởng khá rõ của thói quen quản lý truyền thống, nặng về hồ sơ, thủ tục và kiểm tra tuân thủ hình thức. Điều này làm cho khâu giám sát chưa chuyển mạnh sang đánh giá dựa trên rủi ro, dữ liệu và kết quả đầu ra; đồng thời làm hạn chế khả năng phát hiện sớm rủi ro, cảnh báo sớm và phản hồi chính sách. Bên cạnh đó, năng lực khai thác, phân tích và sử dụng dữ liệu của đội ngũ cán bộ quản lý còn chưa đồng đều; trách nhiệm giải trình và động lực cải tiến trong một số khâu chưa đủ mạnh; vì vậy công tác giám sát, nghiệm thu và điều chỉnh quản lý vẫn còn chậm và thiếu tính chủ động. Đây là nguyên nhân chủ quan có ý nghĩa trực tiếp đối với các hạn chế ở cả trục hệ thống và trục dịch vụ, nhất là đối với các khâu giám sát còn yếu (Bộ Xây dựng, 2025b; Bộ Xây dựng, 2026a).

Trên cơ sở phân tích tại mục 2.4.2 và 2.4.3, có thể khái quát ma trận hạn chế, nguyên nhân chủ quan và nguyên nhân khách quan theo hai nội dung quản lý nhà nước về bảo đảm an toàn hàng hải như sau:

Bảng 2.16. Tổng hợp khái quát hạn chế và nguyên nhân trong tổ chức, quản lý hệ thống và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

[TABLE]

Nguồn: Nghiên cứu sinh tổng hợp từ mục 2.4.2 và 2.4.3, 2026

Từ hạn chế trong quản lý, nguyên nhân chủ quan, nguyên nhân khách quan được tổng hợp trong Bảng 2.16 và kết quả phân tích định lượng tại mục 2.3 là cơ sở để Chương 3 đề xuất hệ thống giải pháp và kiến nghị đồng bộ nhằm hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam đến năm 2030, tầm nhìn đến năm 2045 phù hợp với xu thế phát triển của đất nước trong điều kiện chuyển đổi số toàn diện và hợp tác quốc tế sâu rộng trong lĩnh vực hàng hải.

Chương 3GIẢI PHÁP HOÀN THIỆN QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM

3.1. BỐI CẢNH MỚI, QUAN ĐIỂM VÀ MỤC TIÊU HOÀN THIỆN QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM

3.1.1. Bối cảnh mới và yêu cầu đổi mới quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

Trong giai đoạn hiện nay, hoạt động quản lý nhà nước về bảo đảm an toàn hàng hải tại Việt Nam đang chịu tác động đa chiều từ biến động địa chính trị quốc tế và yêu cầu phát triển nội tại. Việc nhận diện chính xác các xu hướng này là cơ sở thực tiễn quan trọng để xác lập hệ thống giải pháp quản lý phù hợp, nhằm đảm bảo hiệu lực quản lý và nâng cao trạng thái an toàn hàng hải (Bộ Xây dựng, 2026a; UNCTAD, 2024; UNCTAD, 2025b).

Về bối cảnh quốc tế, ngành hàng hải thế giới đang trải qua quá trình tái cấu trúc căn bản dưới tác động của yếu tố địa chính trị và yêu cầu chuyển đổi mô hình quản trị bền vững. Trước hết, sự dịch chuyển trọng tâm địa chính trị và sự đứt gãy của chuỗi cung ứng toàn cầu đã tái định hình bản đồ hàng hải (EMSA, 2025; UNCTAD, 2024; UNCTAD, 2025b).

Chiến lược "Trung Quốc +1" và sự trỗi dậy của khu vực Ấn Độ Dương - Thái Bình Dương làm gia tăng vai trò của Biển Đông như một tuyến vận tải chiến lược. Báo cáo Vận tải biển 2024 của UNCTAD cho thấy các xung đột tại các điểm giao thông hàng hải trọng yếu như Biển Đỏ và eo biển Hormuz buộc nhiều hãng tàu phải định tuyến lại, qua đó làm tăng chi phí logistics, thời gian hành trình và chi phí bảo hiểm. Trong bối cảnh đó, năng lực bảo đảm an toàn hàng hải của quốc gia ven biển trở thành một yếu tố cạnh tranh quan trọng đối với chuỗi logistics và thu hút hàng trung chuyển (UNCTAD, 2024; UNCTAD, 2025b).

năm 2023 với mục tiêu phát thải ròng bằng “0” vào hoặc khoảng năm 2050 đang thúc đẩy hình thành các hành lang vận tải xanh. Xu hướng này đặt ra yêu cầu cấp thiết đối với công tác quản lý nhà nước trong việc rà soát, cập nhật khung pháp lý, tiêu chuẩn kỹ thuật và quy trình ứng phó sự cố đối với các loại nhiên liệu mới. Đồng thời, sự phát triển của tàu tự hành (MASS), e-Navigation và các chuẩn dữ liệu số S-100 đòi hỏi công tác quản lý nhà nước phải hoàn thiện đồng thời chức năng ban hành chính sách, tiêu chuẩn kỹ thuật và cơ chế giám sát để kiểm soát các rủi ro an ninh phi truyền thống, đặc biệt là an ninh mạng hàng hải (IHO, 2022; IMO, 2023; IMO, 2024b).

Về bối cảnh trong nước, giai đoạn đến năm 2030 tạo ra đồng thời động lực và áp lực đổi mới căn bản đối với phương thức quản lý nhà nước. Động lực đổi mới xuất phát từ các chủ trương lớn về phát triển bền vững kinh tế biển, hội nhập quốc tế, đổi mới công tác xây dựng và thi hành pháp luật, phát triển kinh tế tư nhân và đột phá khoa học, công nghệ, đổi mới sáng tạo, chuyển đổi số; đồng thời gắn với tiến trình sắp xếp, tinh gọn bộ máy và phân cấp, phân quyền trong lĩnh vực hàng hải từ năm 2025 và Nghị quyết Đại hội Đại biểu lần thứ XIV của Đảng (Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam, 2018; Bộ Chính trị, 2024; Chính phủ nước CHXHCN Việt Nam, 2025b, 2025e; Đảng Cộng sản Việt Nam, 2026). Trong bối cảnh đó, quản lý nhà nước về bảo đảm an toàn hàng hải phải chuyển mạnh từ tư duy cơ chế phân bổ mang tính hành chính sang cơ chế quản lý theo chuẩn mực, dựa trên dữ liệu và gắn với trách nhiệm giải trình rõ ràng (Bộ Xây dựng, 2026a; Thủ tướng Chính phủ, 2021; Thủ tướng Chính phủ, 2024; Thủ tướng Chính phủ, 2025a).

Bên cạnh đó, mục tiêu trở thành trung tâm trung chuyển quốc tế và duy trì đà tăng trưởng kinh tế cũng đặt ra thách thức lớn về năng lực của hệ thống bảo đảm an toàn hàng hải. Việc hình thành các cảng cửa ngõ như Lạch Huyện, Cái Mép - Thị Vải và định hướng phát triển các trung tâm trung chuyển quốc tế theo Quyết định số 1579/QĐ-TTg, Quyết định số 442/QĐ-TTg và Quyết định số 140/QĐ-TTg đòi hỏi năng lực của hệ thống bảo đảm an toàn hàng hải phải tương thích với tàu mẹ trọng tải lớn (Bộ Xây dựng, 2026a; Thủ tướng Chính phủ, 2021; Thủ tướng Chính phủ, 2024; Thủ tướng Chính phủ, 2025a).

Kết quả phân tích ở Chương 2 cho thấy, mặc dù quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam đã đạt được một số kết quả quan trọng, nhưng vẫn tồn tại những hạn chế đáng chú ý như: khung pháp lý chưa thật đồng bộ; cơ chế quản lý vòng đời tài sản và quản trị dữ liệu còn bất cập; chất lượng tổ chức thực hiện giữa các cấu phần hệ thống chưa đồng đều; cơ chế quản lý cung ứng dịch vụ còn thiên về kiểm soát đầu vào; và giám sát chất lượng dịch vụ chưa thật sự dựa trên dữ liệu, KPI/SLA và phản hồi hiện trường. Các hạn chế này cho thấy yêu cầu hoàn thiện hiện nay không chỉ là sửa đổi từng quy định đơn lẻ, mà là điều chỉnh mô hình quản lý nhà nước theo hướng kiến tạo, dựa trên kết quả, dữ liệu và rủi ro, phù hợp hơn với điều kiện phát triển mới của Việt Nam (Bộ Xây dựng, 2026a; Thủ tướng Chính phủ, 2021; Thủ tướng Chính phủ, 2024; Thủ tướng Chính phủ, 2025a).

Từ đó có thể khẳng định rằng, bối cảnh mới đang đặt ra yêu cầu đổi mới quản lý nhà nước về bảo đảm an toàn hàng hải theo tính chất vừa cấp bách, vừa có hệ thống. Đổi mới ở đây phải được hiểu là đổi mới đồng thời trên cả hai nội dung quản lý là tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải; đồng thời được triển khai xuyên suốt cả ba chức năng quản lý nhà nước là ban hành, tổ chức thực hiện và giám sát, đánh giá. Đây chính là tiền đề thực tiễn trực tiếp cho việc xác lập quan điểm, mục tiêu và định hướng hoàn thiện trong giai đoạn tiếp theo (Bộ Xây dựng, 2026a; OECD, 2014).

3.1.2. Quan điểm hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

Dựa trên việc phân tích bối cảnh mới và nhận diện các hạn chế, nguyên nhân của hạn chế trong thực tiễn quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam được trình bày ở Chương 2, quá trình hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải gắn trực tiếp với khung phân tích 2×3 của luận án cần quán triệt năm quan điểm chỉ đạo xuyên suốt, mang tính nguyên tắc sau:

Thứ nhất, giữ vững sự lãnh đạo toàn diện của Đảng và sự quản lý thống nhất của Nhà nước, đồng thời đẩy mạnh chủ trương xã hội hóa. Nhà nước cần chuyển dịch vai trò từ trực tiếp thực hiện sang vai trò kiến tạo và giám sát, tập trung nguồn lực vào công tác hoạch định chính sách và quy hoạch chiến lược. Cần vận dụng tối đa tinh thần của Nghị quyết số 68-NQ/TW ngày 04/5/2025 của Bộ

Chính trị khóa XIII để xây dựng cơ chế thu hút nguồn lực từ khu vực kinh tế tư nhân tham gia đầu tư, vận hành hạ tầng và cung ứng dịch vụ bảo đảm an toàn hàng hải (Bộ Chính trị, 2025). Điều này giúp giảm gánh nặng cho ngân sách nhà nước, đảm bảo hiệu quả khai thác nguồn lực xã hội mà vẫn giữ vững các yêu cầu về an ninh quốc phòng.

Thứ hai, xác định ưu tiên hàng đầu là "An toàn sinh mạng" và "Bảo vệ môi trường" trong mọi quyết định quản lý. Quản lý nhà nước phải tuân thủ chặt chẽ các công ước quốc tế mà Việt Nam là thành viên, đặc biệt là Công ước quốc tế về an toàn sinh mạng con người trên biển (SOLAS) và Công ước quốc tế về ngăn ngừa ô nhiễm do tàu gây ra (MARPOL) (IMO, 1973/1978; IMO, 1974). Nguyên tắc phòng ngừa rủi ro từ sớm, từ xa cần được thực hiện triệt để. Trong mọi tình huống xung đột lợi ích, yêu cầu bảo đảm an toàn tính mạng con người và bảo vệ hệ sinh thái biển phải được đặt lên trên lợi ích kinh tế ngắn hạn.

Thứ ba, chuyển đổi phương thức quản lý từ cơ chế "kiểm soát đầu vào" sang "quản trị dựa trên kết quả đầu ra" và "quản trị dựa trên dữ liệu". Thay vì tập trung vào các thủ tục hành chính tiền kiểm phức tạp, cơ quan quản lý cần tập trung xây dựng hệ thống tiêu chuẩn, quy chuẩn kỹ thuật quốc gia làm công cụ thước đo và tăng cường công tác hậu kiểm. Việc ra quyết định quản lý – từ điều tiết luồng tuyến đến cấp phép rời cảng – phải dựa trên nền tảng phân tích dữ liệu lớn (Big Data) và tiếp cận dựa trên rủi ro để đảm bảo tính minh bạch, khoa học và hiệu lực quản lý (Bộ Xây dựng, 2026a; IALA, 2023; IHO, 2022).

Thứ tư, chủ động hội nhập quốc tế và nội luật hóa đồng bộ các điều ước quốc tế. Hệ thống pháp luật chuyên ngành cần được rà soát, cập nhật thường xuyên để đảm bảo tính tương thích với các quy định mới của Tổ chức Hàng hải Quốc tế (IMO) và Tổ chức quốc tế về báo hiệu hàng hải (IALA). Quan điểm này đòi hỏi Việt Nam phải chuyển từ trạng thái thụ động tuân thủ sang chủ động tham gia xây dựng các quy định, chuẩn mực chung của khu vực và thế giới, đặc biệt là trong các lĩnh vực mới nổi như an ninh mạng hàng hải và các hành lang vận tải xanh (IALA, 2022; IMO, 2023; IMO, 2024b).

Thứ năm, thực hiện phân cấp, phân quyền triệt để gắn liền với trách nhiệm giải trình rõ ràng. Cần xác định cụ thể và phân tách rạch ròi phạm vi trách nhiệm giải trình giữa Bộ Xây dựng, Cục Hàng hải và Đường thủy Việt Nam và các Cảng vụ hàng hải khu vực, cũng như mối quan hệ giữa cơ quan quản lý nhà nước với các doanh nghiệp cung ứng dịch vụ BĐATHH. Mọi thẩm quyền được phân cấp phải đi kèm với cơ chế kiểm tra, giám sát chặt chẽ và chế tài xử lý vi phạm nghiêm minh, đảm bảo bộ máy vận hành thông suốt, không chồng chéo và nâng cao được tính phản ứng trước các tình huống thực tế (Bộ Xây dựng, 2025a; Chính phủ nước CHXHCN Việt Nam, 2025b).

Như vậy, các quan điểm nêu trên tạo nên khung chuẩn tắc chung cho toàn bộ Chương 3. Đây đồng thời là cơ sở để xác lập mục tiêu và định hướng hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam trong giai đoạn đến năm 2030, tầm nhìn đến năm 2045.

3.1.3. Mục tiêu và định hướng hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

Về căn cứ xác định mục tiêu, luận án dựa trên ba trụ cột chính. Thứ nhất, mục tiêu hoàn thiện được đặt trong định hướng chính trị - pháp lý chung về phát triển bền vững kinh tế biển, phát triển hệ thống cảng biển, bảo đảm trật tự, an toàn giao thông và mục tiêu phát triển đất nước đến năm 2030, tầm nhìn 2045 (Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam, 2018; Thủ tướng Chính phủ, 2021; Thủ tướng Chính phủ, 2024; Thủ tướng Chính phủ, 2025a). Thứ hai, việc xác lập mục tiêu có tham chiếu các chuẩn mực quốc tế chủ yếu trong lĩnh vực bảo đảm an toàn hàng hải, nhất là yêu cầu về độ sẵn sàng của hệ thống báo hiệu và xu hướng chuẩn hóa dữ liệu hàng hải trong bối cảnh chuyển đổi số (IALA, 2017a; IALA, 2023; IHO, 2022; IMO, 1974). Thứ ba, mục tiêu được xây dựng từ những vấn đề thực tiễn đã được nhận diện ở Chương 2, tập trung vào các hạn chế về hạ tầng, dữ liệu và chất lượng dịch vụ bảo đảm an toàn hàng hải (Bộ Xây dựng, 2026a). Ba trụ cột này giúp hệ thống mục tiêu của luận án vừa bám sát định hướng phát triển quốc gia, vừa tiếp cận chuẩn mực quốc tế, đồng thời có cơ sở thực tiễn và tính khả thi trong điều kiện Việt Nam.

Mục tiêu tổng quát của việc hoàn thiện là nâng cao kết quả quản lý nhà nước của Bộ Xây dựng đối với cả hệ thống bảo đảm an toàn hàng hải và hoạt động cung ứng dịch vụ bảo đảm an toàn hàng hải; qua đó duy trì trạng thái an toàn hơn, thông suốt hơn, có độ tin cậy cao hơn và có khả năng thích ứng tốt hơn trước yêu cầu hội nhập quốc tế, chuyển đổi số, tăng trưởng vận tải biển và các rủi ro mới phát sinh (Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam, 2018; Bộ Chính trị, 2024; Chính phủ nước CHXHCN Việt Nam, 2025b). Đồng thời, quá trình hoàn thiện cần bảo đảm các kết quả quản lý nhà nước được theo dõi, lượng hóa và đánh giá thống nhất theo khung 2×3 và bộ KPI tương ứng ở khung giải pháp (Kusek & Rist, 2004; OECD, 2014; OECD, 2019b).

Đến năm 2030, việc hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải cần hướng tới các mục tiêu cụ thể sau đây.

Một là, hoàn thiện tương đối đồng bộ khung thể chế đối với tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải theo hướng bảo đảm tiến độ xây dựng văn bản, quy chuẩn kỹ thuật và quy hoạch; nâng tỷ lệ văn bản, quy hoạch có tham vấn chính thức; tăng tỷ lệ rà soát, cập nhật đúng chu kỳ; tiếp thu có chọn lọc chuẩn mực quốc tế phù hợp; đồng thời đẩy mạnh số hóa, công khai các quy hoạch, quy chuẩn và danh mục luồng hàng hải. Mục tiêu này tương ứng trực tiếp với cấu phần H1, tạo nền tảng pháp lý cho toàn bộ trục quản lý hệ thống (Chính phủ nước CHXHCN Việt Nam, 2025c, 2025d; IALA, 2017a; IALA, 2023; IHO, 2022).

Hai là, nâng cao chất lượng tổ chức thực hiện quản lý hệ thống bảo đảm an toàn hàng hải theo hướng quản trị vòng đời tài sản, phân bổ nguồn lực theo mức độ rủi ro và tăng cường điều hành trên nền dữ liệu. Trọng tâm của mục tiêu này là nâng cao tỷ lệ dự án đầu tư công hoàn thành đúng tiến độ; tăng tỷ lệ khu vực, tuyến luồng rủi ro cao có phương án bảo đảm an toàn hàng hải; tăng tỷ lệ hạ tầng được duy tu, bảo trì đúng kế hoạch; đồng thời nâng mức độ giải quyết đúng hạn và trực tuyến toàn trình đối với các thủ tục hành chính liên quan đến trục hệ thống. Mục tiêu này tương ứng với cấu phần H2 (Bộ Xây dựng, 2025a, 2025b; Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2025d; ISO, 2018).

Ba là, đổi mới công tác giám sát, đánh giá hệ thống bảo đảm an toàn hàng hải theo hướng dựa trên dữ liệu và rủi ro, thay cho cách tiếp cận chủ yếu dựa vào kiểm tra thủ tục hoặc kiểm tra định kỳ hình thức. Theo đó, cần bảo đảm kế hoạch thanh tra, kiểm tra được thực hiện đúng quy định; tăng tỷ lệ giám sát tập trung vào khu vực rủi ro cao; nâng khả năng phát hiện chủ động và khắc phục đúng hạn các khiếm khuyết; tăng tần suất cập nhật dữ liệu hiện trạng trên nền tảng số; đồng thời nâng tỷ lệ thực hiện các khuyến nghị trong nước và quốc tế sau giám sát. Mục tiêu này tương ứng với cấu phần H3 (Bộ Xây dựng, 2026a; Kusek & Rist, 2004; OECD, 2014; OECD, 2019a).

Bốn là, hoàn thiện khung thể chế quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải theo hướng minh bạch hơn, đo lường được hơn và gắn chặt hơn với chất lượng đầu ra. Trọng tâm là nâng tỷ lệ định mức kinh tế - kỹ thuật, đơn giá dịch vụ được ban hành hoặc cập nhật đúng hạn; rút ngắn thời gian ban hành khung giá, định mức; tăng mức độ công khai các văn bản giá, cơ chế tài chính và định mức; nâng khả năng thể chế hóa các khuyến nghị phù hợp từ thực tiễn và kinh nghiệm quốc tế; đồng thời hạn chế tình trạng văn bản phải sửa đổi sớm do chất lượng thiết kế thể chế chưa cao. Mục tiêu này tương ứng với cấu phần D1 (Bộ Giao thông vận tải, 2021a, 2021b, 2024; Bộ Xây dựng, 2025g, 2025h; Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2019).

Năm là, nâng cao chất lượng tổ chức thực hiện quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải theo hướng quản trị chuỗi cung ứng dịch vụ thống nhất, tăng tính minh bạch của hợp đồng, trách nhiệm thực hiện và năng lực điều phối giữa các chủ thể liên quan. Trong đó, cần nâng tỷ lệ thủ tục hành chính về dịch vụ được giải quyết đúng hạn; tăng tỷ lệ xử lý trực tuyến toàn trình; bảo đảm hợp đồng dịch vụ công được ký đúng hạn; mở rộng tỷ lệ gói dịch vụ công được lựa chọn theo phương thức cạnh tranh; đồng thời duy trì cơ chế đánh giá định kỳ đối với doanh nghiệp cung cấp dịch vụ bảo đảm an toàn hàng hải. Mục tiêu này tương ứng với cấu phần D2 (Bộ Giao thông vận tải, 2019; Bộ Giao thông vận tải, 2023b; Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2019; Kusek & Rist, 2004).

Sáu là, hoàn thiện công tác giám sát, đánh giá chất lượng dịch vụ bảo đảm an toàn hàng hải theo hướng dựa trên KPI/SLA, bằng chứng số và hậu kiểm thông minh. Theo đó, cần tăng tỷ lệ hợp đồng dịch vụ công có KPI/SLA được quy định và theo dõi thực chất; tăng tỷ lệ nghiệm thu dịch vụ có giám sát độc lập; nâng tỷ lệ thực hiện các khuyến nghị sau thanh tra, kiểm tra; cải thiện mức độ hài lòng của doanh nghiệp và chủ tàu đối với dịch vụ bảo đảm an toàn hàng hải; đồng thời giảm tỷ lệ tai nạn, sự cố liên quan đến chất lượng dịch vụ. Mục tiêu này tương ứng với cấu phần D3 (Bộ Giao thông vận tải, 2019; Bộ Giao thông vận tải, 2023b; Kusek & Rist, 2004; OECD, 2014; OECD, 2019b).

Về tầm nhìn đến năm 2045, là hình thành mô hình quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam theo hướng hiện đại, số hóa, có năng lực dự báo, giám sát và phản ứng nhanh; trong đó sáu cấu phần H1, H2, H3, D1, D2, D3 vận hành đồng bộ trên nền dữ liệu liên thông, chuẩn đầu ra, KPI/SLA và cơ chế giám sát theo rủi (Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam, 2018; Nguyễn Mạnh Cường & Phan Văn Hưng, 2021; OECD, 2019b; UNCTAD, 2023). Ở tầm nhìn này, hệ thống chỉ tiêu không chỉ là công cụ theo dõi kết quả thực hiện, mà còn trở thành căn cứ thường xuyên cho điều hành, giám sát chất lượng dịch vụ, phản hồi chính sách và kiểm soát rủi ro trong toàn bộ lĩnh vực bảo đảm an toàn hàng hải.

Về định hướng ưu tiên trong giai đoạn đến năm 2030, trọng tâm trước mắt cần đặt vào việc hoàn thiện thể chế và nâng cao chất lượng tổ chức thực hiện đối với trục tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải; đồng thời từng bước tăng cường giám sát hệ thống theo dữ liệu và rủi ro. Song song với đó, cần đổi mới cơ chế quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải theo hướng quản trị kết quả đầu ra, gắn chặt hơn với KPI/SLA, dữ liệu, cơ chế đặt hàng và giám sát chất lượng dịch vụ thực tế hiện trường (Bộ Giao thông vận tải, 2019; Bộ Xây dựng, 2025g, 2025h; Bộ Xây dựng, 2026a; Chính phủ nước CHXHCN Việt Nam, 2019; ISO, 2018; Kusek & Rist, 2004; OECD, 2019b). Định hướng này phù hợp với kết quả phân tích thực trạng chương 3, kết quả phân tích định lượng khảo sát, đồng thời tạo nền chiến lược trực tiếp cho các nhóm giải pháp tại mục 3.2.

Trên cơ sở mục tiêu tổng quát và các mục tiêu cụ thể đã xác định, luận án hệ thống hóa các chỉ tiêu định hướng đến năm 2030 theo sáu cấu phần của khung phân tích 2×3. Việc lượng hóa này nhằm làm rõ hơn đích hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam, đồng thời tạo căn cứ theo dõi kết quả thực hiện trong mối liên hệ giữa quản lý hệ thống và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải. Các chỉ tiêu được lựa chọn trên cơ sở ba căn cứ chính: định hướng phát triển quốc gia, chuẩn mực quốc tế cốt lõi của lĩnh vực hàng hải và kết quả phân tích thực trạng của luận án (Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam, 2018; Thủ tướng Chính phủ, 2021; IALA, 2023; IMO, 1974; Kusek & Rist, 2004).

Bảng 3.1. Các tiêu chí đánh giá kết quả và mục tiêu cụ thể đến năm 2030

[TABLE]

Nguồn: Nghiên cứu sinh tổng hợp và đề xuất, 2026

Ghi chú: các mức mục tiêu định lượng trong bảng 3.1 là mục tiêu định hướng do luận án đề xuất trên cơ sở phân tích thực trạng, chuẩn mực quốc tế cốt lõi và các tiếp cận quản trị theo kết quả (Bộ Giao thông vận tải, 2021a, 2021b, 2024; Bộ Xây dựng, 2025a, 2025b, 2025d, 2025e, 2025f, 2025g, 2025h, 2025i; Bộ Xây dựng, 2026a, 2026d; Cục Hàng hải và Đường thủy Việt Nam, 2025a, 2025b, 2025c; Hollnagel, 2014; IALA, 2017a, 2017b; IALA, 2022; IALA, 2023; IHO, 2022; IMO, 1974; IMO, 1978; IMO, 1991; IMO, 2018a, 2018b; IMO, 2021; IMO, 2024a, 2024b, 2024c; ISO, 2018; Issa-Zadeh & Garay-Rondero, 2025; Kusek & Rist, 2004; Kystverket, n.d.; OECD, 2014; OECD, 2019b).

Bảng 3.1 cho thấy các mục tiêu cụ thể đến năm 2030 được cấu trúc thống nhất theo sáu biến H1, H2, H3, D1, D2 và D3 của khung phân tích 2×3; trong đó, trục tổ chức, quản lý hệ thống bảo đảm an toàn hàng hải nhấn mạnh hoàn thiện thể chế, nâng cao độ sẵn sàng và độ tin cậy của hạ tầng kỹ thuật, cũng như tăng cường giám sát, kiểm soát rủi ro, còn trục quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải tập trung vào chuẩn hóa định mức, đơn giá, nâng cao chất lượng đầu ra, mức độ đáp ứng và cơ chế đánh giá hiệu quả gắn với KPI/SLA. Cách lượng hóa này không chỉ làm rõ đích hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam đến năm 2030, mà còn tạo căn cứ trực tiếp để triển khai các nhóm giải pháp tại mục 3.2 (Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam, 2018; Bộ Xây dựng, 2026a; IALA, 2023; IMO, 1974; Kusek & Rist, 2004).

3.2. GIẢI PHÁP HOÀN THIỆN QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM ĐẾN NĂM 2030, TẦM NHÌN ĐẾN NĂM 2045

3.2.1. Nhóm giải pháp hoàn thiện tổ chức và quản lý hệ thống bảo đảm an toàn hàng hải

3.2.1.1. Hoàn thiện cơ chế, pháp lý về tổ chức và quản lý hệ thống bảo đảm an toàn hàng hải

Về mục tiêu giải pháp, nhằm thiết lập một khung pháp lý – thể chế đồng bộ cho quản lý hệ thống BĐATHH, bảo đảm thống nhất từ Trung ương đến địa phương, xác định rõ chủ thể chịu trách nhiệm theo chuỗi quyết định “ban hành – tổ chức thực hiện – giám sát, đánh giá”, đồng thời xử lý dứt điểm các điểm chồng chéo và khoảng trống trách nhiệm phát sinh khi thay đổi đầu mối quản lý, điều chỉnh phân cấp và sắp xếp tổ chức quản lý nhà nước về giao thông vận tải thuộc Bộ Xây dựng. Mục tiêu cuối cùng là chuyển trọng tâm quản lý từ xử lý sự vụ sang quản lý theo chương trình và theo rủi ro, trong đó các chuẩn kỹ thuật, quy trình điều hành và chuẩn dữ liệu được xác lập như nền tảng bắt buộc để bảo đảm vận hành ổn định và có thể kiểm chứng.

Về nội dung giải pháp, Bộ Xây dựng giữ vai trò đầu mối chủ trì công tác rà soát, chuẩn hóa và hệ thống hóa toàn diện các văn bản quy phạm pháp luật, quy trình kỹ thuật, định mức kinh tế – kỹ thuật, tiêu chuẩn và quy chuẩn liên quan đến quản lý hệ thống bảo đảm an toàn hàng hải (BĐATHH). Quá trình này không chỉ tập trung vào việc cập nhật các quy định hiện hành mà còn ưu tiên nhận diện, đánh giá và điều chỉnh nhóm quy định có ảnh hưởng trực tiếp đến công tác vận hành báo hiệu, quản lý luồng hàng hải, duy tu – bảo trì luồng hàng hải, điều phối sự cố và công bố thông tin an toàn hàng hải. Trong quá trình này, Bộ Xây dựng cần tập trung vào ba nhóm nội dung. Thứ nhất, chuẩn hóa lại phạm vi điều chỉnh và ranh giới trách nhiệm giữa quản lý nhà nước, tổ chức thực thi và hoạt động cung ứng dịch vụ kỹ thuật, qua đó hạn chế tình trạng giao thoa trách nhiệm trong quản lý luồng, báo hiệu, VTS, thông tin duyên hải và dữ liệu nền. Thứ hai, rà soát các điểm chồng chéo hoặc khoảng trống giữa quy định về đầu tư công, quản lý tài sản công, xây dựng, bảo trì và quản lý chuyên ngành hàng hải để hình thành cơ chế điều tiết thống nhất hơn. Thứ ba, chuẩn hóa các quy định liên quan đến quản trị dữ liệu hệ thống, coi dữ liệu báo hiệu, dữ liệu luồng, dữ liệu vận hành và dữ liệu sự cố là một bộ phận của đối tượng quản lý nhà nước, chứ không chỉ là chất liệu kỹ thuật phục vụ tác nghiệp.

Khung quản trị hệ thống cũng chuẩn hóa các quy trình điều phối sự cố và kiểm soát thay đổi trạng thái báo hiệu/luồng theo nguyên tắc quản trị rủi ro. Cụ thể, các quy trình này sẽ quy định chi tiết về thẩm quyền kích hoạt quy trình ứng phó, trách nhiệm thông báo sự cố, ngưỡng ra quyết định, cơ chế phối hợp liên ngành giữa các lực lượng chức năng (an ninh, quốc phòng, môi trường, hải quan, cảng vụ...), cũng như trình tự cập nhật thông tin an toàn hàng hải tới các đối tượng sử dụng như thuyền trưởng, chủ tàu, đại lý tàu biển, doanh nghiệp vận tải và các bên liên quan khác. Việc này giúp bảo đảm tính kịp thời, chính xác và minh bạch của thông tin, giảm thiểu các rủi ro phát sinh từ sự cố hoặc thay đổi bất thường trong hệ thống báo hiệu, luồng hàng hải.

Một nội dung trọng yếu mang tính điều kiện để giảm thiểu giám sát thủ công, tăng tính kiểm chứng và hiện đại hóa công tác quản lý là chuẩn hóa quản trị dữ liệu hệ thống BĐATHH. Bộ Xây dựng sẽ quy định danh mục dữ liệu tối thiểu cần thiết cho quản lý, bao gồm dữ liệu báo hiệu, dữ liệu luồng, dữ liệu thông báo hàng hải, dữ liệu sự cố, dữ liệu bảo trì và dữ liệu khảo sát – thủy đạc. Các yêu cầu về mã hóa/định dạng, tiêu chuẩn siêu dữ liệu, trách nhiệm cập nhật, tần suất cập nhật, quy trình kiểm tra chất lượng dữ liệu và cơ chế chia sẻ liên thông sẽ được xây dựng và áp dụng nghiêm ngặt. Dữ liệu này không chỉ là căn cứ pháp lý cho công tác hậu kiểm, đánh giá tuân thủ, thanh tra theo rủi ro mà còn tạo nền tảng cho điều hành dựa trên bằng chứng, nâng cao năng lực phòng ngừa rủi ro, tăng hiệu quả ra quyết định quản lý và vận hành hệ thống. Ngoài ra, Bộ Xây dựng thúc đẩy việc ứng dụng công nghệ thông tin, chuyển đổi số trong quản lý dữ liệu BĐATHH, tạo điều kiện thuận lợi cho việc tích hợp, phân tích và chia sẻ thông tin giữa các đơn vị trực thuộc và các đối tác liên quan, cả trong và ngoài ngành hàng hải. Điều này góp phần nâng cao khả năng dự báo, phòng ngừa và ứng phó kịp thời với các tình huống rủi ro, đồng thời tăng cường hiệu quả hợp tác quốc tế trong lĩnh vực bảo đảm an toàn hàng hải, đáp ứng yêu cầu phát triển bền vững và hội nhập của đất nước.

Về tổ chức thực hiện giải pháp: Thứ nhất, Bộ Xây dựng là chủ thể quản lý nhà nước trung tâm, giữ vai trò chủ trì rà soát, chuẩn hóa và ban hành hoặc tham mưu ban hành các nội dung nêu trên; Bộ cũng phân định rõ nhiệm vụ giữa các đơn vị: Vụ Vận tải – An toàn giao thông xây dựng phương án vận hành và phối hợp điều chỉnh chính sách; Vụ Pháp chế thẩm định pháp lý, rà soát xung đột và đào tạo cán bộ; Vụ Kế hoạch – Tài chính lập kế hoạch nguồn lực và đề xuất huy động vốn; Vụ Khoa học công nghệ ban hành tiêu chuẩn, thúc đẩy chuyển đổi số và kiểm soát môi trường. Cục Hàng hải và Đường Thủy lên kế hoạch thanh tra, hướng dẫn kỹ thuật, tổng hợp vướng mắc và tập huấn tại địa phương. Cảng vụ giám sát tuyến đầu, xử lý sự cố, giữ an ninh hàng hải. Các Sở Xây dựng phối hợp liên thông dữ liệu, đào tạo và đề xuất sáng kiến phù hợp địa phương. Thứ hai, điều kiện triển khai then chốt là có phương án chuyển tiếp rõ ràng, nguồn lực pháp chế – kỹ thuật đủ mạnh, cơ chế phối hợp liên ngành với các lực lượng và cơ quan liên quan (an ninh, quốc phòng, hải quan, môi trường…) và cơ chế quản trị thay đổi được thiết kế để kiểm soát tác động của việc sửa đổi, bãi bỏ, thay thế văn bản. Thứ ba, rủi ro trọng yếu bao gồm chồng chéo nhiệm vụ tại vùng nước giao thoa, phân tán trách nhiệm do thiếu quy trình thống nhất, tăng số lượng văn bản nhưng giảm khả năng thực thi do thiếu nguồn lực, cùng rủi ro an ninh mạng và rủi ro chất lượng dữ liệu khi số hóa. Biện pháp giảm thiểu cần được tích hợp ngay trong thiết kế triển khai theo hướng thí điểm tại khu vực trọng điểm, ưu tiên chuẩn hóa dữ liệu tối thiểu trước khi mở rộng, triển khai cơ chế kiểm soát thay đổi/phiên bản hóa và cơ chế kiểm tra chéo chất lượng dữ liệu giữa cơ quan quản lý, Cảng vụ và đơn vị vận hành.

Bảng 3.2. Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện cơ chế, chính sách về quản lý hệ thống bảo đảm an toàn hàng hải

[TABLE]

Nguồn: Nghiên cứu sinh đề xuất, kết hợp với khung giải pháp của luận án, 2026

3.2.1.2. Hoàn thiện tổ chức thực hiện quản lý và vận hành hệ thống bảo đảm an toàn hàng hải

Về mục tiêu giải pháp, giải pháp này nhằm xử lý trực tiếp hạn chế nổi bật nhất được chỉ ra ở Chương 2 và cũng là cấu phần có tác động lớn nhất trong mô hình định lượng, đó là chất lượng tổ chức thực hiện đối với quản lý hệ thống còn chưa tương xứng với yêu cầu phát triển của ngành. Dữ liệu Chương 2 cho thấy điểm nghẽn của tổ chức thực hiện và vận hành hệ thống bảo đảm an toàn hàng hải tập trung ở quản trị vòng đời tài sản, bảo trì và duy tu luồng, chất lượng nguồn lực, mức độ số hóa dữ liệu vận hành, cũng như cơ chế phân bổ nguồn lực còn nặng theo chu kỳ ngân sách hằng năm. Với hệ số tác động chuẩn hóa β = 0,438, H2 là trục cải cách cần được ưu tiên cao nhất trong mục 3.2. Mục tiêu đạt được của giải pháp này là nhằm hướng đến nâng cao năng lực tổ chức, điều hành và bảo đảm nguồn lực để hệ thống BĐATHH vận hành ổn định, đồng bộ và có khả năng thích ứng với tăng trưởng vận tải biển, biến đổi khí hậu và rủi ro thiên tai – sự cố; đồng thời tối ưu mô hình “Bộ quản lý – cơ quan chuyên ngành điều hành – đơn vị vận hành thực hiện” theo đúng chức năng, tăng hiệu quả sử dụng nguồn lực công, giảm xung đột lợi ích và nâng mức độ sẵn sàng của các cấu phần hệ thống BĐATHH theo chuẩn an toàn của quốc tế.

Về nội dung giải pháp, Bộ Xây dựng chuẩn hóa công tác quản trị vòng đời tài sản bảo đảm an toàn hàng hải theo chuỗi liên tục gồm: quy hoạch, đầu tư, vận hành, bảo trì, thay thế, thanh lý và đánh giá hiệu quả sau đầu tư. Mỗi thành phần như luồng, báo hiệu, VTS, hạ tầng truyền dẫn, nguồn điện, điểm quan trắc và thiết bị hỗ trợ điều phối đều được xác định là tài sản công cần quản lý thông qua hồ sơ vòng đời, gắn với các tiêu chí kỹ thuật và hiệu năng cụ thể. Trước hết, Bộ Xây dựng cần tổ chức thực hiện quản lý hệ thống theo thứ tự ưu tiên rủi ro, thay cho cách tiếp cận dàn trải. Trong đó, các cấu phần có ý nghĩa nền tảng như luồng hàng hải công cộng, báo hiệu hàng hải, VTS, dữ liệu thủy đạc – hải đồ và thông tin duyên hải cần được xác định là các cụm ưu tiên số một về đầu tư, bảo trì và giám sát. Trên cơ sở đó, Bộ Xây dựng chỉ đạo xây dựng kế hoạch trung hạn cho duy tu và bảo trì, gắn với đánh giá mức độ rủi ro, mức độ xuống cấp và vai trò của từng cấu phần trong chuỗi vận hành hệ thống, thay vì chủ yếu phụ thuộc vào kế hoạch năm tài khóa như giai đoạn trước. Cách tổ chức này đặc biệt cần thiết đối với công tác nạo vét duy tu luồng hàng hải, nơi tính liên tục của sa bồi và biến động thủy văn thường không trùng khớp với chu kỳ phân bổ vốn.

Một nội dung then chốt khác là chuẩn hóa và số hóa quản trị dữ liệu vận hành hệ thống. Bộ Xây dựng cần chỉ đạo xây dựng cơ chế tích hợp dữ liệu về báo hiệu, luồng, VTS, thông tin an toàn hàng hải, lịch bảo trì, tình trạng hỏng hóc và các cảnh báo hiện trường vào một nền quản trị dùng chung ở cấp chuyên ngành. Mục tiêu của số hóa ở đây không chỉ là điện tử hóa hồ sơ, mà là tạo khả năng điều hành dựa trên bằng chứng, rút ngắn thời gian phát hiện – phản ứng – khắc phục sự cố, đồng thời hỗ trợ phân bổ nguồn lực theo mức độ rủi ro. Trong tổ chức thực hiện, cần ưu tiên số hóa các nhật ký vận hành, lịch sử bảo trì, dữ liệu khảo sát thủy đạc và dữ liệu sự cố lặp lại của hệ thống. Đây là điều kiện để công tác bảo trì chuyển dần từ bảo trì khắc phục và bảo trì định kỳ sang bảo trì dự báo đối với các thiết bị then chốt. Việc này cũng góp phần xử lý nguyên nhân khách quan và chủ quan mà Chương 2 đã nêu, nhất là tình trạng thiếu nền tảng dữ liệu tích hợp và thói quen quản lý nặng về hồ sơ giấy tờ.

Song song với dữ liệu, việc hoàn thiện giải pháp này cần gắn chặt với nâng cao năng lực tổ chức và nhân lực thực thi. Bộ Xây dựng cần chuẩn hóa lại quy trình phối hợp giữa cơ quan quản lý nhà nước, cơ quan chuyên ngành, Cảng vụ và đơn vị vận hành hệ thống, nhất là tại các khu vực giao thoa giữa hàng hải và đường thủy nội địa, giữa vùng nước cảng biển và luồng hàng hải công cộng. Đây là yêu cầu có ý nghĩa đặc biệt trong giai đoạn sau thay đổi chủ thể quản lý nhà nước, trong đó trước thời điểm hợp nhất tháng 3/2025 là Bộ Giao thông vận tải. Về nhân lực, cần tập trung vào đội ngũ kỹ thuật trực tiếp gắn với quản trị dữ liệu, khảo sát thủy đạc, vận hành VTS, điều phối sự cố và an toàn thông tin. Trong điều kiện nguồn lực có hạn, việc nâng cao năng lực phải bám đúng các vị trí then chốt, thay vì trải đều. Về nguồn lực, Bộ Xây dựng xây dựng kế hoạch trung hạn cho công tác duy tu, bảo trì, phân định rõ nhiệm vụ chi thường xuyên phục vụ vận hành và phần đầu tư nâng cấp theo chương trình, đồng thời ưu tiên nguồn lực cho khu vực rủi ro cao và hành lang vận tải trọng điểm. Trong phạm vi pháp lý, Bộ cũng nghiên cứu cơ chế huy động nguồn lực xã hội cho các hạng mục công nghệ, quan trắc, truyền dẫn với nguyên tắc kiểm soát rủi ro, bảo đảm an ninh dữ liệu, chuẩn hóa kiến trúc kỹ thuật mà vẫn không ảnh hưởng đến trách nhiệm quản lý của cơ quan nhà nước.

Về tổ chức thực hiện giải pháp gồm: thứ nhất, Bộ Xây dựng chủ trì giữ vai trò điều phối chiến lược, phê duyệt chương trình và kế hoạch trung hạn, phân bổ nguồn lực theo ưu tiên rủi ro và chỉ đạo tổ chức thực hiện theo hành lang/luồng trọng điểm. Cục Hàng hải và Đường thủy Việt Nam thực hiện điều hành chuyên ngành, ban hành hướng dẫn kỹ thuật, tổ chức kiểm tra và trực tiếp chỉ đạo Cảng vụ triển khai tại vùng nước quản lý; Cảng vụ là tuyến đầu quản lý nhà nước tại hiện trường, thực hiện xác nhận trạng thái hệ thống, phối hợp điều phối sự cố và cập nhật dữ liệu. Tổng công ty Bảo đảm an toàn hàng hải Việt Nam là lực lượng nòng cốt thực hiện vận hành và bảo trì các cấu phần báo hiệu/luồng theo nhiệm vụ được giao, chịu trách nhiệm tuân thủ chuẩn kỹ thuật và chế độ dữ liệu. Đối với các nhiệm vụ đầu tư, nâng cấp, Ban Quản lý dự án Hàng hải và Đường thủy thuộc Bộ Xây dựng tham gia tổ chức chuẩn bị và quản lý thực hiện dự án, phối hợp Cục Hàng hải và Đường thủy Việt Nam và địa phương để bảo đảm tiến độ, chất lượng và giải phóng mặt bằng. Cục Đăng kiểm Việt Nam phối hợp đối với các nội dung liên quan tiêu chuẩn an toàn kỹ thuật, kiểm định và chứng nhận khi hệ thống hoặc thiết bị có yêu cầu đánh giá phù hợp, bảo đảm tính hợp chuẩn – hợp quy của cấu phần kỹ thuật. Thứ hai, điều kiện tiên quyết gồm nguồn tài chính ổn định cho duy tu – bảo trì; kiến trúc kỹ thuật và chuẩn dữ liệu tương thích để bảo đảm liên thông; năng lực nhân sự kỹ thuật, đặc biệt nhóm chuyên môn về thiết bị báo hiệu, khảo sát – thủy đạc, VTS và an toàn thông tin; cùng cơ chế phối hợp liên vùng để xử lý sự cố theo hành lang vận tải. Thứ ba, rủi ro trọng yếu là thiếu kinh phí bảo trì dẫn đến suy giảm mức độ sẵn sàng, đứt gãy nhân lực kỹ thuật chuyên sâu, đầu tư công nghệ rời rạc gây không tương thích và tăng chi phí tuân thủ, rủi ro tiêu cực và lãng phí trong nạo vét – duy tu, cùng tác động thiên tai làm hư hại thiết bị kéo dài thời gian khôi phục. Biện pháp giảm thiểu là thiết kế kế hoạch trung hạn có dự phòng rủi ro, chuẩn hóa mua sắm theo kiến trúc kỹ thuật, tăng cường kiểm tra độc lập, áp dụng cơ chế giám sát dựa trên dữ liệu và tổ chức diễn tập ứng phó – khôi phục theo cấp độ sự cố.

Bảng 3.3. Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện tổ chức thực hiện quản lý hệ thống bảo đảm an toàn hàng hải

[TABLE]

Nguồn: Nghiên cứu sinh đề xuất, kết hợp với khung giải pháp của luận án, 2026.

3.2.1.3. Hoàn thiện và nâng cao hiệu quả công tác kiểm tra, giám sát hệ thống bảo đảm an toàn hàng hải

Về mục tiêu giải pháp, nhằm khắc phục hạn chế của công tác giám sát hệ thống còn nặng thủ tục, dữ liệu còn phân tán và khả năng phản hồi chính sách từ giám sát chưa rõ nét. Kết quả định lượng cho thấy H3 chưa có ý nghĩa thống kê độc lập trong mô hình tổng thể. Điều đó không có nghĩa là khâu giám sát không quan trọng, mà gợi ý rằng vấn đề nằm ở phương thức giám sát hiện hành: tăng số cuộc kiểm tra chưa đủ để cải thiện kết quả quản lý nhà nước nếu thiếu cơ chế giám sát dựa trên rủi ro, thiếu dữ liệu vận hành tin cậy và thiếu vòng phản hồi chính sách sau giám sát. Vì vậy, trọng tâm của giải pháp không phải là gia tăng hình thức kiểm tra, mà là đổi mới bản chất của công tác giám sát nhằm thiết lập cơ chế giám sát đủ mạnh, đủ minh bạch và đủ dữ liệu để bảo đảm hệ thống BĐATHH vận hành đạt chuẩn, giảm tai nạn và sự cố liên quan báo hiệu/luồng, đồng thời nâng cao trách nhiệm giải trình của các chủ thể quản lý, điều hành, vận hành và khai thác theo cách tiếp cận quản trị rủi ro. Mục tiêu trung gian là chuyển đổi giám sát từ dựa trên kiểm tra thủ công sang giám sát số hóa và thanh tra theo rủi ro, trong đó dữ liệu vận hành và dữ liệu sự cố trở thành bằng chứng chủ đạo.

Về nội dung giải pháp, Bộ Xây dựng thiết lập ban hành khung chỉ số giám sát/KPI đối với hệ thống BĐATHH, trong đó các chỉ số ưu tiên phản ánh mức độ sẵn sàng của báo hiệu, thời gian gián đoạn, thời gian khôi phục, số sự cố lặp lại, mức độ tuân thủ lịch bảo trì, chất lượng thông báo hàng hải, chất lượng dữ liệu luồng và các chỉ dấu rủi ro theo khu vực. Để bảo đảm các chỉ số này phản ánh thực chất tình trạng hệ thống, quá trình xây dựng và hiệu chỉnh KPI cần lấy ý kiến đa chiều từ các đơn vị quản lý, khai thác thực tế, chuyên gia kỹ thuật cũng như tham khảo các chuẩn mực quốc tế về an toàn hàng hải. Việc này không chỉ giúp chuẩn hóa thước đo, mà còn tạo điều kiện thuận lợi cho việc so sánh, đánh giá hiệu quả quản lý ở các khu vực, qua đó xác định các hạn chế cần ưu tiên xử lý.

Trên nền KPI, Bộ Xây dựng thúc đẩy áp dụng giám sát số hóa thông qua nhật ký vận hành/bảo trì điện tử, bảng điều khiển theo thời gian thực, cảnh báo tự động khi thiết bị giảm dưới ngưỡng, và cơ chế đối soát dữ liệu giữa Cảng vụ, đơn vị vận hành và cơ quan quản lý chuyên ngành nhằm tăng khả năng kiểm chứng, truy vết và phát hiện sớm bất thường. Việc số hóa này tạo ra hệ thống dữ liệu liên thông, giúp loại bỏ tình trạng báo cáo thủ công, giảm nguy cơ sai sót, gian lận hoặc gián đoạn thông tin. Cơ chế đối soát dữ liệu giữa các bên không chỉ giúp kiểm tra chéo, phát hiện xung đột số liệu mà còn nâng cao tính minh bạch, trách nhiệm giải trình của từng chủ thể tham gia vào quá trình vận hành, bảo trì hệ thống BĐATHH.

Tiếp theo, cần chuyển thanh tra, kiểm tra hệ thống sang mô hình giám sát theo rủi ro. Điều đó có nghĩa là tần suất và phạm vi kiểm tra không được phân bổ cào bằng, mà phải dựa trên dữ liệu sự cố, mật độ tàu thuyền, tính chất phức tạp của luồng tuyến, mức độ xuống cấp của cấu phần kỹ thuật và lịch sử bất thường tại từng khu vực. Trong tổ chức thực hiện, các khu vực có mật độ tàu lớn, biến động sa bồi mạnh, tần suất hỏng hóc cao hoặc có lịch sử sự cố phải được xem là đối tượng giám sát ưu tiên. Đồng thời, cần gắn dữ liệu điều tra sự cố, dữ liệu tìm kiếm cứu nạn và dữ liệu phản ánh hiện trường vào một vòng phản hồi chính sách thống nhất để kết quả giám sát có thể quay trở lại hỗ trợ điều chỉnh tiêu chuẩn, quy trình, kế hoạch đầu tư và phương án vận hành.

Giải pháp giám sát cần được gắn với điều tra sự cố/tai nạn và tìm kiếm cứu nạn trong phạm vi thẩm quyền và cơ chế phối hợp, theo hướng tích hợp dữ liệu sự cố vào hệ thống giám sát để tạo vòng phản hồi chính sách – kỹ thuật, bảo đảm các bài học từ sự cố được chuyển hóa thành sửa đổi quy trình, tiêu chuẩn hoặc ưu tiên đầu tư. Việc này không chỉ giúp nâng cao năng lực phòng ngừa, xử lý sự cố mà còn đóng vai trò quan trọng trong việc cập nhật, điều chỉnh chính sách quản lý cho phù hợp với diễn biến thực tế. Bộ Xây dựng cùng các cơ quan liên quan cần xây dựng quy trình tích hợp và phân tích dữ liệu sự cố, bảo đảm các thông tin thu thập được sử dụng hiệu quả cho công tác cải tiến, đào tạo nhân lực và hoạch định đầu tư hệ thống BĐATHH.

Trên phương diện công cụ, cơ chế công khai có chọn lọc một phần chỉ số theo vùng nước/cụm cảng được xác định như một phương thức tăng áp lực cải thiện chất lượng và tạo kênh giám sát xã hội, đồng thời phải được thiết kế bảo đảm an ninh, an toàn thông tin và đúng thẩm quyền. Việc công khai này có thể thông qua các báo cáo định kỳ, bảng điều khiển giám sát trực tuyến hoặc bản tin chuyên ngành, cho phép các bên liên quan và cộng đồng có thể theo dõi, phản biện và đề xuất giải pháp cải thiện. Tuy nhiên, cần chú trọng xây dựng hệ thống bảo mật, phân quyền truy cập phù hợp để tránh lộ lọt dữ liệu nhạy cảm, đồng thời tuân thủ các quy định về bảo vệ thông tin cá nhân, bí mật doanh nghiệp và an toàn mạng.

Bổ sung vào đó, việc đào tạo nâng cao năng lực phân tích dữ liệu, sử dụng công nghệ số cho đội ngũ cán bộ giám sát, vận hành là yếu tố then chốt để giải pháp này phát huy hiệu quả lâu dài. Bộ Xây dựng nên phối hợp với các trường đại học như Đại học Hàng hải Việt Nam, Đại học Giao thông vận tải, viện nghiên cứu, tổ chức đào tạo chuyên sâu về quản trị dữ liệu, phân tích rủi ro và ứng dụng công nghệ mới, giúp cán bộ không chỉ vận hành tốt hệ thống giám sát mà còn chủ động phát hiện, xử lý các nguy cơ tiềm ẩn trong quản lý báo hiệu hàng hải. Bên cạnh đó, Bộ Xây dựng tập trung tổ chức thực hiện Đề án xây dựng Trường Đại học Hàng hải Việt Nam (theo Quyết định số 1901/QĐ-TTg ngày 05/9/2025 của Thủ tướng Chính phủ và Quyết định 2287/QĐ-BXD, ngày 12/12/2025 của Bộ Xây dựng) trở thành trường trọng điểm quốc gia về đào tạo và nghiên cứu, thông qua việc cụ thể hóa mục tiêu, phân công nhiệm vụ và điều phối các nguồn lực, qua đó bảo đảm cung ứng nguồn nhân lực hàng hải chất lượng cao chuẩn quốc tế phục vụ phát triển bền vững kinh tế biển.

Về tổ chức thực hiện giải pháp: thứ nhất, Bộ Xây dựng chỉ đạo, điều phối toàn bộ hệ thống giám sát BĐATHH cả nước, xây dựng quy chế liên ngành và cơ chế phản hồi để xử lý sự cố kịp thời, tập trung thanh tra, kiểm tra theo chuyên đề tại khu vực có rủi ro cao, dựa trên dữ liệu số hóa để chủ động phát hiện và xử lý nhanh chóng. Vụ Vận tải và An toàn giao thông tổng hợp báo cáo định kỳ, phân tích rủi ro, tham mưu ban hành KPI và cập nhật quy trình báo cáo phù hợp thực tiễn. Cục Hàng hải và Đường thủy Việt Nam hướng dẫn chuẩn hóa dữ liệu, thiết lập chế độ báo cáo, kiểm tra kỹ thuật, hỗ trợ đào tạo nâng cao năng lực cho cán bộ giám sát theo chuẩn quốc tế. Cảng vụ hàng hải quản lý nhà nước tại cảng, thu thập dữ liệu thực địa, giám sát báo hiệu hàng hải và báo cáo kết quả lên cấp trên; đồng thời phối hợp xử lý sự cố hoặc vi phạm. Đơn vị vận hành chịu trách nhiệm kiểm soát kỹ thuật, đảm bảo hệ thống hoạt động an toàn, cung cấp dữ liệu, đánh giá hiệu quả theo KPI, tăng minh bạch và giải trình với cộng đồng. Các bên cần đẩy mạnh đào tạo, ứng dụng công nghệ số, xây dựng dữ liệu liên thông và đối soát đa chiều để phát hiện sớm nguy cơ, nâng cấp hệ thống quản lý an toàn hàng hải theo tiêu chuẩn quốc tế. Thứ hai, điều kiện triển khai giải pháp bao gồm hệ thống dữ liệu đủ tin cậy, hạ tầng công nghệ thông tin an toàn, nhân lực phân tích dữ liệu và cơ chế chia sẻ dữ liệu đúng thẩm quyền để bảo đảm tính hợp pháp của bằng chứng giám sát và quy định pháp lý do Bộ ban hành. Thứ ba, rủi ro chủ yếu khi thực hiện là số liệu thiếu chuẩn hóa dẫn đến “mù thông tin”, báo cáo hình thức không phục vụ quyết định, xung đột vai trò giữa cơ quan giám sát và đơn vị vận hành, rủi ro lộ lọt hoặc gián đoạn dữ liệu do an ninh mạng, cùng nguy cơ thiết kế KPI không phù hợp tạo động cơ “chạy KPI” không thực chất. Biện pháp giảm thiểu là chuẩn hóa dữ liệu ngay từ đầu, thiết kế cơ chế kiểm tra chéo và kiểm toán dữ liệu, phân quyền truy cập hợp lý theo vai trò và thiết kế KPI theo nguyên tắc đo được, kiểm chứng được, gắn trách nhiệm và có cơ chế hiệu chỉnh định kỳ theo rủi ro.

Bảng 3.4. Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện giám sát, đánh giá hệ thống bảo đảm an toàn hàng hải

[TABLE]

Nguồn: Nghiên cứu sinh đề xuất, kết hợp với khung giải pháp của luận án, 2026

3.2.2. Nhóm giải pháp hoàn thiện quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

3.2.2.1. Hoàn thiện khung thể chế quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

Về mục tiêu của giải pháp, nhằm xử lý hạn chế về cơ chế giá, tài chính và định hướng chất lượng dịch vụ còn chưa hoàn thiện; tư duy quản lý đầu vào còn khá đậm; và dữ liệu phục vụ quản trị kết quả còn thiếu. Việc D1 chưa có ý nghĩa thống kê độc lập trong mô hình tổng thể cho thấy vấn đề không nằm ở số lượng quy định về dịch vụ, mà ở chỗ khung thể chế dịch vụ hiện nay chưa đủ “động”, chưa đủ đo lường được và chưa đủ sức dẫn dắt hành vi cung ứng theo chuẩn đầu ra. Vì vậy, giải pháp phải tập trung vào chất lượng thiết kế thể chế dịch vụ, thay vì mở rộng quy định theo hướng liệt kê hành chính.

Nội dung cốt lõi của giải pháp là Bộ Xây dựng hoàn thiện khung thể chế quản lý cung ứng dịch vụ BĐATHH theo hướng xác định rõ ranh giới giữa dịch vụ sự nghiệp công được Nhà nước đặt hàng – giao nhiệm vụ và dịch vụ có thể vận hành theo cơ chế giá thị trường có điều tiết; đồng thời chuẩn hóa chất lượng theo đầu ra để nâng cao minh bạch, tăng cường trách nhiệm giải trình và chuyển trọng tâm quản lý từ kiểm tra thủ công sang giám sát dựa trên dữ liệu trong toàn bộ chuỗi cung ứng dịch vụ BĐATHH (theo Nghị định 34/2025/NĐ-CP của Chính phủ). Trên cơ sở đó, Bộ Xây dựng chủ trì ban hành hoặc hoàn thiện các quy định thuộc thẩm quyền và tổ chức triển khai theo các nội dung liên kết chặt chẽ với nhau. Trong phạm vi pháp luật hiện hành, Bộ Xây dựng trực tiếp hoàn thiện các quy định thuộc thẩm quyền; đối với nội dung vượt thẩm quyền hoặc cần sửa đổi ở cấp luật, Bộ Xây dựng chủ trì tổng kết thi hành và tham mưu cơ quan có thẩm quyền xem xét sửa đổi theo đúng quy trình pháp lý.

Trước hết, Bộ Xây dựng chủ trì ban hành hệ thống các văn bản điều chỉnh hoạt động của các loại dịch vụ BĐATHH, ban hành bộ chuẩn chất lượng đầu ra tối thiểu cho từng nhóm dịch vụ và chuẩn bị cho hành lang pháp lý của dịch vụ bảo đảm an toàn hàng hải mới trong tương lai theo xu hướng quốc tế, đồng thời Bộ cần đề xuất bổ sung những nội dung quan trọng này vào Bộ Luật hàng hải mới: cơ chế tài chính, định mức kinh tế kỹ thuật, điều kiện cung cấp; đồng thời quy định phạm vi, tiêu chuẩn kỹ thuật và tiêu chuẩn chất lượng áp dụng cho từng nhóm dịch vụ theo cách tiếp cận đo lường được. Trọng tâm của chuẩn hóa là xác lập bộ tiêu chí đầu ra bắt buộc làm căn cứ quản lý, đặt hàng và giám sát, bao gồm các đơn vị đo lường như tỷ lệ sẵn sàng của hệ thống báo hiệu, thời gian khắc phục sự cố, thời gian đáp ứng điều động hoa tiêu, mức độ đầy đủ, kịp thời và chính xác của thông tin an toàn hàng hải. Việc chuẩn hóa theo đầu ra tạo nền tảng cho quản lý nhất quán trên toàn quốc, hạn chế khoảng trống trách nhiệm và giảm bất cân xứng thông tin giữa cơ quan quản lý với nhà cung ứng dịch vụ BĐATHH.

Cùng với chuẩn chất lượng, Bộ cần chuyển cơ chế giá và định mức theo hướng gắn chặt hơn với đầu ra và trách nhiệm giải trình. Đối với các dịch vụ mang tính công ích, ngân sách nhà nước chi trả theo phương thức đặt hàng dựa trên định mức chi phí được xác lập khoa học, minh bạch và gắn chặt với tiêu chí chất lượng; qua đó chuyển từ logic “chi theo đầu vào” sang “thanh toán theo kết quả”. Đối với các dịch vụ có thể vận hành theo cơ chế thị trường, Bộ Xây dựng phối hợp với cơ quan quản lý giá và ngân sách thiết kế hệ thống giá có điều tiết nhằm vừa tạo động lực nâng cao chất lượng, vừa kiểm soát rủi ro độc quyền tự nhiên và bảo vệ lợi ích của các bên liên quan; đồng thời quy định nghĩa vụ niêm yết, kê khai và công khai cấu phần giá cùng tiêu chí chất lượng đi kèm. Trong thực tiễn, Bộ Xây dựng đã ban hành các quy định về định mức chi phí áp dụng cho dịch vụ sự nghiệp công về Thông tin duyên hải sử dụng ngân sách nhà nước theo phương thức đặt hàng, xác định rõ đối tượng áp dụng là Cục Hàng hải và Đường thủy Việt Nam cùng Công ty TNHH MTV Thông tin điện tử Hàng hải Việt Nam (VISHIPEL), qua đó cung cấp cơ sở vận hành cho cơ chế đặt hàng gắn trách nhiệm giải trình.

Đồng thời, Bộ Xây dựng ban hành và áp dụng các chuẩn quản trị dữ liệu đối với dịch vụ BĐATHH như một trụ cột quyết định của quản lý hiện đại. Theo đó, Bộ Xây dựng quy định tiêu chuẩn dữ liệu đối với báo hiệu, dữ liệu lượt dẫn tàu và dữ liệu thông tin an toàn hàng hải; xác lập ngưỡng dữ liệu tối thiểu phải thu thập; quy định chuẩn kết nối – chia sẻ; và thiết lập cơ chế lưu trữ, sử dụng dữ liệu làm căn cứ pháp lý cho hậu kiểm, giám sát và thanh toán đặt hàng. Đối với dịch vụ hoa tiêu, các văn bản quy phạm pháp luật đã quy định tiêu chuẩn đào tạo, cấp chứng chỉ cho hoa tiêu đồng thời yêu cầu các tổ chức hoa tiêu xây dựng cơ sở dữ liệu quản lý lượt dẫn tàu, đặt mốc hoàn thành trước ngày 01/01/2027. Trên cơ sở đó, Bộ Xây dựng giao Cục Hàng hải và Đường thủy Việt Nam (VIMAWA) tổ chức kiểm tra, đôn đốc và xác nhận mức độ hoàn thành nền tảng dữ liệu lượt dẫn tàu theo đúng mốc thời gian, coi đây là điều kiện quan trọng để vận hành cơ chế giám sát dựa trên dữ liệu và nâng cao hiệu lực quản lý nhà nước.

Cuối cùng, Bộ Xây dựng làm rõ cơ chế tổ chức hệ thống thực thi ở địa phương, đặc biệt là vai trò của Cảng vụ và các đầu mối chuyên môn trong quản lý chất lượng dịch vụ BĐATHH tại vùng nước cảng biển. Việc chuẩn hóa các văn bản quy phạm pháp luật về tổ chức và hoạt động của Cảng vụ tạo cơ sở pháp lý thống nhất cho điều phối, kiểm soát chất lượng và giám sát thực địa; qua đó hạn chế phân tán trách nhiệm và bảo đảm các hoạt động cung cấp dịch vụ được vận hành hiệu quả, phù hợp với mục tiêu hiện đại hóa và nâng cao năng lực quản lý nhà nước trong lĩnh vực hàng hải.

Về tổ chức thực hiện giải pháp: trước hết, Bộ Xây dựng chủ động, chịu trách nhiệm chủ trì ban hành hoặc điều chỉnh các quy định thuộc thẩm quyền; đồng thời phân công rõ vai trò tham mưu trong nội bộ Bộ gắn với chuỗi công cụ quản lý. Vụ Pháp chế chủ trì rà soát thẩm quyền, bảo đảm hợp hiến, hợp pháp của cơ chế đặt hàng, quản trị dữ liệu và chế tài; Vụ Kế hoạch – Tài chính chủ trì thiết kế định mức, đơn giá và quy trình thanh toán theo đầu ra, phối hợp cơ quan quản lý giá và ngân sách để bảo đảm tính khả thi, minh bạch; Vụ Vận tải và An toàn giao thông chủ trì nội dung chuyên ngành về tiêu chuẩn, quy chuẩn, danh mục dịch vụ và khung KPI/SLA tối thiểu. Cục Hàng hải và Đường thủy Việt Nam là cơ quan chuyên ngành giúp Bộ soạn thảo tiêu chuẩn, quy chuẩn, danh mục dịch vụ, định mức/đơn giá, hướng dẫn thực hiện; đồng thời tổ chức kiểm tra, tổng hợp dữ liệu và báo cáo chất lượng dịch vụ phục vụ điều hành nhà nước. Cảng vụ hàng hải (trực thuộc VIMAWA) là đầu mối thực thi quản lý nhà nước tại khu vực cảng biển, phối hợp với đơn vị cung ứng để chuẩn hóa dữ liệu đầu vào và xác nhận thực trạng hiện trường phục vụ quản lý và giám sát. Thứ hai, điều kiện triển khai là phải có dữ liệu chi phí, dữ liệu vận hành và dữ liệu chất lượng đủ tin cậy để tránh tình trạng định mức thấp nhưng yêu cầu chất lượng cao, hoặc ngược lại. Thứ ba, rủi ro cần kiểm soát là tiếp tục duy trì tư duy quản lý đầu vào, khiến bộ chuẩn dịch vụ bị biến thành điều kiện hành chính cứng; hoặc xây dựng cơ chế giá mà không đi cùng chuẩn chất lượng và dữ liệu, làm suy giảm hiệu quả điều tiết. Vì vậy, việc hoàn thiện cơ chế, pháp luật về quản lý cung ứng dịch vụ trong giai đoạn đến năm 2030 cần được định hướng như một quá trình chuẩn hóa có thể đo lường được, thay vì quy định hóa theo lối liệt kê.

Bảng 3.5. Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện khung thể chế quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

[TABLE]

Nguồn: Nghiên cứu sinh đề xuất, kết hợp với khung giải pháp của luận án, 2026.

3.2.2.2. Hoàn thiện công tác tổ chức thực hiện quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

Về mục tiêu giải pháp, nhằm xử lý trực tiếp hạn chế tổ chức cung ứng dịch vụ và quản lý hợp đồng chưa thật sự hiệu quả; cơ chế phối hợp giữa các chủ thể trong chuỗi cung ứng dịch vụ còn phân tán; năng lực áp dụng KPI/SLA và quản trị dữ liệu còn hạn chế. Qua đó hướng đến mục tiêu xây dựng và tổ chức thực thi quản lý cung ứng dịch vụ BĐATHH theo mô hình “một chuỗi cung ứng dịch vụ thống nhất”, trong đó Bộ Xây dựng giữ vai trò ban hành chính sách và chịu trách nhiệm trước Chính phủ về chất lượng dịch vụ; Cục Hàng hải và Đường thủy Việt Nam là cơ quan điều phối chuyên ngành; Cảng vụ hàng hải là đầu mối tại hiện trường; các doanh nghiệp và tổ chức cung ứng dịch vụ thực hiện theo hợp đồng hoặc đặt hàng gắn KPI/SLA. Trong mô hình này, chuyển đổi số là điều kiện vận hành cốt lõi, giúp giảm giám sát thủ công, tiết kiệm chi phí tuân thủ và nâng cao chất lượng, an toàn của dịch vụ.

Về nội dung và phương pháp thực hiện, Bộ Xây dựng thiết kế cơ chế phòng ngừa xung đột lợi ích trong toàn bộ chuỗi cung ứng dịch vụ bằng việc tách bạch rành mạch giữa chức năng quản lý nhà nước và hoạt động cung ứng dịch vụ. Theo đó, các hoạt động ban hành tiêu chuẩn, cấp phép, kiểm tra, thanh tra, xử lý vi phạm và chấm điểm KPI thuộc cơ quan quản lý nhà nước; trong khi vận hành báo hiệu, điều động hoa tiêu, khai thác thông tin duyên hải do các đơn vị cung ứng thực hiện theo hợp đồng hoặc đặt hàng. Trọng tâm của tách bạch là bảo đảm minh bạch về chất lượng và chi phí dịch vụ, giảm thiểu tình trạng “vừa quản lý vừa cung ứng” trong cùng một chuỗi quyết định. Trong bối cảnh Ủy ban Quản lý vốn nhà nước tại doanh nghiệp đã được giải thể từ ngày 21/3/2025, Bộ Xây dựng cần thiết kế cơ chế tách biệt giữa chức năng đại diện chủ sở hữu doanh nghiệp và chức năng quản lý nhà nước chuyên ngành, qua đó củng cố tính khách quan của giám sát và nâng hiệu quả quản trị công.

Trên nền tảng tách bạch, Bộ Xây dựng chỉ đạo kiện toàn các chủ thể cung ứng dịch vụ trọng yếu theo cấu trúc chuỗi giá trị nhằm bảo đảm vận hành đồng bộ, nhằm cung ứng hệ thống dịch vụ bảo đảm an toàn hàng hải theo chuẩn mực quốc tế và góp phần phát triển kinh tế biển. Đơn cử, một số dịch vụ như đối với báo hiệu hàng hải, tiếp tục củng cố năng lực vận hành tập trung của doanh nghiệp nòng cốt, mới được hợp nhất là Tổng công ty Bảo đảm an toàn hàng hải Việt Nam, theo hướng chuẩn hóa năng lực, quản trị chất lượng và tăng tính chuyên nghiệp. Đối với thông tin duyên hải và thông tin hàng hải, Bộ Xây dựng tổ chức áp dụng cơ chế đặt hàng dịch vụ sự nghiệp công gắn định mức chi phí và chuẩn chất lượng; VISHIPEL tiếp tục được Nhà nước giao nhiệm vụ quản lý, khai thác hệ thống thông tin duyên hải Việt Nam để bảo đảm tính liên tục, ổn định của dịch vụ. Đối với hoa tiêu hàng hải, Bộ Xây dựng quy định yêu cầu các tổ chức hoa tiêu chuẩn hóa quy trình điều động, hồ sơ năng lực và dữ liệu lượt dẫn tàu, bảo đảm kết nối liên thông dữ liệu với Cảng vụ; mốc 01/01/2027 là điểm chuyển đổi quan trọng để quản lý điều hành dựa trên dữ liệu có thể vận hành thực chất. Đối với các loại hình dịch vụ khác, Bộ cũng cần có cơ chế quản lý phù hợp với tính chất kỹ thuật, điều kiện cung ứng và yêu cầu kiểm soát chất lượng của từng dịch vụ.

Bộ Xây dựng đổi mới phương thức hợp đồng và đặt hàng dịch vụ công ích theo hướng lấy đầu ra làm trung tâm, tích hợp giá/đơn giá với KPI/SLA và cơ chế thưởng – phạt rõ ràng để tạo động lực cải thiện chất lượng. Cụ thể, các hợp đồng dịch vụ công ích sẽ được thiết kế dựa trên kết quả thực tế, trong đó việc xác định giá hoặc đơn giá dịch vụ phải gắn liền với các chỉ số hiệu suất (KPI) và mức độ đáp ứng cam kết chất lượng dịch vụ (SLA). Điều này không chỉ giúp minh bạch hóa các tiêu chí đánh giá chất lượng, mà còn tạo ra cơ chế khuyến khích và chế tài rõ ràng, thúc đẩy các đơn vị cung ứng dịch vụ nâng cao năng lực, chủ động cải tiến quy trình, đáp ứng tốt hơn nhu cầu của người sử dụng và các bên liên quan.

Bên cạnh đó, đối với các dịch vụ vận hành theo giá thị trường có điều tiết, Bộ Xây dựng quy định cơ chế niêm yết, kê khai và công khai đầy đủ các yếu tố cấu thành giá cùng các tiêu chí chất lượng dịch vụ. Đây là biện pháp quản lý bắt buộc nhằm ngăn chặn tình trạng áp dụng giá cào bằng không hợp lý, giảm nguy cơ lạm dụng vị thế thị trường của các đơn vị cung ứng, đồng thời tăng cường sự giám sát minh bạch từ phía các cơ quan quản lý nhà nước cũng như người sử dụng dịch vụ. Việc công khai thông tin về cơ cấu giá và chất lượng sẽ giúp các bên liên quan dễ dàng so sánh, đánh giá, lựa chọn nhà cung ứng phù hợp, từ đó nâng cao hiệu quả sử dụng nguồn lực xã hội và thúc đẩy cạnh tranh lành mạnh trong lĩnh vực dịch vụ công ích. Với phương thức đổi mới này, Bộ Xây dựng hướng tới mục tiêu xây dựng một hệ thống quản lý dịch vụ BĐATHH vừa bảo đảm sự công bằng, minh bạch, vừa tạo động lực phát triển, nâng cao chất lượng phục vụ, góp phần vào sự phát triển bền vững của ngành và các yêu cầu của phát triển kinh tế – xã hội trong bối cảnh mới.

Cuối cùng, Bộ Xây dựng cần tăng cường năng lực thực thi tại Cảng vụ Hàng hải nhằm đảm bảo vận hành chuỗi dịch vụ một cách thống nhất. Quy trình phối hợp giữa các bên liên quan sẽ được chuẩn hóa, đồng thời triển khai cơ chế một cửa dữ liệu tại cảng giúp đồng bộ hóa quy trình, giảm trùng lặp, tối ưu hóa nguồn lực và nâng cao hiệu quả quản lý. Việc áp dụng công nghệ thông tin và chuyển đổi số góp phần tăng cường tính minh bạch, đẩy nhanh tốc độ xử lý tình huống, cũng như đánh giá chất lượng dịch vụ dựa trên các chỉ số KPI và SLA. Khi hệ thống dữ liệu được tích hợp chặt chẽ, quá trình giám sát và cải tiến hoạt động trở nên chủ động hơn, đáp ứng tốt nhu cầu sử dụng và tiêu chuẩn quốc tế. Cơ chế một cửa dữ liệu còn đóng vai trò là nền tảng xây dựng môi trường quản lý hiện đại, hướng tới Big Data và AI để nâng cao khả năng quyết định, dự báo, qua đó thúc đẩy phát triển kinh tế biển bền vững.

Về tổ chức thực hiện giải pháp: Thứ nhất, Bộ Xây dựng chủ trì và giữ vai trò thống nhất cơ chế và chuẩn hóa mô hình quản lý; Cục Hàng hải và Đường thủy Việt Nam điều phối chuyên ngành, hướng dẫn và kiểm tra; Cảng vụ hàng hải là đầu mối xác nhận hiện trường, điều phối thực địa và tiếp nhận dữ liệu; các doanh nghiệp và tổ chức cung ứng có trách nhiệm cung cấp dịch vụ theo chuẩn, cung cấp đủ dữ liệu và chấp hành cơ chế giám sát. Thứ hai, điều kiện triển khai là phải có quy trình dữ liệu đủ thống nhất, cơ chế hợp đồng đủ rõ và hạ tầng số đủ tối thiểu để tránh gián đoạn chuỗi cung ứng dịch vụ. Thứ ba, rủi ro cần kiểm soát là hợp đồng đầu ra nhưng không có dữ liệu chứng minh đầu ra; phối hợp liên chủ thể bị hình thức hóa; hoặc duy trì tình trạng “một cơ chế cho mọi dịch vụ”, trong khi mỗi dịch vụ có đặc tính kỹ thuật và mức độ rủi ro khác nhau. Vì vậy, giải pháp này cần được triển khai theo hướng “chuỗi dịch vụ thống nhất nhưng quản trị theo đặc tính từng dịch vụ”.

Bảng 3.6. Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện tổ chức thực hiện quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải

[TABLE]

Nguồn: Nghiên cứu sinh đề xuất, kết hợp với khung giải pháp của luận án, 2026

3.2.2.3. Hoàn thiện công tác giám sát, đánh giá chất lượng dịch vụ bảo đảm an toàn hàng hải

Về mục tiêu giải pháp, nhằm xây dựng cơ chế giám sát chất lượng dịch vụ BĐATHH một cách liên tục, dựa trên dữ liệu và quản lý rủi ro, qua đó giảm phụ thuộc vào kiểm tra thủ công và tăng khả năng phát hiện sớm nguy cơ mất an toàn. Cụ thể, Giải pháp này nhằm xử lý hạn chế trong công tác giám sát, nghiệm thu và phản hồi chất lượng dịch vụ còn hình thức; năng lực phân tích dữ liệu và tiếp nhận phản ánh còn yếu; tiêu chuẩn giám sát liên thông chưa hoàn thiện. Bên cạnh đó, D3 có ý nghĩa thống kê trong mô hình với β = 0,088, cho thấy đây là một cấu phần có tác động thực tế nhưng chỉ phát huy hiệu quả khi được đặt trên nền D2 đủ vững. Vì vậy, giải pháp này không tách rời khỏi việc hoàn thiện tổ chức thực hiện, mà cần được thiết kế như khâu bảo đảm chất lượng đầu ra của toàn bộ chuỗi cung ứng dịch vụ. Về nội dung của giải pháp, trọng tâm đầu tiên là thiết lập một khung KPI/SLA tối thiểu áp dụng thống nhất cho các nhóm dịch vụ bảo đảm an toàn hàng hải. Đối với hoa tiêu hàng hải, các chỉ số cần tập trung vào thời gian điều động, thời gian tàu chờ, tỷ lệ hủy hoặc lùi chuyến do nguyên nhân chủ quan và mức độ an toàn của lượt dẫn tàu. Đối với thông tin an toàn hàng hải và thông tin duyên hải, cần theo dõi độ kịp thời, độ đầy đủ, độ liên tục và chất lượng xử lý phản hồi. Đối với các dịch vụ công ích gắn với báo hiệu, VTS hoặc nhiệm vụ bảo đảm an toàn liên quan, cần gắn các chỉ số vận hành và khôi phục với cơ chế nghiệm thu, thanh toán và xử lý vi phạm. Việc chuẩn hóa KPI/SLA ở đây không chỉ để đo lường, mà còn để thiết lập một ngôn ngữ quản lý thống nhất giữa Bộ Xây dựng, cơ quan chuyên ngành, Cảng vụ và nhà cung ứng dịch vụ.

Trên nền khung chỉ số đó, Bộ cần chuyển mạnh từ giám sát nặng tiền kiểm sang hậu kiểm thông minh dựa trên dữ liệu điều động, dữ liệu cung ứng, dữ liệu phản hồi và dữ liệu hiện trường. Điều này có nghĩa là nghiệm thu và thanh toán không nên chỉ dựa vào biên bản hoặc hồ sơ giấy, mà cần gắn với bằng chứng số, nhật ký điện tử, dữ liệu điều hành và dữ liệu phản hồi đã được đối soát. Bộ Xây dựng cần chỉ đạo xây dựng các dashboard giám sát chất lượng dịch vụ theo cụm cảng hoặc vùng nước trọng điểm, để cơ quan quản lý có thể theo dõi liên tục các chỉ số dịch vụ thay vì chờ tới kỳ kiểm tra định kỳ. Cùng với đó, cơ chế tiếp nhận phản ánh của doanh nghiệp vận tải biển, đại lý tàu, cảng biển và người sử dụng dịch vụ cần được chuẩn hóa, coi đây là một nguồn dữ liệu bổ sung có giá trị đối với giám sát chất lượng thực tế.

Cuối cùng, Bộ Xây dựng hoàn thiện hệ thống chế tài gắn chặt với hợp đồng/đặt hàng dịch vụ công và điều kiện cấp phép hoạt động của tổ chức cung ứng. Về chế tài tài chính, áp dụng các biện pháp xử phạt dựa trên kết quả KPI– SLA, bao gồm phạt theo mức độ vi phạm từng chỉ số; cắt giảm hoặc tạm dừng thanh toán khi không đáp ứng chất lượng hoặc không cung cấp đủ bằng chứng dữ liệu; và kéo dài thời hạn thanh toán khi cần xác minh, bổ sung dữ liệu. Về chế tài hành chính, áp dụng đình chỉ hoạt động, thu hồi giấy phép hoặc hạn chế phạm vi cung ứng đối với tổ chức vi phạm nghiêm trọng hoặc tái phạm. Đồng thời, công khai kết quả xếp hạng chất lượng trên cổng thông tin điện tử của Bộ và các cơ quan quản lý nhà nước liên quan được xem là công cụ tạo áp lực xã hội nhằm thúc đẩy cạnh tranh lành mạnh và nâng chất lượng dịch vụ BĐATHH.

Về tổ chức thực hiện giải pháp: Thứ nhất, Bộ Xây dựng chủ trì và ban hành khung chỉ số, nguyên tắc giám sát và chế tài; Cục Hàng hải và Đường thủy Việt Nam vận hành hệ thống giám sát chuyên ngành, tổng hợp báo cáo chất lượng và tổ chức đánh giá định kỳ; Cảng vụ hàng hải thực hiện kiểm chứng hiện trường, tiếp nhận phản ánh và phối hợp xử lý vi phạm; các doanh nghiệp và tổ chức cung ứng có trách nhiệm cung cấp đầy đủ dữ liệu, chấp hành đối soát và chịu trách nhiệm về tính trung thực của bằng chứng số. Thứ hai, về điều kiện triển khai hệ thống giải pháp trên cần phải có cơ sở pháp lý cho việc sử dụng dữ liệu điện tử như chứng cứ giám sát, có hạ tầng an toàn thông tin đủ tin cậy và có năng lực phân tích dữ liệu ở cấp cơ quan thực thi. Thứ ba, rủi ro cần kiểm soát là dữ liệu thiếu chuẩn xác, dẫn đến đánh giá sai; hoặc hiện tượng “lách KPI” làm sai lệch mục tiêu an toàn thực chất. Vì vậy, giải pháp giám sát dịch vụ cần được hoàn thiện theo hướng giám sát liên tục, nghiệm thu có chứng cứ, phản hồi có xử lý.

Bảng 3.7. Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện giám sát, đánh giá chất lượng dịch vụ bảo đảm an toàn hàng hải

[TABLE]

Nguồn: Nghiên cứu sinh đề xuất, kết hợp với khung giải pháp của luận án, 2026

3.3. KIẾN NGHỊ HOÀN THIỆN QUẢN LÝ NHÀ NƯỚC VỀ BẢO ĐẢM AN TOÀN HÀNG HẢI Ở VIỆT NAM

Các giải pháp tại mục 3.2 được thiết kế trong phạm vi thẩm quyền của Bộ Xây dựng; tuy nhiên, hiệu lực triển khai phụ thuộc đáng kể vào (i) hoàn thiện khung pháp lý ở cấp luật; (ii) cơ chế điều phối liên ngành ở cấp Chính phủ; và (iii) cơ chế tài chính, dữ liệu, an ninh mạng có tính liên thông. Thực tiễn quản trị công trong lĩnh vực liên ngành cho thấy, nếu thiếu phân cấp trách nhiệm rõ ràng và cơ chế phối hợp thống nhất, hệ thống giải pháp dễ bị phân tán, thiếu liên thông nguồn lực và dữ liệu, làm giảm khả năng đo lường theo KPI/SLA và giảm tính chủ động trong quản trị rủi ro.

3.3.1. Kiến nghị với Quốc hội

Một là, đưa vào chương trình sửa đổi, bổ sung Bộ luật Hàng hải theo hướng khắc phục khoảng trống quản lý vòng đời kết cấu hạ tầng hàng hải. Báo cáo tổng kết thi hành nêu rõ pháp luật chuyên ngành hàng hải hiện hành chưa có quy định về xử lý, quản lý kết cấu hạ tầng hàng hải sau khi dự án hết thời hạn/ chấm dứt hoạt động hoặc khi tổ chức, cá nhân bàn giao cho Nhà nước quản lý, vận hành; khoảng trống này có thể ảnh hưởng trực tiếp đến an toàn, môi trường và trật tự quản lý tài sản công. Kiến nghị Quốc hội xem xét bổ sung quy định theo hướng xác định rõ thẩm quyền, trình tự–thủ tục, nguồn lực thực hiện và nguyên tắc bình đẳng trong khai thác/kết thúc dự án, tạo căn cứ pháp lý ổn định cho quản lý vòng đời hạ tầng. Ngoài ra, các nội dung xu hướng mới trên thế giới, dịch vụ bảo đảm an toàn hàng hải mới, và những thay đổi theo xu thế của thời đại cũng cần đưa vào Bộ luật Hàng hải mới để tránh lạc hậu. Triển khai hệ thống chính sách liên quan tới hàng hải và bảo đảm an toàn hàng hải phù hợp với xu thế và các tiêu chuẩn quốc tế.

Hai là, hoàn thiện khuôn khổ pháp lý ở tầm luật đối với quản trị dữ liệu hàng hải và giám sát dựa trên dữ liệu. Chương 2 khẳng định hạn chế chủ yếu nằm ở “quản trị dữ liệu” và chỉ ra tồn tại khoảng trống pháp lý cấp luật về quản lý, khai thác và bảo mật dữ liệu hàng hải, khiến tích hợp dữ liệu thời gian thực và đo KPI/SLA gặp khó khăn, đồng thời ảnh hưởng chia sẻ dữ liệu liên ngành. Kiến nghị Quốc hội định hướng luật hóa các nguyên tắc tối thiểu về dữ liệu: quyền–trách nhiệm cung cấp/khai thác, chuẩn bảo mật và lưu vết, cơ chế chia sẻ dữ liệu phục vụ giám sát rủi ro, bảo đảm dữ liệu trở thành căn cứ cho quản trị theo kết quả.

Ba là, tạo hành lang pháp lý cho cơ chế quản trị theo kết quả (KPI/SLA) và cơ chế tài chính bền vững đối với dịch vụ công ích BĐATHH. Luận án nhấn mạnh KPI/SLA là chuẩn mực quốc gia và có thể tích hợp vào phân bổ ngân sách, hợp đồng PPP và hợp đồng vận hành và bảo trì (O&M); đồng thời trong nhóm giải pháp dịch vụ có đề xuất cơ chế tài chính bền vững thông qua khung giá theo chất lượng và cơ chế tài chính bảo đảm an toàn hàng hải linh hoạt. Vì vậy, kiến nghị Quốc hội xem xét khuôn khổ pháp lý cho (i) áp dụng KPI/SLA như tiêu chí bắt buộc trong đặt hàng/đấu thầu dịch vụ công ích; (ii) cơ chế quỹ/nguồn lực ổn định, minh bạch và được kiểm toán, nhằm giảm áp lực “chi phí khó dự báo” và tăng năng lực ứng phó nhiệm vụ đột xuất.

3.3.2. Kiến nghị với Chính phủ

Một là, thiết lập cơ chế điều phối liên ngành cấp quốc gia về an toàn hàng hải. Cần thành lập Ban Điều phối An toàn hàng hải quốc gia cấp Chính phủ do một Phó Thủ tướng chủ trì nhằm phối hợp chính sách, chương trình liên ngành mà không làm thay đổi chức năng từng bộ. Kiến nghị Chính phủ cụ thể hóa bằng Quyết định thành lập Ban Điều phối kèm quy chế hoạt động, cơ chế giải quyết các vấn đề liên ngành (luồng tuyến, dữ liệu, ứng phó sự cố, an ninh mạng) cần xử lý. Đề nghị sử dụng nguồn nhân lực hiện có của Cục Hàng hải và Đường thủy Việt Nam sau khi hợp nhất, đồng thời sắp xếp thành phần Ban cho phù hợp, cơ quan thường trực nên được đặt tại Cục Hàng hải và Đường thủy Việt Nam. Không làm tăng nhân lực, bộ máy trong bối cảnh cả nước đang thực hiện cuộc cách mạng tinh gọn bộ máy.

Hai là, ban hành khung phối hợp–phân cấp theo nguyên tắc “một đầu mối điều phối – nhiều chủ thể thực hiện”, giảm chồng chéo khi triển khai tại tuyến/vùng. Chính phủ xem xét triển khai mô hình điều phối thống nhất, chuẩn hóa SOP (xây dựng và vận hành các quy trình theo tiêu chuẩn thống nhất, đồng bộ, có thể đo lường và đánh giá) và yêu cầu phân định rõ vai trò giữa Bộ Xây dựng, Cục Hàng hải và Đường thủy Việt Nam, Cảng vụ, doanh nghiệp hạ tầng và địa phương; đồng thời gợi ý “bản đồ trách nhiệm/RACI” để liên kết các tầng chủ thể. Kiến nghị Chính phủ ban hành quy định/đề án về phối hợp liên ngành và phân cấp trong các tình huống bình thường–bất thường, từ đó làm cơ sở triển khai nhất quán các giải pháp KPI/SLA, dữ liệu và giám sát theo rủi ro.

Ba là, chỉ đạo cơ chế tài chính trung hạn và ngân sách theo kết quả đối với duy tu–vận hành hạ tầng BĐATHH. Chương 2 cho thấy chi phí nạo vét/duy tu luồng hàng hải lớn, toàn bộ lấy từ ngân sách nhà nước và “áp lực do chi phí khó dự báo”, PPP không phù hợp cho duy tu luồng nên huy động nguồn lực xã hội còn hạn chế. Chính phủ cần chỉ đạo xây dựng cơ chế phân bổ ngân sách theo “kết quả–rủi ro” và thiết kế cơ chế phản ứng tài chính cho nhiệm vụ đột xuất (giảm thời gian phê duyệt/giải ngân, gắn với KPI).

Bốn là, chỉ đạo chương trình chuyển đổi số và bảo đảm an ninh mạng cho hạ tầng giám sát của BĐATHH theo hướng quản trị rủi ro. Chương 3 đã đặt yêu cầu xây dựng trung tâm dữ liệu/giám sát, hồ dữ liệu tập trung và cơ chế an ninh mạng 24/7, đồng thời nhấn mạnh kiến trúc dữ liệu theo chuẩn quốc tế và cơ chế giám sát dựa trên dữ liệu. Kiến nghị Chính phủ ban hành chương trình/đề án liên ngành về dữ liệu, an ninh mạng hàng hải, coi an ninh mạng vận hành là điều kiện bắt buộc trong phê duyệt đầu tư và vận hành hệ thống BĐATHH.

Năm là, Chính phủ cần chỉ đạo quyết liệt việc phát triển Trường Đại học Hàng hải Việt Nam thành trường trọng điểm quốc gia và khu vực về hàng hải. Đồng thời, chỉ đạo Bộ Xây dựng và các cơ quan liên quan nhanh chóng thực hiện Quyết định số 1901/QĐ-TTg và Quyết định số 2287/QĐ-BXD, phân rõ trách nhiệm giữa các đơn vị, đảm bảo tiến độ, chất lượng đào tạo, nghiên cứu khoa học gắn với kinh tế biển. Việc triển khai phải được giám sát chặt chẽ nhằm nâng cao chất lượng nguồn nhân lực hàng hải, đáp ứng yêu cầu hội nhập và phát triển bền vững kinh tế biển quốc gia.

3.3.3. Kiến nghị với các cơ quan khác

Một là, đối với Bộ Tài chính, các cơ quan tài chính–kế hoạch và các chủ thể phân bổ nguồn lực. Đề nghị phối hợp thiết kế cơ chế tài chính bền vững, đa dạng hóa nguồn vốn (ngân sách nhà nước, phí dịch vụ, hợp tác công–tư, hỗ trợ kỹ thuật…) để bảo đảm duy tu–nâng cấp liên tục các cấu phần như AtoN, AIS/VTS, SAR, nền tảng dữ liệu số; đồng thời gắn phân bổ nguồn lực với KPI/SLA và kết quả đầu ra để nâng trách nhiệm giải trình.

Hai là, đối với cơ quan chuyên trách an toàn thông tin/an ninh mạng. Đề nghị phối hợp xây dựng chuẩn tối thiểu, quy trình ứng cứu sự cố và cơ chế diễn tập định kỳ đối với các hệ thống thông tin hàng hải trọng yếu (AIS/VTS/SCADA/Data Lake), bảo đảm vận hành liên tục và có khả năng truy vết, qua đó tăng độ tin cậy của dữ liệu KPI và giảm rủi ro gián đoạn giám sát.

Ba là, đối với địa phương ven biển. Đề nghị UBND các tỉnh/thành ven biển phối hợp với Cảng vụ và cơ quan chuyên ngành trong bảo vệ hạ tầng, quản lý hành lang công trình, phối hợp ứng phó sự cố và chia sẻ dữ liệu rủi ro tại địa bàn; đồng thời lồng ghép mục tiêu an toàn hàng hải vào phát triển kinh tế–xã hội và quản lý không gian ven biển theo đúng chức năng quản lý địa phương.

Bốn là, đối với doanh nghiệp khai thác cảng, vận tải biển và đơn vị cung ứng dịch vụ. Đề nghị doanh nghiệp tuân thủ cơ chế quản trị theo KPI/SLA, chủ động chia sẻ dữ liệu vận hành theo quy chế, tham gia cơ chế phản hồi và cải tiến chất lượng dịch vụ; qua đó hình thành vòng phản hồi “đo lường–công khai– giải trình–cải tiến” mà luận án định hướng.

Năm là, đối với Trường Đại học hàng hải Việt Nam, Trường Đại học Giao thông vận tải, các cơ sở đào tạo/viện nghiên cứu/tổ chức nghề nghiệp. Đề nghị phối hợp triển khai chương trình đào tạo lại giai đoạn 2026–2030, bồi dưỡng theo chuẩn mực quốc tế (STCW, khuyến nghị IMO liên quan) và năng lực số (dữ liệu, rủi ro, an ninh mạng vận hành), đáp ứng yêu cầu chuyển đổi số và hội nhập quản trị hiện đại.

Dựa trên hệ thống giải pháp mục 3.2, luận án đề xuất các kiến nghị khả thi cho Quốc hội, Chính phủ và các cơ quan liên quan nhằm đảm bảo triển khai hiệu quả. Bảng 3.8 tổng hợp các kiến nghị theo từng đối tượng và sản phẩm quản lý kỳ vọng, tạo khung hỗ trợ toàn diện cho việc thực hiện giải pháp.

Bảng 3.8. Tổng hợp kiến nghị hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam

[TABLE]

Nguồn: Nghiên cứu sinh đề xuất, 2025.

Tóm lại, các kiến nghị trên giúp hỗ trợ thể chế, tài chính, phối hợp và nguồn lực cho việc thực hiện các giải pháp tại mục 3.2 nhằm hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam trong thời gian tới.

KẾT LUẬN

Luận án tiến sĩ nghiên cứu quản lý nhà nước về bảo đảm an toàn hàng hải tại Việt Nam trên cơ sở khung phân tích tích hợp 2×3 (hai nhóm nội dung: quản lý hệ thống bảo đảm an toàn hàng hải và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải; ba chức năng: ban hành, tổ chức thực hiện, giám sát, đánh giá), tập trung đánh giá thực trạng giai đoạn 2015–2025 và đề xuất định hướng, giải pháp đến năm 2030, tầm nhìn 2045. Trên nền thiết kế nghiên cứu hỗn hợp, luận án kết hợp phân tích tài liệu và so sánh kinh nghiệm quốc tế, phỏng vấn sâu chuyên gia và khảo sát định lượng N=250; mô hình hồi quy tuyến tính bội theo khung 2×3 được dùng để lượng hóa tác động của các nhân tố tới kết quả quản lý nhà nước. Dữ liệu khảo sát thu thập tháng 3–5/2025 theo chọn mẫu thuận tiện kết hợp có chủ đích để bao quát nhóm chủ thể và vùng miền khi khó hình thành danh sách tổng thể.

Về cơ sở khoa học của luận án, Chương 1 hệ thống hóa lý luận và kinh nghiệm quốc tế, làm rõ nội hàm quản lý nhà nước về bảo đảm an toàn hàng hải và phát triển khung 2×3 cùng ma trận tiêu chí đánh giá nhằm tạo ngôn ngữ chung để mô tả, đo lường, so sánh kết quả giữa các khâu ban hành, thực hiện và giám sát trong cả hai trụ cột hệ thống và dịch vụ.

Từ phân tích định tính và số liệu thứ cấp, luận án chỉ ra thực trạng quản lý nhà nước giai đoạn 2015–2025 theo sáu cấu phần của khung 2×3, làm rõ các điểm mạnh, hạn chế và nguyên nhân; trong đó các hạn chế chủ yếu được nhận diện liên quan đến năng lực tổ chức thực thi, cơ chế phối hợp – phân cấp và nền tảng dữ liệu phục vụ giám sát. Việc kết hợp phỏng vấn sâu và đối chiếu kinh nghiệm quốc tế giúp tăng tính giải thích cho các nhận định về nguyên nhân và đồng thời cung cấp căn cứ để sắp xếp ưu tiên giải pháp.

Kết quả định lượng khẳng định năng lực giải thích của khung 2×3 khi được thao tác hóa thành các nhân tố H1–H2–H3 và D1–D2–D3: mô hình định lượng giải thích 77,6% biến thiên của kết quả quản lý nhà nước (R²=0,776). Kết luận khoa học trung tâm là kết quả quản lý nhà nước về bảo đảm an toàn hàng hải trong bối cảnh nghiên cứu chịu chi phối mạnh nhất bởi năng lực tổ chức thực thi đối với trụ cột hệ thống (H2), tiếp đến là chất lượng ban hành đối với trụ cột hệ thống (H1), rồi đến năng lực tổ chức thực hiện cung ứng dịch vụ (D2) và năng lực giám sát chất lượng dịch vụ (D3). Ngược lại, giám sát hệ thống (H3) và ban hành dịch vụ (D1) chưa thể hiện ý nghĩa thống kê trong mô hình tổng thể, gợi ý nhu cầu đổi mới giám sát theo dữ liệu thực, rủi ro và chuyển cơ chế ban hành dịch vụ sang quản lý theo chuẩn đầu ra KPI/SLA thay vì thiên về thủ tục, quy định tĩnh.

Từ các phát hiện trên, hàm ý chính sách và ưu tiên giải pháp được rút ra theo logic nguyên nhân – bằng chứng – ưu tiên: hoàn thiện quản lý nhà nước cần triển khai đồng bộ ở cả hai trụ cột hệ thống – dịch vụ và xuyên suốt ba chức năng, nhưng trọng tâm trước hết là tăng năng lực tổ chức thực thi (đặc biệt ở trụ cột hệ thống), tiếp đến là nâng chất lượng ban hành gắn với nguồn lực và tính khả thi, đồng thời kiện toàn cơ chế thực hiện và giám sát chất lượng dịch vụ theo dữ liệu và chuẩn đầu ra.

Về đóng góp mới, luận án (i) phát triển và vận dụng khung 2×3 như công cụ mô hình hóa và định vị ưu tiên cải cách trong quản lý nhà nước một lĩnh vực công kỹ thuật cao; (ii) cung cấp đánh giá có cấu trúc về thực trạng giai đoạn 2015–2025 theo sáu nội dung quản lý theo khung 2x3 và làm rõ logic ưu tiên giải pháp theo bằng chứng; và (iii) lượng hóa khung 2×3 bằng mô hình hồi quy tuyến tính bội theo khung 2×3 (R²=0,776), qua đó bổ sung thêm bằng chứng thực chứng cho đánh giá kết quả quản lý nhà nước về bảo đảm an toàn hàng hải.

Bên cạnh kết quả đạt được, luận án còn một số hạn chế. Thứ nhất, do giới hạn phạm vi, nghiên cứu tập trung vào hai nhóm nội dung theo khung 2×3 nên một số lớp vấn đề liên quan nhưng không thuộc trọng tâm chưa được đi sâu; nghiên cứu tiếp theo có thể mở rộng theo liên thông giữa an toàn – an ninh – môi trường để phản ánh đầy đủ hơn rủi ro phi truyền thống. Thứ hai, dữ liệu định lượng dựa trên khảo sát từ tháng 3/2025 đến tháng 5/2025 nên phản ánh dạng ảnh chụp; hướng tiếp theo cần khảo sát lặp hoặc dữ liệu bảng theo chu kỳ để theo dõi xu hướng và đánh giá tác động chính sách theo thời gian. Thứ ba, mô hình hồi quy tuyến tính bội có thể chưa bao quát hết biến trung gian/điều tiết; nghiên cứu tiếp theo có thể triển khai mô hình đa nhóm hoặc bổ sung biến điều tiết để so sánh theo vùng, theo nhóm chủ thể hoặc theo loại hình dịch vụ bảo đảm an toàn hàng hải.

Tổng thể, luận án tiến sĩ “Quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam” được thực hiện và hoàn thiện tại Học viện Chính trị Quốc gia Hồ Chí Minh đã cơ bản đạt được mục tiêu nghiên cứu đặt ra cả về phương diện lý luận và thực tiễn. Kết quả nghiên cứu không chỉ góp phần bổ sung, phát triển cơ sở khoa học cho việc nhận diện và đánh giá hoạt động quản lý nhà nước trong lĩnh vực bảo đảm an toàn hàng hải, mà còn từng bước hình thành khung tư duy và công cụ phân tích có giá trị ứng dụng trong hoạch định, tổ chức thực hiện và giám sát chính sách. Trên cơ sở đó, luận án tạo lập luận cứ cho định hướng xây dựng một hệ thống quản lý nhà nước về bảo đảm an toàn hàng hải theo hướng hiện đại, minh bạch, quản lý theo kết quả và dựa trên dữ liệu; qua đó góp phần bảo đảm an toàn cho con người, phương tiện, tài sản và môi trường, đồng thời thúc đẩy phát triển kinh tế biển bền vững trong thế kỷ XXI.

DANH MỤC CÁC CÔNG TRÌNH KHOA HỌC ĐÃ CÔNG BỐ

1. Phạm Quang Giáp, Nguyễn Ngọc Toàn (2025), Khung lý thuyết tích hợp "2 nội dung - 3 bình diện" trong quản lý nhà nước về bảo đảm an toàn hàng hải, Tạp chí Kinh tế và Dự báo, Bộ Tài chính (e-ISSN 2734–9365), số 902, tháng 9/2025 (32393).

2. Phạm Quang Giáp, Nguyễn Ngọc Toàn (2025), Kinh nghiệm quốc tế về mô hình quản lý nhà nước về bảo đảm an toàn hàng hải và gợi ý cho Việt Nam, Tạp chí Kinh tế và Dự báo, Bộ Tài chính (e-ISSN 2734–9365), số 1001, tháng 10/2025, (32402).

3. Phạm Quang Giáp, Nguyễn Ngọc Toàn (2025), Giải pháp hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam đến năm 2030 tầm nhìn năm 2045, Tạp chí Kinh tế và Dự báo, Bộ Tài chính, (e-ISSN 2734–9365), số 1001, tháng 10/2025, (32410).

4. Phạm Quang Giáp, Nguyễn Ngọc Toàn (2025), Tổ chức bảo đảm an toàn hàng hải ở Việt Nam hiện nay, Tạp chí Kinh tế và Quản lý, Học viện Chính trị quốc gia Hồ Chí Minh, (ISSN 1859 - 4565), số 86, tháng 10/2025 (tr.52 -tr.58).

5. Phạm Quang Giáp, Nguyễn Ngọc Toàn (2025), Quản lý nhà nước về dịch vụ bảo đảm an toàn hàng hải mới ở Việt Nam trong kỷ nguyên số và hội nhập toàn cầu, Tạp chí Kinh tế - Tài chính, Bộ Tài chính (ISSN 3093–3390), Kỳ II tháng 10/2025 (tr.121 – tr.126).

TÀI LIỆU THAM KHẢO

Abuja Memorandum of Understanding on Port State Control. (2024). 2024 Annual Report, Abuja MOU.

Abuja Memorandum of Understanding on Port State Control. (2025). Report of Annual Port State Inspection Data (APSID 2024), Abuja MOU.

African Union. (2012). 2050 Africas Integrated Maritime Strategy (2050 AIM Strategy), African Union Commission.

Androjna, A., Perkovič, M., Pavic, I., & Mišković, J. (2021). AIS Data Vulnerability Indicated by a Spoofing Case-Study, Applied Sciences, 11(11), 5015. https://doi.org/10.3390/app11115015

Ban Chấp hành Trung ương Đảng Cộng sản Việt Nam. (2018). Nghị quyết số 36-NQ/TW ngày 22/10/2018 về Chiến lược phát triển bền vững kinh tế biển Việt Nam đến năm 2030, tầm nhìn đến năm 2045.

Bộ Chính trị. (2024). Nghị quyết số 57-NQ/TW ngày 22/12/2024 về đột phá phát triển khoa học, công nghệ, đổi mới sáng tạo và chuyển đổi số quốc gia.

Bộ Chính trị. (2025). Nghị quyết số 68-NQ/TW ngày 04/5/2025 về phát triển kinh tế tư nhân.

Bộ Công Thương. (2024). Tọa đàm trực tuyến: Logistics với thị trường Hoa Kỳ. https://moit.gov.vn/tin-tuc/thi-truong-nuoc-ngoai/toa-dam-truc-tuyen-logistics-voi-thi-truong-hoa-ky.html

Bộ Giao thông vận tải. (2019). Thông tư số 42/2019/TT-BGTVT ngày 30/10/2019 quy định tiêu chí, kiểm tra, giám sát, đánh giá, nghiệm thu chất lượng dịch vụ sự nghiệp công bảo đảm an toàn hàng hải.

Bộ Giao thông vận tải. (2021a). Thông tư số 37/2021/TT-BGTVT ngày 30/12/2021 hướng dẫn giá dịch vụ sự nghiệp công bảo đảm an toàn hàng hải sử dụng kinh phí ngân sách nhà nước từ nguồn kinh phí thường xuyên, thực hiện theo phương thức đặt hàng.

Bộ Giao thông vận tải. (2021b). Thông tư số 38/2021/TT-BGTVT ngày 30/12/2021 ban hành định mức kinh tế - kỹ thuật trong lĩnh vực cung ứng dịch vụ sự nghiệp công bảo đảm an toàn hàng hải.

Bộ Giao thông vận tải. (2022). Thông tư số 19/2022/TT-BGTVT ngày 26 tháng 7 năm 2022 quy định về bảo trì công trình hàng hải.

Bộ Giao thông vận tải. (2023a). Thông tư số 20/2023/TT-BGTVT ngày 30/6/2023 quy định về tiêu chuẩn chuyên môn, chứng chỉ chuyên môn, đào tạo, huấn luyện thuyền viên và định biên an toàn tối thiểu của tàu biển Việt Nam.

Bộ Giao thông vận tải. (2023b). Thông tư số 40/2023/TT-BGTVT ngày 25/12/2023 quy định tiêu chí chất lượng và công tác kiểm tra, giám sát, đánh giá để nghiệm thu chất lượng dịch vụ sự nghiệp công thông tin duyên hải.

Bộ Giao thông vận tải. (2023c). Thông tư số 57/2023/TT-BGTVT ngày 31/12/2023 quy định về chương trình đào tạo, huấn luyện thuyền viên, hoa tiêu hàng hải.

Bộ Giao thông vận tải. (2024a). Quyết định số 814/QĐ-BGTVT ngày 01 tháng 7 năm 2024 ban hành giá tối đa dịch vụ hoa tiêu hàng hải tại cảng biển Việt Nam.

Bộ Giao thông vận tải. (2024b). Thông tư số 12/2024/TT-BGTVT ngày 15/5/2024 quy định cơ chế, chính sách quản lý giá dịch vụ tại cảng biển Việt Nam.

Bộ Giao thông vận tải. (2025). QCVN 21:2025/BGTVT: Quy chuẩn kỹ thuật quốc gia về phân cấp và đóng tàu biển vỏ thép.

Bộ Khoa học và Công nghệ. (2015a). TCVN 10703:2015: Yêu cầu chất lượng dịch vụ vận hành đèn biển.

Bộ Khoa học và Công nghệ. (2015b). TCVN 10704:2015: Yêu cầu chất lượng dịch vụ vận hành luồng hàng hải.

Bộ Khoa học và Công nghệ. (2024). TCVN 14141:2024: Phương pháp tính toán, xác định tầm hiệu lực của báo hiệu hàng hải.

Bộ Tài chính. (2016). Thông tư số 261/2016/TT-BTC ngày 14 tháng 11 năm 2016 quy định về phí, lệ phí hàng hải và biểu mức thu phí, lệ phí hàng hải.

Bộ Xây dựng. (2025a). Quyết định số 08/QĐ-BXD ngày 01/3/2025 quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Cục Hàng hải và Đường thủy Việt Nam.

Bộ Xây dựng. (2025b). Quyết định số 1644/QĐ-BXD ngày 30/9/2025 ban hành Chiến lược chuyển đổi số của Bộ Xây dựng giai đoạn 2025–2030.

Bộ Xây dựng. (2025c). Quyết định số 2287/QĐ-BXD ngày 12/12/2025 ban hành Kế hoạch triển khai thực hiện Quyết định số 1901/QĐ-TTg.

Bộ Xây dựng. (2025d). Quyết định số 2530/QĐ-BXD ngày 31/12/2025 về việc công bố thủ tục hành chính được sửa đổi, bổ sung trong lĩnh vực hàng hải thuộc phạm vi chức năng quản lý của Bộ Xây dựng.

Bộ Xây dựng. (2025e). Quyết định số 438/QĐ-BXD ngày 18/4/2025 về việc thành lập Tổng công ty Bảo đảm an toàn hàng hải Việt Nam.

Bộ Xây dựng. (2025f). Thông tư số 18/2025/TT-BXD ngày 30/6/2025 quy định về tổ chức và hoạt động của Cảng vụ hàng hải, Cảng vụ đường thủy nội địa.

Bộ Xây dựng. (2025g). Thông tư số 21/2025/TT-BXD ngày 21/7/2025 ban hành định mức chi phí áp dụng cho dịch vụ sự nghiệp công thông tin duyên hải sử dụng ngân sách nhà nước từ nguồn kinh phí chi thường xuyên, thực hiện theo phương thức đặt hàng.

Bộ Xây dựng. (2025h). Thông tư số 31/2025/TT-BXD ngày 31/10/2025 quy định về tiêu chuẩn đào tạo hoa tiêu hàng hải; cấp, thu hồi chứng chỉ chuyên môn hoa tiêu hàng hải và giấy chứng nhận vùng hoạt động hoa tiêu hàng hải.

Bộ Xây dựng. (2025i). Văn bản hợp nhất số 02/VBHN-BXD ngày 20 tháng 3 năm 2025 hợp nhất Nghị định số 58/2017/NĐ-CP và các quy định sửa đổi, bổ sung liên quan.

Bộ Xây dựng. (2026a). Báo cáo số 36/BC-BXD ngày 12/02/2026 về tổng kết việc thi hành Bộ luật Hàng hải Việt Nam năm 2015, Luật Giao thông đường thủy nội địa năm 2004 và các sửa đổi, bổ sung.

Bộ Xây dựng. (2026b). Quyết định số 143/QĐ-BXD ngày 03/02/2026 về việc giao một số chỉ tiêu định hướng năm 2026 đối với Tổng công ty Bảo đảm an toàn hàng hải Việt Nam.

Bộ Xây dựng. (2026c). Quyết định số 147/QĐ-BXD ngày 03/02/2026 về việc giao một số chỉ tiêu định hướng năm 2026 cho Công ty TNHH MTV Thông tin điện tử hàng hải Việt Nam.

Bộ Xây dựng. (2026d). Thông tư số 05/2026/TT-BXD ngày 10/02/2026 quy định về bảo trì công trình hàng hải và tần suất khảo sát thông báo hàng hải.

Chính phủ nước CHXHCN Việt Nam. (2016). Nghị định số 70/2016/NĐ-CP ngày 01/7/2016 về điều kiện cung cấp dịch vụ bảo đảm an toàn hàng hải.

Chính phủ nước CHXHCN Việt Nam. (2017). Nghị định số 58/2017/NĐ-CP ngày 10 tháng 5 năm 2017 quy định chi tiết một số điều của Bộ luật Hàng hải Việt Nam về quản lý hoạt động hàng hải.

Chính phủ nước CHXHCN Việt Nam. (2019). Nghị định số 32/2019/NĐ-CP ngày 10/4/2019 quy định giao nhiệm vụ, đặt hàng hoặc đấu thầu cung cấp sản phẩm, dịch vụ công sử dụng ngân sách nhà nước từ nguồn kinh phí chi thường xuyên.

Chính phủ nước CHXHCN Việt Nam. (2021a). Nghị định số 06/2021/NĐ-CP ngày 26/01/2021 quy định chi tiết một số nội dung về quản lý chất lượng, thi công xây dựng và bảo trì công trình xây dựng.

Chính phủ nước CHXHCN Việt Nam. (2021b). Nghị định số 99/2021/NĐ-CP ngày 11/11/2021 quy định về quản lý, thanh toán, quyết toán sử dụng vốn đầu tư công.

Chính phủ nước CHXHCN Việt Nam. (2022). Nghị định số 69/2022/NĐ-CP ngày 23/09/2022 sửa đổi, bổ sung một số điều của các Nghị định quy định liên quan đến hoạt động kinh doanh trong lĩnh vực hàng hải.

Chính phủ nước CHXHCN Việt Nam. (2024). Nghị định số 57/2024/NĐ-CP ngày 20 tháng 5 năm 2024 về quản lý hoạt động nạo vét trong vùng nước cảng biển và vùng nước đường thủy nội địa.

Chính phủ nước CHXHCN Việt Nam. (2025a). Nghị định số 214/2025/NĐ-CP ngày 04/8/2025 quy định chi tiết một số điều và biện pháp thi hành Luật Đấu thầu về lựa chọn nhà thầu.

Chính phủ nước CHXHCN Việt Nam. (2025b). Nghị định số 33/2025/NĐ-CP ngày 25/02/2025 quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ Xây dựng.

Chính phủ nước CHXHCN Việt Nam. (2025c). Nghị định số 34/2025/NĐ-CP ngày 25 tháng 2 năm 2025 sửa đổi, bổ sung một số nghị định trong lĩnh vực hàng hải.

Chính phủ nước CHXHCN Việt Nam. (2025d). Nghị định số 84/2025/NĐ-CP ngày 04 tháng 4 năm 2025 quy định việc quản lý, sử dụng và khai thác tài sản kết cấu hạ tầng hàng hải.

Chính phủ nước CHXHCN Việt Nam. (2025e). Nghị quyết số 58/NQ-CP ngày 21/3/2025 về giải thể Ủy ban Quản lý vốn nhà nước tại doanh nghiệp.

Cổng Thông tin điện tử Chính phủ. (2025). Hàng hóa qua cảng biển tăng mạnh, 100% thủ tục hành chính được làm online. https://baochinhphu.vn/hang-hoa-qua-cang-bien-tang-manh-100-thu-tuc-hanh-chinh-duoc-lam-online-102251224220645014.htm

Công ty TNHH MTV Thông tin Điện tử Hàng hải Việt Nam (VISHIPEL). (2026). Giới thiệu/Hệ thống Thông tin duyên hải Việt Nam. https://vishipel.vn/

Creswell, J. W., & Plano Clark, V. L. (2018). Designing and Conducting Mixed Methods Research, 3rd ed., SAGE.

Cục Hàng hải và Đường thủy Việt Nam. (2025a). Cục Hàng hải và Đường thủy Việt Nam tổ chức Hội nghị tổng kết công tác năm 2025 và triển khai kế hoạch năm 2026. https://vimawa.gov.vn/vi/tin-tuc/cuc-hang-hai-va-duong-thuy-viet-nam-chuc-hoi-nghi-tong-ket-cong-tac-nam-2025-va-trien-khai

Cục Hàng hải và Đường thủy Việt Nam. (2025b). Mô hình hệ thống. https://vimawa.gov.vn/vi/noi-dung/mo-hinh-he-thong

Cục Hàng hải và Đường thủy Việt Nam. (2025c). Thống kê. https://vimawa.gov.vn/vi/thong-ke

Cục Hàng hải Việt Nam. (2022). Hội thảo xin ý kiến về dự thảo Quy hoạch chi tiết phát triển hạ tầng cảng biển 2021–2030, tầm nhìn đến năm 2050. https://vimawa.gov.vn/vi/tin-tuc/hoi-thao-xin-y-kien-ve-du-thao-quy-hoach-chi-tiet-phat-trien-ha-tang-cang-bien-2021–2030-tam

Đảng Cộng sản Việt Nam. (2026). Nghị quyết Đại hội đại biểu toàn quốc lần thứ XIV của Đảng.

European Maritime Safety Agency (EMSA). (2024). Annual Overview of Marine Casualties and Incidents 2024, EMSA.

European Maritime Safety Agency (EMSA). (2025). The 2025 European Maritime Safety Report (EMSAFE), EMSA.

European Maritime Safety Agency (EMSA). (n.d.). Common Information Sharing Environment (CISE). https://emsa.europa.eu/ssn-main/378-cise.html

European Maritime Safety Agency (EMSA). (n.d.). SafeSeaNet. https://www.emsa.europa.eu/ssn-main.html

Gill, P., Stewart, K., Treasure, E., & Chadwick, B. (2008). Methods of data collection in qualitative research: Interviews and focus groups, British Dental Journal, 204, 291–295. https://doi.org/10.1038/bdj.2008.192

Hair, J. F., Black, W. C., Babin, B. J., & Anderson, R. E. (2010). Multivariate Data Analysis, 7th ed., Pearson.

Hair, J. F., Risher, J. J., Sarstedt, M., & Ringle, C. M. (2019). When to use and how to report the results of PLS-SEM, European Business Review, 31(1), 2-24.

Heikkilä, M., Himmanen, H., Soininen, O., Sonninen, S., & Heikkilä, J. (2024). Navigating the Future: Developing Smart Fairways for Enhanced Maritime Safety and Efficiency, Journal of Marine Science and Engineering, 12(2), 324. https://doi.org/10.3390/jmse12020324

Hoàng Thị Lịch. (2021). Quản lý nhà nước về dịch vụ cảng biển tại Việt Nam, Luận án Tiến sĩ, Trường Đại học Hàng hải Việt Nam, Hải Phòng.

Hollnagel, E. (2014). Safety-I and Safety-II: The Past and Future of Safety Management, Ashgate, Farnham.

Hood, C., & Peters, B. G. (2004). The Middle Aging of New Public Management: Into the Age of Paradox?, Journal of Public Administration Research and Theory, 14(3), 267-282. https://doi.org/10.1093/jopart/muh019

International Association of Marine Aids to Navigation and Lighthouse Authorities. (2017a). Recommendation R0130: Categorisation and Availability Objectives for Short Range Aids to Navigation (Edition 3.1, revised 16 June 2017), IALA, Saint-Germain-en-Laye, France.

International Association of Marine Aids to Navigation and Lighthouse Authorities. (2017b). Recommendation R1002: Risk Management for Marine Aids to Navigation (Edition 1.1, revised 16 June 2017), IALA, Saint-Germain-en-Laye, France.

International Association of Marine Aids to Navigation and Lighthouse Authorities. (2022). Guideline G1089: Provision of a VTS (Edition 2.0, revised 31 January 2022), IALA, Saint-Germain-en-Laye, France.

International Association of Marine Aids to Navigation and Lighthouse Authorities. (2023). Standard S1010: Marine Aids to Navigation Planning and Service Requirements, IALA, Saint-Germain-en-Laye, France.

International Hydrographic Organization. (2018). Publication M-2: The Need for National Hydrographic Services (Version 3.0.7), IHO, Monaco.

International Hydrographic Organization. (2022). IHO S-100: Universal Hydrographic Data Model (Edition 5.0.0), IHO, Monaco.

International Hydrographic Organization. (2024). S-44: IHO Standards for Hydrographic Surveys (Edition 6.2.0, October 2024), IHO, Monaco.

International Maritime Organization. (1972). Convention on the International Regulations for Preventing Collisions at Sea (COLREG), 1972, IMO.

International Maritime Organization. (1973/1978). International Convention for the Prevention of Pollution from Ships (MARPOL), IMO.

International Maritime Organization. (1974). International Convention for the Safety of Life at Sea (SOLAS), 1974, IMO.

International Maritime Organization. (1978). International Convention on Standards of Training, Certification and Watchkeeping for Seafarers (STCW), 1978, IMO.

International Maritime Organization. (1991). Resolution A.705(17): Promulgation of Maritime Safety Information, IMO.

International Maritime Organization. (2003). Resolution A.958(23): Provision of Hydrographic Services, IMO.

International Maritime Organization. (2013). Resolution A.1070(28): IMO Instruments Implementation Code (III Code), IMO.

International Maritime Organization. (2018a). MSC- MEPC.2/Circ.12/Rev.2: Revised Guidelines for Formal Safety Assessment (FSA) for Use in the IMO Rule-Making Process, IMO.

International Maritime Organization. (2018b). MSC.1/Circ.1595: E- Navigation Strategy Implementation Plan – Update 1, IMO.

International Maritime Organization. (2019). MSC.1/Circ.1610: Initial Descriptions of Maritime Services in the Context of E-Navigation, IMO.

International Maritime Organization. (2020). SOLAS Consolidated Edition 2020, IMO.

International Maritime Organization. (2021). Resolution A.1158(32): Guidelines for Vessel Traffic Services, IMO.

International Maritime Organization. (2023). 2023 IMO Strategy on Reduction of GHG Emissions from Ships. Resolution MEPC.377(80), IMO.

International Maritime Organization. (2024a). MSC.1/Circ.1310/Rev.2: Joint IMO/IHO/WMO Manual on Maritime Safety Information, IMO.

International Maritime Organization. (2024b). MSC.1/Circ.1610/Rev.1: Descriptions of Maritime Services in the Context of E-Navigation, IMO.

International Maritime Organization. (2024c). SOLAS Consolidated Edition 2024, IMO.

International Maritime Organization. (n.d.). Maritime Security and Piracy. https://www.imo.org/en/OurWork/Security/Pages/MaritimeSecurity.aspx

International Maritime Organization. (n.d.). SOLAS XI-2 and the ISPS Code. https://www.imo.org/en/OurWork/Security/Pages/ISPSCode.aspx

International Maritime Organization. (n.d.). Status of Conventions. https://www.imo.org/en/about/conventions/pages/statusofconventions.aspx

International Organization for Marine Aids to Navigation (IALA). (2025). Guideline G1111: Establishing Functional and Performance Requirements for VTS Systems and Equipment (Edition 2.1), IALA, Saint- Germain-en-Laye, France.

ISO. (2018). ISO 31000:2018 Risk management – Guidelines, ISO.

ISO. (2024). ISO 55000:2024 Asset management - Vocabulary, overview and principles, ISO.

Issa-Zadeh, S. B., & Garay-Rondero, C. L. (2025). Maritime Pilotage and Sustainable Seaport: A Systematic Review, Journal of Marine Science and Engineering, 13(5), 945. https://doi.org/10.3390/jmse13050945

Japan Coast Guard – Osaka Wan Vessel Traffic Service Center (OSAKA MARTIS). (2025). User Manual (English), Japan Coast Guard.

Japan Coast Guard. (2025). Navigation Safety Guidance: Tokyo Wan, Ise Wan (including Nagoya-Ko), Seto Inland Sea (including Kanmon Kaikyo) (38th Revised Edition, March 2025), Maritime Traffic Department, Navigation Safety Division.

Joint Nautical Authority (VTS-Scheldt). (n.d.). Joint Nautical Authority. https://www.vts-scheldt.net/default.aspx?KL=en&path=Over+ons%2FBeleid%2FGNA

Kline, R. B. (2016). Principles and Practice of Structural Equation Modeling, The Guilford Press.

Kuo, C. (1998). Managing Ship Safety, Lloyds of London Press.

Kusek, J. Z., & Rist, R. C. (2004). Ten Steps to a Results-Based Monitoring and Evaluation System, World Bank.

Lee, C., & Lee, S. (2024). Expanding IMO Compendium with NAVTEX Messages for Maritime Single Window, Journal of Marine Science and Engineering, 12(12), 2328. https://doi.org/10.3390/jmse12122328

Lương Thị Kim Dung. (2019). An ninh hàng hải đối với tàu biển, cảng biển trong pháp luật quốc tế và thực tiễn của Việt Nam, Luận án Tiến sĩ, Trường Đại học Luật Hà Nội.

Lưu Việt Hùng. (2019). Nghiên cứu giải pháp nâng cao an toàn hàng hải vùng biển Việt Nam, Luận án Tiến sĩ, Trường Đại học Hàng hải Việt Nam, Hải Phòng.

Majone, G. (1994). The Rise of the Regulatory State in Europe, West European Politics, 17(3), 77-101. https://doi.org/10.1080/01402389408425031

Mao, X., & Wang, Z. (2020). AIS Big Data in Maritime Safety: Applications and Challenges, Journal of Marine Science and Engineering, 8(10), 789. https://doi.org/10.3390/jmse8100789

Marine Casualties Investigative Body (Italy). (2013). Cruise Ship COSTA CONCORDIA Marine Casualty on January 13, 2012: Report on the Safety Technical Investigation, Ministry of Infrastructure and Transport.

Maritime and Port Authority of Singapore (MPA). (2023a). Port Marine Circular No. 10 of 2023: digitalPORT@SGTM – Implementation of Just in Time Planning and Coordination Platform for Port of Singapore, MPA.

Maritime and Port Authority of Singapore (MPA). (2023b). Port Statistics, MPA.

Maritime and Port Authority of Singapore (MPA). (2025). Singapore Port Information (STRAITREP, VTIS/TSS Guidance), MPA.

Maritime and Port Authority of Singapore (MPA). (n.d.). About MPA. https://www.mpa.gov.sg/who-we-are/about-mpa

Ministry of Transport Malaysia. (2023). Aids to Navigation, Ministry of Transport.

Ministry of Transport Malaysia. (n.d.). Vessel Traffic System (VTS). https://www.mot.gov.my/en/maritime/safety-and-security/VTS

Moore, M. H. (1995). Creating Public Value: Strategic Management in Government, Harvard University Press, Cambridge, MA.

Musgrave, R. A., & Musgrave, P. B. (1989). Public Finance in Theory and Practice, McGraw-Hill.

National Oceanic and Atmospheric Administration. (n.d.). Exxon Valdez. https://darrp.noaa.gov/oil-spills/exxon-valdez

Nguyễn Mạnh Cường, & Phan Văn Hưng. (2021). Những lợi ích của e-navigation và xu hướng phát triển, Tạp chí Khoa học Công nghệ Hàng hải, 65(01), 96–100.

North, D. C. (1990). Institutions, Institutional Change and Economic Performance, Cambridge University Press.

Norwegian Coastal Administration (Kystverket). (2025). Rates of fee 2025, Kystverket.

Norwegian Coastal Administration (Kystverket). (n.d.). This is the standard for Norwegian coast markings. https://www.kystverket.no/en/fairway/lightshouses-and-navigations-marks/standard-for-norwegian-coast/

Norwegian Coastal Administration (Kystverket). (n.d.). Vessel Traffic Service (VTS). https://www.kystverket.no/en/navigation-and-monitoring/vts---vessel-traffic-service/

Norwegian Coastal Administration (Kystverket). (n.d.). VTS services. https://www.kystverket.no/en/navigation-and-monitoring/vts---vessel-traffic-service/services/

OECD. (2014). OECD Framework for Regulatory Policy Evaluation, OECD Publishing.

OECD. (2019a). Better Regulation Practices across the European Union, OECD Publishing.

OECD. (2019b). OECD Good Practices for Performance Budgeting, OECD Publishing.

Osborne, D., & Gaebler, T. (1992). Reinventing Government: How the Entrepreneurial Spirit is Transforming the Public Sector, Addison-Wesley.

Osborne, S. P., chủ biên. (2010). The New Public Governance? Emerging Perspectives on the Theory and Practice of Public Governance, Routledge.

Palinkas, L. A., Horwitz, S. M., Green, C. A., Wisdom, J. P., Duan, N., & Hoagwood, K. (2015). Purposeful Sampling for Qualitative Data Collection and Analysis in Mixed Method Implementation Research, Administration and Policy in Mental Health and Mental Health Services Research, 42(5), 533–544. https://doi.org/10.1007/s10488-013-0528-y

Pollitt, C., & Bouckaert, G. (2011). Public Management Reform: A Comparative Analysis - New Public Management, Governance, and the Neo-Weberian State, 3rd ed., Oxford University Press.

Port Klang Authority. (2025). Marine Handbook, Port Klang Authority.

Port of Rotterdam. (2021). VTS services and VHF communication procedure. https://www.portofrotterdam.com/en/contact-harbourmaster/vts-services-and-vhf-communication-procedure

Praetorius, G. (2014). Vessel Traffic Service (VTS): a maritime information service or traffic control system? Understanding everyday performance and resilience in a socio-technical system under change, Doctoral thesis, Chalmers University of Technology.

Quốc hội nước CHXHCN Việt Nam. (2015). Bộ luật Hàng hải Việt Nam số 95/2015/QH13.

Rhodes, R. A. W. (1996). The new governance: governing without government, Political Studies, 44(4), 652-667.

Sampson, H., & Bloor, M. (2012). The effectiveness of global regulation in the shipping industry: a critical case study, Revista Latino-americana de Estudos do Trabalho, 17(28), 45–72.

Samuelson, P. A. (1954). The pure theory of public expenditure, Review of Economics and Statistics, 36(4), 387-389.

Stiglitz, J. E., & Rosengard, J. K. (2015). Economics of the Public Sector, 4th ed., W. W. Norton.

Thanh tra. (2025). Kết luận thanh tra tại Công ty Cảng Container Trung tâm Sài Gòn. https://thanhtra.com.vn/ket-luan-thanh-tra-E17BD7A25/ket-luan-thanh-tra-tai-cong-ty-cang-container-trung-tam-sai-gon-fd59fa7ed.html

Thủ tướng Chính phủ. (2021). Quyết định số 1579/QĐ-TTg ngày 22 tháng 9 năm 2021 phê duyệt Quy hoạch tổng thể phát triển hệ thống cảng biển Việt Nam thời kỳ 2021–2030, tầm nhìn đến năm 2050.

Thủ tướng Chính phủ. (2024). Quyết định số 442/QĐ-TTg ngày 22 tháng 5 năm 2024 phê duyệt điều chỉnh Quy hoạch tổng thể phát triển hệ thống cảng biển Việt Nam.

Thủ tướng Chính phủ. (2025a). Quyết định số 140/QĐ-TTg ngày 16 tháng 1 năm 2025 phê duyệt Quy hoạch chi tiết nhóm cảng biển, bến cảng, khu nước, vùng nước thời kỳ 2021–2030, tầm nhìn đến năm 2050.

Thủ tướng Chính phủ. (2025b). Quyết định số 1901/QĐ-TTg ngày 05/9/2025 về việc phê duyệt Đề án xây dựng Trường Đại học Hàng hải Việt Nam là trường trọng điểm quốc gia về đào tạo, nghiên cứu phục vụ phát triển bền vững kinh tế biển giai đoạn đến năm 2030, tầm nhìn đến năm 2045.

Tokyo Memorandum of Understanding on Port State Control. (n.d.). New Inspection Regime (NIR): Flags Meeting Low Risk Criteria. https://www.tokyo-mou.org/inspections-detentions/nir/

Trung tâm Phối hợp tìm kiếm, cứu nạn hàng hải Việt Nam (VMRCC). (n.d.). Trang chủ. https://vmrcc.gov.vn/trang-chu

UNCTAD. (2023). Review of Maritime Transport 2023, United Nations.

UNCTAD. (2024). Review of Maritime Transport 2024, United Nations.

UNCTAD. (2025a). Review of Maritime Transport 2025, Chapter 4: Port Performance and Maritime Trade Facilitation, United Nations.

UNCTAD. (2025b). Review of Maritime Transport 2025, United Nations.

UNCTADstat. (n.d.). Maritime and other transport. https://unctadstat.unctad.org/insights/theme/246

UNDP. (2009). Handbook on Planning, Monitoring and Evaluating for Development Results, United Nations Development Programme.

United Nations. (1982). United Nations Convention on the Law of the Sea (UNCLOS), United Nations, Montego Bay.

United States Environmental Protection Agency. (n.d.). Summary of the Oil Pollution Act. https://www.epa.gov/laws-regulations/summary-oil-pollution-act

Valdez Banda, O. A., & Goerlandt, F. (2018). A STAMP-based approach for designing maritime safety management systems: The case of the Vessel Traffic Services in the Gulf of Finland, Safety Science, 109, 109-129. https://doi.org/10.1016/j.ssci.2018.05.003

Vicente, J. P. D. (2022). Portugals cartographic responsibility in Africa, The International Hydrographic Review, 28, 197-204. https://doi.org/10.58440/ihr-28-n07

Vũ Đăng Thái. (2023). Rủi ro hàng hải: Tổng quan và xu hướng nghiên cứu, Tạp chí Khoa học Công nghệ Hàng hải, 75(75), 82-87.

Weber, M. (1947). The Theory of Social and Economic Organization (A. M. Henderson và T. Parsons, trans.), Oxford University Press, New York. (Original work published 1922).

Wilhelmsen Ship Management. (2024). Marine Safety Management: Safety and Compliance Excellence. https://www.wilhelmsen.com/media-news-and-events/industry-perspectives/2024/marine-safety-management-systems/

Wilson, W. (1887). The Study of Administration, Political Science Quarterly, 2(2), 197-222. https://doi.org/10.2307/2139277

World Bank & International Association of Ports and Harbors (IAPH). (2021). Accelerating Digitalization: Critical Actions to Strengthen the Resilience of the Maritime Supply Chain, World Bank.

World Bank Group, Asian Development Bank, European Bank for Reconstruction and Development, Inter-American Development Bank, Islamic Development Bank, OECD, UNECE và UNESCAP. (2017). PPP Reference Guide 3.0 (Full version), World Bank Group.

World Bank. (1994). World Development Report 1994: Infrastructure for Development, Oxford University Press for the World Bank.
