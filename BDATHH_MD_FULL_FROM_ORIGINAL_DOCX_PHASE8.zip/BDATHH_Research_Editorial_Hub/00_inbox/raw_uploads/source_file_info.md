# Source file info

- Source DOCX: `Pham_Quang_Giap_Luan_an_APA7_rut_gon_Mo_dau_den_TLTK_giai_doan_4.docx`
- SHA256: `fe0f47c5fb401093babfe6f0c24e19d775465e10d43a71fab8154b1bcf03ebfb`
- Size: 2180936 bytes
- Extracted paragraphs/tables/images sequence items: 796
- Tables detected: 30
- Figures detected: 11
