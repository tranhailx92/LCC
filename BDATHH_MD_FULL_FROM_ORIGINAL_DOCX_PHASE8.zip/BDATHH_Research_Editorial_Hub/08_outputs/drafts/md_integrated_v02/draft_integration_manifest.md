# Draft Integration Manifest

- Tables integrated: 30
- Figures integrated: 11
- Draft path: `08_outputs/drafts/md_integrated_v02/`
- Original DOCX source processed directly in ChatGPT container.

## Tables

| ID | Number | Title |
| :--- | :--- | :--- |
| T_DOCX_001 | Bảng 1.1 | Tổng hợp một số cách tiếp cận về an toàn hàng hải |
| T_DOCX_002 | Bảng 1.2 | Tổng hợp một số cách tiếp cận về bảo đảm an toàn hàng hải |
| T_DOCX_003 | Bảng 1.3 | Nội dung quản lý nhà nước về bảo đảm an toàn hàng hải theo khung phân tích 2×3 |
| T_DOCX_004 | Bảng 1.4 | Tổng hợp các tiêu chí đánh giá kết quả quản lý nhà nước về bảo đảm an toàn hàng hải theo khung phân tích 2×3 |
| T_DOCX_005 | Bảng 1.5 | Tổng hợp các yếu tố ảnh hưởng đến kết quả quản lý nhà nước về bảo đảm an toàn hàng hải và sự quy chiếu vào khung phân tích 2×3 |
| T_DOCX_006 | Bảng 1.6 | Tổng hợp kinh nghiệm quốc tế trong quản lý nhà nước về bảo đảm an toàn hàng hải theo khung phân tích 2×3 |
| T_DOCX_007 | Bảng 2.1 | So sánh cơ cấu quản lý nhà nước về bảo đảm an toàn hàng hải trước và sau hợp nhất |
| T_DOCX_008 | Bảng 2.2 | Hệ thống văn bản quy phạm pháp luật quản lý vòng đời tài sản |
| T_DOCX_009 | Bảng 2.3 | Đối chiếu sự chuyển dịch mô hình quản trị hệ thống bảo đảm an toàn hàng hải |
| T_DOCX_010 | Bảng 2.4 | Tổng hợp các dự án đầu tư và mua sắm trọng điểm liên quan tới hệ thống bảo đảm an toàn hàng hải |
| T_DOCX_011 | Bảng 2.5 | Chỉ số độ tin cậy vận hành hệ thống bảo đảm an toàn hàng hải |
| T_DOCX_012 | Bảng 2.6 | Mức độ số hóa các thành phần quản lý tài sản hệ thống bảo đảm an toàn hàng hải |
| T_DOCX_013 | Bảng 2.7 | Phân loại danh mục dịch vụ bảo đảm an toàn hàng hải |
| T_DOCX_014 | Bảng 2.8 | Hệ thống văn bản thiết lập tiêu chuẩn chất lượng dịch vụ bảo đảm an toàn hàng hải |
| T_DOCX_015 | Bảng 2.9 | Hệ thống văn bản về cơ chế tài chính và điều kiện năng lực đơn vị cung ứng |
| T_DOCX_016 | Bảng 2.10 | Tổng hợp kết quả quản lý giữa dịch vụ thông tin và dịch vụ hạ tầng cứng (2020–2025) |
| T_DOCX_017 | Bảng 2.11 | Năng lực cung ứng dịch vụ hoa tiêu hàng hải (2019–2025) |
| T_DOCX_018 | Bảng 2.12 | Tổng hợp kết quả thanh tra, kiểm tra chuyên ngành đối với doanh nghiệp cung ứng dịch vụ hàng hải (2019–2023) |
| T_DOCX_019 | Bảng 2.13 | Độ tin cậy của các thang đo tổng hợp trong mô hình định lượng |
| T_DOCX_020 | Bảng 2.14 | Ma trận tương quan Pearson giữa các biến nghiên cứu và chỉ số VIF |
| T_DOCX_021 | Bảng 2.15 | Kết quả ước lượng mô hình hồi quy tuyến tính bội theo khung 2×3 |
| T_DOCX_022 | Bảng 2.16 | Tổng hợp khái quát hạn chế và nguyên nhân trong tổ chức, quản lý hệ thống và quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải |
| T_DOCX_023 | Bảng 3.1 | Các tiêu chí đánh giá kết quả và mục tiêu cụ thể đến năm 2030 |
| T_DOCX_024 | Bảng 3.2 | Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện cơ chế, chính sách về quản lý hệ thống bảo đảm an toàn hàng hải |
| T_DOCX_025 | Bảng 3.3 | Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện tổ chức thực hiện quản lý hệ thống bảo đảm an toàn hàng hải |
| T_DOCX_026 | Bảng 3.4 | Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện giám sát, đánh giá hệ thống bảo đảm an toàn hàng hải |
| T_DOCX_027 | Bảng 3.5 | Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện khung thể chế quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải |
| T_DOCX_028 | Bảng 3.6 | Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện tổ chức thực hiện quản lý cung ứng dịch vụ bảo đảm an toàn hàng hải |
| T_DOCX_029 | Bảng 3.7 | Kết quả kỳ vọng và hệ KPI đối với giải pháp hoàn thiện giám sát, đánh giá chất lượng dịch vụ bảo đảm an toàn hàng hải |
| T_DOCX_030 | Bảng 3.8 | Tổng hợp kiến nghị hoàn thiện quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam |

## Figures

| ID | Number | Title | Asset |
| :--- | :--- | :--- | :--- |
| F_DOCX_001 | Hình 2.1 | Sản lượng hàng hóa thông qua hệ thống cảng biển Việt Nam giai đoạn 2015–2025. | 05_figures/assets/F_DOCX_001.png |
| F_DOCX_002 | Hình 2.2 | Chỉ số kết nối vận tải biển (LSCI) của Việt Nam và một số quốc gia ASEAN (2024–2025) | 05_figures/assets/F_DOCX_002.png |
| F_DOCX_003 | Hình 2.3 | Sơ đồ tổ chức bộ máy quản lý nhà nước về bảo đảm an toàn hàng hải ở Việt Nam sau hợp nhất. | 05_figures/assets/F_DOCX_003.png |
| F_DOCX_004 | Hình 2.4 | Biểu đồ tăng trưởng hệ thống bảo đảm an toàn hàng hải Việt Nam, giai đoạn 2015–2025 | 05_figures/assets/F_DOCX_004.png |
| F_DOCX_005 | Hình 2.5 | Kinh phí bảo trì kết cấu hạ tầng hàng hải giai đoạn 2015–2026 | 05_figures/assets/F_DOCX_005.png |
| F_DOCX_006 | Hình 2.6 | Biểu đồ diễn biến tai nạn hàng hải giai đoạn 2015–2025. | 05_figures/assets/F_DOCX_006.png |
| F_DOCX_007 | Hình 2.7 | Xu hướng kinh phí nạo vét duy tu luồng hàng hải giai đoạn 2015–2025 | 05_figures/assets/F_DOCX_007.png |
| F_DOCX_008 | Hình 2.8 | Biểu đồ tỷ trọng và cơ cấu nguồn nhân lực dịch vụ hàng hải giai đoạn 2015–2024 | 05_figures/assets/F_DOCX_008.png |
| F_DOCX_009 | Hình 2.9 | Cơ cấu phân hạng hoa tiêu hàng hải Việt Nam hiện nay | 05_figures/assets/F_DOCX_009.png |
| F_DOCX_010 | Hình 2.10 | Mô hình hồi quy tuyến tính bội theo khung 2×3. | 05_figures/assets/F_DOCX_010.png |
| F_DOCX_011 | Hình 2.11 | Cơ cấu mẫu khảo sát phân bổ theo giới tính, độ tuổi, vai trò công tác và thâm niên làm việc (N=250 mẫu) | 05_figures/assets/F_DOCX_011.png |
