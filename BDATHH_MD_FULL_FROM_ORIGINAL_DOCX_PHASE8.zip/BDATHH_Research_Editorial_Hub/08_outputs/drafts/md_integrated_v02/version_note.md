# Version note

`md_integrated_v02` was generated directly from the original DOCX in this ChatGPT run. Tables are integrated as Markdown tables. Figures are linked to extracted draft assets and marked as not final until visual QA/rebuild.
